import { createWidget, widget, align, prop } from '@zos/ui'
import {
  mstStartScan, mstStopScan, mstConnect, mstDisconnect,
  mstBuildProfile, mstPrepare, mstOnPrepare, mstGetProfileInstance,
  mstOnCharaNotification, mstWriteDescriptor, mstOnCharaValueArrived,
  mstReadCharacteristic, mstOffAllCb, mstDestroyProfileInstance,
} from '@zos/ble'
import { setInterval, clearInterval } from '@zos/timer'
import { decodePacket, noteName, keyName, chordName } from '../lib/packet'

const SERVICE = 'b1a73010-cc72-4d56-8c5b-f3d06d204001'
const LIVE = 'b1a73011-cc72-4d56-8c5b-f3d06d204001'
const CCCD = '00002902-0000-1000-8000-00805f9b34fb'
const PROFILE = 'graue_live_direct'
const C = { bg:0x0c1727,card:0x1b3049,white:0xffffff,muted:0xb0c5db,mint:0x6ee4ad,blue:0x28547f,red:0xc85b6d,gold:0xf5cf69 }
function rect(x,y,w,h,color,radius=14) { return createWidget(widget.FILL_RECT,{x,y,w,h,color,radius}) }
function label(x,y,w,h,value,size,color) {
  return createWidget(widget.TEXT,{x,y,w,h,text:value,text_size:size,color,align_h:align.CENTER_H,align_v:align.CENTER_V})
}
function button(x,y,w,h,title,handler) {
  return createWidget(widget.BUTTON,{x,y,w,h,text:title,text_size:27,color:C.white,
    normal_color:C.blue,press_color:C.card,radius:16,click_func:handler})
}
Page({
  state:{ connection:-1,address:null,profile:null,started:false,lastUpdate:0,lastSeq:-1,interval:null,connecting:false },
  build(){
    rect(0,0,390,450,C.bg,0)
    label(20,10,350,40,'GRAUE   LIVE',29,C.white)
    this.state.status=label(16,53,358,28,'Desconectado · celular?',18,C.muted)
    rect(28,91,334,115,C.card)
    label(50,98,290,29,'NOTA DA VOZ',19,C.muted)
    this.state.note=label(38,124,314,73,'--',59,C.white)
    rect(28,216,334,83,C.card)
    label(40,220,310,25,'TONALIDADE PROVAVEL',17,C.muted)
    this.state.tonality=label(35,249,320,45,'Analisando...',26,C.mint)
    rect(28,312,334,64,C.card)
    this.state.degree=label(34,314,322,27,'Grau: --',20,C.gold)
    this.state.chord=label(34,343,322,28,'Acordes: --',20,C.white)
    this.state.connectButton=button(55,383,280,49,'CONECTAR',()=>this.toggleConnect())
    this.state.interval=setInterval(()=>this.refreshFreshness(),1000)
  },
  setStatus(value){if(this.state.status)this.state.status.setProperty(prop.TEXT,value)},
  toggleConnect(){
    if(this.state.connection>=0 || this.state.connecting){this.disconnect();return}
    this.findPhone()
  },
  findPhone(){
    if(this.state.started)return
    this.state.started=true
    this.setStatus('Procurando Grauê no celular...')
    this.state.connectButton.setProperty(prop.MORE,{text:'CANCELAR'})
    try{
      const ok=mstStartScan((result)=>{
        if(!result || !result.dev_addr || this.state.connecting || this.state.connection>=0)return
        const uuids=result.service_uuid_array || []
        if(uuids.length && !uuids.some(x=>String(x).toLowerCase()===SERVICE))return
        this.state.connecting=true
        this.state.address=result.dev_addr
        mstStopScan();this.state.started=false
        this.setStatus('Conectando BLE...')
        mstConnect(result.dev_addr,(event)=>{
          if(event.connected===0){
            this.state.connecting=false
            this.state.connection=event.connect_id
            this.setStatus('Configurando canal de notas...')
            this.prepareProfile()
          }else if(event.connected===2 || event.connected===1){
            this.state.connection=-1;this.state.connecting=false;this.setStatus('BLE desconectado / indisponivel')
            this.state.connectButton.setProperty(prop.MORE,{text:'CONECTAR'})
          }
        })
      },{service_uuid:SERVICE,duration:20,on_timeout:()=>{
        if(this.state.connection<0&&!this.state.connecting){this.state.started=false;this.setStatus('Celular nao encontrado');this.state.connectButton.setProperty(prop.MORE,{text:'TENTAR NOVAMENTE'})}
      }})
      if(!ok){this.state.started=false;this.setStatus('Busca BLE nao permitida')}
    }catch(e){this.state.started=false;this.setStatus('Erro ao buscar celular');console.log(String(e))}
  },
  prepareProfile(){
    const state=this.state
    try{
      mstOnPrepare((profile,status)=>{
        if(status!==0){this.setStatus('GATT nao preparado');return}
        state.profile=mstGetProfileInstance(PROFILE,state.connection)
        if(state.profile===undefined){this.setStatus('Perfil BLE indisponivel');return}
        mstOnCharaNotification((p,uuid,data,length)=>{
          if(String(uuid).toLowerCase()===LIVE && p===state.profile)this.consume(data)
        })
        mstOnCharaValueArrived((p,uuid,data,status2)=>{
          if(status2===0&&String(uuid).toLowerCase()===LIVE&&p===state.profile)this.consume(data)
        })
        mstWriteDescriptor(state.profile,LIVE,CCCD,new Uint8Array([1,0]).buffer,2)
        mstReadCharacteristic(state.profile,LIVE)
        this.setStatus('Conectado · aguardando voz')
        this.state.connectButton.setProperty(prop.MORE,{text:'DESCONECTAR'})
      })
      const built=mstBuildProfile({pair:false,id:state.connection,profile:PROFILE,dev:state.address,
        len:1,list:[{len:1,list:[{uuid:SERVICE,permission:0,len1:1,list:[{uuid:LIVE,permission:0,len:1,
          list:[{uuid:CCCD,permission:0}]}]}]}]})
      if(!built){this.setStatus('Falha ao construir perfil');return}
      const instance=mstGetProfileInstance(PROFILE,state.connection)
      if(instance===undefined){this.setStatus('Perfil nao disponivel');return}
      mstPrepare(instance)
    }catch(e){this.setStatus('Erro de negociacao BLE');console.log(String(e))}
  },
  consume(buf){
    const parsed=decodePacket(buf)
    if(!parsed)return
    if(parsed.sequence===this.state.lastSeq)return
    this.state.lastSeq=parsed.sequence
    this.state.lastUpdate=Date.now()
    this.state.note.setProperty(prop.TEXT,noteName(parsed.midi))
    this.state.tonality.setProperty(prop.TEXT,keyName(parsed.root,parsed.mode))
    this.state.degree.setProperty(prop.TEXT,'Nota: '+(parsed.degree?parsed.degree+'o grau':'--'))
    this.state.chord.setProperty(prop.TEXT,'Sug.: '+chordName(parsed.chord1,parsed.quality1)+' / '+chordName(parsed.chord2,parsed.quality2))
    this.setStatus('AO VIVO  ·  Bluetooth OK')
  },
  refreshFreshness(){
    if(this.state.lastUpdate && Date.now()-this.state.lastUpdate>4000){
      this.state.note.setProperty(prop.TEXT,'--')
      this.setStatus('Sem nota recente · confira celular')
    }
  },
  disconnect(){
    try{mstStopScan()}catch(e){}
    try{if(this.state.profile!==null)mstDestroyProfileInstance(this.state.profile)}catch(e){}
    try{if(this.state.connection>=0)mstDisconnect(this.state.connection)}catch(e){}
    try{mstOffAllCb()}catch(e){}
    this.state.connection=-1;this.state.profile=null;this.state.connecting=false;this.state.started=false
    this.state.lastUpdate=0;this.state.lastSeq=-1
    this.setStatus('Desconectado')
    if(this.state.connectButton)this.state.connectButton.setProperty(prop.MORE,{text:'CONECTAR'})
  },
  onDestroy(){if(this.state.interval!==null){clearInterval(this.state.interval);this.state.interval=null}this.disconnect()},
})
