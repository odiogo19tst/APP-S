App({
  globalData: {},
  onCreate() { console.log('GRAUE LIVE Bip6 iniciou') },
  onDestroy() { console.log('GRAUE LIVE Bip6 encerrou') },
})
