import { test } from 'node:test'
import assert from 'node:assert/strict'
import { decodePacket, noteName,keyName,chordName } from '../lib/packet.js'
function frame(fields) {
  const a=new Uint8Array([71,1,7,71,7,0,3,74,7,0,4,1,255,0,0,0]);
  Object.assign(a,fields)
  let sum=0;for(let i=0;i<15;i++)sum^=a[i];a[15]=sum
  return a
}
test('BLE frame accepts valid major G: B4',()=>{
  const p=decodePacket(frame({}));assert.equal(p.midi,71);assert.equal(p.root,7)
  assert.equal(noteName(p.midi),'B4');assert.equal(keyName(p.root,p.mode),'G Maior')
  assert.equal(chordName(p.chord1,p.quality1),'G');assert.equal(chordName(p.chord2,p.quality2),'Em')
})
test('rejects corrupted packet checksum',()=>{const p=frame({});p[3]^=1;assert.equal(decodePacket(p),null)})
test('rejects wrong packet version',()=>{assert.equal(decodePacket(frame({'1':3})),null)})
test('unknown pitch is rendered as neutral',()=>{assert.equal(noteName(-1),'--');assert.equal(keyName(-1,-1),'Aguardando...')})
