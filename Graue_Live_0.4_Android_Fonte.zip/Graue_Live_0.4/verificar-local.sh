#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
node --test watch/test/*.test.mjs
TMPDIR=$(mktemp -d)
trap 'rm -rf "$TMPDIR"' EXIT
javac -d "$TMPDIR" \
  android/app/src/main/java/br/com/doapps/grauelive/{PitchDetector,MusicBrain,GrauePacket}.java \
  android/app/src/test/java/br/com/doapps/grauelive/AudioLogicSelfTest.java
java -cp "$TMPDIR" br.com.doapps.grauelive.AudioLogicSelfTest
node --check watch/page/index.js
node --check watch/app.js
