package br.com.doapps.grauelive;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattDescriptor;
import android.bluetooth.BluetoothGattServer;
import android.bluetooth.BluetoothGattServerCallback;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.bluetooth.BluetoothProfile;
import android.bluetooth.le.AdvertiseCallback;
import android.bluetooth.le.AdvertiseData;
import android.bluetooth.le.AdvertiseSettings;
import android.bluetooth.le.BluetoothLeAdvertiser;
import android.content.Context;
import android.os.Build;
import android.os.ParcelUuid;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Android peripheral: open GATT service emitting binary harmonization frames. */
public final class BlePeripheral {
    public static final UUID SERVICE=UUID.fromString("b1a73010-cc72-4d56-8c5b-f3d06d204001");
    public static final UUID LIVE=UUID.fromString("b1a73011-cc72-4d56-8c5b-f3d06d204001");
    public static final UUID CCCD=UUID.fromString("00002902-0000-1000-8000-00805f9b34fb");
    public interface Log { void status(String s); }
    private final Context ctx; private final Log log;
    private final Set<BluetoothDevice> subscribed=new HashSet<>();
    private BluetoothManager manager;
    private BluetoothLeAdvertiser advertiser;
    private BluetoothGattServer gatt;
    private BluetoothGattCharacteristic characteristic;
    private AdvertiseCallback advCb;
    private boolean advertised=false;
    private byte[] latest=new byte[GrauePacket.SIZE];
    public BlePeripheral(Context context,Log listener){ctx=context;log=listener;}
    public synchronized boolean isStarted(){return gatt!=null;}
    @SuppressLint("MissingPermission")
    public synchronized void start(){
        stop();
        manager=(BluetoothManager)ctx.getSystemService(Context.BLUETOOTH_SERVICE);
        BluetoothAdapter adapter=manager!=null?manager.getAdapter():null;
        if(adapter==null||!adapter.isEnabled()){log.status("Ligue o Bluetooth");return;}
        if(!adapter.isMultipleAdvertisementSupported()){log.status("Este aparelho não anuncia BLE");return;}
        advertiser=adapter.getBluetoothLeAdvertiser();
        if(advertiser==null){log.status("BLE Peripheral indisponível");return;}
        try{
            gatt=manager.openGattServer(ctx,gattCb);
            if(gatt==null){log.status("Falha ao abrir servidor BLE");return;}
            BluetoothGattService svc=new BluetoothGattService(SERVICE,BluetoothGattService.SERVICE_TYPE_PRIMARY);
            characteristic=new BluetoothGattCharacteristic(LIVE,
                    BluetoothGattCharacteristic.PROPERTY_NOTIFY | BluetoothGattCharacteristic.PROPERTY_READ,
                    BluetoothGattCharacteristic.PERMISSION_READ);
            characteristic.addDescriptor(new BluetoothGattDescriptor(CCCD,BluetoothGattDescriptor.PERMISSION_READ|BluetoothGattDescriptor.PERMISSION_WRITE));
            svc.addCharacteristic(characteristic);
            if(!gatt.addService(svc)){log.status("Falha ao registrar serviço BLE");stop();}
            else log.status("Registrando serviço Bluetooth...");
        }catch(Exception e){log.status("Falha BLE: "+e.getMessage());stop();}
    }
    @SuppressLint("MissingPermission")
    private void beginAdvertising(){
        if(advertiser==null || advertised)return;
        AdvertiseSettings options=new AdvertiseSettings.Builder().setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_LOW_LATENCY)
                .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM).setConnectable(true).setTimeout(0).build();
        AdvertiseData data=new AdvertiseData.Builder().addServiceUuid(new ParcelUuid(SERVICE)).setIncludeDeviceName(false).build();
        advCb=new AdvertiseCallback(){
            @Override public void onStartSuccess(AdvertiseSettings settings){advertised=true;log.status("BLE anunciando — conecte pelo Bip 6");}
            @Override public void onStartFailure(int code){advertised=false;log.status("Anúncio BLE falhou: código "+code);}
        };
        try{advertiser.startAdvertising(options,data,advCb);}catch(Exception e){log.status("Anúncio recusado: "+e.getMessage());}
    }
    private final BluetoothGattServerCallback gattCb=new BluetoothGattServerCallback(){
        @Override public void onServiceAdded(int status,BluetoothGattService service){
            if(status==BluetoothGatt.GATT_SUCCESS) beginAdvertising();else log.status("Serviço GATT recusado: "+status);
        }
        @Override public void onConnectionStateChange(BluetoothDevice device,int status,int newState){
            if(newState==BluetoothProfile.STATE_CONNECTED)log.status("Bip/dispositivo conectado: "+safeName(device));
            else {synchronized(BlePeripheral.this){subscribed.remove(device);}log.status("Dispositivo desconectado");}
        }
        @Override public void onCharacteristicReadRequest(BluetoothDevice d,int id,int offset,BluetoothGattCharacteristic c){
            if(gatt==null)return;
            if(!LIVE.equals(c.getUuid())){respond(d,id,BluetoothGatt.GATT_REQUEST_NOT_SUPPORTED,offset,null);return;}
            byte[] value; synchronized(BlePeripheral.this){value=latest.clone();}
            if(offset>value.length){respond(d,id,BluetoothGatt.GATT_INVALID_OFFSET,offset,null);return;}
            respond(d,id,BluetoothGatt.GATT_SUCCESS,offset,Arrays.copyOfRange(value,offset,value.length));
        }
        @Override public void onDescriptorReadRequest(BluetoothDevice d,int id,int offset,BluetoothGattDescriptor desc){
            byte[] v;
            synchronized(BlePeripheral.this){v=subscribed.contains(d)?BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE:BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE;}
            respond(d,id,BluetoothGatt.GATT_SUCCESS,offset,v);
        }
        @Override public void onDescriptorWriteRequest(BluetoothDevice d,int id,BluetoothGattDescriptor desc,
                     boolean prepared,boolean responseNeeded,int offset,byte[] value){
            int result=BluetoothGatt.GATT_SUCCESS;
            if(!CCCD.equals(desc.getUuid())||offset!=0||prepared)result=BluetoothGatt.GATT_REQUEST_NOT_SUPPORTED;
            else if(Arrays.equals(value,BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)){
                synchronized(BlePeripheral.this){subscribed.add(d);} log.status("Relógio inscrito nas notas ao vivo");
            }else if(Arrays.equals(value,BluetoothGattDescriptor.DISABLE_NOTIFICATION_VALUE)){
                synchronized(BlePeripheral.this){subscribed.remove(d);}
            }else result=BluetoothGatt.GATT_FAILURE;
            if(responseNeeded)respond(d,id,result,0,null);
        }
    };
    private String safeName(BluetoothDevice d){try{return d.getAddress();}catch(Exception e){return "BLE";}}
    @SuppressLint("MissingPermission")
    private void respond(BluetoothDevice d,int id,int status,int offset,byte[] data){
        try{if(gatt!=null)gatt.sendResponse(d,id,status,offset,data);}catch(Exception ignored){}
    }
    @SuppressLint("MissingPermission")
    public synchronized void publish(byte[] packet){
        if(!GrauePacket.verify(packet))return;
        latest=packet.clone();
        if(gatt==null || characteristic==null)return;
        for(BluetoothDevice d:new HashSet<>(subscribed)){
            try{
                if(Build.VERSION.SDK_INT>=33)gatt.notifyCharacteristicChanged(d,characteristic,false,packet);
                else{ characteristic.setValue(packet);gatt.notifyCharacteristicChanged(d,characteristic,false);}
            }catch(Exception e){log.status("Falha na notificação: "+e.getMessage());}
        }
    }
    @SuppressLint("MissingPermission")
    public synchronized void stop(){
        if(advertiser!=null&&advCb!=null){try{advertiser.stopAdvertising(advCb);}catch(Exception ignored){}}
        advCb=null;advertised=false;
        if(gatt!=null){try{gatt.close();}catch(Exception ignored){}}
        gatt=null;characteristic=null;subscribed.clear();advertiser=null;
    }
}
