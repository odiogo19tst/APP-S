# Grauê Live v0.4-dev — atualização experimental Android

## Objetivo
Corrigir a confusão entre tons maiores e menores e acrescentar reconhecimento espectral experimental de acordes simples, sem inventar acordes que não foram escutados.

## O que mudou
- Detector YIN (nota predominante), **não isola a voz** em gravações com instrumentos.
- `ChromaAnalyzer` (FFT): hipóteses conservadoras de tríades maiores e menores tocadas simultaneamente; **não é rede neural**, separação de fontes ou transcrição polifônica completa.
- `MusicBrain`: associa evidências melódicas com sequências de tríades e pausas finais de frase, usando finais recorrentes como evidência fraca de tônica; evita afirmar um maior/menor relativo quando houver somente notas ambíguas.
- Modo `automático` / `priorizar MAIOR` / `priorizar MENOR`, botão para confirmar o tom provisório e `Nova música` para limpar contexto anterior.
- Botões com altura dimensionada em dp para melhor visualização no celular.
- Conexão BLE com relógio desativada nesta versão devido ao relato de reinicialização completa do Bip 6. O app do relógio pode continuar instalado, mas não será alimentado nesta versão.

## Limitações importantes
- Uso experimental. Sem testes em canto ou instrumentos físicos, nem validação em aparelho Android.
- Sem inteligência artificial neural embarcada. Não distingue com segurança canto e instrumentos sobrepostos.
- A separação robusta da voz requer adicionar e testar um modelo neural de separação de fontes; a análise de acordes em gravação mista também necessita de validação e calibração.
- Tom estimado depende de contexto suficiente; às vezes 'indefinido' é a saída correta.
- Não existem gravação ou envio de áudio a servidores.

## Verificações locais
`javac` + testes Java:
- `AudioLogicSelfTest` — 13 verificações.
- `Harmony04SelfTest` — 11 verificações, incluindo tonalidades maiores/menores, acordes sintéticos e frases vocais sem acompanhamento.

## Compilação
Executar o workflow `graue-live-04-android.yml` no GitHub Actions após subir ZIP do projeto na raiz e YAML em `.github/workflows/`. O workflow gera apenas o APK Android de depuração. Instalação em relógio NÃO incluída nesta atualização.

## Validação sugerida
1. Cante Dó isolado e teste mudança para Mi ou Sol: campo 'nota predominante' deve acompanhar.
2. Toque tríades simples no teclado (C, F, G; Am, Dm, E): confirmar se 'acorde detectado' acompanha sem falsos positivos.
3. Observe se a análise evita cravar Lá menor ao cantar uma frase em Dó maior sem acompanhamento.
4. Evite conectar o Bip 6 enquanto investigamos a reinicialização.
