# DinoPocket 1.6.2 — Dino calmo no Bip 6

Mudanças: a tela principal exibe quadro estático da pose correspondente ao estado (alegre, triste, sujo, com fome, doente). Ao tocar/carinho, anima o Dino por 2,5 s e retorna ao quadro parado. Ações (alimentar, banho, jogos, estudos) reproduzem animação por 2,5 s e depois congelam, mantendo resultado e OK. Dormir continua escuro e estático.

O mesmo appId 29318764, a chave de dados dinopocket.state.v1 e o schema 1 são preservados. NÃO desinstale nem limpe dados antes de atualizar.

É fonte para compilar no Codespaces com Zeus, não é o .zab pronto. Testes automatizados não garantem instalação física.
