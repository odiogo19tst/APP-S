import test from 'node:test'
import assert from 'node:assert/strict'
import vm from 'node:vm'
import {readFileSync} from 'node:fs'
import * as game from '../src/game.js'
import * as settings from '../src/phone_settings.js'
import * as sound from '../src/sound_rules.js'
import * as visual from '../src/visual_rules.js'
import * as touch from '../src/touch_rules.js'
import * as expansion from '../src/expansion.js'
import {advanceForTest} from '../src/advance_for_test.js'
const NOW=Date.UTC(2026,9,14,12)
function build(variant={}){
 const saved={...game.enhance(game.newGame(NOW)),stage:2,bornAt:NOW-2*game.DAY,...variant}
 const values=new Map([[settings.PET_SAVE_KEY,saved]])
 let current=[],page,seq=0
 const timers=new Map()
 class Storage{getItem(k,d){return values.has(k)?values.get(k):d}setItem(k,v){values.set(k,v)}}
 const E=new Proxy({},{get:(_,k)=>k})
 const code=readFileSync(new URL('../page/index.js',import.meta.url),'utf8').replace(/^import\s[\s\S]*?from\s+['"][^'"]+['"]\s*\r?\n/gm,'')
 const clock=class Clock extends Date{constructor(...a){super(...(a.length?a:[NOW]))}static now(){return NOW}}
 vm.runInNewContext(code,{...game,...settings,...sound,...visual,...touch,...expansion,advanceForTest,
   Date:clock,LocalStorage:Storage,Page:p=>page=p,
   createWidget:(type,p)=>{const w={type,p,setProperty(){},addEventListener(){},createWidget(){return{setProperty(){},addEventListener(){}}}};current.push(w);return w},
   deleteWidget:w=>{current=current.filter(x=>x!==w)},widget:E,align:E,text_style:E,prop:E,anim_status:E,event:E,
   createConnect(){},disConnect(){},sendBluetooth(){},Accelerometer:class{setFreqMode(){}onChange(){}start(){}stop(){}offChange(){}},
   Vibrator:class{start(){}},FREQ_MODE_NORMAL:0,VIBRATOR_SCENE_SHORT_LIGHT:0,VIBRATOR_SCENE_NOTIFICATION:0,
   createMedia(){throw Error('no audio')},mediaId:E,
   setTimeout:(fn,ms)=>{const id=++seq;timers.set(id,{fn,ms});return id},
   clearTimeout:id=>timers.delete(id),setInterval:()=>1000,clearInterval(){},console})
 page.onInit();page.build()
 return {get widgets(){return current},values,timers,page,
   click(label){const b=current.find(w=>w.type==='BUTTON'&&w.p.text===label);assert.ok(b,'button '+label);b.p.click_func()},
   runTimer(ms){const entry=[...timers].find(([id,v])=>v.ms===ms);assert.ok(entry,'timer '+ms);timers.delete(entry[0]);entry[1].fn()}}
}
function animated(ui){return ui.widgets.filter(w=>w.type==='IMG_ANIM')}
function still(ui){return ui.widgets.filter(w=>w.type==='IMG'&&w.p.src?.startsWith('anim/'))}
test('resting, happy, dirty and sick dinosaurs never loop animation on home',()=>{
 for(const state of [{},{joy:98},{poop:3},{sick:true},{hunger:12},{dead:true}]){
  const ui=build(state);assert.equal(animated(ui).length,0,JSON.stringify(state));assert.equal(still(ui).length,1)
  assert.ok(still(ui)[0].p.src.endsWith('frame_0.png'))
  ui.page.onDestroy()
 }
})
test('feeding animates briefly, freezes with OK, then rests on home',()=>{
 const ui=build(); ui.click('MENU');ui.click('ALIMENTACAO');ui.click('COMIDAS');ui.click('CARNE')
 assert.equal(animated(ui).length,1);assert.ok(ui.widgets.some(w=>w.p.text==='OK'))
 ui.runTimer(2500)
 assert.equal(animated(ui).length,0);assert.equal(still(ui).length,1)
 assert.ok(ui.widgets.some(w=>w.p.text==='OK'))
 ui.click('OK');assert.equal(animated(ui).length,0);assert.equal(still(ui).length,1)
 assert.equal(ui.values.get(settings.PET_SAVE_KEY).schema,1)
 ui.page.onDestroy()
})
test('leaving reaction cancels event timer without reanimating',()=>{
 const ui=build();ui.click('MENU');ui.click('HIGIENE');ui.click('DAR BANHO')
 assert.equal(animated(ui).length,1);ui.click('OK')
 assert.equal(animated(ui).length,0)
 assert.equal([...ui.timers.values()].some(t=>t.ms===2500),false)
 ui.page.onDestroy()
})
test('sleep remains night still and waking returns to static home',()=>{
 const ui=build();ui.click('MENU');ui.click('DESCANSO');ui.click('DORMIR')
 assert.equal(animated(ui).length,0); assert.ok(ui.widgets.some(w=>w.p.src==='scenes/night.png'))
 ui.click('ACORDAR');assert.equal(animated(ui).length,0);assert.equal(still(ui).length,1)
 ui.page.onDestroy()
})
