from PIL import Image,ImageDraw
from pathlib import Path
import math,random
random.seed(42)
ROOT=Path(__file__).resolve().parents[1]/'assets'/'390x450-bip6'
DIR=ROOT/'scenes';DIR.mkdir(exist_ok=True)
ICONS=ROOT/'icons';ICONS.mkdir(exist_ok=True)
# Originais simples em pixel art desenhados programaticamente (sem imagens externas)
pal={
 'food':('#f7d8af','#9a633b'), 'games':('#c4ddf5','#417eaa'),
 'hygiene':('#c4edeb','#3d9eae'),'study':('#f5e5b1','#977738'),
 'sleep':('#aeb8df','#485caa'),'health':('#f2b5bd','#b94b6b'),
 'status':('#bfe7bb','#367951'),'tools':('#d5cdec','#675a95'),
 'dessert':('#f5b5d7','#a84f82'),'drink':('#a6def6','#3973ae'),
 'fooditem':('#ffe4ad','#c97c3a'),'test':('#f2d5b2','#9d6a54')
}
for name,(bg,fg) in pal.items():
 im=Image.new('RGBA',(44,44),(0,0,0,0));d=ImageDraw.Draw(im)
 d.rounded_rectangle((2,2,41,41),radius=10,fill=bg)
 if name in ('food','fooditem'):
  d.ellipse((12,19,32,33),fill='#fa8a54',outline=fg,width=2)
  d.polygon([(21,19),(24,12),(29,10),(27,16)],fill='#6fa75a')
 elif name=='dessert':
  d.polygon([(13,21),(33,21),(29,35),(17,35)],fill='#ffefd6',outline=fg)
  d.ellipse((12,14,32,24),fill='#fff2f7',outline=fg)
  d.ellipse((21,11,25,16),fill='#c2496c')
 elif name=='drink':
  d.polygon([(13,13),(31,13),(27,35),(17,35)],fill='#fffefd',outline=fg)
  d.polygon([(16,20),(28,20),(26,32),(18,32)],fill='#72c2dd')
  d.line((27,9,27,19),fill='#3683a4',width=3)
 elif name=='games':
  d.rounded_rectangle((9,17,36,30),radius=6,fill='#ffffff',outline=fg,width=2)
  d.line((14,22,24,22),fill=fg,width=3);d.line((19,18,19,27),fill=fg,width=3)
  for x,y in [(29,20),(32,25)]:d.ellipse((x,y,x+3,y+3),fill='#f38b77')
 elif name=='hygiene':
  d.rectangle((17,18,28,34),fill='#ffffff',outline=fg,width=2)
  for x,y,r in [(12,11,4),(27,9,5),(32,15,3)]:d.ellipse((x-r,y-r,x+r,y+r),outline=fg,width=2)
 elif name=='study':
  d.polygon([(10,14),(22,17),(22,35),(10,31)],fill='#fff',outline=fg)
  d.polygon([(22,17),(34,14),(34,31),(22,35)],fill='#fffdf5',outline=fg)
  d.line((22,17,22,35),fill=fg,width=2)
 elif name=='sleep':
  d.ellipse((11,8,35,33),fill='#fce7a5')
  d.ellipse((20,3,39,30),fill=bg)
  d.polygon([(11,34),(13,30),(15,34),(19,36),(15,38)],fill='#faf8ff')
 elif name=='health':
  d.ellipse((10,9,25,25),fill='#e85f73');d.ellipse((19,9,34,25),fill='#e85f73');d.polygon([(10,21),(34,21),(22,35)],fill='#e85f73')
 elif name=='status':
  d.rounded_rectangle((11,11,34,34),radius=5,fill='#fff',outline=fg,width=2)
  d.line((15,25,19,25,22,18,25,29,29,24,32,24),fill=fg,width=2)
 elif name=='tools':
  d.ellipse((10,11,31,32),outline=fg,width=4);d.rectangle((18,5,23,12),fill=fg)
  d.rectangle((17,31,24,39),fill=fg)
 elif name=='test':
  d.rounded_rectangle((13,9,32,35),radius=2,fill='#fff',outline=fg,width=2)
  for yy in (16,23,30):d.line((17,yy,29,yy),fill=fg,width=2)
 im.save(ICONS/f'{name}.png')

# Cenas LCD 306x288: desenhadas 153x144, ampliadas em nearest neighbour.
scenes={
 'egg':('#e1f7e7','#98cfb3','#4f9e7d','#327c6b'),
 'baby':('#e6f7df','#90d5c9','#6dbb7d','#397454'),
 'small':('#caeddf','#8ad0a0','#4d9a6c','#2d7155'),
 'young':('#d9eafa','#a1c7d7','#6d9e87','#426c79'),
 'rex':('#f9e9ce','#e0bd98','#86b580','#598d6c'),
 'bronto':('#cce9fb','#99cfc9','#6caf9c','#458772'),
 'trike':('#e0e5f9','#b6c1e5','#8ca2b3','#5e798a'),
 'sick':('#d4e6e0','#a6c8c3','#8eaaa4','#697e82'),
 'dirty':('#d4dbbd','#c7b68b','#aa9c73','#857556'),
 'ghost':('#bccad4','#8ea1b2','#60758e','#475970')}
for name,(sky,far,ground,hill) in scenes.items():
 im=Image.new('RGB',(153,144),sky);d=ImageDraw.Draw(im)
 d.rectangle((0,88,153,144),fill=ground)
 if name in ('egg','baby','small','rex','bronto'):
  d.ellipse((118,10,141,33),fill='#f8f7d0')
 else:
  d.ellipse((116,9,137,30),fill='#e4e4f6')
 d.polygon([(0,93),(40,53),(75,90),(113,62),(153,101)],fill=far)
 d.polygon([(0,105),(50,78),(86,107),(137,80),(153,105)],fill=hill)
 d.rectangle((0,110,153,144),fill=ground)
 if name=='egg':
  for x in (12,50,107):
   d.rectangle((x,100,x+6,118),fill='#7c9680');d.ellipse((x-8,87,x+16,106),fill='#93ba97')
 elif name in ('small','young','rex','trike','bronto'):
  for x in (8,30,130):
   d.rectangle((x,90,x+7,119),fill='#6e7161');d.polygon([(x-9,98),(x+4,66),(x+18,98)],fill='#548e74')
 elif name=='baby':
  d.rectangle((0,108,153,144),fill='#cbbaa5');d.polygon([(10,100),(38,72),(69,100)],fill='#fff2d2')
 elif name=='dirty':
  for cx in (20,54,101,128):d.ellipse((cx,117,cx+21,124),fill='#6e6854')
 elif name=='sick':
  d.rectangle((11,102,35,120),fill='#eef4e9');d.rectangle((20,96,26,125),fill='#bc777b')
 elif name=='ghost':
  for _ in range(30):
   x=random.randrange(0,153);y=random.randrange(0,85);d.point((x,y),fill='#e8f2f6')
 for x,y in [(13,126),(41,136),(90,129),(143,141)]:
  if name not in ('dirty','ghost'):d.line((x,y,x+3,y-5),fill='#e9efb9',width=2)
 im.resize((306,288),Image.Resampling.NEAREST).save(DIR/(name+'.png'),optimize=True)

im=Image.new('RGB',(153,144),'#05070e');d=ImageDraw.Draw(im)
d.rectangle((0,104,153,144),fill='#080c18')
d.ellipse((124,14,140,30),fill='#53637e');d.ellipse((130,9,146,26),fill='#05070e')
for _ in range(30):
 x=random.randrange(3,150);y=random.randrange(4,102)
 d.rectangle((x,y,x+1,y+1),fill=random.choice(['#27364d','#34425a','#415477']))
d.polygon([(0,105),(33,91),(70,109),(115,88),(153,106)],fill='#0d1725')
d.rectangle((0,110,153,144),fill='#0b111f')
im.resize((306,288),Image.Resampling.NEAREST).save(DIR/'night.png',optimize=True)
# Sprites dormindo escurecidos, somente para a cena noturna. Nenhuma animação acesa.
for stem in ['egg','baby','small','young','rex','bronto','trike','sick','ghost']:
 src=ROOT/'anim'/stem/'sleep'/'frame_0.png'
 if not src.exists():src=ROOT/'anim'/stem/'idle'/'frame_0.png'
 if not src.exists():continue
 base=Image.open(src).convert('RGBA')
 data=[]
 for r,g,b,a in base.getdata():data.append((int(r*.20),int(g*.25),int(b*.33),int(a*.72)))
 base.putdata(data);base.save(DIR/('sleep_'+stem+'.png'),optimize=True)
print('Scenes', len(list(DIR.glob('*.png'))),'icons',len(list(ICONS.glob('*.png'))))
