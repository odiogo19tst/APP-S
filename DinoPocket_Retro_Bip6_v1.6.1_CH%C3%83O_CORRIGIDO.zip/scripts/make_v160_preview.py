from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
r=Path(__file__).resolve().parents[1]
a=r/'assets/390x450-bip6'
fontpath='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
try:
 f=lambda size:ImageFont.truetype(fontpath,size)
except:
 f=lambda size:ImageFont.load_default()
images=[]
for panel in ('MENU','DORMINDO'):
 im=Image.new('RGB',(390,450),'#142831' if panel=='MENU' else '#03050b');d=ImageDraw.Draw(im)
 if panel=='MENU':
  d.rounded_rectangle((12,12,378,438),22,fill='#376b70')
  d.rounded_rectangle((23,23,367,388),14,fill='#f4f4dc')
  d.rounded_rectangle((29,29,361,66),7,fill='#fcf9e9')
  d.text((99,34),'CENTRAL DO DINO',font=f(19),fill='#243f42')
  d.text((81,72),'Escolha uma categoria',font=f(17),fill='#243f42')
  labels=[('ALIMENTACAO','food'),('JOGOS','games'),('HIGIENE','hygiene'),('ESTUDOS','study'),('DESCANSO','sleep'),('SAUDE','health'),('STATUS','status'),('FERRAMENTAS','tools')]
  for i,(title,icon) in enumerate(labels):
   x=37 if i%2==0 else 198;y=102+(i//2)*61
   d.rounded_rectangle((x,y,x+155,y+53),10,fill='#e4ebe0')
   ico=Image.open(a/'icons'/f'{icon}.png').convert('RGBA');im.paste(ico,(x+5,y+5),ico)
   d.rounded_rectangle((x+49,y+6,x+149,y+46),10,fill='#357f81')
   fs=10 if title in ('ALIMENTACAO','FERRAMENTAS') else 12
   bb=d.textbbox((0,0),title,font=f(fs));d.text((x+99-(bb[2]-bb[0])/2,y+17),title,font=f(fs),fill='#fff',anchor='lt')
  d.rounded_rectangle((114,337,276,381),10,fill='#357f81')
  d.text((195,345),'DINO',font=f(16),fill='#fff',anchor='mt')
  d.rounded_rectangle((29,395,361,426),8,fill='#142831')
  d.text((61,403),'DINOPOCKET  //  90s EDITION',font=f(12),fill='#f4f4dc')
 else:
  d.rounded_rectangle((12,12,378,438),24,fill='#0c1320')
  d.rounded_rectangle((23,24,367,426),15,fill='#070d18')
  d.text((67,34),'DINOPOCKET // BOA NOITE',font=f(17),fill='#8795b2')
  im.paste(Image.open(a/'scenes/night.png'),(42,80))
  im.paste(Image.open(a/'scenes/sleep_rex.png'),(89,146),Image.open(a/'scenes/sleep_rex.png'))
  d.text((80,310),'Z z z... DESCANSANDO',font=f(18),fill='#92a1bd')
  d.text((94,355),'DORMINDO ATE ACORDAR',font=f(13),fill='#667792')
  d.rounded_rectangle((96,387,294,419),10,fill='#1b2a3e')
  d.text((195,395),'ACORDAR',font=f(15),fill='#a6bacb',anchor='mt')
 images.append(im)
out=Image.new('RGB',(790,485),'#ffffff')
for i,im in enumerate(images):out.paste(im,(5+i*395,10))
out.save('/mnt/data/DinoPocket_Bip6_v1.6.0_PREVIA.png',optimize=True)
