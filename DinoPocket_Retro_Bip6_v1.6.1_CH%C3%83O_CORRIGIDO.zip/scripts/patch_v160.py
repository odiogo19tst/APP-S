from pathlib import Path
import json
root=Path(__file__).resolve().parents[1]
p=root/'page/index.js'
s=p.read_text()
def sub(old,new):
 global s
 n=s.count(old)
 assert n==1,(n,old[:80])
 s=s.replace(old,new)
sub("import { advanceForTest } from '../src/advance_for_test'", "import { advanceForTest } from '../src/advance_for_test'\nimport { cleanCare, giveDessert, playGuess, playParity, questionFor, answerStudy, sceneFor } from '../src/expansion'")
sub("let voiceIndex = 0", "let voiceIndex = 0\nlet activeQuiz = null\nlet parityChoice = 'par'")
sub("function spriteAnim(name,pose='idle',x=51,y=131) {", """function picture(src,x,y) { controls.push(createWidget(widget.IMG,{x,y,src})) }
function menuRow(label,icon,y,action,size=16) {
  picture('icons/'+icon+'.png',47,y+1)
  tap(label,99,y,244,43,action,false,size)
}
function categoryPage(header,rows,target='menu') {
  backdrop(header)
  rows.forEach((a,i)=>menuRow(a[0],a[1],91+i*47,a[2],a[3]||16))
  bottom(target==='menu'?'MENU':'VOLTAR',target)
}
function spriteAnim(name,pose='idle',x=51,y=131) {""")
start=s.index('function home() {')
end=s.index('\nfunction go(name)',start)
s=s[:start]+'''function sleepHome() {
  // Tela LCD noturna: sem painel claro, sem animações brilhantes.
  rect(0,0,390,450,0x03050b)
  rect(12,12,366,426,0x0c1320,24)
  rect(23,24,344,402,0x070d18,15)
  txt('DINOPOCKET  //  BOA NOITE',33,32,323,34,15,0x8795b2)
  picture('scenes/night.png',42,80)
  picture('scenes/sleep_'+characterStem(pet)+'.png',89,146)
  txt('Z z z...  DESCANSANDO',50,310,290,35,18,0x92a1bd)
  txt('DORMINDO ATE ACORDAR',51,352,288,25,13,0x667792)
  controls.push(createWidget(widget.BUTTON,{x:96,y:387,w:198,h:32,text:'ACORDAR',text_size:15,
    color:0xa6bacb,radius:10,normal_color:0x1b2a3e,press_color:0x314764,
    click_func:()=>perform('acordar')}))
  tap('MENU',308,36,54,30,()=>go('menu'),false,11)
}
function home() {
  if(pet.awake===false && !pet.dead && pet.stage>0){sleepHome();return}
  // Cenários reagem a ovo, crescimento, espécie adulta, doença e sujeira.
  rect(0,0,390,450,COLOR.bg)
  rect(12,12,366,426,COLOR.shell,24)
  rect(23,24,344,402,COLOR.lcd,15)
  rect(32,31,326,34,COLOR.light,6)
  txt('DINOPOCKET',41,33,175,29,17,COLOR.ink,align.LEFT)
  txt(petAgeString(pet),207,33,97,29,14,COLOR.ink)
  rect(37,75,316,299,COLOR.shade,11)
  picture('scenes/'+sceneFor(pet)+'.png',42,80)
  spriteAnim(characterStem(pet),speechLine && pet.awake!==false && pet.stage>0 ? 'touch' : restingPose(pet),51,133)
  const currentMessage=speechLine || (isPaused(pet)?'PAUSADO':describe(pet))
  rect(48,306,295,42,0xddeadd,7)
  txt(currentMessage,51,306,288,42,17,COLOR.ink)
  if(pet.stage>0 && pet.poop>0) txt('COCO: '+pet.poop+' | MENU > HIGIENE',56,350,277,22,12,COLOR.alert)
  if(pet.dead) {
    tap('NOVO OVO',107,379,177,37,()=>{
      pet=enhance(revive(pet,Date.now()));save();speechLine='';render()
    },false,15)
  } else {
    txt('TOQUE: CARINHO   |   SEGURE: MENU',47,388,296,25,12,COLOR.ink)
  }
  const attention=dinoConfig.alerts ? needsAttention(pet):null
  if(attention) txt('! '+attention+' !',92,353,206,19,15,COLOR.alert)
  touchArea()
  tap('MENU',307,32,53,31,()=>{speechLine='';go('menu')},false,11)
}
''' + s[end:]
start=s.index('function menu() {')
end=s.index('\nfunction testsScreen()',start)
s=s[:start]+'''function menu() {
  backdrop('CENTRAL DO DINO')
  txt('Escolha uma categoria',43,70,305,25,17)
  const actions=[
    ['ALIMENTACAO','food','alimento'],['JOGOS','games','gamesMenu'],
    ['HIGIENE','hygiene','hygieneMenu'],['ESTUDOS','study','studiesMenu'],
    ['DESCANSO','sleep','restMenu'],['SAUDE','health','healthMenu'],
    ['STATUS','status','status'],['FERRAMENTAS','tools','more']
  ]
  actions.forEach((a,i)=>{
    const x=i%2===0?37:198,y=102+Math.floor(i/2)*61
    rect(x,y,155,53,0xe4ebe0,10)
    picture('icons/'+a[1]+'.png',x+5,y+5)
    tap(a[0],x+49,y+6,100,40,()=>go(a[2]),false,a[0]==='ALIMENTACAO'||a[0]==='FERRAMENTAS'?10:12)
  })
  bottom('DINO','home')
}
function alimento(){categoryPage('ALIMENTACAO',[
  ['BEBIDAS','drink',()=>go('drinks')],
  ['COMIDAS','fooditem',()=>go('food')],
  ['SOBREMESAS','dessert',()=>go('dessert')]
])}
function gamesMenu(){categoryPage('JOGOS',[
  ['PEDRA PAPEL TESOURA','games',()=>go('game'),12],
  ['ZERO OU UM','games',()=>go('binary')],
  ['PAR OU IMPAR','games',()=>go('parity')],
  ['BRINCAR COM DINO','games',()=>perform('brincar'),14]
])}
function hygieneMenu(){categoryPage('HIGIENE',[
  ['LIMPAR COCO','hygiene',()=>perform('limpar_coco')],
  ['DAR BANHO','hygiene',()=>perform('banho')],
  ['ESCOVAR DENTES','hygiene',()=>perform('escovar')],
  ['LAVAR AS MAOS','hygiene',()=>perform('lavar_maos')]
])}
function studiesMenu(){categoryPage('ESTUDOS',[
  ['MATEMATICA','study',()=>startQuiz('matematica')],
  ['INGLES','study',()=>startQuiz('ingles')],
  ['PORTUGUES','study',()=>startQuiz('portugues')],
  ['BOAS MANEIRAS','study',()=>perform('educar')],
  ['ESTUDO LIVRE','study',()=>perform('estudar')]
])}
function restMenu(){categoryPage('DESCANSO',[
  [pet.awake===false?'ACORDAR':'DORMIR','sleep',()=>perform(pet.awake===false?'acordar':'dormir')],
  ['AJUSTAR PAUSA','tools',()=>go('pause')]
])}
function healthMenu(){categoryPage('SAUDE',[
  ['DAR REMEDIO','health',()=>perform('remedio')],
  ['VER STATUS','status',()=>go('status')]
])}
function moreScreen(){categoryPage('FERRAMENTAS',[
  ['SONS E ALERTAS','tools',()=>go('alerts')],
  ['TEMPERATURA','tools',()=>go('temp')],
  ['PAUSA','tools',()=>go('pause')],
  ['RELOGIO','tools',()=>go('clock')],
  ['TESTES','test',()=>go('tests')]
])}
''' + s[end:]
idx=s.index('function statusBar(')
s=s[:idx]+'''function dessert(){categoryPage('SOBREMESAS',[
  ['SALADA DE FRUTAS','dessert',()=>perform('doce_fruta'),14],
  ['PUDIM','dessert',()=>perform('doce_pudim')],
  ['SORVETE','dessert',()=>perform('doce_sorvete')]
],'alimento')}
function ensureReady(){
  if(pet.stage===0 || pet.dead || isPaused(pet) || pet.awake===false){
    result='Acorde o Dino ou aguarde chocar!';lastAction='AVISO';reactionAction='';go('reaction');return false
  }
  return true
}
function binaryScreen(){
  backdrop('ZERO OU UM')
  txt('ADIVINHE A ESCOLHA DO DINO',43,84,304,35,17)
  txt('O Dino vai mostrar 0 ou 1.',43,132,304,29,16)
  tap('0',46,198,142,76,()=>doBinary(0),false,32)
  tap('1',202,198,142,76,()=>doBinary(1),false,32)
  bottom('JOGOS','gamesMenu')
}
function doBinary(choice){
  if(!ensureReady())return
  const played=playGuess(pet,choice,Math.floor(Math.random()*2),Date.now())
  pet=played.state;save();result=pet.message;lastAction='ZERO OU UM';reactionAction='jogo'
  reactionOpponent='';go('reaction');feedback(played.result==='ganhou'?FX.win:FX.lose)
}
function parityScreen(){categoryPage('PAR OU IMPAR',[
  ['ESCOLHER PAR','games',()=>{parityChoice='par';go('parityNumber')}],
  ['ESCOLHER IMPAR','games',()=>{parityChoice='impar';go('parityNumber')}]
],'gamesMenu')}
function parityNumberScreen(){
  backdrop('PAR OU IMPAR')
  txt('ESCOLHEU '+parityChoice.toUpperCase(),40,78,310,32,21)
  txt('Escolha de 0 a 5.',45,112,300,25,17)
  for(let n=0;n<6;n++){
    const x=45+(n%3)*104,y=154+Math.floor(n/3)*75
    tap(String(n),x,y,93,60,()=>doParity(n),false,25)
  }
  bottom('VOLTAR','parity')
}
function doParity(number){
  if(!ensureReady())return
  const played=playParity(pet,parityChoice,number,Math.floor(Math.random()*6),Date.now())
  pet=played.state;save();result=pet.message;lastAction='PAR OU IMPAR';reactionAction='jogo'
  reactionOpponent='';go('reaction');feedback(played.result==='ganhou'?FX.win:FX.lose)
}
function startQuiz(topic){
  if(!ensureReady())return
  activeQuiz=questionFor(topic,Math.floor(Math.random()*100))
  go('quiz')
}
function quizScreen(){
  backdrop('ESTUDOS: '+activeQuiz.topic.toUpperCase())
  txt(activeQuiz.question,39,83,311,59,18)
  activeQuiz.choices.forEach((option,i)=>tap(option,48,160+i*54,294,46,()=>answerQuiz(i),false,17))
  bottom('ESTUDOS','studiesMenu')
}
function answerQuiz(i){
  if(!ensureReady())return
  const checked=answerStudy(pet,activeQuiz,i,Date.now());pet=checked.state
  save();result=pet.message;lastAction='ESTUDOS';reactionAction='estudar'
  go('reaction');feedback(checked.result==='certo'?FX.win:FX.lose)
}
''' + s[idx:]
sub("  txt('JEITO: '+personalityOf(pet).toUpperCase(),46,314,295,20,13)", "  txt('JEITO: '+personalityOf(pet).toUpperCase()+' | ACERTOS: '+(pet.studyCorrect||0),46,314,295,20,13)")
sub("  if(action==='educar')pet=giveDiscipline(pet,Date.now())\n  else pet=enhance(act(pet,action,Date.now()))", """  const now=Date.now()
  if(action==='educar')pet=giveDiscipline(pet,now)
  else if(action==='escovar'||action==='lavar_maos')pet=cleanCare(pet,action)
  else if(action.startsWith('doce_'))pet=giveDessert(pet,action.slice(5),now)
  else pet=enhance(act(pet,action,now))""")
sub("    acordar:'ACORDANDO',remedio:'REMEDIO',educar:'EDUCANDO'", "    acordar:'ACORDANDO',remedio:'REMEDIO',educar:'EDUCANDO',\n    escovar:'DENTINHOS',lavar_maos:'MAOS LIMPAS',doce_fruta:'FRUTINHAS',doce_pudim:'PUDIM',doce_sorvete:'SORVETE'")
sub("  save();go('reaction');feedback(feedbackForAction(action))", """  save()
  if(action==='dormir'){speechLine='';go('home');return}
  if(action==='acordar'){speechLine='';go('home');feedback(FX.happy);return}
  go('reaction');feedback(feedbackForAction(action))""")
sub("  if(reactionAction==='jogo') txt('DINO FAZ: '+reactionOpponent.toUpperCase(),53,288,284,23,14,COLOR.ink)", "  if(reactionAction==='jogo' && reactionOpponent) txt('DINO FAZ: '+reactionOpponent.toUpperCase(),53,288,284,23,14,COLOR.ink)")
sub("  if(screen==='menu') menu()", """  if(screen==='menu') menu()
  else if(screen==='alimento') alimento()
  else if(screen==='gamesMenu') gamesMenu()
  else if(screen==='hygieneMenu') hygieneMenu()
  else if(screen==='studiesMenu') studiesMenu()
  else if(screen==='restMenu') restMenu()
  else if(screen==='healthMenu') healthMenu()
  else if(screen==='dessert') dessert()
  else if(screen==='binary') binaryScreen()
  else if(screen==='parity') parityScreen()
  else if(screen==='parityNumber') parityNumberScreen()
  else if(screen==='quiz') quizScreen()""")
p.write_text(s)
# Changes deliberately additive and backward-compatible
q=root/'src/game.js';g=q.read_text()
g=g.replace("    t.poopProgress = 0\n    t.hygiene = round(clamp(t.hygiene + 55))\n    t.poop = 0\n    t.message = 'Limpinho!'", "    // Banho cuida do corpo; limpar coco e uma acao separada.\n    t.hygiene = round(clamp(t.hygiene + 48))\n    t.message = 'Banho tomado! Corpo limpinho!'")
q.write_text(g)
a=root/'app.json';obj=json.loads(a.read_text());obj['app']['version']={'code':18,'name':'1.6.0'};obj['app']['description']='DinoPocket 1.6.0: menus por categorias, minijogos, estudos e modo noturno escuro.';a.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
a=root/'package.json';obj=json.loads(a.read_text());obj['version']='1.6.0';obj['description']='DinoPocket Retro 1.6.0: categorias e cenas dinamicas para Bip 6';a.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n')
a=root/'tests/features_v15.test.js';a.write_text(a.read_text().replace("app.app.version.name,'1.5.10'","app.app.version.name,'1.6.0'"))
a=root/'tests/evolution.test.js';z=a.read_text().replace("ui.click('MENU');ui.click('MAIS');ui.click('TESTES')","ui.click('MENU');ui.click('FERRAMENTAS');ui.click('TESTES')").replace("ui.click('MENU');ui.click('MAIS');","ui.click('MENU');ui.click('FERRAMENTAS');").replace("const labels=['SONS / ALERTAS','TEMPERATURA','PAUSAR / CONTINUAR','RELOGIO','TESTES','MENU'];","const labels=['SONS E ALERTAS','TEMPERATURA','PAUSA','RELOGIO','TESTES','MENU'];")
z=z.replace("test('TESTES does not overlap MENU on More screen'","test('TESTES does not overlap MENU on Ferramentas screen'")
a.write_text(z)
print('patched page',len(s),'bytes')
