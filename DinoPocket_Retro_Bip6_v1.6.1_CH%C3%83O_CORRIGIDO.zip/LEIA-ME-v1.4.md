# DinoPocket Retro 1.4 - Central Zepp

Versao: 1.4.0 | ID 29318764 | Amazfit Bip 6 (Zepp OS 4)

## Configuracoes no Zepp
No aplicativo Zepp: gerenciar o DinoPocket > Configuracoes (pode depender do modo de instalacao por QR Code).
O app passa a incluir `setting/index.js` (pagina no celular) e `app-side/index.js` (ponte Bluetooth).

Preferencias padrao: modo CLASSICO, especie SURPRESA, 5 fases, sons ON, gestos ON, alertas ON.
- Classico: a alimentacao decide a especie, como antes.
- Personalizado/Livre: escolha da especie adulta vale **somente na proxima evolucao natural** de um Dino ainda nao adulto, nao troca adulto existente, nem acelera os dias.
- 5 fases sao as fases realmente desenhadas no relogio nesta versao; mais especies/fases serao desenvolvidas separadamente.
- Alertas sao os indicadores e sons de atencao durante o uso do jogo. Alertas em segundo plano nao fazem parte desta versao.

## Progresso preservado
- Pet permanece em `dinopocket.state.v1` (`schema: 1`), chave original.
- Preferencias sao guardadas separadamente em `dinopocket.config.v1` e no settingsStorage do Zepp.
- Nao desinstalar a versao anterior: atualizar usando o mesmo appId.
- Nenhum comando de reset nem escrita de estados do Zepp para o pet.

## Sincronizacao
- Alterar preferencia no Zepp -> settingsStorage -> Side Service -> mensagem Bluetooth -> Device App -> LocalStorage.
- Ao abrir o jogo, o relogio pede as preferencias atuais ao Zepp.
- Se estiver desconectado, o relogio usa as ultimas preferencias recebidas.
- O BLE precisa ser validado em um Bip 6 fisico, e a pagina de configuracao deve ser validada no Zepp com o QR Code de preview.

## Compilar
Acesse o repositório `odiogo19tst/APP-S`, envie o ZIP renomeado para
`DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip`, e use o mesmo GitHub Actions anterior.
Para gerar QR no Codespaces:
`cd /workspaces/APP-S && git pull --ff-only && mkdir -p dinopocket-v1.4 && unzip -o -q DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip -d dinopocket-v1.4 && cd dinopocket-v1.4 && zeus preview`

Referencias:
https://docs.zepp.com/docs/guides/framework/app-settings/register/
https://docs.zepp.com/docs/guides/architecture/arc/
https://docs.zepp.com/docs/reference/side-service-api/messaging/
https://docs.zepp.com/docs/reference/device-app-api/newAPI/ble/createConnect/
