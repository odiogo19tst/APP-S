# DinoPocket Retro v1.5.2 (build de teste)

**Motivo:** o pacote da 1.5.1 apresentou "Failed to unzip the package" ao importar o QR Code no Zepp.

Este pacote reduz de oito para quatro quadros cada animação (usando quadros-chave 0, 2, 4 e 6). Preserva os gráficos coloridos, 25 ações/poses, desenhos distintos das evoluções, lógica do jogo e salvamento `dinopocket.state.v1`.

Usa PNG RGBA originais, sem mudar formato nem paleta, para maximizar compatibilidade com o conversor Zeus. Ainda requer `zeus build`/`zeus preview` e validação em relógio físico.

**Nunca desinstalar a versão atual antes de testar a atualização.** Se houver outro erro, registrar a mensagem e verificar logs no Zepp Developer Mode.
