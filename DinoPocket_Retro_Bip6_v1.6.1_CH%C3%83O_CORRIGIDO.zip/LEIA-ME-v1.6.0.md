# DinoPocket Retro 1.6.0 — Amazfit Bip 6

Atualização experimental baseada na fonte validada 1.5.10. Mesmo appId 29318764, mesma chave `dinopocket.state.v1`, `schema: 1` e versão de compilação 18. Não desinstale a versão instalada nem limpe os dados; a preservação de progresso real deve ser confirmada no relógio.

## Melhorias

- MENU → ALIMENTAÇÃO → BEBIDAS / COMIDAS / SOBREMESAS (máximo 2 sobremesas por dia).
- MENU → JOGOS → PEDRA/PAPEL/TESOURA, 0 OU 1, PAR OU ÍMPAR, BRINCAR.
- MENU → HIGIENE → LIMPAR COCÔ, DAR BANHO, ESCOVAR DENTES, LAVAR AS MÃOS. Banho não limpa o cocô; cada cuidado tem efeito diferente.
- MENU → ESTUDOS → MATEMÁTICA, INGLÊS, PORTUGUÊS (perguntas de 3 alternativas com pontuação), BOAS MANEIRAS, ESTUDO LIVRE.
- MENU → DESCANSO → DORMIR/ACORDAR e AJUSTAR PAUSA.
- MENU → SAÚDE → REMÉDIO e STATUS.
- MENU → FERRAMENTAS → SONS/ALERTAS, TEMPERATURA, PAUSA, RELÓGIO e TESTES (evolução manual).
- Ícones PNG originais de navegação; cenários LCD por fase e situação (ovo, bebê, filhote, jovem, espécie adulta, doença e sujeira).
- Ao dormir, a tela principal passa para a cena noturna escura com personagem estático escurecido, até despertar automaticamente após 8h ou pressionar ACORDAR. A tela física pode apagar no tempo determinado pelo firmware do relógio. Não implementa Always-On Display.
- Progresso de higiene bucal/mãos e acertos de estudo no STATUS. Novo progresso incluído na chave antiga sem alterar dados anteriores.

## Validação

- `npm test` (testes de lógica, navegação, compatibilidade e assets): 90 testes passaram no ambiente de desenvolvimento.
- Ainda NÃO validado via `zeus build` nem instalado fisicamente no Bip 6 nesta versão. O compilador Zeus e o relógio devem confirmar a compatibilidade.

## Gerar QR Code no GitHub Codespaces

1. Baixe `DinoPocket_Retro_Bip6_v1.6.0_FONTE.zip` e faça upload para a raiz `/workspaces/APP-S` no GitHub; confirme que está na `main`.
2. No terminal do Codespaces, execute:

```sh
cd /workspaces/APP-S && git pull --ff-only && mkdir -p /tmp/dinopocket-bip6-160 && unzip -qo DinoPocket_Retro_Bip6_v1.6.0_FONTE.zip -d /tmp/dinopocket-bip6-160 && cd /tmp/dinopocket-bip6-160 && npm test && zeus preview
```

3. Selecione Amazfit Bip 6 e escaneie o QR com o Zepp (modo de desenvolvedor). Atualize sobre a versão atual sem desinstalar. No caso de erro no `git pull` por alterações locais, não force: envie um print do erro.

**Importante:** o QR Code não é carregável diretamente nesta ZIP; depende de `zeus preview` autenticado e do relógio. A tela de dormir permanece escura apenas enquanto o aplicativo está visível; o firmware pode suspender a tela e o processo.

## Futuro Android

A mesma engine poderá alimentar um widget Android, mas sincronização com o relógio requer canal/ponte e um app Android dedicado. Não existe conexão direta entre widgets Android e app Zepp usando apenas a Settings Page. Prioridade atual: validar a atualização Bip 6.
