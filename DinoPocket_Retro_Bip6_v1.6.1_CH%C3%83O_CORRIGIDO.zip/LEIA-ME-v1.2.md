# DinoPocket Retro 1.2 — Edicao Nostalgia (Amazfit Bip 6)

**Estado:** projeto criado e testado com `npm test` (25 testes). O `.zab` desta versao so existira depois de compilar via Zeus CLI/GitHub Actions. A execucao fisica v1.2 ainda nao foi validada.

## Novidades do jogo

- LCD retro, animacoes de oito quadros a 3 FPS com o Dino andando horizontalmente; o ovo oscila sem pular.
- Menu: COMIDA, JOGO, LIMPAR, DORMIR, REMEDIO, EDUCAR, TEMP., STATUS, PAUSA e RELOGIO.
- Pedra-papel-tesoura, com vitorias registradas e impacto em alegria/energia.
- Disciplina e temperatura; pausa opcional (congela tempo e necessidades).
- Saudabilidade, higiene, fome, energia, alegria, evolucao a cada 24h e rotas por dieta (T-Rex, Bronto, Triceratopo).
- Reacoes apos cuidados. Nenhum carregamento de rede necessario para jogar.
- Personagens/arte proprios; inspira-se no LCD e nas funcoes do Dinkie Dino, nao reutiliza codigo/arte do brinquedo original.

## Compatibilidade com instalacoes anteriores

- **ID do app:** `29318764` (igual a v1.0 e v1.1).
- **Versao:** `1.2.0`, codigo `3`.
- **Chave:** `dinopocket.state.v1` e `schema=1`, preservados.
- Adiciona valores padrao ao save antigo; testes de migracao inclusos.
- A preservacao dos dados **nao e garantida pelo instalador**. NAO desinstale o app antes de testar a substituicao.

## Compilar no GitHub do usuario

Este ZIP deve ser enviado INTEIRO como substituicao de `DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip` no repo `odiogo19tst/APP-S` (sem descompactar). O workflow existente `.github/workflows/compilar-dinopocket.yml` usa esse arquivo, roda `npm test`, `zeus build` e anexa o `.zab` como artefato.

1. Pelo Chrome, abra `https://github.com/odiogo19tst/APP-S/upload/main`.
2. Selecione **DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip** preparado aqui.
3. Confirme sobrescrita do arquivo, se solicitada, e `Commit changes` na branch main.
4. No GitHub, acompanhe `https://github.com/odiogo19tst/APP-S/actions`.
5. Baixe o artefato da execucao mais nova depois que ficar verde.
6. Para instalacao de teste, Codespaces > terminal:

```
cd /workspaces/APP-S
git pull --ff-only
mkdir -p dinopocket-v1.2
unzip -o -q DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip -d dinopocket-v1.2
cd dinopocket-v1.2
zeus preview
```

Depois de autenticar na Zepp, selecione Amazfit Bip 6, escaneie o QR com Zepp > Modo Desenvolvedor > Digitalizar. Se usar o mesmo telefone, apresente o QR em outro dispositivo ou use a opcao de Galeria, caso exista.

## Verificacao automatizada

`npm test` / `node --check page/index.js` / `node --check src/game.js`.

## Restricoes previstas

- Implementados efeitos 8-bit MP3 de ovo, nascimento, comida, brincadeira, cuidado, evolucao, alertas e doenca, alem de vibracao; menu ALERTAS permite ligar/desligar som e vibracao.
- Os efeitos funcionam com o aplicativo aberto. **Notificacoes persistentes com o aplicativo fechado ainda nao estao implementadas**; exigem App Service e testes especificos.
- Alertas passivos ficam silenciosos de 22h a 8h; acoes comandadas pelo usuario respeitam os interruptores de som/vibracao.
- O modo dormir restaura energia ao toque; nao depende de detecao real de sono.
- Relogio marca o horario atual do dispositivo na tela RELOGIO, sem atualizar dinamicamente enquanto a tela estiver aberta.

## Interacao por movimento e personalidade

- Ao sacudir o pulso enquanto o jogo estiver aberto **na tela inicial**,
  o ovo reage sem nascer antes de 24h ou o Dino brinca com uma fala
  influenciada pela sua personalidade.
- Usamos `Accelerometer` oficial (`device:os.accelerometer`),
  FREQ_MODE_NORMAL, 3 impactos em 1,3 segundo e espera minima de 10 segundos.
  Necessita testar o limiar de 520 cm/s² no Bip 6 real e calibrar.
- Ao fechar a pagina, o sensor e desligado. Nao permanece monitorando
  movimentos em segundo plano.
- Personalidades: curioso, brincalhao, manhoso, tranquilo, travesso.
  O comportamento considera humor, disciplina, cuidados e brincadeiras.
- Estado original de save (`dinopocket.state.v1`) e campos anteriores mantidos;
  adiciona `wristPlays`, `eggShakes`, `careCount` e `temperament`.

## Efeitos 8-bit e feedback de pulso

- Arquivos de audio originais `assets/390x450-bip6/sfx/*.mp3` (8 efeitos).
- Playback de MP3 via `@zos/media` e vibracoes leves de `@zos/sensor` enquanto o app estiver aberto.
- O menu **ALERTAS** alterna som e vibracao de forma independente.
- O som/vibracao de nascimento e evolucao sera emitido na abertura que detectar a mudanca; quando estiver em horario noturno (22h–08h), esse aviso passivo fica silencioso.
- **Avisos com o aplicativo fechado nao estao implementados ainda.** A funcionalidade exigiria alarme e App Service com permissao de notificacoes, testes de consumo e controle de horario.
- SONS: pulso / ovo / fome / comida / cuidado / evolucao / alegria / doenca.
- Sem codigo de terceiros ou audio copiado do brinquedo original.
