# DinoPocket Bip 6 — 1.5.8 (pacote de teste final)

Base: v1.5.2 comprovadamente instalada no Bip 6.
Sem alteracoes no comportamento do jogo nem no ID 29318764 e chave de progresso dinopocket.state.v1.
Corrige 843 imagens e preserva todos os 972 quadros de animacao.
Redimensiona para 80% as imagens animadas para reduzir a carga descompactada na memoria do relogio. Ajusta o posicionamento central em +29,+16 pixels.
Aparencia: o Dino aparece aproximadamente 20% menor em relacao a versao 1.5.2; nao ha perda de quadros, cores ou poses.
AVISO: A instalacao no relogio ainda precisa ser validada. Nao desinstale a 1.5.2 antes de confirmar.
