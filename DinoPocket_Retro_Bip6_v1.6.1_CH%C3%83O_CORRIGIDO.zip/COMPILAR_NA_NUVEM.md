# DinoPocket Retro - Build na nuvem (Amazfit Bip 6)

Este ZIP possui o CODIGO-FONTE. Nao e um .zab compilado.

## GitHub Actions - gerar um .zab

1. Crie um repositorio **privado** em https://github.com/new chamado `dinopocket-bip6`.
2. Envie os arquivos e pastas extraidos deste ZIP para a raiz do repositorio,
   preservando `.github/workflows/compilar-dinopocket.yml` e `assets/`.
3. No GitHub, abra **Actions > Compilar DinoPocket para Amazfit Bip 6**.
   O build comeca automaticamente no primeiro commit de `main` ou `master`,
   ou clique em **Run workflow**.
4. Se o build ficar verde, abra a execucao e baixe o artefato `DinoPocket-Bip6-ZAB`.
   O download sera um ZIP contendo o(s) arquivo(s) `.zab`.
5. Caso falhe, envie a mensagem de erro do log para corrigirmos.

ATENCAO: o arquivo `.zab` **nao se instala automaticamente** pelo Zepp.
O procedimento oficial de testes envolve **zeus preview** para gerar um QR Code
no ambiente autenticado do desenvolvedor.

## GitHub Codespaces - maquina virtual no navegador

1. Apos criar o repositorio, use **Code > Codespaces > Create codespace on main**.
2. Aguarde instalacao do Node e do Zeus CLI pelo `.devcontainer/devcontainer.json`.
3. Em Terminal, rode `npm test` e `zeus build`.
4. Para tentar a instalacao via QR Code, rode `zeus preview` e faca login no
   Zepp Open Platform, se solicitado. Essa etapa pode exigir interface grafica
   ou interacao no terminal e **nao foi validada** neste Codespace.
5. Se o QR aparecer, Zepp (celular) > Perfil > Configuracoes > Sobre, toque 7 vezes
   no logo Zepp para habilitar Modo Desenvolvedor e depois use Digitalizar.

Documentacao oficial:
https://docs.zepp.com/docs/guides/tools/cli/
https://docs.zepp.com/docs/guides/quick-start/preview/

Alvo do aplicativo: tela 390 x 450, modelos Bip 6 9765120 / 9765121 / 10158337.
Os testes automatizados verificam a logica, nao o funcionamento do app no relogio.
Nao renomeie o ZIP comum para .zab: isso nao produz um aplicativo Zepp OS.
