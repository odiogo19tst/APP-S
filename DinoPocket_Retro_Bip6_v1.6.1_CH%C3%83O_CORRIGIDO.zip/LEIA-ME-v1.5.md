# DinoPocket Retro 1.5.1 — Dino mais expressivo no Amazfit Bip 6

**Versão 1.5.1 de desenvolvimento (código 7). Não enviada para a Zepp App Store nem instalada no relógio automaticamente.**

## O que entrou na 1.5

- Dinossauro retrabalhado em pixel art colorida de 96×54 pixels lógicos (antes 72×41), cabeça maior, dois olhos com brilho, bochechas, patas, bracinhos, espinhos e expressões ampliadas. Cada ação tem 8 quadros.
- **1.800 PNGs animados** para 9 formas (ovo, bebê, pequeno, jovem, T-Rex, Brontossauro, Tricerátopo, doente, fantasma) e 25 reações visuais, incluindo sono, alimentação específica, bebidas, estudo, brincar, sujeira, banho, cocô, minijogo pedra/papel/tesoura, carinho, despertar e evolução.
- **22 sons suaves** em MP3 mono, 22.050 Hz. O estilo clássico continua disponível pelo menu.
- Três bebidas: água, suco e leite. Nova barra de sede e contadores no mesmo save antigo.
- Estudo: o Dino abre o livro e aumenta inteligência e disciplina.
- Pedra, papel e tesoura: gesto visível do Dino, resposta contextual com resultado.
- Cocô acumulado por tempo e refeições; sujeira aparece no pet, opção de limpar cocô ou dar banho.
- Dormir realmente: Dino se deita, olhos fechados e animação de respiração, recupera energia gradualmente, acorda após até oito horas ou manualmente.
- Brincar: animação com bolinha, energia e felicidade com consequências reais.
- Toque: dino reage na tela; toque longo: menu; pulso: resposta respeitando sono e a preferência do Zepp.
- Paleta moderna suave, preservando os contornos retro pixelados.
- Temporizador leve de 60 segundos enquanto o jogo está na tela, evitando o problema de perder progresso fracionário de necessidades e cocô.

## Compatibilidade, evolução e privacidade

- App ID: **29318764**, inalterado.
- Chave de salvamento: **`dinopocket.state.v1`**, inalterada; schema **1**.
- Idade, geração, evolução, comidas, conquistas e personalidade antigos são preservados na leitura.
- Evolução clássica por cinco etapas e alimentação permanece compatível. Escolha de espécie adulta configurada no Zepp permanece válida.
- Dados do animal ficam localmente no relógio. Só preferências simplificadas são trocadas com o Zepp por Bluetooth.
- **Não desinstale o Dino 1.4** para instalar a atualização: isso pode apagar o progresso.
- A integração da aba de configuração no Zepp depende de validação real na distribuição oficial. O código original de `setting` e `app-side` foi mantido.

## Compilação no GitHub

Requer o workflow no repositório `odiogo19tst/APP-S` que lê o arquivo `DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip` na raiz.

1. Execute `npm test` no projeto (64 testes na entrega).
2. Baixe o ZIP preparado **com o nome exato** `DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip`.
3. Faça upload deste único ZIP na raiz do repositório `APP-S` e confirme a substituição, sem extrair. Isso pode iniciar um GitHub Actions de compilação, mas **não envia uma versão à Zepp**.
4. Baixe o `.zab` da execução concluída do GitHub Actions.
5. Faça teste via `zeus preview` no Codespaces antes de qualquer publicação na Zepp App Store.

**Importante:** compilação Zeus e teste real de áudio, FPS, sensores e desempenho no Bip 6 ainda precisam ser feitos. Os testes locais de lógica e estrutura não os substituem.

## Arquivos principais

- `src/game.js`: engine, sono, sede, aprendizagem, cocô e migração segura.
- `src/visual_rules.js`: prioridades e poses de cada ação/estado.
- `page/index.js`: UI, animação em IMG_ANIM, toque, menus, realimentação sonora.
- `src/sound_rules.js`: mapeamento dos novos sons suaves, modo clássico.
- `scripts/make_v15_sprites.py`: gera as animações autorais, sem depender de PNGs de terceiros.
- `scripts/make_v15_sounds.py`: sintetiza os efeitos MP3 originais com envelope suave.
- `tests/features_v15.test.js`: testes de regressão novos.

## Ajustes visuais adicionais da 1.5.1

- 1.800 sprites **efetivamente incluídos na pasta `assets/390x450-bip6/anim`** (não são só uma arte de demonstração).
- Ovo, bebê, pequeno, jovem, rex, bronto, trike, doente e fantasma têm desenhos adaptados.
- Dormir: o Dino deita e mexe a barriguinha, com Zzz deslocando.
- Comer: alimento vai à boca, tem mastigação e farelos. Beber: copinho, canudo e líquido adequado.
- Estudar: livro aberto e movimento das páginas. Brincar: bola e patas animadas.
- Coco e sujeira: manchas e cocô visíveis; banho: bolhas animadas. Pedra/papel/tesoura: três formatos distintos da patinha.
- Todos os arquivos têm 288×164 pixels de dimensão, em PNG com fundo transparente, e continuam no formato usado pelo `IMG_ANIM`.
- Ícone e sprites estáticos atualizados ao novo visual.
- 67 testes de lógica, salvamento e animações passaram localmente. Ainda não houve compilação/instalação real desta revisão.

**Salvamento preservado:** mesmo App ID `29318764` e chave `dinopocket.state.v1`. Atualize por cima; nunca desinstale antes de conferir o backup/progresso. A revisão atual na Zepp App Store não foi alterada.
