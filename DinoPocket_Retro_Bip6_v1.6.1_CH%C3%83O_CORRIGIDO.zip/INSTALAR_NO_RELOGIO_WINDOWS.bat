@echo off
setlocal
cd /d "%~dp0"
echo.
echo ============================================
echo  DINOPOCKET RETRO - AMAZFIT BIP 6
echo ============================================
echo.
where node >nul 2>nul
if errorlevel 1 (
  echo ERRO: Node.js nao encontrado. Instale Node.js LTS primeiro.
  echo Site: https://nodejs.org/
  pause
  exit /b 1
)
where npm >nul 2>nul
if errorlevel 1 (
  echo ERRO: npm nao encontrado. Reinstale Node.js.
  pause
  exit /b 1
)
where zeus >nul 2>nul
if errorlevel 1 (
  echo Instalando a ferramenta oficial Zeus CLI pela internet...
  call npm install -g @zeppos/zeus-cli
  if errorlevel 1 (
    echo Falha ao instalar Zeus CLI. Confira sua conexao e permissoes.
    pause
    exit /b 1
  )
)
echo.
echo Ligue o Bip 6 e mantenha-o conectado ao Zepp.
echo A seguir, Zeus gerara um QR Code para ler no Zepp, em Modo Desenvolvedor.
echo Se solicitado, faca login na sua conta Zepp.
echo.
call zeus preview
if errorlevel 1 (
  echo.
  echo Nao foi possivel gerar o QR Code; veja o erro acima.
)
echo.
pause
