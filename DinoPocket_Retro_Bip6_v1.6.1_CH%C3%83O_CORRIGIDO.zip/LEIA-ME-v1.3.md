# DinoPocket Retro 1.3 — Tela Imersiva + Voz Expressiva

Novo layout: tela inteira e sprites animados; tocar no LCD faz carinho, **segurar por 0,7 segundo abre MENU**. MENU secundario discreto no canto, util se alguma versao do firmware reservar o gesto longo. STATUS continua no menu.

16 vozes sintetizadas novas (8-bit, todas originais), com humor e personalidade; som pode alternar EXPRESSIVO/CLASSICO e ligar/desligar. Vibracao independente. Sacudir pulso continua acionando as brincadeiras como na v1.2.

### Compatibilidade
- Mesmo appId `29318764`, versionCode `4`, versao `1.3.0`.
- Mesmo save `dinopocket.state.v1`, `schema=1`; nao desinstale a versao anterior.
- O instalador Zepp pode nao preservar dados; precisamos testar no Bip 6.
- O gesto longo usa `widget.GROUP` + `CLICK_DOWN`/`CLICK_UP` + timer; exige validacao em hardware.
- Audio via @zos/media, feedback somente com o jogo aberto; nenhuma notificacao em background.

### GitHub
Envie o ZIP `DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip` para raiz do repo APP-S, substituindo o anterior, e aguarde a acao compilar-dinopocket.yml concluir. Pelo Codespaces:

```bash
cd /workspaces/APP-S
git pull --ff-only
mkdir -p dinopocket-v1.3
unzip -o -q DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip -d dinopocket-v1.3
cd dinopocket-v1.3
zeus preview
```

Escolha Amazfit Bip 6; escaneie o QR no Zepp modo desenvolvedor. Se preciso, use outra tela para mostrar o QR.

### Validacao
- `npm test`
- `node --check page/index.js`
- `zeus build` via GitHub Actions, pois compilacao oficial nao foi executada localmente.
