# DinoPocket Retro 1.6.1 — alinhamento do Dino ao solo (Amazfit Bip 6)

Correção focada na tela inicial: personagens (ovo/bebê/filhote/jovem/adulto,
incluindo doença e fantasminha) passam a utilizar a mesma âncora de solo,
52 pixels abaixo da posição anterior. As mensagens e avisos foram reposicionados
abaixo do personagem para evitar esconder os pés.

- Versão: 1.6.1; código 19; ID: 29318764.
- Save: `dinopocket.state.v1`, schema 1, **inalterado**.
- Não há alteração de lógica de crescimento, animações, sons, jogos, saúde ou estudos.
- `npm test` passou em 92/92 testes, incluindo regressões de posicionamento e sono.
- A compilação Zeus e instalação no relógio ainda precisam ser verificadas.
- Instalar como atualização sem desinstalar nem limpar os dados.

Usar `zeus preview` em um ambiente com Zeus CLI para compilar e gerar um QR Code
no Zepp. Confirmar no relógio se o Dino está no chão e se o progresso permaneceu.
