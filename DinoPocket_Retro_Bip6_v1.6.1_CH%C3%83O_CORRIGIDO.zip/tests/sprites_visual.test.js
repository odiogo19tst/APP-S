import test from 'node:test'
import assert from 'node:assert/strict'
import fs from 'node:fs'
import path from 'node:path'
import crypto from 'node:crypto'
import { fileURLToPath } from 'node:url'

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..','assets','390x450-bip6','anim')
const forms=['egg','baby','small','young','rex','bronto','trike','sick','ghost']
const poses=['idle','happy','sleep','hunger','sad','dirty','sick','eat','drink','study','play','bath','poop','rps_pedra','rps_papel','rps_tesoura','evolve','touch','wake','eat_carne','eat_vegetais','eat_massa','drink_agua','drink_suco','drink_leite']
const frame=(form,pose,n)=>fs.readFileSync(path.join(root,form,pose,`frame_${n}.png`))
const digest=(b)=>crypto.createHash('sha256').update(b).digest('hex')

test('as 900 animation frames are bundled and have real Bip 6 dimensions',()=>{
  let count=0
  for(const form of forms){
    for(const pose of poses){
      for(let i=0;i<4;i++){
        const bytes=frame(form,pose,i)
        assert.equal(bytes.toString('hex',0,8),'89504e470d0a1a0a')
        assert.equal(bytes.readUInt32BE(16),230)
        assert.equal(bytes.readUInt32BE(20),131)
        count++
      }
    }
  }
  assert.equal(count,900)
})
test('sleep, smiles, food, drinking, study and play use changing real frames',()=>{
  for(const pose of ['idle','sleep','happy','eat_carne','eat_vegetais','drink_agua','study','play','bath','rps_tesoura']){
    const uniq=new Set(Array.from({length:4},(_,i)=>digest(frame('baby',pose,i))))
    assert.ok(uniq.size>=3,`pose ${pose} had only ${uniq.size} distinct frames`)
  }
})
test('sleep, book, hunger, rock-paper-scissors, and breeds are different drawings',()=>{
  assert.notEqual(digest(frame('baby','sleep',2)),digest(frame('baby','idle',2)))
  assert.notEqual(digest(frame('baby','study',2)),digest(frame('baby','idle',2)))
  assert.notEqual(digest(frame('baby','rps_papel',2)),digest(frame('baby','rps_tesoura',2)))
  assert.notEqual(digest(frame('baby','rps_pedra',2)),digest(frame('baby','rps_papel',2)))
  assert.notEqual(digest(frame('rex','idle',0)),digest(frame('bronto','idle',0)))
  assert.notEqual(digest(frame('bronto','idle',0)),digest(frame('trike','idle',0)))
})
