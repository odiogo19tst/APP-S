import test from 'node:test'
import assert from 'node:assert/strict'
import {readFileSync,existsSync} from 'node:fs'
import {newGame,enhance,advance,act,DAY,HOUR} from '../src/game.js'
import {cleanCare,giveDessert,playGuess,playParity,questionFor,answerStudy,sceneFor} from '../src/expansion.js'
const NOW=Date.UTC(2026,9,14,12)
const baby=()=>enhance({...newGame(NOW),stage:1,bornAt:NOW-DAY,updatedAt:NOW,poop:2})
test('old pet migrations preserve schema and extras without overwriting progress',()=>{
 const prior={...baby(),generation:9,lives:2,achievements:{x:['done']},unknown:'stay'}
 const copy=enhance(JSON.parse(JSON.stringify(prior)))
 assert.equal(copy.schema,1);assert.equal(copy.generation,9)
 assert.deepEqual(copy.achievements,{x:['done']});assert.equal(copy.unknown,'stay')
 assert.equal(copy.teethCare,60);assert.equal(copy.handCare,60)
})
test('cleaning poop differs from bathing; brushing and washing have distinct benefits',()=>{
 let s=baby();s.hygiene=22
 const bath=act(s,'banho',NOW)
 assert.equal(bath.poop,2);assert.ok(bath.hygiene>s.hygiene)
 const floor=act(s,'limpar_coco',NOW)
 assert.equal(floor.poop,0);assert.ok(floor.hygiene<s.hygiene+48)
 const teeth=cleanCare(s,'escovar');const hands=cleanCare(s,'lavar_maos')
 assert.ok(teeth.teethCare>s.teethCare);assert.equal(teeth.handCare,s.handCare)
 assert.ok(hands.handCare>s.handCare);assert.equal(hands.teethCare,s.teethCare)
 assert.equal(s.hygiene,22)
})
test('oral and hand care decay slowly over hours',()=>{
 const old=cleanCare(cleanCare(baby(),'escovar'),'lavar_maos')
 const next=advance(old,NOW+HOUR)
 assert.ok(next.teethCare<old.teethCare);assert.ok(next.handCare<old.handCare)
})
test('dessert types provide happiness, and 2/day quota cannot be bypassed by reopen',()=>{
 const start=baby();const first=giveDessert(start,'fruta',NOW)
 const second=giveDessert(first,'pudim',NOW)
 const third=giveDessert(second,'sorvete',NOW)
 assert.equal(first.dessertsToday,1);assert.equal(second.dessertsToday,2)
 assert.equal(third.dessertsToday,2);assert.equal(third.joy,second.joy)
 assert.ok(third.message.includes('duas vezes'))
 const next=giveDessert(third,'sorvete',NOW+DAY)
 assert.equal(next.dessertsToday,1);assert.equal(next.schema,1)
 assert.deepEqual(start.meals,{carne:0,vegetais:0,massa:0})
})
test('0 ou 1: guess is real; win and loss are registered',()=>{
 const p=baby()
 const won=playGuess(p,1,1,NOW)
 const lost=playGuess(won.state,0,1,NOW)
 assert.equal(won.result,'ganhou');assert.equal(lost.result,'perdeu')
 assert.equal(lost.state.extraGames,2);assert.equal(lost.state.extraWins,1)
 assert.equal(lost.state.gamesPlayed,p.gamesPlayed+2)
 assert.equal(p.extraGames,0)
})
test('par ou impar: sum and parity determine victory',()=>{
 const p=baby()
 let a=playParity(p,'par',2,4,NOW)
 assert.equal(a.result,'ganhou');assert.equal(a.state.extraWins,1)
 a=playParity(p,'impar',2,4,NOW)
 assert.equal(a.result,'perdeu')
 assert.equal(playParity(p,'par',7,0,NOW).result,'invalido')
})
test('quizzes in three subjects are answerable and score only once',()=>{
 for(const subject of ['matematica','ingles','portugues']){
  const q=questionFor(subject,3)
  const state=baby()
  const yes=answerStudy(state,q,q.correct,NOW)
  const wrong=answerStudy(state,q,(q.correct+1)%3,NOW)
  assert.equal(yes.result,'certo');assert.equal(wrong.result,'errado')
  assert.equal(yes.state.studyCount,state.studyCount+1)
  assert.equal(yes.state.studyCorrect,state.studyCorrect+1)
  assert.equal(wrong.state.studyCorrect,state.studyCorrect)
  assert.equal(yes.state.studiesBySubject[subject],1)
  assert.ok(yes.state.intelligence>wrong.state.intelligence)
 }
})
test('dark sleep persists when energy is full; manual wake works',()=>{
 let s={...baby(),energy:98}
 s=act(s,'dormir',NOW)
 assert.equal(s.awake,false)
 assert.equal(sceneFor(s),'night')
 assert.equal(advance(s,NOW+HOUR).awake,false)
 assert.equal(advance(s,NOW+9*HOUR).awake,true)
 assert.equal(act(s,'acordar',NOW).awake,true)
})
test('scene changes with growth, species, dirt, illness and night',()=>{
 const p={...baby(),poop:0}
 for(const [s,scene] of [[{...p,stage:0},'egg'],[p,'baby'],[{...p,stage:2},'small'],[{...p,stage:3},'young'],[{...p,stage:4,species:'rex'},'rex'],[{...p,stage:4,species:'bronto'},'bronto'],[{...p,stage:4,species:'trike'},'trike'],[{...p,sick:true},'sick'],[{...p,poop:3},'dirty'],[{...p,awake:false},'night'],[{...p,dead:true},'ghost']]){
  assert.equal(sceneFor(s),scene)
  assert.ok(existsSync(new URL(`../assets/390x450-bip6/scenes/${scene}.png`,import.meta.url)))
 }
})
test('all menu icon pngs and night sprites exist',()=>{
 const root=new URL('../assets/390x450-bip6/',import.meta.url)
 for(const name of ['food','games','hygiene','study','sleep','health','status','tools','dessert','drink','fooditem','test'])assert.ok(existsSync(new URL(`icons/${name}.png`,root)),name)
 for(const name of ['egg','baby','small','young','rex','bronto','trike','sick','ghost'])assert.ok(existsSync(new URL(`scenes/sleep_${name}.png`,root)),name)
})
test('version is newer, ID and save remain unchanged',()=>{
 const app=JSON.parse(readFileSync(new URL('../app.json',import.meta.url)))
 assert.equal(app.app.version.name,'1.6.1');assert.equal(app.app.version.code,19)
 assert.equal(app.app.appId,29318764);assert.equal(enhance(newGame(NOW)).schema,1)
})
