import test from 'node:test'
import assert from 'node:assert/strict'
import vm from 'node:vm'
import {readFileSync} from 'node:fs'
import * as game from '../src/game.js'
import * as settings from '../src/phone_settings.js'
import * as sound from '../src/sound_rules.js'
import * as visual from '../src/visual_rules.js'
import * as touch from '../src/touch_rules.js'
import * as expansion from '../src/expansion.js'
import {advanceForTest} from '../src/advance_for_test.js'
const NOW=Date.UTC(2026,9,14,12)
function renderState(saved){
 const values=new Map([[settings.PET_SAVE_KEY,{...saved}]])
 let page;let widgets=[]
 class Storage{
  getItem(k,f){return values.has(k)?values.get(k):f}
  setItem(k,v){values.set(k,v)}
 }
 const enums=new Proxy({},{get:(_,key)=>key})
 const code=readFileSync(new URL('../page/index.js',import.meta.url),'utf8').replace(/^import\s[\s\S]*?from\s+['"][^'"]+['"]\s*\r?\n/gm,'')
 vm.runInNewContext(code,{...game,...settings,...sound,...visual,...touch,...expansion,advanceForTest,
  Date:class Clock extends Date{constructor(...a){super(...(a.length?a:[NOW]))}static now(){return NOW}},
  LocalStorage:Storage,Page:p=>page=p,
  createWidget:(type,p)=>{const w={type,p,setProperty(){},addEventListener(){},createWidget(){return{setProperty(){},addEventListener(){}}}};widgets.push(w);return w},
  deleteWidget:w=>{widgets=widgets.filter(x=>x!==w)},widget:enums,align:enums,text_style:enums,prop:enums,anim_status:enums,event:enums,
  createConnect(){},disConnect(){},sendBluetooth(){},Accelerometer:class{setFreqMode(){}onChange(){}start(){}stop(){}offChange(){}},
  Vibrator:class{start(){}},FREQ_MODE_NORMAL:0,VIBRATOR_SCENE_SHORT_LIGHT:0,VIBRATOR_SCENE_NOTIFICATION:0,
  createMedia(){throw Error('No audio')},mediaId:enums,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){},console})
 page.onInit();page.build()
 return {widgets, values}
}
test('Dino is grounded at home across 5 stages, all 3 adult species, sick and deceased',()=>{
 const initial=game.enhance(game.newGame(NOW))
 for(const variant of [
  {stage:0}, {stage:1},{stage:2},{stage:3},
  {stage:4,species:'rex'}, {stage:4,species:'bronto'}, {stage:4,species:'trike'},
  {stage:3,sick:true}, {stage:2,poop:3}, {stage:3,dead:true}]){
   const state={...initial,...variant,bornAt:NOW-(variant.stage||0)*game.DAY}
   const a=renderState(state)
   const sprite=a.widgets.find(w=>w.type==='IMG_ANIM')
   assert.ok(sprite,JSON.stringify(variant))
   assert.equal(sprite.p.y,201,JSON.stringify(variant))
   const feet=sprite.p.y+128
   assert.ok(feet>=322 && feet<=334, 'feet align with terrain')
   const banner=a.widgets.find(w=>w.type==='FILL_RECT'&&w.p.color===0xddeadd)
   assert.ok(banner)
   assert.ok(banner.p.y>feet+10, 'message box must be below feet')
   assert.equal(a.values.get(settings.PET_SAVE_KEY).generation,state.generation)
   assert.equal(a.values.get(settings.PET_SAVE_KEY).stage,state.stage)
 }
})
test('Sleeping keeps still dim scene, without visible sprite animation',()=>{
 const initial=game.enhance(game.newGame(NOW))
 const a=renderState({...initial,stage:3,bornAt:NOW-3*game.DAY,awake:false,sleepUntil:NOW+2*game.HOUR})
 assert.ok(a.widgets.some(w=>w.type==='IMG'&&w.p.src==='scenes/night.png'))
 assert.equal(a.widgets.some(w=>w.type==='IMG_ANIM'),false)
})
