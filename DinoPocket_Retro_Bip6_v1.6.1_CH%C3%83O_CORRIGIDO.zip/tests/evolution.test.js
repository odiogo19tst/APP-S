import test from 'node:test'
import assert from 'node:assert/strict'
import vm from 'node:vm'
import { readFileSync } from 'node:fs'
import * as game from '../src/game.js'
import * as settings from '../src/phone_settings.js'
import * as sound from '../src/sound_rules.js'
import * as visual from '../src/visual_rules.js'
import * as touch from '../src/touch_rules.js'
import { advanceForTest } from '../src/advance_for_test.js'
import * as expansion from '../src/expansion.js'

const now=Date.UTC(2026,9,13,12)
const egg=()=>game.enhance(game.newGame(now))

test('manual evolution advances exactly four times and stays adult',()=>{
  let pet=egg()
  for(let stage=1;stage<=4;stage++){
    pet=advanceForTest(pet,now)
    assert.equal(pet.stage,stage)
    assert.equal(game.advance(pet,now).stage,stage)
  }
  assert.equal(advanceForTest(pet,now),pet)
  assert.equal(game.advance(pet,now+game.HOUR).stage,4)
})
test('evolution preserves care, achievements, schema, generation and unknown fields',()=>{
  let pet={...egg(),hunger:33,joy:41,hygiene:25,energy:18,thirst:52,health:37,sick:true,
    intelligence:62,careCount:18,gamesWon:9,generation:7,lives:2,
    meals:{carne:5,vegetais:1,massa:0},achievements:{custom:['kept']},futureField:'retained'}
  const before=structuredClone(pet)
  const mutable=new Set(['stage','ageDays','bornAt','updatedAt','species','message'])
  for(let i=0;i<4;i++)pet=advanceForTest(pet,now)
  for(const key of Object.keys(before))if(!mutable.has(key))assert.deepEqual(pet[key],before[key],key)
  assert.deepEqual(before,{...egg(),hunger:33,joy:41,hygiene:25,energy:18,thirst:52,health:37,sick:true,
    intelligence:62,careCount:18,gamesWon:9,generation:7,lives:2,
    meals:{carne:5,vegetais:1,massa:0},achievements:{custom:['kept']},futureField:'retained'})
  assert.equal(pet.species,'rex')
})
test('paused and sleeping pets keep their settings and do not regress on resume',()=>{
  let pet={...egg(),pausedAt:now,awake:false,sleepingSince:now,sleepUntil:now+8*game.HOUR}
  pet=advanceForTest(pet,now+2*game.HOUR)
  assert.equal(pet.pausedAt,now);assert.equal(pet.awake,false)
  assert.equal(pet.sleepUntil,now+8*game.HOUR)
  pet=game.setPause(pet,false,now+3*game.HOUR)
  assert.equal(game.advance(pet,now+3*game.HOUR).stage,1)
})
test('invalid, dead and adult states are unchanged; no revival',()=>{
  for(const state of [null,{schema:2,stage:0},{...egg(),dead:true},
    {...egg(),stage:4},{...egg(),stage:7},{...egg(),stage:1.5}])assert.equal(advanceForTest(state,now),state)
})
test('adult species follows existing food rules and optional phone preference',()=>{
  for(const [meals,species] of [[{carne:4},'rex'],[{vegetais:4},'bronto'],[{},'trike']]){
    const pet={...egg(),stage:3,meals}
    assert.equal(advanceForTest(pet,now).species,species)
    assert.equal(settings.adjustNaturalEvolution(pet,advanceForTest(pet,now),{mode:'custom',species:'bronto'}).species,'bronto')
  }
})

function watch(saved){
  const values=new Map([[settings.PET_SAVE_KEY,structuredClone(saved)]])
  const widgets=new Set();let page
  class Storage {
    getItem(k,f){return values.has(k)?structuredClone(values.get(k)):f}
    setItem(k,v){values.set(k,structuredClone(v))}
  }
  class Clock extends Date {constructor(...a){super(...(a.length?a:[now]))}static now(){return now}}
  const enums=new Proxy({},{get:(_,key)=>key})
  const code=readFileSync(new URL('../page/index.js',import.meta.url),'utf8').replace(/^import\s[\s\S]*?from\s+['"][^'"]+['"]\s*\r?\n/gm,'')
  vm.runInNewContext(code,{...game,...settings,...sound,...visual,...touch,...expansion,advanceForTest,
    Date:Clock,LocalStorage:Storage,Page:p=>page=p,
    createWidget:(type,p)=>{const w={type,p,setProperty(){},addEventListener(){},createWidget(){return {setProperty(){},addEventListener(){}}}};widgets.add(w);return w},
    deleteWidget:w=>widgets.delete(w),widget:enums,align:enums,text_style:enums,prop:enums,anim_status:enums,event:enums,
    createConnect(){},disConnect(){},sendBluetooth(){},Accelerometer:class{setFreqMode(){}onChange(){}start(){}stop(){}offChange(){}},
    Vibrator:class{start(){}},FREQ_MODE_NORMAL:0,VIBRATOR_SCENE_SHORT_LIGHT:0,VIBRATOR_SCENE_NOTIFICATION:0,
    createMedia(){throw Error('No audio in mock')},mediaId:enums,setTimeout:()=>1,clearTimeout(){},setInterval:()=>1,clearInterval(){},console})
  page.onInit();page.build()
  return {values,page,widgets,click(label){const w=[...widgets].find(w=>w.type==='BUTTON'&&w.p.text===label);assert.ok(w,'button '+label);w.p.click_func()}}
}
test('real menu callback persists one phase per tap and reopening never triggers test evolution',()=>{
  const original=egg();let ui=watch(original)
  assert.equal(ui.values.get(settings.PET_SAVE_KEY).stage,0)
  ui.click('MENU');ui.click('FERRAMENTAS');ui.click('TESTES')
  assert.equal(ui.values.get(settings.PET_SAVE_KEY).stage,0)
  for(let stage=1;stage<=4;stage++){
    ui.click('AVANCAR EVOLUCAO')
    const saved=ui.values.get(settings.PET_SAVE_KEY)
    assert.equal(saved.stage,stage);assert.equal(saved.schema,1)
    for(const key of ['hunger','joy','hygiene','energy','thirst','health','careCount','generation','gamesWon'])assert.equal(saved[key],original[key],key)
  }
  assert.ok(![...ui.widgets].some(w=>w.p.text==='AVANCAR EVOLUCAO'))
  ui.page.onDestroy()
  const adult=ui.values.get(settings.PET_SAVE_KEY)
  ui=watch(adult)
  assert.equal(ui.values.get(settings.PET_SAVE_KEY).stage,4)
  assert.equal(ui.values.get(settings.PET_SAVE_KEY).generation,adult.generation)
})

test('TESTES does not overlap MENU on Ferramentas screen',()=>{
  const ui=watch(egg());ui.click('MENU');ui.click('FERRAMENTAS');
  const labels=['SONS E ALERTAS','TEMPERATURA','PAUSA','RELOGIO','TESTES','MENU'];
  const btns=[...ui.widgets].filter(w=>w.type==='BUTTON');
  for(const label of labels)assert.ok(btns.some(w=>w.p.text===label),label);
  for(let i=0;i<btns.length;i++)for(let j=i+1;j<btns.length;j++){
    const a=btns[i].p,b=btns[j].p;
    assert.equal(a.x<b.x+b.w&&b.x<a.x+a.w&&a.y<b.y+b.h&&b.y<a.y+a.h,false,a.text+' overlaps '+b.text)
  }
})

test('category navigation has real interaction and settings grouped',()=>{
 const a=watch({...egg(),stage:2, bornAt:now-2*game.DAY})
 a.click('MENU');a.click('ALIMENTACAO');a.click('SOBREMESAS');a.click('PUDIM')
 assert.equal(a.values.get(settings.PET_SAVE_KEY).dessertsToday,1)
 a.click('OK');a.click('MENU');a.click('ESTUDOS');a.click('MATEMATICA')
 assert.ok([...a.widgets].filter(x=>x.type==='BUTTON').length>=4)
 const answers=[...a.widgets].filter(x=>x.type==='BUTTON'&&x.p.text!=='ESTUDOS')
 answers[0].p.click_func()
 assert.equal(a.values.get(settings.PET_SAVE_KEY).studyCount,1)
 a.click('OK');a.click('MENU');a.click('JOGOS');a.click('0 OU 1');a.click('0')
 assert.equal(a.values.get(settings.PET_SAVE_KEY).extraGames,1)
 a.click('OK');a.click('MENU');a.click('FERRAMENTAS');a.click('TESTES')
 assert.ok([...a.widgets].some(w=>w.p.text==='AVANCAR EVOLUCAO'))
})

test('sleep draws only dim static graphics until explicit wake',()=>{
 const s={...egg(),stage:2,bornAt:now-2*game.DAY,energy:95}
 const a=watch(s)
 a.click('MENU');a.click('DESCANSO');a.click('DORMIR')
 const data=a.values.get(settings.PET_SAVE_KEY)
 assert.equal(data.awake,false)
 assert.ok([...a.widgets].some(w=>w.type==='IMG'&&w.p.src==='scenes/night.png'))
 assert.equal([...a.widgets].some(w=>w.type==='IMG_ANIM'),false)
 a.click('ACORDAR')
 assert.equal(a.values.get(settings.PET_SAVE_KEY).awake,true)
 assert.ok([...a.widgets].some(w=>w.type==='IMG_ANIM'))
})

test('main eight categories have non-overlapping tap targets',()=>{
 const a=watch(egg());a.click('MENU')
 const boxes=[...a.widgets].filter(w=>w.type==='BUTTON').map(w=>w.p)
 assert.equal(boxes.length,9)
 for(let i=0;i<boxes.length;i++)for(let j=i+1;j<boxes.length;j++){
  const p=boxes[i],q=boxes[j]
  assert.equal(p.x<q.x+q.w&&q.x<p.x+p.w&&p.y<q.y+q.h&&q.y<p.y+p.h,false,p.text+' x '+q.text)
 }
})

test('category submenus keep buttons separated from navigation footer',()=>{
 const menus=['ALIMENTACAO','JOGOS','HIGIENE','ESTUDOS','DESCANSO','SAUDE','FERRAMENTAS']
 for(const name of menus){
   const a=watch({...egg(),stage:2,bornAt:now-2*game.DAY})
   a.click('MENU');a.click(name)
   const buttons=[...a.widgets].filter(w=>w.type==='BUTTON').map(w=>w.p)
   for(let i=0;i<buttons.length;i++)for(let j=i+1;j<buttons.length;j++){
     const p=buttons[i],q=buttons[j]
     const overlaps=p.x<q.x+q.w && q.x<p.x+p.w && p.y<q.y+q.h && q.y<p.y+p.h
     assert.equal(overlaps,false,name+': '+p.text+' x '+q.text)
   }
 }
})

test('hygiene submenu does not remove poop when bathing, but does when cleaning floor',()=>{
 const s={...egg(),stage:2,bornAt:now-2*game.DAY,poop:3,hygiene:38}
 const a=watch(s)
 a.click('MENU');a.click('HIGIENE');a.click('DAR BANHO')
 assert.equal(a.values.get(settings.PET_SAVE_KEY).poop,3)
 a.click('OK');a.click('MENU');a.click('HIGIENE');a.click('LIMPAR COCO')
 assert.equal(a.values.get(settings.PET_SAVE_KEY).poop,0)
})
