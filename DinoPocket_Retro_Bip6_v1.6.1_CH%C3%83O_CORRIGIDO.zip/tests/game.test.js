import test from 'node:test'
import assert from 'node:assert/strict'
import {newGame, tick, act, revive, stageForAge, determineSpecies, DAY, HOUR, spriteName} from '../src/game.js'

const start = Date.UTC(2026,9,8,12,0,0)
const b = () => newGame(start)

test('ovo nasce e evolui exatamente a cada 24 horas', () => {
  assert.equal(tick(b(),start+DAY-1).stage,0)
  assert.equal(tick(b(),start+DAY).stage,1)
  assert.equal(tick(b(),start+2*DAY).stage,2)
  assert.equal(tick(b(),start+3*DAY).stage,3)
  assert.equal(tick(b(),start+4*DAY).stage,4)
})

test('ovo nao sofre perdas durante o primeiro dia', () => {
  const x=tick(b(),start+DAY-1)
  assert.equal(x.health,100)
  assert.ok(x.hunger>=70)
})

test('alimentar altera cuidados e contagem da rota de evolucao', () => {
  let x=tick(b(),start+DAY)
  const oldH=x.hunger
  x=act(x,'carne',start+DAY)
  assert.equal(x.meals.carne,1)
  assert.ok(x.hunger>oldH)
  assert.equal(determineSpecies(x.meals),'rex')
})

test('evolucao final por comida carnivoro herbivoro e misto', () => {
  assert.equal(determineSpecies({carne:4,vegetais:1,massa:2}),'rex')
  assert.equal(determineSpecies({carne:1,vegetais:6,massa:0}),'bronto')
  assert.equal(determineSpecies({carne:1,vegetais:1,massa:2}),'trike')
  assert.equal(determineSpecies({carne:2,vegetais:2,massa:2}),'trike')
})

test('especie fica travada quando adulto', () => {
  let x=b()
  x.meals={carne:10,vegetais:0,massa:0}
  x=tick(x,start+4*DAY)
  assert.equal(x.species,'rex')
  for(let i=0;i<20;i++) x=act(x,'vegetais',start+4*DAY)
  assert.equal(x.species,'rex')
})

test('brincadeira consome energia, banho limpa, sono recupera', () => {
  let x=tick(b(),start+DAY)
  const e=x.energy
  x=act(x,'brincar',start+DAY)
  assert.ok(x.energy<e)
  x={...x,poop:2,hygiene:15}
  x=act(x,'banho',start+DAY)
  assert.equal(x.poop,2) // banho cuida do corpo, nao do chao
  x=act(x,'dormir',start+DAY)
  assert.ok(x.energy>e-12)
})

test('estado persiste por serializacao e tempo offline contabilizado', () => {
  const x=act(tick(b(),start+DAY),'carne',start+DAY)
  const persisted=JSON.parse(JSON.stringify(x))
  const after=tick(persisted,start+DAY+4*HOUR)
  assert.equal(after.meals.carne,1)
  assert.ok(after.hunger<x.hunger)
})

test('abandono prolongado gera morte e novo ovo incrementa geracao', () => {
  const x=tick(b(),start+10*DAY)
  assert.equal(x.dead,true)
  assert.equal(spriteName(x),'ghost.png')
  const next=revive(x,start+11*DAY)
  assert.equal(next.dead,false)
  assert.equal(next.stage,0)
  assert.equal(next.generation,2)
})

test('relogio alterado para tras nao reduz atributos', () => {
  const x=act(tick(b(),start+DAY),'carne',start+DAY)
  const y=tick(x,start+DAY-HOUR)
  assert.equal(y.hunger,x.hunger)
  assert.equal(y.meals.carne,1)
})

test('limites de atributos entre 0 e 100', () => {
  let x=tick(b(),start+DAY)
  for(let n=0;n<35;n++) x=act(x,'carne',start+DAY)
  assert.ok(x.hunger<=100 && x.hunger>=0)
  assert.ok(x.health<=100)
})
