// DinoPocket 1.6.0: escolhas reais, sem bibliotecas externas ou nova chave de save.
// Preserva dinopocket.state.v1 / schema 1; nao muta o objeto recebido.
const clamp = v => Math.min(100, Math.max(0, Number(v) || 0))
const defaults = s => ({...s,
  teethCare: clamp(s.teethCare ?? 60), handCare:clamp(s.handCare ?? 60),
  dessertsToday:Math.max(0, Number(s.dessertsToday)||0),
  dessertDay:typeof s.dessertDay==='string'?s.dessertDay:'',
  extraGames:Math.max(0,Number(s.extraGames)||0),extraWins:Math.max(0,Number(s.extraWins)||0),
  studyCorrect:Math.max(0,Number(s.studyCorrect)||0),
  studiesBySubject:{...{matematica:0,ingles:0,portugues:0},...(s.studiesBySubject||{})}
})
export const TOPICS=['matematica','ingles','portugues']
export function cleanCare(s,kind){
  const t=defaults(s)
  if(kind==='escovar')return {...t,teethCare:clamp(t.teethCare+35),hygiene:clamp(t.hygiene+9),health:clamp(t.health+2),careCount:(t.careCount||0)+1,message:'Dentinhos escovados!'}
  if(kind==='lavar_maos')return {...t,handCare:clamp(t.handCare+40),hygiene:clamp(t.hygiene+7),careCount:(t.careCount||0)+1,message:'Maos limpinhas!'}
  return t
}
export function giveDessert(s,type,now=Date.now()){
  const t=defaults(s)
  const date=new Date(now)
  const today=date.getFullYear()+'-'+(date.getMonth()+1)+'-'+date.getDate()
  const count=t.dessertDay===today?t.dessertsToday:0
  if(count>=2)return {...t,message:'Doces so duas vezes por dia!'}
  const labels={fruta:'Salada de frutas!',pudim:'Pudim delicioso!',sorvete:'Sorvete geladinho!'}
  if(!labels[type])return t
  return {...t,dessertDay:today,dessertsToday:count+1,hunger:clamp(t.hunger+8),joy:clamp(t.joy+9),hygiene:clamp(t.hygiene-2),poopProgress:Math.min(0.99999,(t.poopProgress||0)+0.1),message:labels[type]}
}
export function playGuess(s,choice,opponent,now=Date.now()){
  const t=defaults(s)
  if(![0,1].includes(choice)||![0,1].includes(opponent))return {state:t,result:'invalido'}
  const won=choice===opponent
  return {state:{...t,extraGames:t.extraGames+1,extraWins:t.extraWins+(won?1:0),
    gamesPlayed:(t.gamesPlayed||0)+1,gamesWon:(t.gamesWon||0)+(won?1:0),
    joy:clamp(t.joy+(won?12:4)),energy:clamp(t.energy-4),lastGameAt:now,
    message:'Dino: '+opponent+' | '+(won?'ACERTOU!':'ERROU!')},result:won?'ganhou':'perdeu',opponent}
}
export function playParity(s,parity,number,opponent,now=Date.now()){
  const t=defaults(s)
  if(!['par','impar'].includes(parity)||!Number.isInteger(number)||number<0||number>5||!Number.isInteger(opponent)||opponent<0||opponent>5)return {state:t,result:'invalido'}
  const total=number+opponent
  const won=(total%2===0?'par':'impar')===parity
  return {state:{...t,extraGames:t.extraGames+1,extraWins:t.extraWins+(won?1:0),
    gamesPlayed:(t.gamesPlayed||0)+1,gamesWon:(t.gamesWon||0)+(won?1:0),
    joy:clamp(t.joy+(won?14:4)),energy:clamp(t.energy-5),lastGameAt:now,
    message:number+' + '+opponent+' = '+total+' ('+(total%2?'IMPAR':'PAR')+') '+(won?'GANHOU!':'PERDEU!')},result:won?'ganhou':'perdeu',opponent}
}
export function questionFor(topic,seed=0){
  const n=Math.abs(Math.trunc(Number(seed)||0))
  const bank={
    matematica:[
      {question:'QUANTO E 4 + 3?',choices:['6','7','8'],correct:1},
      {question:'QUANTO E 9 - 5?',choices:['4','3','5'],correct:0},
      {question:'QUANTO E 3 X 2?',choices:['5','7','6'],correct:2},
      {question:'METADE DE 10?',choices:['5','2','7'],correct:0},
      {question:'QUANTO E 2 + 8?',choices:['9','10','12'],correct:1}
    ],
    ingles:[
      {question:'CAT EM PORTUGUES?',choices:['GATO','CAO','PATO'],correct:0},
      {question:'BLUE SIGNIFICA?',choices:['VERDE','AZUL','ROXO'],correct:1},
      {question:'THANK YOU E?',choices:['OI','POR FAVOR','OBRIGADO'],correct:2},
      {question:'DOG EM PORTUGUES?',choices:['GATO','CACHORRO','SOL'],correct:1},
      {question:'RED SIGNIFICA?',choices:['VERMELHO','AMARELO','BRANCO'],correct:0}
    ],
    portugues:[
      {question:'QUAL E UMA VOGAL?',choices:['B','A','T'],correct:1},
      {question:'PLURAL DE FLOR?',choices:['FLORES','FLORAS','FLOR'],correct:0},
      {question:'OPosto DE ALTO?',choices:['LONGO','BAIXO','LARGO'],correct:1},
      {question:'QUANTAS SILABAS: CASA?',choices:['1','3','2'],correct:2},
      {question:'COMPLETE: BOM ___',choices:['DIA','DIE','DOI'],correct:0}
    ]
  }
  if(!TOPICS.includes(topic))return null
  return {...bank[topic][n%bank[topic].length],topic}
}
export function answerStudy(s,question,index,now=Date.now()){
  const t=defaults(s)
  if(!question||!TOPICS.includes(question.topic)||!Number.isInteger(index)||index<0||index>=question.choices.length)return {state:t,result:'invalido'}
  const correct=index===question.correct
  return {state:{...t,studyCount:(t.studyCount||0)+1,studyCorrect:t.studyCorrect+(correct?1:0),
    studiesBySubject:{...t.studiesBySubject,[question.topic]:t.studiesBySubject[question.topic]+1},
    intelligence:clamp(t.intelligence+(correct?7:1)),discipline:clamp((t.discipline||65)+(correct?2:0)),
    energy:clamp(t.energy-3),joy:clamp(t.joy+(correct?3:0)),updatedAt:now,
    message:correct?'PARABENS! RESPOSTA CERTA.':'TENTE DE NOVO. RESPOSTA: '+question.choices[question.correct]},result:correct?'certo':'errado'}
}
export function sceneFor(s){
  if(!s||s.dead)return 'ghost'
  if(s.awake===false)return 'night'
  if(s.stage===0)return 'egg'
  if(s.sick)return 'sick'
  if(s.poop>=2||s.hygiene<25)return 'dirty'
  if(s.stage===1)return 'baby'
  if(s.stage===2)return 'small'
  if(s.stage===3)return 'young'
  return ['rex','trike','bronto'].includes(s.species)?s.species:'trike'
}
