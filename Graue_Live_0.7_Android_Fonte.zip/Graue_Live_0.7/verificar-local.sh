#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/android"
mkdir -p build/selftest
ROOT=app/src/main/java/br/com/doapps/grauelive
TEST=app/src/test/java/br/com/doapps/grauelive
javac -d build/selftest \
  "$ROOT/PitchDetector.java" "$ROOT/ChromaAnalyzer.java" "$ROOT/MusicBrain.java" \
  "$ROOT/GrauePacket.java" "$ROOT/CifraLinks.java" "$ROOT/MidiChordClassifier.java" \
  "$ROOT/XpsPreset.java" "$ROOT/XpsCatalog.java" \
  "$TEST/AudioLogicSelfTest.java" "$TEST/Harmony04SelfTest.java" \
  "$TEST/CifraLinksSelfTest.java" "$TEST/MidiChordSelfTest.java" "$TEST/XpsControlSelfTest.java"
for t in AudioLogicSelfTest Harmony04SelfTest CifraLinksSelfTest MidiChordSelfTest XpsControlSelfTest; do
  java -cp build/selftest "br.com.doapps.grauelive.$t"
done
