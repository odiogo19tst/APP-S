package br.com.doapps.grauelive;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.content.res.ColorStateList;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Website embedded in a dedicated, first-party WebView. No scraping, DOM injection,
 * credential capture, paywall bypass or copying the site's charts into the app.
 * Site login uses the WebView's own cookie jar, not the Chrome or native-app jar.
 */
public final class CifraClubPanel extends LinearLayout {
    private static final String HOME = "https://www.cifraclub.com.br/";
    private final WebView browser;
    private final TextView musicalHud;
    private final TextView navigationStatus;
    private boolean started;

    public CifraClubPanel(Context context, Runnable onClose) {
        super(context);
        setOrientation(VERTICAL);
        setBackgroundColor(0xFF0C1727);
        setPadding(dp(8), dp(8), dp(8), dp(8));

        LinearLayout toolbar = new LinearLayout(context);
        toolbar.setOrientation(HORIZONTAL);
        Button back = makeButton(context,"← Ao vivo");
        Button home = makeButton(context,"Cifra Club");
        toolbar.addView(back, new LayoutParams(0, dp(56), 1));
        toolbar.addView(home, new LayoutParams(0, dp(56), 1));
        addView(toolbar);
        back.setOnClickListener(v->onClose.run());

        musicalHud = new TextView(context);
        musicalHud.setTextColor(0xFF69E2B4);
        musicalHud.setTextSize(17);
        musicalHud.setPadding(dp(10),dp(10),dp(10),dp(10));
        musicalHud.setText("♫ Aguardando áudio • Tom indefinido");
        addView(musicalHud);

        navigationStatus = new TextView(context);
        navigationStatus.setTextColor(0xFFD5E3EF);
        navigationStatus.setTextSize(12);
        navigationStatus.setText("Site oficial do Cifra Club • login feito no próprio site");
        addView(navigationStatus);

        browser = new WebView(context);
        browser.setBackgroundColor(Color.WHITE);
        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setSupportMultipleWindows(false);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        CookieManager cookies = CookieManager.getInstance();
        cookies.setAcceptCookie(true);
        // Optional federated sign-in may use third-party cookies; never read cookies.
        cookies.setAcceptThirdPartyCookies(browser, true);
        browser.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                navigationStatus.setText("Navegando no Cifra Club • sessão sujeita às regras do site");
                CookieManager.getInstance().flush();
            }
        });
        browser.setWebChromeClient(new WebChromeClient());
        browser.setSaveEnabled(true);
        addView(browser, new LayoutParams(LayoutParams.MATCH_PARENT, 0, 1));
        home.setOnClickListener(v->browser.loadUrl(HOME));

        // Fallback for providers that block embedded OAuth sign-in. This opens a
        // separate browser session; those cookies do NOT transfer to this WebView.
        Button external = makeButton(context,"Abrir no navegador (sessão separada)");
        addView(external, new LayoutParams(LayoutParams.MATCH_PARENT, dp(56)));
        external.setOnClickListener(v -> context.startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(HOME))));
    }

    private static Button makeButton(Context ctx,String caption) {
        Button b=new Button(ctx);
        b.setAllCaps(false);
        b.setText(caption);
        b.setTextColor(Color.WHITE);
        b.setTextSize(13);
        b.setMinHeight(dp(56));
        b.setPadding(dp(6),dp(8),dp(6),dp(8));
        GradientDrawable shape=new GradientDrawable();shape.setColor(0xFF1E4C78);shape.setCornerRadius(dp(12));
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF),shape,null));
        return b;
    }

    private static int dp(int n){return (int)(n*android.content.res.Resources.getSystem().getDisplayMetrics().density+0.5f);}
    public void open() {
        setVisibility(VISIBLE);
        if(!started){ browser.loadUrl(HOME); started=true; }
    }
    public void openUrl(String officialCifraClubUrl){
        setVisibility(VISIBLE);
        started=true;
        browser.loadUrl(officialCifraClubUrl);
    }
    public void updateMusic(String note, String key, String chord) {
        musicalHud.setText("♫ "+note+"   |   "+key+"   |   "+chord);
    }
    public boolean goBackInSite() {
        if(browser.canGoBack()){browser.goBack();return true;}
        return false;
    }
    public void saveSession() { CookieManager.getInstance().flush(); }
    public void dispose() { saveSession(); browser.destroy(); }
}
