package br.com.doapps.grauelive;

import java.net.URI;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Import a shared original URL, never download or copy copyrighted chart content. */
public final class CifraLinks {
    private static final Pattern URL = Pattern.compile("https://[^\\s<>]+",Pattern.CASE_INSENSITIVE);
    private CifraLinks() {}
    public static String fromShareText(String sharedText) {
        if(sharedText==null)return null;
        Matcher m=URL.matcher(sharedText);
        while(m.find()){
            String candidate=m.group().replaceAll("[.,;)]+$", "");
            try {
                URI uri=URI.create(candidate);
                String host=uri.getHost();
                if(host==null)continue;
                if(!"https".equalsIgnoreCase(uri.getScheme()))continue;
                if(!("cifraclub.com.br".equalsIgnoreCase(host)||"www.cifraclub.com.br".equalsIgnoreCase(host)))continue;
                if(uri.getUserInfo()!=null)continue;
                return candidate;
            } catch(IllegalArgumentException ignored){}
        }
        return null;
    }
}
