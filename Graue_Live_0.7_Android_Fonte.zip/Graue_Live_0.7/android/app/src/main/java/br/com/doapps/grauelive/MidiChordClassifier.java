package br.com.doapps.grauelive;

import java.util.Set;

/** Limited 3-note triad recognition for incoming MIDI notes. */
public final class MidiChordClassifier {
    private MidiChordClassifier(){}
    public static String label(Set<Integer> held){
        if(held==null||held.size()<3)return "Acorde ainda indefinido";
        boolean[] pc=new boolean[12];
        for(int n:held)if(n>=0&&n<=127)pc[n%12]=true;
        for(int r=0;r<12;r++)if(pc[r]&&pc[(r+7)%12]){
            if(pc[(r+4)%12])return MusicBrain.NOTE[r]+" maior (tríade)";
            if(pc[(r+3)%12])return MusicBrain.NOTE[r]+" menor (tríade)";
        }
        return "Acorde ainda indefinido";
    }
}
