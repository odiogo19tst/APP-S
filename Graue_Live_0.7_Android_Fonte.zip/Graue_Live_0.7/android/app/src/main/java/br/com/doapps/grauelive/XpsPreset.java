package br.com.doapps.grauelive;

/** MIDI bank map of Roland XPS-10 original (not XPS-10X). Human slots are 1-based. */
public final class XpsPreset {
  public enum Group { USER_PATCH, USER_PERFORMANCE, PRESET_PATCH, PRESET_PERFORMANCE }
  public final Group group;
  public final int number, msb, lsb, program;
  private XpsPreset(Group g,int n,int m,int l,int p){group=g;number=n;msb=m;lsb=l;program=p;}
  public static int capacity(Group g){switch(g){case USER_PATCH:return 256;case USER_PERFORMANCE:return 128;case PRESET_PATCH:return 1273;default:return 16;}}
  public static XpsPreset of(Group g,int n){if(g==null||n<1||n>capacity(g))throw new IllegalArgumentException("Slot inválido");
    switch(g){case USER_PATCH:return new XpsPreset(g,n,87,(n-1)/128,(n-1)%128);
      case USER_PERFORMANCE:return new XpsPreset(g,n,85,0,n-1);
      case PRESET_PATCH:return new XpsPreset(g,n,87,64+(n-1)/128,(n-1)%128);
      default:return new XpsPreset(g,n,85,64,n-1);}
  }
  public String id(){return group.name()+":"+number;}
  public String slot(){String kind=group==Group.USER_PATCH?"User Patch":group==Group.USER_PERFORMANCE?"User Performance":group==Group.PRESET_PATCH?"Preset Patch":"Preset Performance";
    return kind+" "+String.format(java.util.Locale.US,"%03d",number);
  }
  public static XpsPreset parse(String key){try{String[] a=key.split(":");return a.length==2?of(Group.valueOf(a[0]),Integer.parseInt(a[1])):null;}catch(Exception e){return null;}}
  /** Wire bytes: CC0 bank MSB, CC32 LSB, Program Change. No SysEx/write. */
  public byte[] messages(int channel){if(channel<1||channel>16)throw new IllegalArgumentException("Canal MIDI 1..16");int c=channel-1;
    return new byte[]{(byte)(0xB0+c),0,(byte)msb,(byte)(0xB0+c),32,(byte)lsb,(byte)(0xC0+c),(byte)program};
  }
}
