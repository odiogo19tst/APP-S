package br.com.doapps.grauelive;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.content.res.ColorStateList;
import android.graphics.drawable.RippleDrawable;
import android.widget.ImageView;
import android.provider.DocumentsContract;
import android.content.ClipData;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.FrameLayout;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.text.TextWatcher;
import android.text.Editable;
import android.widget.Toast;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Locale;

/** Visible foreground-only prototype: microphone stays active while app is open. */
public final class MainActivity extends Activity {
    private static final int BG=0xFF071426,CARD=0xFF152942,WHITE=0xFFF5FAFF,MINT=0xFF64EFB9,MUTED=0xFFAABFD3,BLUE=0xFF3388D9;
    private TextView note,key,degree,chords,detectedChord,bleStatus,audioStatus,subtitle;
    private Button start,bluetooth,demo,modeButton,confirmButton,newSongButton;
    private CifraClubPanel cifraPanel;
    private ScrollView liveScreen;
    private ScrollView keyboardScreen, vaultScreen;
    private LinearLayout vaultItems, nav;
    private FrameLayout tabHost;
    private XpsMidiMonitor midiMonitor;
    private BackupVault backupVault;
    private XpsCatalogStore catalogStore;
    private XpsCatalog xpsCatalog;
    private LinearLayout quickFavorites, catalogEntries;
    private TextView catalogCounter, selectedSound, liveKeyboardStatus;
    private Spinner soundGroup, channelSpinner;
    private EditText soundFilter;
    private int soundPage=0;
    private XpsPreset lastSelection;
    private static final int REQ_CATALOG_IMPORT=611, REQ_CATALOG_EXPORT=612;
    private TextView midiStatus, midiNotes, midiChord;
    private Button[] navButtons=new Button[4];
    private int currentTab=0;
    private static final int REQ_IMPORT=601,REQ_EXPORT=602;
    private String exportSha;
    private TextView diagnostic;
    private AudioAnalyzer audio;private BlePeripheral ble;
    private int sequence=0;private long lastPacket=0;
    private boolean liveListening=false;
    private boolean keyIsLocked=false;
    private final MusicBrain demoBrain=new MusicBrain();
    @Override public void onCreate(Bundle b){super.onCreate(b);
        catalogStore=new XpsCatalogStore(this);xpsCatalog=catalogStore.load();buildUi();
        ble=new BlePeripheral(this,s->runOnUiThread(()->bleStatus.setText(s)));
        backupVault=new BackupVault(this);
        midiMonitor=new XpsMidiMonitor(this,new XpsMidiMonitor.Listener(){
            @Override public void onStatus(String s){runOnUiThread(()->{
                midiStatus.setText(s);if(liveKeyboardStatus!=null)liveKeyboardStatus.setText(s);
            });}
            @Override public void onNotes(String n,String c){runOnUiThread(()->{midiNotes.setText(n);midiChord.setText(c);});}
        });
        refreshVault();
        refreshQuickFavorites();refreshSoundCatalog();
        audio=new AudioAnalyzer(new AudioAnalyzer.Callback(){
            @Override public void onResult(PitchDetector.Result p,MusicBrain.Harmony h){
                long now=SystemClock.elapsedRealtime();
                // Bluetooth deliberately disabled until the Bip 6 reboot defect is diagnosed.
                runOnUiThread(()->render(p,h));
            }
            @Override public void onError(String s){runOnUiThread(()->audioStatus.setText(s));}
        });
        start.setOnClickListener(v->{if(audio.isRunning()){stopAudio("Microfone parado");}
            else if(checkPermission(Manifest.permission.RECORD_AUDIO))startAudio();else requestAllPermissions();});
        bluetooth.setEnabled(false); // Bip 6 has rebooted on BLE connect; inhibit until on-device diagnosis.
        modeButton.setOnClickListener(v->{int next=audio.manualMode()==-1?0:(audio.manualMode()==0?1:-1);audio.setManualMode(next);
            modeButton.setText(next==-1?"Modo: automático":next==0?"Modo: priorizar MAIOR":"Modo: priorizar MENOR");
            keyIsLocked=false;confirmButton.setText("Confirmar tom sugerido");
            key.setText("Reavaliando o tom...");});
        newSongButton.setOnClickListener(v->{audio.resetAnalysis();keyIsLocked=false;confirmButton.setText("Confirmar tom sugerido");
            key.setText("Tom: recomeçando análise");degree.setText("Grau: —");chords.setText("Aguardando novas frases");
            detectedChord.setText("Acorde detectado: aguardando");});
        confirmButton.setOnClickListener(v->{
            if(!keyIsLocked){if(audio.confirmKey()){keyIsLocked=true;confirmButton.setText("Liberar tom confirmado");}else{audioStatus.setText("Aguarde melodia ou acordes para confirmar o tom");}}
            else{audio.unlockKey();keyIsLocked=false;confirmButton.setText("Confirmar tom sugerido");}
        });
        demo.setOnClickListener(v->{
            // Synthetic melody tests the BLE path independently from microphone.
            int[] melody={67,69,71,72,74,76,74,71,69,67,71,74};
            demoBrain.reset();MusicBrain.Harmony h=null;
            for(int m:melody)h=demoBrain.accept(m);
            if(h!=null)render(new PitchDetector.Result(0,1,0,h.midi),h);
            audioStatus.setText("Exemplo calculado no celular (sem áudio real, sem Bluetooth)");
        });
        // If user shared a Cifra Club song link from Android, show its original page.
        handleSharedCifra(getIntent());
        // Request microphone only when the user starts listening.
    }
    private boolean checkPermission(String p){return checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
    private void requestAllPermissions(){
        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},101);
    }
    @Override protected void onNewIntent(Intent intent){
        super.onNewIntent(intent);setIntent(intent);handleSharedCifra(intent);
    }
    private void handleSharedCifra(Intent intent){
        if(intent==null||!Intent.ACTION_SEND.equals(intent.getAction()))return;
        String text=intent.getStringExtra(Intent.EXTRA_TEXT);
        if(text==null)return;
        // Parse shared URL only; never read protected content or login cookies.
        String url=CifraLinks.fromShareText(text);
        if(url!=null){showTab(1);cifraPanel.openUrl(url);}
    }

    private void startAudio(){
        audio.start();
        if(audio.isRunning()){
            liveListening=true;
            start.setText("■  PARAR ESCUTA");
            audioStatus.setText("Microfone captando • aguardando sinal musical");
        }
    }
    private void stopAudio(String status){
        audio.stop(); liveListening=false;
        start.setText("●  INICIAR ESCUTA");
        audioStatus.setText(status);
    }
    @Override public void onRequestPermissionsResult(int code,String[] perms,int[] grants){
        super.onRequestPermissionsResult(code,perms,grants);
        if(code!=101)return;
        if(grants.length>0 && grants[0]==PackageManager.PERMISSION_GRANTED)startAudio();
        else audioStatus.setText("Microfone negado: habilite nas permissões do Android");
    }
    @Override protected void onStop(){
        if(audio!=null&&audio.isRunning())stopAudio("Escuta pausada ao sair do Grauê");
        if(midiMonitor!=null)midiMonitor.close();
        if(cifraPanel!=null)cifraPanel.saveSession();
        super.onStop();
    }
    @Override public void onBackPressed(){
        if(currentTab==1){
            if(!cifraPanel.goBackInSite())showTab(0);
            return;
        }
        if(currentTab!=0){showTab(0);return;}
        super.onBackPressed();
    }
    private void buildUi(){
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        ScrollView scroll=scrollPage(); liveScreen=scroll;
        LinearLayout root=pageContent(scroll);
        LinearLayout brand=new LinearLayout(this);brand.setGravity(Gravity.CENTER_VERTICAL);brand.setOrientation(LinearLayout.HORIZONTAL);
        ImageView logo=new ImageView(this);logo.setImageResource(R.drawable.graue_logo);
        brand.addView(logo,new LinearLayout.LayoutParams(dp(62),dp(62)));
        LinearLayout labels=new LinearLayout(this);labels.setOrientation(LinearLayout.VERTICAL);labels.setPadding(dp(12),0,0,0);
        labels.addView(txt("GRAUÊ  LIVE",24,WHITE,true));
        subtitle=txt("Copiloto musical  •  Android + Bip 6",12,MUTED,false);labels.addView(subtitle);
        brand.addView(labels);root.addView(brand);root.addView(space(18));
        LinearLayout hero=card(root);
        hero.addView(label("NOTA PREDOMINANTE",12));
        note=txt("—",62,WHITE,true);note.setGravity(Gravity.CENTER);hero.addView(note);
        key=txt("Tom: analisando melodia",18,MINT,true);key.setGravity(Gravity.CENTER);hero.addView(key);
        degree=txt("Grau: —",15,MUTED,false);degree.setGravity(Gravity.CENTER);hero.addView(degree);
        root.addView(space(12));
        LinearLayout predictions=card(root);
        predictions.addView(label("ACOMPANHAMENTO / SUGESTÕES",12));
        chords=txt("Aguardando notas suficientes",22,WHITE,true);predictions.addView(chords);
        detectedChord=txt("Acorde detectado: aguardando",14,MINT,false);predictions.addView(detectedChord);
        predictions.addView(txt("Sugestões são estimativas; não os acordes originais da música",11,MUTED,false));
        root.addView(space(14));
        LinearLayout liveMidi=card(root);
        liveMidi.addView(txt("🎹  TROCA RÁPIDA DE TIMBRES",18,WHITE,true));
        liveMidi.addView(txt("Escolha os favoritos na aba Teclado. Toque aqui durante o louvor para trocar os sons via USB-MIDI.",12,MUTED,false));
        selectedSound=txt("Som do teclado: não selecionado",14,MINT,true);liveMidi.addView(selectedSound);
        liveKeyboardStatus=txt("Controle MIDI desativado",12,MUTED,false);liveMidi.addView(liveKeyboardStatus);
        quickFavorites=new LinearLayout(this);quickFavorites.setOrientation(LinearLayout.VERTICAL);liveMidi.addView(quickFavorites);
        Button openKeys=action(liveMidi,"Gerenciar timbres e performances  →",0xFF304761);
        openKeys.setOnClickListener(v->showTab(2));
        root.addView(space(12));
        start=action(root,"●  INICIAR ESCUTA",0xFF12795B);
        LinearLayout pair=new LinearLayout(this);pair.setOrientation(LinearLayout.HORIZONTAL);
        modeButton=action(pair,"Maior / Menor",0xFF20578E);pair.addView(spaceHorizontal(6));
        newSongButton=action(pair,"↻  Nova música",0xFF304761);
        root.addView(pair);
        confirmButton=action(root,"Confirmar tom sugerido",0xFF304761);
        bluetooth=action(root,"Bluetooth do Bip 6 suspenso por segurança",0xFF4A4056);
        bluetooth.setTextSize(13);
        demo=action(root,"▶  Testar com exemplo musical",0xFF304761);
        root.addView(space(10));
        LinearLayout debug=card(root);
        debug.addView(label("DIAGNÓSTICO EM TEMPO REAL",12));
        diagnostic=txt("Nenhuma amostra de áudio recebida",12,MUTED,false);debug.addView(diagnostic);
        audioStatus=txt("Aguardando permissão do microfone",14,WHITE,false);debug.addView(audioStatus);
        bleStatus=txt("Bip 6 não conectado (BLE bloqueado)",12,MUTED,false);debug.addView(bleStatus);
        root.addView(space(12));
        root.addView(txt("v0.6 • áudio local e análise experimental • sem IA neural nem separação de instrumentos • BLE do relógio desativado",11,MUTED,false));

        keyboardScreen=scrollPage();LinearLayout keys=pageContent(keyboardScreen);
        keys.addView(sectionTitle("🎹  Roland XPS-10","Timbres, performances e favoritos para trocar ao vivo"));
        LinearLayout monitor=card(keys);monitor.addView(label("NOTAS MIDI RECEBIDAS",12));
        midiNotes=txt("Aguardando USB MIDI",20,WHITE,true);monitor.addView(midiNotes);
        midiChord=txt("Acorde não identificado",14,MINT,false);monitor.addView(midiChord);
        keys.addView(space(12));
        Button connectMidi=action(keys,"①  CONECTAR XPS-10 VIA USB",0xFF12795B);
        connectMidi.setOnClickListener(v->midiMonitor.start());
        Button armMidi=action(keys,"②  HABILITAR TROCA DE SONS",0xFF20578E);
        armMidi.setOnClickListener(v->new android.app.AlertDialog.Builder(this)
            .setTitle("Autorizar comandos MIDI ao XPS-10?")
            .setMessage("O Grauê enviará SOMENTE seleção de banco (CC0/CC32) e programa para trocar sons na memória existente. Não instala, apaga ou sobrescreve timbres. Confirme que o cabo está conectado ao seu XPS-10 original. O som pode variar segundo o modo e canal MIDI do teclado.")
            .setNegativeButton("Cancelar",null)
            .setPositiveButton("Habilitar",(dlg,which)->{String st=midiMonitor.armControl(true);midiStatus.setText(st);liveKeyboardStatus.setText(st);}).show());
        Button stopMidi=action(keys,"Desconectar / bloquear comandos",0xFF304761);
        stopMidi.setOnClickListener(v->{midiMonitor.close();midiStatus.setText("Controle MIDI desconectado e bloqueado");liveKeyboardStatus.setText("MIDI desconectado");});
        midiStatus=txt("USB-MIDI desconectado; comandos bloqueados",14,MUTED,false);keys.addView(midiStatus);
        keys.addView(space(10));
        LinearLayout picker=card(keys);
        picker.addView(txt("BIBLIOTECA DE SONS",18,WHITE,true));
        picker.addView(txt("Os números e bancos são mapeados pelo manual MIDI. Os nomes reais do seu teclado ainda precisam ser cadastrados/importados; não foram lidos automaticamente.",12,MUTED,false));
        picker.addView(space(9));picker.addView(label("CATEGORIA",12));
        soundGroup=new Spinner(this);
        String[] types={"Timbres de usuário (256)","Performances de usuário (128)","Timbres de fábrica (1273)","Performances de fábrica (16)"};
        ArrayAdapter<String> kinds=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,types);
        soundGroup.setAdapter(kinds);picker.addView(soundGroup,new LinearLayout.LayoutParams(-1,dp(52)));
        picker.addView(label("CANAL MIDI DE CONTROLE",12));
        channelSpinner=new Spinner(this);String[] chans=new String[16];for(int ix=0;ix<16;ix++)chans[ix]="Canal "+(ix+1);
        channelSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,chans));
        picker.addView(channelSpinner,new LinearLayout.LayoutParams(-1,dp(52)));
        soundFilter=new EditText(this);soundFilter.setSingleLine(true);soundFilter.setTextColor(WHITE);soundFilter.setHintTextColor(MUTED);
        soundFilter.setHint("Buscar nome ou número do som");soundFilter.setTextSize(16);
        picker.addView(soundFilter,new LinearLayout.LayoutParams(-1,dp(54)));
        catalogCounter=txt("",13,MUTED,false);picker.addView(catalogCounter);
        catalogEntries=new LinearLayout(this);catalogEntries.setOrientation(LinearLayout.VERTICAL);picker.addView(catalogEntries);
        LinearLayout pages=new LinearLayout(this);pages.setOrientation(LinearLayout.HORIZONTAL);picker.addView(pages);
        Button previous=action(pages,"← Voltar",0xFF304761);Button next=action(pages,"Próximos →",0xFF304761);
        previous.setOnClickListener(v->{soundPage=Math.max(0,soundPage-1);refreshSoundCatalog();});
        next.setOnClickListener(v->{soundPage++;refreshSoundCatalog();});
        soundGroup.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            @Override public void onItemSelected(android.widget.AdapterView<?> p,View v,int n,long id){soundPage=0;refreshSoundCatalog();}
            @Override public void onNothingSelected(android.widget.AdapterView<?> p){}
        });
        soundFilter.addTextChangedListener(new TextWatcher(){
            @Override public void beforeTextChanged(CharSequence s,int a,int c,int after){}
            @Override public void onTextChanged(CharSequence s,int st,int before,int count){soundPage=0;refreshSoundCatalog();}
            @Override public void afterTextChanged(Editable e){}
        });
        keys.addView(space(12));
        LinearLayout importPanel=card(keys);importPanel.addView(txt("CATÁLOGO E FAVORITOS",18,WHITE,true));
        importPanel.addView(txt("Importe/exporte nomes, números e favoritos em CSV do Grauê. Não extrai timbres de arquivos proprietários de backup e não sincroniza automaticamente os FAVORITE do painel Roland.",12,MUTED,false));
        Button loadCsv=action(importPanel,"Importar catálogo CSV",0xFF20578E);loadCsv.setOnClickListener(v->chooseCatalogCsv());
        Button exportCsv=action(importPanel,"Exportar catálogo e favoritos",0xFF304761);exportCsv.setOnClickListener(v->exportCatalogCsv());
        keys.addView(space(12));
        LinearLayout inst=card(keys);inst.addView(txt("Como usar ao vivo",18,WHITE,true));
        inst.addView(txt("1. XPS-10 USB COMPUTER → cabo USB-B/USB-C OTG no celular.\n2. No teclado, selecione USB Driver = GENERIC, se necessário, e ajuste o canal de recepção MIDI.\n3. Conecte, autorize comandos, escolha um som e marque com ★.\n4. Os favoritos aparecem também no Ao Vivo para troca rápida.\n5. Se o som não mudar, confira PATCH/PERFORMANCE e MIDI Rx Bank/Program.",13,MUTED,false));
        inst.addView(txt("SEM SysEx, RESTORE, gravação em memória ou importação de samples. O Bip 6 continua com BLE bloqueado.",12,MINT,true));

        vaultScreen=scrollPage();LinearLayout vault=pageContent(vaultScreen);
        vault.addView(sectionTitle("▣  Biblioteca XPS-10","Preserve seus backups e timbres"));
        LinearLayout tip=card(vault);
        tip.addView(txt("MODO SEGURO — NÃO DESTRUTIVO",13,MINT,true));
        tip.addView(txt("O XPS-10 grava backups em pendrive: MENU → UTILITY → BACKUP. Conecte o pendrive ao celular e importe cópias aqui. RESTORE no teclado sobrescreve todos os dados de usuário.",14,WHITE,false));
        vault.addView(space(12));
        Button importBtn=action(vault,"＋  Importar backups do pendrive",0xFF12795B);
        importBtn.setOnClickListener(v->chooseBackup());
        Button mergeBtn=action(vault,"Mesclar timbres (em análise)",0xFF4A4056);
        mergeBtn.setOnClickListener(v->new android.app.AlertDialog.Builder(this)
            .setTitle("Mesclagem segura ainda indisponível")
            .setMessage("Não vamos combinar arquivos proprietários sem compreender seu formato. Os arquivos guardados aqui são cópias idênticas; o teclado nunca é modificado. Para avaliar a mesclagem, precisamos de dois backups reais do mesmo XPS-10 e conhecer a estrutura dos timbres.")
            .setPositiveButton("Entendi",null).show());
        vault.addView(space(10));vault.addView(label("BACKUPS GUARDADOS NESTE CELULAR",12));
        vaultItems=new LinearLayout(this);vaultItems.setOrientation(LinearLayout.VERTICAL);vault.addView(vaultItems);
        vault.addView(space(10));vault.addView(txt("Arquivos originais guardados com verificação SHA-256, sem conversão, substituição ou restauração. Não é possível extrair timbres isolados sem validar o formato.",12,MUTED,false));

        FrameLayout host=new FrameLayout(this);tabHost=host;
        host.addView(scroll,new FrameLayout.LayoutParams(-1,-1));
        cifraPanel=new CifraClubPanel(this,()->showTab(0));cifraPanel.setVisibility(View.GONE);host.addView(cifraPanel,new FrameLayout.LayoutParams(-1,-1));
        keyboardScreen.setVisibility(View.GONE);host.addView(keyboardScreen,new FrameLayout.LayoutParams(-1,-1));
        vaultScreen.setVisibility(View.GONE);host.addView(vaultScreen,new FrameLayout.LayoutParams(-1,-1));
        LinearLayout layout=new LinearLayout(this);layout.setOrientation(LinearLayout.VERTICAL);layout.setBackgroundColor(BG);
        layout.addView(host,new LinearLayout.LayoutParams(-1,0,1));
        nav=new LinearLayout(this);nav.setOrientation(LinearLayout.HORIZONTAL);nav.setPadding(dp(4),dp(6),dp(4),dp(8));nav.setBackgroundColor(0xFF102239);
        String[] tabs={"♫  Ao vivo","▤  Cifras","♬  Teclado","▣  Backups"};
        for(int i=0;i<tabs.length;i++){final int index=i;Button b=new Button(this);b.setAllCaps(false);b.setText(tabs[i]);b.setTextSize(12);
            b.setMinHeight(dp(56));b.setPadding(dp(1),0,dp(1),0);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(58),1);lp.setMargins(dp(2),0,dp(2),0);
            nav.addView(b,lp);navButtons[i]=b;b.setOnClickListener(v->showTab(index));}
        layout.addView(nav);setContentView(layout);showTab(0);
    }
    private ScrollView scrollPage(){ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setBackgroundColor(BG);s.setClipToPadding(false);return s;}
    private LinearLayout pageContent(ScrollView scroll){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.VERTICAL);r.setPadding(dp(16),dp(20),dp(16),dp(22));scroll.addView(r);return r;}
    private LinearLayout sectionTitle(String title,String caption){
        LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.addView(txt(title,24,WHITE,true));
        p.addView(txt(caption,14,MUTED,false));p.addView(space(14));return p;
    }
    private TextView label(String t,int size){return txt(t,size,MUTED,true);}
    private void showTab(int i){currentTab=i;
        liveScreen.setVisibility(i==0?View.VISIBLE:View.GONE);
        cifraPanel.setVisibility(i==1?View.VISIBLE:View.GONE);
        keyboardScreen.setVisibility(i==2?View.VISIBLE:View.GONE);
        vaultScreen.setVisibility(i==3?View.VISIBLE:View.GONE);
        if(i==1)cifraPanel.open();if(i==3)refreshVault();
        for(int j=0;j<navButtons.length;j++){Button b=navButtons[j];if(b==null)continue;
            b.setTextColor(j==i?0xFF06201C:WHITE);
            b.setBackground(rippleBackground(j==i?MINT:0xFF223A56,dp(14)));
        }
    }
    private GradientDrawable rounded(int color,int radius){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(radius);return g;}
    private android.graphics.drawable.Drawable rippleBackground(int color,int radius){
        return new RippleDrawable(ColorStateList.valueOf(0x55FFFFFF),rounded(color,radius),null);
    }
    private LinearLayout card(LinearLayout root){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(18),dp(17),dp(18),dp(17));
        GradientDrawable bg=rounded(CARD,dp(20));bg.setStroke(dp(1),0xFF294361);box.setBackground(bg);
        root.addView(box,new LinearLayout.LayoutParams(-1,-2));return box;}
    private Button action(LinearLayout root,String name,int color){Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setTextColor(WHITE);
        b.setBackground(rippleBackground(color,dp(14)));b.setMinHeight(dp(58));b.setPadding(dp(9),dp(6),dp(9),dp(6));
        LinearLayout.LayoutParams lp=root.getOrientation()==LinearLayout.HORIZONTAL?new LinearLayout.LayoutParams(0,dp(60),1):new LinearLayout.LayoutParams(-1,dp(60));
        lp.bottomMargin=dp(9);root.addView(b,lp);return b;}
    private View spaceHorizontal(int d){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(dp(d),1));return v;}
    private int dp(int value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}
    private TextView txt(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setPadding(0,dp(2),0,dp(5));t.setIncludeFontPadding(true);return t;}
    private View space(int amount){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp(amount)));return v;}
    private void chooseBackup(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);startActivityForResult(i,REQ_IMPORT);}
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);
        if(result!=RESULT_OK||data==null)return;
        if(request==REQ_CATALOG_IMPORT){
            Uri uri=data.getData();if(uri==null)return;
            try(InputStream in=getContentResolver().openInputStream(uri)){
                ByteArrayOutputStream buff=new ByteArrayOutputStream();byte[] ch=new byte[4096];int n;
                while((n=in.read(ch))!=-1){if(buff.size()+n>300000)throw new IllegalArgumentException("CSV maior que 300 KB");buff.write(ch,0,n);}
                int updated=xpsCatalog.importCsv(new String(buff.toByteArray(),StandardCharsets.UTF_8));
                catalogStore.save(xpsCatalog);refreshQuickFavorites();refreshSoundCatalog();
                new android.app.AlertDialog.Builder(this).setMessage(updated+" sons/favoritos locais importados").setPositiveButton("OK",null).show();
            }catch(Exception e){new android.app.AlertDialog.Builder(this).setTitle("CSV inválido").setMessage(e.getMessage()).setPositiveButton("OK",null).show();}
            return;
        }
        if(request==REQ_CATALOG_EXPORT){Uri uri=data.getData();if(uri==null)return;
            try(OutputStream out=getContentResolver().openOutputStream(uri)){
                out.write(xpsCatalog.csv().getBytes(StandardCharsets.UTF_8));
                Toast.makeText(this,"Catálogo exportado",Toast.LENGTH_SHORT).show();
            }catch(Exception e){Toast.makeText(this,"Erro de exportação: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            return;
        }
        if(request==REQ_EXPORT){
            Uri destination=data.getData();final String id=exportSha;
            if(destination!=null&&id!=null)new Thread(()->{
                String message;try{backupVault.exportOriginal(id,destination);message="Cópia original exportada, sem modificações";}
                catch(Exception e){message="Erro ao exportar: "+e.getMessage();}
                final String m=message;runOnUiThread(()->new android.app.AlertDialog.Builder(this).setMessage(m).setPositiveButton("OK",null).show());
            },"graue-export").start();
            return;
        }
        if(request!=REQ_IMPORT)return;
        java.util.ArrayList<Uri> uris=new java.util.ArrayList<>();
        if(data.getData()!=null)uris.add(data.getData());ClipData clip=data.getClipData();
        if(clip!=null)for(int i=0;i<clip.getItemCount();i++)uris.add(clip.getItemAt(i).getUri());
        new Thread(()->{StringBuilder report=new StringBuilder();for(Uri u:uris){try{report.append(backupVault.importDocument(u)).append("\n");}catch(Exception e){report.append("Erro: ").append(e.getMessage()).append("\n");}}
            runOnUiThread(()->{refreshVault();new android.app.AlertDialog.Builder(this).setTitle("Importação de cópias").setMessage(report.toString()).setPositiveButton("OK",null).show();});
        },"graue-vault").start();
    }
    private void refreshVault(){if(vaultItems==null||backupVault==null)return;vaultItems.removeAllViews();
        List<BackupVault.Item> all=backupVault.list();
        if(all.isEmpty()){vaultItems.addView(txt("Nenhum backup importado",15,MUTED,false));return;}
        for(BackupVault.Item item:all){LinearLayout c=card(vaultItems);c.addView(txt("◉ "+item.name,15,WHITE,true));
            c.addView(txt(String.format(Locale.US,"%.2f MB • SHA-256 %s...",item.size/1048576.0,item.hash.substring(0,12)),12,MUTED,false));
            Button save=action(c,"Exportar cópia original",0xFF304761);
            save.setOnClickListener(v->{exportSha=item.hash;Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("application/octet-stream");
                intent.putExtra(Intent.EXTRA_TITLE,item.name);startActivityForResult(intent,REQ_EXPORT);});
            vaultItems.addView(space(8));}
    }
    private XpsPreset.Group chosenSoundGroup(){if(soundGroup==null)return XpsPreset.Group.USER_PATCH;
        switch(soundGroup.getSelectedItemPosition()){
            case 1:return XpsPreset.Group.USER_PERFORMANCE;
            case 2:return XpsPreset.Group.PRESET_PATCH;
            case 3:return XpsPreset.Group.PRESET_PERFORMANCE;
            default:return XpsPreset.Group.USER_PATCH;
        }
    }
    private void chooseCatalogCsv(){Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");startActivityForResult(i,REQ_CATALOG_IMPORT);}
    private void exportCatalogCsv(){Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("text/csv");i.putExtra(Intent.EXTRA_TITLE,"graue_xps10_catalogo.csv");startActivityForResult(i,REQ_CATALOG_EXPORT);}
    private void selectKeyboardSound(XpsPreset preset){lastSelection=preset;
        String feedback=midiMonitor==null?"Conecte USB-MIDI primeiro":midiMonitor.sendPreset(preset,channelSpinner==null?1:channelSpinner.getSelectedItemPosition()+1);
        if(liveKeyboardStatus!=null)liveKeyboardStatus.setText(feedback);
        if(midiStatus!=null)midiStatus.setText(feedback);
        if(selectedSound!=null)selectedSound.setText((midiMonitor!=null&&midiMonitor.isArmed()?"Comando enviado: ":"Preparado no app: ")+xpsCatalog.label(preset)+" • "+preset.slot());
    }
    private void editSound(XpsPreset p){EditText edit=new EditText(this);edit.setText(xpsCatalog.alias(p));
        edit.setSingleLine(true);edit.setHint("Nome personalizado (ex: Piano Louvor)");
        new android.app.AlertDialog.Builder(this).setTitle("Renomear "+p.slot()).setView(edit)
        .setNeutralButton("Limpar nome",(d,w)->{xpsCatalog.name(p,"");catalogStore.save(xpsCatalog);refreshSoundCatalog();refreshQuickFavorites();})
        .setNegativeButton("Cancelar",null)
        .setPositiveButton("Salvar",(d,w)->{xpsCatalog.name(p,edit.getText().toString());catalogStore.save(xpsCatalog);refreshSoundCatalog();refreshQuickFavorites();}).show();
    }
    private void refreshSoundCatalog(){if(xpsCatalog==null||catalogEntries==null||soundGroup==null||soundFilter==null)return;
        XpsPreset.Group group=chosenSoundGroup();String filter=soundFilter.getText().toString();int total=xpsCatalog.count(group,filter);
        if(soundPage*12>=total)soundPage=Math.max(0,(total-1)/12);int offset=soundPage*12;
        catalogCounter.setText(total+" slots • mostrando "+(total==0?0:offset+1)+"–"+Math.min(total,offset+12)+" • Página "+(soundPage+1));
        catalogEntries.removeAllViews();
        for(XpsPreset p:xpsCatalog.page(group,filter,offset,12)){
            LinearLayout line=new LinearLayout(this);line.setOrientation(LinearLayout.VERTICAL);line.setPadding(dp(6),dp(6),dp(6),dp(6));
            line.addView(txt(xpsCatalog.label(p)+"  ("+p.slot()+")",15,WHITE,true));
            LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.HORIZONTAL);line.addView(controls);
            Button play=action(controls,"▶ Usar",0xFF12795B);play.setOnClickListener(v->selectKeyboardSound(p));
            Button star=action(controls,xpsCatalog.isFavorite(p)?"★":"☆",0xFF20578E);
            star.setOnClickListener(v->{xpsCatalog.favorite(p,!xpsCatalog.isFavorite(p));catalogStore.save(xpsCatalog);refreshSoundCatalog();refreshQuickFavorites();});
            Button name=action(controls,"✎",0xFF304761);name.setOnClickListener(v->editSound(p));
            catalogEntries.addView(line);
        }
    }
    private void refreshQuickFavorites(){if(quickFavorites==null||xpsCatalog==null)return;quickFavorites.removeAllViews();
        List<XpsPreset> favorites=xpsCatalog.favorites();
        if(favorites.isEmpty()){quickFavorites.addView(txt("Sem favoritos. Vá em Teclado, escolha o som e toque ☆ para adicioná-lo aqui.",13,MUTED,false));return;}
        int shown=0;for(XpsPreset preset:favorites){if(shown++>=8)break;
            Button b=action(quickFavorites,"▶  "+xpsCatalog.label(preset)+" · "+preset.slot(),0xFF20578E);
            b.setOnClickListener(v->selectKeyboardSound(preset));
        }
    }
    private void render(PitchDetector.Result p,MusicBrain.Harmony h){
        if(audio!=null && audio.isRunning()){
            diagnostic.setText(String.format(Locale.US,"Diagnóstico: %.0f Hz • RMS %.4f • clareza %.0f%% • nota MIDI %d",p.hz,p.rms,p.clarity*100,p.midi));
            audioStatus.setText(p.rms<0.008?"Sinal baixo ou silêncio":p.midi<0?"Áudio captado, mas sem nota confiável":"Áudio captado • nota reconhecida");
        }
        if(cifraPanel!=null){
            String sn=h.midi<0?"—":MusicBrain.NOTE[h.midi%12]+(h.midi/12-1);
            String sk=h.knownKey()?MusicBrain.NOTE[h.root]+(h.mode==0?" maior":" menor"):"Tom indefinido";
            String sc=h.heardChord<0?"Acorde indefinido":MusicBrain.NOTE[h.heardChord]+suffix(h.heardQuality);
            cifraPanel.updateMusic(sn,sk,sc);
        }
        note.setText(h.midi<0?"—":MusicBrain.NOTE[h.midi%12]+(h.midi/12-1));
        detectedChord.setText("Acorde detectado: "+(h.heardChord<0?"indefinido":MusicBrain.NOTE[h.heardChord]+suffix(h.heardQuality)));
        if(!h.knownKey()){key.setText("Tom: indefinido (maior/menor ambíguos)");degree.setText("Cante frases ou toque acordes");chords.setText("Aguardando contexto harmônico");return;}
        key.setText((h.locked?"Tom FIXADO MANUALMENTE: ":"Tom provável: ")+MusicBrain.NOTE[h.root]+(h.mode==0?" maior":" menor")+(h.locked?" (não validado automaticamente)":" · confiança heurística "+h.confidence+"%"));
        degree.setText("Grau melódico: "+(h.degree>0?h.degree+"º":"cromático"));
        String a=h.chord1<0?"—":MusicBrain.NOTE[h.chord1]+suffix(h.quality1);
        String b=h.chord2<0?"—":MusicBrain.NOTE[h.chord2]+suffix(h.quality2);
        chords.setText(a+"    ou    "+b);
    }
    private String suffix(int q){return q==1?"m":q==2?"dim":"";}
    @Override protected void onDestroy(){
        audio.stop();ble.stop();if(midiMonitor!=null)midiMonitor.close();if(cifraPanel!=null)cifraPanel.dispose();super.onDestroy();
    }
}
