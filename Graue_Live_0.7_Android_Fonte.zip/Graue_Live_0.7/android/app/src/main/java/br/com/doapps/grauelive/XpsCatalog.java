package br.com.doapps.grauelive;

import java.util.*;
/** Local labels and favorites. NOT live extraction of Roland's proprietary patches. */
public final class XpsCatalog {
  private final Map<String,String> labels=new HashMap<>();
  private final LinkedHashSet<String> favorites=new LinkedHashSet<>();
  public void name(XpsPreset p,String text){String s=text==null?"":text.trim().replace('\n',' ');if(s.length()>80)s=s.substring(0,80);
    if(s.isEmpty())labels.remove(p.id());else labels.put(p.id(),s);}
  public String label(XpsPreset p){String s=labels.get(p.id());return s==null?p.slot():s;}
  public String alias(XpsPreset p){return labels.getOrDefault(p.id(),"");}
  public void favorite(XpsPreset p,boolean yes){if(yes)favorites.add(p.id());else favorites.remove(p.id());}
  public boolean isFavorite(XpsPreset p){return favorites.contains(p.id());}
  public List<XpsPreset> favorites(){List<XpsPreset> list=new ArrayList<>();for(String id:favorites){XpsPreset p=XpsPreset.parse(id);if(p!=null)list.add(p);}return list;}
  public int count(XpsPreset.Group group,String filter){int c=0;for(int n=1;n<=XpsPreset.capacity(group);n++)if(matches(XpsPreset.of(group,n),filter))c++;return c;}
  private boolean matches(XpsPreset p,String filter){String f=filter==null?"":filter.trim().toLowerCase(Locale.ROOT);
    return f.isEmpty()||label(p).toLowerCase(Locale.ROOT).contains(f)||p.slot().toLowerCase(Locale.ROOT).contains(f);}
  public List<XpsPreset> page(XpsPreset.Group g,String filter,int offset,int size){List<XpsPreset> r=new ArrayList<>();int skipped=0;
    for(int n=1;n<=XpsPreset.capacity(g);n++){XpsPreset p=XpsPreset.of(g,n);if(!matches(p,filter))continue;
      if(skipped++<offset)continue;if(r.size()==size)break;r.add(p);}return r;}
  private String quote(String s){return "\""+s.replace("\"","\"\"")+"\"";}
  /** Exchange format of Grauê: tipo;numero;nome;favorito. No Roland proprietary parsing. */
  public String csv(){StringBuilder b=new StringBuilder("tipo;numero;nome;favorito\n");
    for(XpsPreset.Group group:XpsPreset.Group.values())for(int n=1;n<=XpsPreset.capacity(group);n++){
      XpsPreset p=XpsPreset.of(group,n);if(alias(p).isEmpty()&&!isFavorite(p))continue;
      b.append(group.name()).append(';').append(n).append(';').append(quote(alias(p))).append(';').append(isFavorite(p)?1:0).append('\n');
    }return b.toString();
  }
  public int importCsv(String csv){String[] lines=csv.replace("\r","").split("\n");
    if(lines.length==0||!lines[0].trim().equals("tipo;numero;nome;favorito"))throw new IllegalArgumentException("CSV do Grauê esperado: tipo;numero;nome;favorito");
    List<Runnable> changes=new ArrayList<>();
    for(int i=1;i<lines.length;i++){if(lines[i].trim().isEmpty())continue;
      String[] a=splitLine(lines[i]);if(a.length!=4)throw new IllegalArgumentException("Linha "+(i+1)+" inválida");
      XpsPreset p;try{p=XpsPreset.of(XpsPreset.Group.valueOf(a[0].trim()),Integer.parseInt(a[1].trim()));}catch(Exception e){throw new IllegalArgumentException("Slot inválido na linha "+(i+1));}
      String alias=a[2];boolean f=a[3].trim().equals("1")||a[3].trim().equalsIgnoreCase("true");
      changes.add(()->{name(p,alias);favorite(p,f);});
    }
    for(Runnable r:changes)r.run();return changes.size();
  }
  private static String[] splitLine(String s){List<String> out=new ArrayList<>();StringBuilder word=new StringBuilder();boolean in=false;
    for(int i=0;i<s.length();i++){char c=s.charAt(i);if(c=='"'){
      if(in&&i+1<s.length()&&s.charAt(i+1)=='"'){word.append('"');i++;}else in=!in;
    }else if(c==';'&&!in){out.add(word.toString());word.setLength(0);}else word.append(c);}
    if(in)throw new IllegalArgumentException("Aspas abertas no CSV");out.add(word.toString());return out.toArray(new String[0]);
  }
}
