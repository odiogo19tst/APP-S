package br.com.doapps.grauelive;
import android.content.Context;
import android.content.SharedPreferences;
/** Persistent local catalog; never touches the keyboard's stored sound data. */
public final class XpsCatalogStore {
  private final SharedPreferences prefs;
  public XpsCatalogStore(Context context){prefs=context.getSharedPreferences("graue-xps-catalog",Context.MODE_PRIVATE);}
  public XpsCatalog load(){XpsCatalog c=new XpsCatalog();String csv=prefs.getString("csv","");if(!csv.isEmpty())try{c.importCsv(csv);}catch(Exception ignored){}return c;}
  public void save(XpsCatalog c){prefs.edit().putString("csv",c.csv()).apply();}
}
