package br.com.doapps.grauelive;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Non-destructive vault for exact, original XPS backup files. No proprietary parsing/merging. */
public final class BackupVault {
    private final Context context;
    private final File root;
    public BackupVault(Context ctx){context=ctx.getApplicationContext();root=new File(ctx.getFilesDir(),"backup_vault");root.mkdirs();}
    public static final class Item{
        public final String name,hash; public final long size;
        Item(String n,String h,long s){name=n;hash=h;size=s;}
    }
    public synchronized List<Item> list(){
        List<Item> items=new ArrayList<>();
        File[] fs=root.listFiles();if(fs==null)return items;
        for(File meta:fs)if(meta.getName().endsWith(".meta")){
            try{JSONObject o=new JSONObject(readText(meta));String hash=o.getString("sha256");
                File binary=new File(root,hash+".original");
                if(binary.isFile())items.add(new Item(o.getString("name"),hash,binary.length()));
            }catch(Exception ignored){}
        }
        items.sort((a,b)->a.name.compareToIgnoreCase(b.name));return items;
    }
    public synchronized String importDocument(Uri uri)throws Exception{
        String name="backup";
        try(Cursor cur=context.getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){
            if(cur!=null&&cur.moveToFirst())name=cur.getString(0);
        }
        name=sanitize(name);
        File tmp=File.createTempFile("graue-", ".tmp",root);
        MessageDigest dig=MessageDigest.getInstance("SHA-256");long size=0;
        try(InputStream in=context.getContentResolver().openInputStream(uri);OutputStream out=new FileOutputStream(tmp)){
            if(in==null)throw new IOException("Não foi possível abrir arquivo");
            byte[] buf=new byte[16384];int n;
            while((n=in.read(buf))!=-1){size+=n;
                if(size>512L*1024*1024)throw new IOException("Arquivo acima do limite de 512 MB por item");
                out.write(buf,0,n);dig.update(buf,0,n);
            }
        }catch(Exception e){tmp.delete();throw e;}
        StringBuilder sb=new StringBuilder();for(byte b:dig.digest())sb.append(String.format(Locale.ROOT,"%02x",b&0xFF));
        String hash=sb.toString();File saved=new File(root,hash+".original");
        if(saved.exists()){tmp.delete();return "Arquivo idêntico já guardado (SHA-256).";}
        if(!tmp.renameTo(saved)){tmp.delete();throw new IOException("Não foi possível guardar cópia");}
        JSONObject info=new JSONObject();info.put("name",name);info.put("sha256",hash);info.put("size",size);
        try(FileOutputStream out=new FileOutputStream(new File(root,hash+".meta"))){out.write(info.toString().getBytes("UTF-8"));}
        return "Backup preservado sem alterações: "+name;
    }
    public void exportOriginal(String sha256,Uri target)throws Exception{
        if(sha256==null||!sha256.matches("[0-9a-f]{64}"))throw new IOException("Identificador inválido");
        File saved=new File(root,sha256+".original");
        if(!saved.isFile())throw new IOException("Cópia não encontrada");
        try(InputStream in=new FileInputStream(saved);OutputStream out=context.getContentResolver().openOutputStream(target)){
            if(out==null)throw new IOException("Destino indisponível");
            byte[] buffer=new byte[16384];int count;
            while((count=in.read(buffer))!=-1)out.write(buffer,0,count);
        }
    }
    private static String readText(File f)throws Exception{try(FileInputStream in=new FileInputStream(f)){byte[] bytes=new byte[(int)Math.min(f.length(),8192)];int n=in.read(bytes);return new String(bytes,0,Math.max(0,n),"UTF-8");}}
    private static String sanitize(String n){n=n.replaceAll("[/\\\\\\r\\n\\t]","_");return n.length()>90?n.substring(0,90):n;}
}
