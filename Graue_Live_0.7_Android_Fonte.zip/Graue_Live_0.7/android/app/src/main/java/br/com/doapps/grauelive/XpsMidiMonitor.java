package br.com.doapps.grauelive;

import android.content.Context;
import android.media.midi.MidiDevice;
import android.media.midi.MidiDeviceInfo;
import android.media.midi.MidiManager;
import android.media.midi.MidiOutputPort;
import android.media.midi.MidiInputPort;
import android.media.midi.MidiReceiver;
import android.os.Handler;
import android.os.Looper;
import java.io.IOException;
import java.util.TreeSet;

/** MIDI input monitor and explicitly-armed outbound sound selection. Never sends SysEx or writes user-memory. */
public final class XpsMidiMonitor {
    public interface Listener { void onStatus(String status); void onNotes(String notes, String chord); }
    private final MidiManager manager;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private MidiDevice opened;
    private MidiOutputPort out;
    private MidiInputPort in;
    private boolean armed;
    private boolean identifiedRoland;
    private String selectedName="";
    private final TreeSet<Integer> held = new TreeSet<>();
    private boolean listening;
    public XpsMidiMonitor(Context ctx, Listener cb) { manager=(MidiManager)ctx.getSystemService(Context.MIDI_SERVICE);listener=cb; }
    private void status(String s){main.post(()->listener.onStatus(s));}
    public void start(){
        if(manager==null){status("MIDI indisponível neste Android");return;}
        MidiDeviceInfo[] ds=manager.getDevices();
        if(ds.length==0){status("Conecte o XPS-10 por USB-C/OTG (USB Drv: GENERIC)");return;}
        MidiDeviceInfo selected=null;
        for(MidiDeviceInfo d:ds){
            String name=d.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME,"").toLowerCase();
            if(d.getType()==MidiDeviceInfo.TYPE_USB&&d.getOutputPortCount()>0&&(name.contains("xps")||name.contains("roland"))){selected=d;break;}
        }
        if(selected==null){for(MidiDeviceInfo d:ds)if(d.getType()==MidiDeviceInfo.TYPE_USB&&d.getOutputPortCount()>0){selected=d;break;}}
        if(selected==null){status("Dispositivo MIDI encontrado, mas sem saída de notas");return;}
        close(); listening=true;
        final String label=selected.getProperties().getString(MidiDeviceInfo.PROPERTY_NAME,"USB MIDI");
        identifiedRoland=label.toLowerCase().contains("roland")||label.toLowerCase().contains("xps");selectedName=label;
        manager.openDevice(selected,device->{
            if(!listening){if(device!=null)device.close();return;}
            if(device==null){status("Não foi possível abrir MIDI. Verifique USB GENERIC.");return;}
            opened=device;
            out=device.getInfo().getOutputPortCount()>0?device.openOutputPort(0):null;
            in=device.getInfo().getInputPortCount()>0?device.openInputPort(0):null;
            if(out!=null)out.connect(receiver);
            status("USB MIDI: "+label+(in==null?" • sem porta de controle":" • controle DESARMADO")+(out==null?" • sem notas de entrada":""));
        },main);
        status("Procurando notas MIDI... nenhum dado será escrito no teclado");
    }
    private final MidiReceiver receiver=new MidiReceiver(){
        @Override public void onSend(byte[] msg,int off,int count,long timestamp)throws IOException {
            for(int i=off;i<off+count;){
                int status=msg[i]&0xFF;
                int type=status&0xF0;
                if(status<0x80){i++;continue;}
                if((type==0x90||type==0x80)&&i+2<off+count){
                    int pitch=msg[i+1]&0x7F,vel=msg[i+2]&0x7F;
                    synchronized(held){if(type==0x90&&vel>0)held.add(pitch);else held.remove(pitch);publish();}
                    i+=3;
                }else if((type==0xB0||type==0xA0||type==0xE0||type==0xC0||type==0xD0)&&status<0xF0){
                    i+=(type==0xC0||type==0xD0)?2:3;
                }else i++;
            }
        }
    };
    private void publish(){
        StringBuilder notes=new StringBuilder();

        for(int pitch:held){if(notes.length()>0)notes.append(" · ");notes.append(MusicBrain.NOTE[pitch%12]).append(pitch/12-1);}
        String chord=MidiChordClassifier.label(held);
        final String n=notes.length()>0?notes.toString():"Nenhuma tecla pressionada",c=chord;
        main.post(()->listener.onNotes(n,c));
    }
    /** Explicit user-armed output, only to selected USB MIDI port. Never SysEx/write. */
    public synchronized String armControl(boolean allowGeneric){
        if(!listening||opened==null||in==null)return "Conecte o XPS-10 por USB antes de habilitar controles";
        if(!identifiedRoland&&!allowGeneric)return "Dispositivo sem nome Roland/XPS: confirme a ligação antes de controlar";
        armed=true;return "Comandos MIDI habilitados para "+selectedName;
    }
    public synchronized void disarm(){armed=false;}
    public synchronized boolean isArmed(){return armed&&in!=null&&listening;}
    public synchronized String sendPreset(XpsPreset preset,int channel){
        if(!isArmed())return "Controle bloqueado: conecte USB e habilite transmissão MIDI";
        // Hard-coded factory/user bank map; only CC0, CC32, Program Change.
        byte[] packet=preset.messages(channel);
        try{
            in.send(packet,0,3,0);in.send(packet,3,3,0);in.send(packet,6,2,0);
            return "Enviado: "+preset.slot()+" (Ch "+channel+") • confira o som no teclado";
        }catch(IOException|IllegalStateException e){armed=false;return "Erro de comunicação MIDI: "+e.getClass().getSimpleName();}
    }
    public void close(){listening=false;armed=false;identifiedRoland=false;
        if(in!=null){try{in.close();}catch(Exception ignored){}in=null;}
        if(out!=null){try{out.close();}catch(Exception ignored){}out=null;}
        if(opened!=null){try{opened.close();}catch(Exception ignored){}opened=null;}
        synchronized(held){held.clear();}
    }
}
