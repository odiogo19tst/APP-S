package br.com.doapps.grauelive;

public final class CifraLinksSelfTest {
    private static int checks;
    private static void is(boolean value){checks++;if(!value)throw new AssertionError("check #"+checks);}
    public static void main(String[] args){
        is("https://www.cifraclub.com.br/autor/musica/".equals(CifraLinks.fromShareText("Confira https://www.cifraclub.com.br/autor/musica/")));
        is("https://cifraclub.com.br/autor/".equals(CifraLinks.fromShareText("https://cifraclub.com.br/autor/")));
        is(CifraLinks.fromShareText("http://www.cifraclub.com.br/autor/")==null);
        is(CifraLinks.fromShareText("https://cifraclub.com.br.evil.tld/test")==null);
        is(CifraLinks.fromShareText("https://cifraclub.com.br@evil.tld/test")==null);
        is(CifraLinks.fromShareText("https://user:pw@www.cifraclub.com.br/test")==null);
        is(CifraLinks.fromShareText("abc")==null);
        is(CifraLinks.fromShareText(null)==null);
        System.out.println("OK: "+checks+" Cifra Club URL sharing checks");
    }
}
