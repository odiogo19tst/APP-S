package br.com.doapps.grauelive;
import java.util.HashSet;
import java.util.Arrays;
public final class MidiChordSelfTest {
    private static void assertEq(String expected,String actual){if(!expected.equals(actual))throw new AssertionError(expected+" != "+actual);}
    public static void main(String[] args){
        assertEq("C maior (tríade)",MidiChordClassifier.label(new HashSet<>(Arrays.asList(60,64,67))));
        assertEq("A menor (tríade)",MidiChordClassifier.label(new HashSet<>(Arrays.asList(57,60,64))));
        assertEq("G maior (tríade)",MidiChordClassifier.label(new HashSet<>(Arrays.asList(55,59,62))));
        assertEq("Acorde ainda indefinido",MidiChordClassifier.label(new HashSet<>(Arrays.asList(60,62))));
        System.out.println("OK: 4 MIDI harmony checks");
    }
}
