package br.com.doapps.grauelive;
public final class XpsControlSelfTest {
  private static int checks=0;static void ok(boolean x,String desc){if(!x)throw new AssertionError(desc);checks++;}
  private static void bytes(byte[] got,int... expected){ok(got.length==expected.length,"length");for(int i=0;i<expected.length;i++)ok((got[i]&255)==expected[i],"byte "+i);}
  public static void main(String[] args){
    bytes(XpsPreset.of(XpsPreset.Group.USER_PATCH,1).messages(1),0xB0,0,87,0xB0,32,0,0xC0,0);
    bytes(XpsPreset.of(XpsPreset.Group.USER_PATCH,129).messages(1),0xB0,0,87,0xB0,32,1,0xC0,0);
    bytes(XpsPreset.of(XpsPreset.Group.USER_PATCH,256).messages(16),0xBF,0,87,0xBF,32,1,0xCF,127);
    bytes(XpsPreset.of(XpsPreset.Group.USER_PERFORMANCE,128).messages(1),0xB0,0,85,0xB0,32,0,0xC0,127);
    bytes(XpsPreset.of(XpsPreset.Group.PRESET_PERFORMANCE,16).messages(1),0xB0,0,85,0xB0,32,64,0xC0,15);
    bytes(XpsPreset.of(XpsPreset.Group.PRESET_PATCH,1273).messages(1),0xB0,0,87,0xB0,32,73,0xC0,120);
    XpsCatalog c=new XpsCatalog();XpsPreset p=XpsPreset.of(XpsPreset.Group.USER_PATCH,39);c.name(p,"Cordas ; Igreja \"A\"");c.favorite(p,true);
    XpsCatalog d=new XpsCatalog();ok(d.importCsv(c.csv())==1,"csv rows");ok(d.label(p).equals("Cordas ; Igreja \"A\""),"csv escaped");
    ok(d.favorites().size()==1,"favorite preserved");ok(d.count(XpsPreset.Group.USER_PATCH,"cordas")==1,"search");
    boolean fail=false;try{XpsPreset.of(XpsPreset.Group.USER_PATCH,257);}catch(IllegalArgumentException e){fail=true;}ok(fail,"number check");
    fail=false;try{d.importCsv("tipo;numero;nome;favorito\nUSER_PATCH;999;invalido;1");}catch(IllegalArgumentException e){fail=true;}ok(fail,"bad catalog rejected");
    System.out.println("XPS MIDI + catalog checks passed: "+checks);
  }
}
