# Grauê Live 0.7 — Controlador Roland XPS-10 (protótipo)

**Status:** implementação em código-fonte. Testes JVM de mapeamento MIDI/catálogo e lógica musical; **APK 0.7 ainda não compilado/testado no XPS-10 físico**.

## Implementações novas

- Aba **Teclado**: 256 posições de timbres de usuário, 128 performances de usuário, 1.273 patches de fábrica e 16 performances de fábrica. Aparecem como *slots* numerados; **os nomes reais do teclado não são lidos automaticamente**.
- Renomear timbres/performances no celular, pesquisar por nome ou número, marcar e desmarcar favoritos, paginação de 12 itens.
- Aba **Ao Vivo**: até 8 favoritos como botões grandes, um toque para transmitir a seleção ao teclado, com retorno visual da tentativa.
- Catálogo local salvo no celular e importação/exportação em `tipo;numero;nome;favorito` (CSV UTF-8). **Não confundir com backup proprietário do Roland.**
- MIDI por USB-C/OTG (Android host) -> USB-B COMPUTER (XPS-10): monitorar notas e, **apenas após autorização explícita**, enviar CC0/MSB, CC32/LSB e Program Change ao teclado no canal MIDI escolhido.
- Segurança: comandos MIDI não escrevem na memória permanente, não enviam SysEx, não restauram backups, não importam WAV. O teclado pode ignorar seleção conforme modo/receive-channel, a validar.
- O microfone, Cifra Club e biblioteca de cópias de backup são preservados da v0.6. **BLE do Bip 6 continua BLOQUEADO devido aos reinícios reportados**.

## Valores MIDI no XPS-10 ORIGINAL (não confundir com XPS-10X)

| Grupo | CC0/MSB | CC32/LSB | PC (0-based) | Slots mostrados |
|---|---:|---:|---:|---|
| User Patch 1–128 | 87 | 0 | 0–127 | 001–128 |
| User Patch 129–256 | 87 | 1 | 0–127 | 129–256 |
| User Performance | 85 | 0 | 0–127 | 001–128 |
| Preset Performance | 85 | 64 | 0–15 | 001–016 |
| Preset Patch | 87 | 64–73 | 0–127 (último 0–120) | 001–1273 |

As mensagens são enviadas na sequência Bank Select MSB (CC0), LSB (CC32), Program Change. Não garantimos que alterem o som ativo no XPS-10 sem confirmar parâmetros MIDI Rx, canal, Patch/Performance e firmware.

Fontes: https://www.roland.com/global/support/by_product/xps-10/owners_manuals/ ; https://www.seekmanuals.com/manual/roland-xr-20-roland-xr-20-midi-implementation-user-guide.html (prévia reproduz modelo XPS-10, edição 2014).

## Importar sons e favoritos de verdade

**O que aparece hoje:** slots e aliases digitados/importados pelo usuário, não uma cópia automática de todos os timbres do instrumento.

1. Em **Teclado > Importar catálogo CSV**, selecione planilha-texto UTF-8 com `tipo;numero;nome;favorito`.
2. Para renomear um slot, toque **✎**. Toque **☆** para adicionar aos favoritos.
3. Na aba **Ao vivo**, os favoritos aparecem como botões grandes e mandam comandos MIDI se o controle estiver conectado e armado.
4. Para copiar dados originais do teclado: no XPS-10 use `MENU > UTILITY > BACKUP` para um pendrive, depois **Backups** no Grauê para guardar uma cópia intacta. Ainda não há parser confiável dos arquivos proprietários; não é possível garantir extração automática dos nomes/performance/favoritos nem mesclagem de backups.
5. Não use RESTORE como forma de mesclar: **RESTORE apaga/substitui os dados de usuário existentes**.

## Conectar e testar de modo seguro

1. Use adaptador USB-C OTG e cabo USB-B (porta COMPUTER) e confirme que o teclado aparece no Android como USB-MIDI. Confira `USB Driver = GENERIC` se necessário.
2. Em Teclado, toque `CONECTAR` e confirme chegada de notas primeiro.
3. Faça um backup do estado atual do XPS-10 antes de fazer testes de seleção (a seleção é temporária, mas o backup protege o estado do instrumento).
4. Toque `HABILITAR TROCA DE SONS`, confirme que está conectado ao **XPS-10 original** e selecione um User Patch pouco crítico, sem tocar em performance ao vivo.
5. Confirme visual e auditivamente que o som ativo muda. Caso contrário, veja configurações de canal MIDI e Rx Program/Bank; nunca execute RESTORE para testar.

## Compilação

Envie `Graue_Live_0.7_Android_Fonte.zip` à raiz de `odiogo19tst/APP-S` e `graue-live-07-android.yml` a `.github/workflows` e acompanhe Actions. APK debug na seção Artifacts se compilar verde.

## Limitações

- Android SDK não está disponível neste ambiente para teste APK; requer GitHub Actions, depois teste no celular e teclado.
- Os favoritos do Grauê são locais: **não representam leitura automática dos FAVORITE registrados no painel do XPS-10**.
- Seleção de bancos não faz download nem upload de amostras, patches ou backups.
- Não foram implementados remotamente SPLIT, DUAL, efeitos, volume ou edição de memória: dependem de mapeamento e testes físicos e não devem ser prometidos como funcionais.
- MIDI não opera sem cabo adaptador host USB; o Bip 6 não foi alterado nesta versão.
