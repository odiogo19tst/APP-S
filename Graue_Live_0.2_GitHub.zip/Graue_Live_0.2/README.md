# Grauê Live 0.2 — protótipo integrado Android + Amazfit Bip 6

**Status honesto:** código-fonte e testes de lógica executados; **APK e ZAB não compilados neste ambiente** (sem Android SDK/Zeus CLI/rede npm). Conexão BLE real e precisão com voz ao vivo **não verificadas em aparelhos**. Não é uma versão pronta para publicação em loja.

## Proposta

O **Android** (app nativo Java, pacote `br.com.doapps.grauelive`) capta áudio mono a 16 kHz e estima frequência fundamental com algoritmo YIN em janelas de 4096 amostras (aprox. 256 ms, deslocamento de ~128 ms). Um rastreador harmônico tenta estimar tonalidade maior/menor após notas distintas e propõe acordes que *podem* harmonizar com a nota identificada. O aplicativo não reconhece os acordes efetivamente tocados por uma banda, nem determina o tom com certeza a partir de uma única nota.

O **relógio** roda um miniapp Zepp OS 3+, procura o serviço BLE anunciado pelo telefone, se conecta como central, recebe notificações GATT e exibe **nota cantada, tonalidade estimada, grau melódico e possibilidades de acordes**. Áudio **não** é transmitido ao relógio nem enviado para nuvem.

### Conteúdo

- `android/`: projeto Android Studio/Gradle (Java), sem bibliotecas externas além do Android SDK.
- `watch/`: miniapp Zepp OS, tela projetada em 390 × 450, cliente BLE central.
- `.github/workflows/graue-build.yml`: CI de geração de APK de teste e ZAB.
- `watch/test/packet.test.mjs`: testes de integridade do protocolo.
- `android/app/src/test/.../AudioLogicSelfTest.java`: testes independentes do Android SDK.

### Como compilar

**GitHub Actions:** publicar esta pasta **como `Graue_Live_0.2` na raiz** de um repositório, copiar `.github/workflows/graue-build.yml` para a pasta `.github/workflows` da **raiz do repositório**, e acionar o workflow `Graue Live - APK and Bip6 ZAB`. Se publicar como repositório separado, ajustar `working-directory` e `path` no workflow.

**Android Studio:** abrir `android/`, sincronizar o Gradle e executar `:app:assembleDebug`; instalar `app/build/outputs/apk/debug/app-debug.apk`. O projeto não inclui `gradle-wrapper.jar`; no computador local use uma instalação Gradle 8.9 ou o GitHub Actions.

**Zepp:** instalar Zeus CLI compatível, executar `cd watch && npm test && zeus build`. Instalar o `.zab` por modo desenvolvedor/QR ou ferramenta compatível; alterar **appId experimental** (`10000002`) para ID oficial próprio antes de distribuir/publicar.

### Teste em dois aparelhos

1. **Não desinstalar o Zepp.** Manter o pareamento atual do Bip 6; testar primeiro com os apps abertos e próximos.
2. No Android: instalar o APK de teste; autorizar **Microfone, Bluetooth anunciar e conectar**; tocar **Ativar Bluetooth para o Bip 6**. O telefone precisa suportar modo **BLE Peripheral/advertising**.
3. No Bip 6: instalar o miniapp Grauê Live; abrir e tocar **CONECTAR**. A busca verifica nosso UUID, sem usar a ponte do Zepp. Confirmar status `Conectado` no relógio e `inscrito nas notas ao vivo` no Android.
4. Com o app Android ainda aberto, pressionar **Enviar notas simuladas (teste)**: a tela do relógio deve atualizar sem utilizar o microfone. Este passo valida o transporte, não a inteligência.
5. Pressionar **Iniciar escuta** no Android, cantar uma nota constante perto do microfone e checar a nota mostrada. Cantar frases com várias notas para o sistema acumular evidências antes de propor um tom.
6. Testar celular com banda ao fundo e registrar latência/erros. O desempenho com música polifônica e igreja ruidosa não foi validado; a primeira versão prioriza **voz isolada ou predominante**.

### Especificação BLE

- Android: **GATT peripheral**, Zepp OS: **central**.
- Service UUID: `b1a73010-cc72-4d56-8c5b-f3d06d204001`
- Notify/read characteristic: `b1a73011-cc72-4d56-8c5b-f3d06d204001`
- CCCD: `00002902-0000-1000-8000-00805f9b34fb`
- Notificação com **16 bytes**, marcada por ASCII `G`, versão `1`, byte de sequência e checksum XOR.

| Byte | Campo |
|:--:|---|
| 0 | `'G'` |
| 1 | Versão `1` |
| 2 | Sequência modular |
| 3 | Nota MIDI (255 = desconhecido) |
| 4 | Classe da tônica (0=C … 11=B; 255 = desconhecido) |
| 5 | Modo (0=maior, 1=menor, 255 = desconhecido) |
| 6 | Grau da nota (1-7; 0 = desconhecido/cromático) |
| 7 | Score indicativo (não é confiança estatística calibrada) |
| 8, 9 | 1ª sugestão de acorde (tônica e qualidade) |
| 10, 11 | 2ª sugestão |
| 12-14 | Reservados |
| 15 | XOR dos bytes 0-14 |

### Limitações técnicas e de produto

- O BLE direto é uma **hipótese de integração a validar no Bip 6**, ainda que as duas APIs sejam oficialmente documentadas. A manutenção do vínculo simultâneo com o Zepp depende do firmware e não foi testada.
- O APK precisa estar **aberto na tela** nesta versão. Segundo plano com serviço de microfone, otimização de bateria, reconexão e gravação contínua ainda não implementados.
- Não há confirmação automática do tom pelo músico no relógio, aprendizado neural, separação de voz, previsão harmônica treinada nem transcrição polifônica nesta versão. São itens do roadmap.
- O algoritmo detecta **uma voz principal** em áudio relativamente limpo; múltiplas fontes/vozes podem causar erros ou ambiguidade.
- Nenhuma gravação é persistida, sem contas ou servidores. O sinal analítico BLE não é criptografado pela aplicação; manter apenas em testes até implementar segurança de conexão/pareamento adequada.
- Publicação em loja exige marca, app ID real, validação de políticas e testes físicos.

### Documentação técnica

- https://docs.zepp.com/docs/guides/framework/device/ble-central/
- https://docs.zepp.com/docs/reference/device-app-api/newAPI/ble/mstStartScan/
- https://docs.zepp.com/docs/reference/device-app-api/newAPI/ble/mstBuildProfile/
- https://docs.zepp.com/docs/reference/device-app-api/newAPI/ble/mstOnCharaNotification/
- https://developer.android.com/reference/android/bluetooth/le/BluetoothLeAdvertiser
