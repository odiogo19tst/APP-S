package br.com.doapps.grauelive;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import java.util.Locale;

/** Visible foreground-only prototype: microphone stays active while app is open. */
public final class MainActivity extends Activity {
    private static final int BG=0xFF0C1727,CARD=0xFF192C43,WHITE=0xFFF2F6FF,MINT=0xFF68E0AB,MUTED=0xFFABC0D8;
    private TextView note,key,degree,chords,bleStatus,audioStatus,subtitle;
    private Button start,bluetooth,demo;
    private AudioAnalyzer audio;private BlePeripheral ble;
    private int sequence=0;private long lastPacket=0;
    private final MusicBrain demoBrain=new MusicBrain();
    @Override public void onCreate(Bundle b){super.onCreate(b);buildUi();
        ble=new BlePeripheral(this,s->runOnUiThread(()->bleStatus.setText(s)));
        audio=new AudioAnalyzer(new AudioAnalyzer.Callback(){
            @Override public void onResult(PitchDetector.Result p,MusicBrain.Harmony h){
                long now=SystemClock.elapsedRealtime();
                if(now-lastPacket>=120){lastPacket=now;ble.publish(GrauePacket.encode(++sequence,h));}
                runOnUiThread(()->render(p,h));
            }
            @Override public void onError(String s){runOnUiThread(()->audioStatus.setText(s));}
        });
        start.setOnClickListener(v->{if(audio.isRunning()){audio.stop();start.setText("Iniciar escuta");audioStatus.setText("Microfone parado");}
            else if(checkPermission(Manifest.permission.RECORD_AUDIO))startAudio();else requestAllPermissions();});
        bluetooth.setOnClickListener(v->{if(!checkPermission(Manifest.permission.BLUETOOTH_ADVERTISE)||!checkPermission(Manifest.permission.BLUETOOTH_CONNECT))requestAllPermissions();else{ble.start();bluetooth.setText("Reiniciar Bluetooth");}});
        demo.setOnClickListener(v->{
            // Synthetic melody tests the BLE path independently from microphone.
            int[] melody={67,69,71,72,74,76,74,71,69,67,71,74};
            demoBrain.reset();MusicBrain.Harmony h=null;
            for(int m:melody)h=demoBrain.accept(m);
            if(h!=null){ble.publish(GrauePacket.encode(++sequence,h));render(new PitchDetector.Result(0,1,0,h.midi),h);}
            audioStatus.setText("Demonstração enviada (sem áudio real)");
        });
        if(Build.VERSION.SDK_INT>=31)requestAllPermissions();
    }
    private boolean checkPermission(String p){return Build.VERSION.SDK_INT<31&& !p.equals(Manifest.permission.RECORD_AUDIO)||checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}
    private void requestAllPermissions(){
        if(Build.VERSION.SDK_INT>=31)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO,Manifest.permission.BLUETOOTH_ADVERTISE,Manifest.permission.BLUETOOTH_CONNECT},101);
        else requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},101);
    }
    private void startAudio(){audio.start();if(audio.isRunning()){start.setText("Parar escuta");audioStatus.setText("Analisando voz localmente · sem envio à nuvem");}}
    private void buildUi(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(BG);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(24,42,24,28);scroll.addView(root);
        TextView title=txt("♫  GRAUÊ LIVE",28,WHITE,true);root.addView(title);
        subtitle=txt("Copiloto de acompanhamento • Bip 6",14,MUTED,false);root.addView(subtitle);
        root.addView(space(24));
        LinearLayout hero=card(root);hero.addView(txt("NOTA OUVIDA",13,MUTED,true));
        note=txt("—",72,WHITE,true);note.setGravity(Gravity.CENTER);hero.addView(note);
        key=txt("Tom: analisando melodia",20,MINT,true);key.setGravity(Gravity.CENTER);hero.addView(key);
        degree=txt("Grau: —",16,MUTED,false);degree.setGravity(Gravity.CENTER);hero.addView(degree);
        root.addView(space(16));
        LinearLayout suggestions=card(root);suggestions.addView(txt("ACOMPANHAMENTO POSSÍVEL",13,MUTED,true));
        chords=txt("Aguardando notas suficientes",25,WHITE,true);suggestions.addView(chords);
        suggestions.addView(txt("Sugestões, não acordes identificados na gravação",12,MUTED,false));
        root.addView(space(18));
        start=action(root,"Iniciar escuta",0xFF297A5D);bluetooth=action(root,"Ativar Bluetooth para o Bip 6",0xFF214C80);
        demo=action(root,"Enviar notas simuladas (teste)",0xFF37465C);
        root.addView(space(20));
        root.addView(txt("STATUS DO ÁUDIO",12,MUTED,true));audioStatus=txt("Aguardando permissão de microfone",15,WHITE,false);root.addView(audioStatus);
        root.addView(space(13));root.addView(txt("CONEXÃO DO RELÓGIO",12,MUTED,true));bleStatus=txt("BLE ainda não iniciado",15,WHITE,false);root.addView(bleStatus);
        root.addView(space(22));
        root.addView(txt("Versão experimental 0.2 • análise no celular • tela deve ficar aberta durante o teste. Não grava nem envia áudio para servidores.",12,MUTED,false));
        setContentView(scroll);
    }
    private LinearLayout card(LinearLayout root){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(22,20,22,20);
        GradientDrawable bg=new GradientDrawable();bg.setColor(CARD);bg.setCornerRadius(22);box.setBackground(bg);root.addView(box,new LinearLayout.LayoutParams(-1,-2));return box;}
    private Button action(LinearLayout root,String name,int color){Button b=new Button(this);b.setAllCaps(false);b.setText(name);b.setTextSize(16);b.setTextColor(WHITE);
        GradientDrawable bg=new GradientDrawable();bg.setColor(color);bg.setCornerRadius(16);b.setBackground(bg);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,58);lp.bottomMargin=12;root.addView(b,lp);return b;}
    private TextView txt(String value,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(value);t.setTextSize(size);t.setTextColor(color);
        t.setTypeface(Typeface.DEFAULT,bold?Typeface.BOLD:Typeface.NORMAL);t.setPadding(0,2,0,4);return t;}
    private View space(int dp){View v=new View(this);v.setLayoutParams(new LinearLayout.LayoutParams(1,dp));return v;}
    private void render(PitchDetector.Result p,MusicBrain.Harmony h){
        note.setText(h.midi<0?"—":MusicBrain.NOTE[h.midi%12]+(h.midi/12-1));
        if(!h.knownKey()){key.setText("Tom: analisando melodia");degree.setText("Cante algumas frases");chords.setText("Aguardando contexto");return;}
        key.setText("Tom possível: "+MusicBrain.NOTE[h.root]+(h.mode==0?" maior":" menor"));
        degree.setText("Grau melódico: "+(h.degree>0?h.degree+"º":"cromático"));
        String a=h.chord1<0?"—":MusicBrain.NOTE[h.chord1]+suffix(h.quality1);
        String b=h.chord2<0?"—":MusicBrain.NOTE[h.chord2]+suffix(h.quality2);
        chords.setText(a+"    ou    "+b);
    }
    private String suffix(int q){return q==1?"m":q==2?"dim":"";}
    @Override protected void onDestroy(){audio.stop();ble.stop();super.onDestroy();}
}
