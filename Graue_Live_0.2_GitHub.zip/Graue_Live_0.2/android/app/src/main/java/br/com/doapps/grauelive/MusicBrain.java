package br.com.doapps.grauelive;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Deque;

/** Tempered-scale tracking, major/minor key hypotheses and melody-safe chord hints. */
public final class MusicBrain {
    public static final String[] NOTE={"C","C#","D","Eb","E","F","F#","G","Ab","A","Bb","B"};
    private static final double[] MAJOR={6.35,2.23,3.48,2.33,4.38,4.09,2.52,5.19,2.39,3.66,2.29,2.88};
    private static final double[] MINOR={6.33,2.68,3.52,5.38,2.60,3.53,2.54,4.75,3.98,2.69,3.34,3.17};
    private final Deque<Integer> history=new ArrayDeque<>();
    private final double[] histogram=new double[12];
    private int count=0, currentRoot=-1, currentMode=-1;
    private int prospectiveRoot=-1, prospectiveMode=-1, prospectiveCount=0;
    public static final class Harmony {
        public final int midi, root, mode, degree, confidence, chord1, quality1, chord2, quality2;
        Harmony(int p,int r,int m,int d,int conf,int a,int qa,int b,int qb){
            midi=p;root=r;mode=m;degree=d;confidence=conf;chord1=a;quality1=qa;chord2=b;quality2=qb;
        }
        public boolean knownKey(){return root>=0;}
    }
    public synchronized void reset(){history.clear();Arrays.fill(histogram,0);count=0;currentRoot=-1;currentMode=-1;prospectiveRoot=-1;prospectiveMode=-1;prospectiveCount=0;}
    public synchronized Harmony accept(int midi){
        if(midi>=0 && midi<=127){
            int pc=midi%12;
            // Consecutive identical pitch frames must not dominate tonality.
            if(history.isEmpty() || history.peekLast()!=pc){
                history.addLast(pc); histogram[pc] += 1; count++;
                if(history.size()>80){int old=history.removeFirst();histogram[old]-=1;}
            }
        }
        int distinct=0;for(double h:histogram)if(h>0.1)distinct++;
        if(history.size()>=8 && distinct>=4){
            double best=-1e6,second=-1e6;int bestRoot=-1,bestMode=-1;
            for(int mode=0;mode<2;mode++)for(int root=0;root<12;root++){
                double score=similarity(root, mode);
                if(score>best){second=best;best=score;bestRoot=root;bestMode=mode;}
                else if(score>second){second=score;}
            }
            // Avoid declaring certainty for an ambiguous melody.
            if(best>=0.48 && best-second>=0.025){
                if(bestRoot==currentRoot && bestMode==currentMode){ prospectiveCount=0;}
                else if(bestRoot==prospectiveRoot && bestMode==prospectiveMode)prospectiveCount++;
                else {prospectiveRoot=bestRoot;prospectiveMode=bestMode;prospectiveCount=1;}
                if(prospectiveCount>=3 || currentRoot==-1 && prospectiveCount>=2){currentRoot=bestRoot;currentMode=bestMode;prospectiveCount=0;}
            }
        }
        if(currentRoot==-1 || midi<0) return new Harmony(midi,currentRoot,currentMode,0,0,-1,-1,-1,-1);
        int[] intervals=currentMode==0?new int[]{0,2,4,5,7,9,11}:new int[]{0,2,3,5,7,8,10};
        int rel=(midi%12-currentRoot+12)%12;
        int degree=0;
        for(int i=0;i<7;i++)if(intervals[i]==rel){degree=i+1;break;}
        // Chord choices are harmonizations, not a transcription of performed harmony.
        int[] quality=currentMode==0?new int[]{0,1,1,0,0,1,2}:new int[]{1,2,0,1,1,0,0};
        int[] order={0,3,4,5,1,2,6};
        int first=-1,second=-1;
        for(int di:order){
            int root=(currentRoot+intervals[di])%12;
            int third=(root+(quality[di]==0?4:3))%12;
            int fifth=(root+(quality[di]==2?6:7))%12;
            int note=midi%12;
            if(note==root||note==third||note==fifth){if(first<0)first=di;else {second=di;break;}}
        }
        int conf=Math.min(90,40+Math.min(35,history.size())/2);
        return new Harmony(midi,currentRoot,currentMode,degree,conf,
                first<0?-1:(currentRoot+intervals[first])%12,first<0?-1:quality[first],
                second<0?-1:(currentRoot+intervals[second])%12,second<0?-1:quality[second]);
    }
    private double similarity(int root,int mode){
        double[] profile=mode==0?MAJOR:MINOR;
        double avgx=0,avgy=0;
        for(int j=0;j<12;j++){avgx+=histogram[j];avgy+=profile[j];}
        avgx/=12;avgy/=12;
        double num=0,dx=0,dy=0;
        for(int j=0;j<12;j++){
            double x=histogram[j]-avgx;
            double y=profile[(j-root+12)%12]-avgy;
            num+=x*y;dx+=x*x;dy+=y*y;
        }
        return dx*dy>0?num/Math.sqrt(dx*dy):0;
    }
}
