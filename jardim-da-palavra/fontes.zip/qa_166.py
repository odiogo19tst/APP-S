from pathlib import Path
from playwright.sync_api import sync_playwright
import re, json
ROOT=Path(__file__).parent
A=ROOT/'app/src/main/assets'
s=(A/'index.html').read_text().replace('<link rel="stylesheet" href="style.css" />','<style>'+ (A/'style.css').read_text()+'</style>')
s=s.replace('<script src="data.js"></script>','<script>Object.defineProperty(window,"localStorage",{configurable:true,value:{getItem:()=>window.__data||null,setItem:(k,v)=>{window.__data=v;}}});</script>\n<script>\n'+(A/'data.js').read_text()+'\n</script>')
for f in re.findall(r'<script src="(.*?)"></script>',s):
 s=s.replace(f'<script src="{f}"></script>','<script>\n'+(A/f).read_text()+'\n</script>')
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':412,'height':900},locale='pt-BR',device_scale_factor=1.7)
 errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.set_content(s,wait_until='load')
 assert page.locator('.mini[data-tab="assistant"]').count()==1
 page.screenshot(path='/mnt/data/Jardim_166_Home.png',full_page=True)
 page.locator('.mini[data-tab="assistant"]').click()
 assert page.locator('textarea#chat-input').count()==1
 assert page.get_by_text('Não é IA generativa').count()>=1
 assert page.locator('a[href*="chatgpt.site"]').count()==0
 page.locator('textarea#chat-input').fill('Qual a diferença entre exegese e hermenêutica?')
 page.locator('button[data-action="chat-send"]').click()
 assert page.locator('.chat-message').count()==2
 assert 'Hermenêutica' in page.locator('.chat-content').last.inner_text() or 'Exegese' in page.locator('.chat-content').last.inner_text()
 assert page.locator('button[data-action="chat-source"]').count()>=1
 page.screenshot(path='/mnt/data/Jardim_166_Assistente.png',full_page=True)
 page.locator('button[data-action="chat-source"]').first.click()
 assert page.locator('#screen').get_attribute('data-view') in ['course-lesson','study']
 # local Q&A stores history when coming back
 page.locator('button[data-tab="more"]').click()
 page.locator('button[data-tab="assistant"]').click()
 assert page.locator('.chat-message').count()==2
 page.locator('button[data-action="chat-prompt"]').nth(2).click()
 assert page.locator('.chat-message').count()==4
 # course caderno
 page.locator('button[data-tab="studies"]').click()
 page.locator('button[data-tab="course"]').first.click()
 page.locator('button[data-action="open-course-subject"][data-subject="m10"]').first.click()
 page.locator('button[data-action="open-course-lesson"]').first.click()
 assert page.locator('.course-caderno').count()==1
 assert page.get_by_text('Hermenêutica aplicada: quatro leituras de um texto').count()>=1
 page.screenshot(path='/mnt/data/Jardim_166_Curso.png',full_page=True)
 # theme toggles
 colors=[]
 for t in ['plum','forest','ocean','sand','night']:
  page.locator('button[data-tab="more"]').click()
  page.locator(f'button[data-theme="{t}"]').click()
  colors.append(page.evaluate('getComputedStyle(document.body).backgroundColor'))
 assert len(set(colors))==5,colors
 page.screenshot(path='/mnt/data/Jardim_166_Tema_Noite.png',full_page=True)
 # ensure assistant and devotional do not cause horizontal scrolling at small sizes
 for w in [360,412,600]:
  page.set_viewport_size({'width':w,'height':900})
  for tab in ['assistant','devotional','course']:
   page.evaluate(f'go("{tab}")')
   overflow=page.evaluate('document.documentElement.scrollWidth>innerWidth+2')
   assert not overflow,(w,tab,page.evaluate('document.documentElement.scrollWidth'))
 assert not errors,errors
 print(json.dumps({'chatInsideApp':True,'chatSources':True,'chatHistory':True,'cadernos':len(page.evaluate('Object.keys(window.JARDIM_CADERNOS)')),'themesDistinct':len(set(colors)),'noHorizontalOverflow':True,'jsErrors':errors},ensure_ascii=False))
 browser.close()
