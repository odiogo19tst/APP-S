const fs=require('fs'), vm=require('vm'), assert=require('assert');
const dir=__dirname+'/app/src/main/assets';
const ctx=vm.createContext({window:{},S:{courseDone:[],courseExamDone:[],courseAnswers:{},courseShown:[],courseSubjectId:'m01',courseLessonId:'m01-a1',courseTrack:'all'},esc:s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'),section:(name)=>name,console});
for(const file of ['curso_data.js','curso_dossie.js','curso_ui.js'])vm.runInContext(fs.readFileSync(dir+'/'+file,'utf8'),ctx,{filename:file});
const {subjects}=ctx.window.JARDIM_CURSO;
const d=ctx.window.JARDIM_DOSSIER;
assert.equal(subjects.length,52);
assert.equal(Object.keys(d).length,52);
let tested=0;
for (const s of subjects){
  assert(d[s.id]);
  for (let i=0;i<s.lessons.length;i++){
    const l=s.lessons[i];
    ctx.S.courseSubjectId=s.id;ctx.S.courseLessonId=l.id;
    const rendered=vm.runInContext('courseLesson()',ctx);
    for(const item of ['Contexto histórico','Comentário e interpretação','Vocabulário bíblico','Referências cruzadas','Leituras para pesquisa','Dora: narrar o estudo','Verifique o que aprendeu']){
      assert(rendered.includes(item), `${l.id}: missing ${item}`);
    }
    assert(rendered.includes(d[s.id].context.slice(0,30)),`${l.id}: no context`);
    assert(rendered.includes(d[s.id].lexicon.slice(0,20)),`${l.id}: no lexicon`);
    assert(rendered.length>2700,`${l.id}: lesson too short ${rendered.length}`);
    tested++;
  }
}
const case12=d.m12;
assert(case12.lexicon.includes('λόγος') && case12.study.includes('Verbo'));
const case13=d.m13;
assert(case13.lexicon.includes('רֹעִי'));
console.log('PASS: '+subjects.length+' matérias / '+tested+' estudos com texto, comentário, tradução, original, referências, bibliografia e narração.');
