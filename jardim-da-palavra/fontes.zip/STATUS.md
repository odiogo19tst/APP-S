# Jardim da Palavra 1.6.5 — estado de validação

- Implementado: leitor offline com livros, capítulos, versículos, navegação, pesquisa de texto local, leitura por TTS e importação de arquivo ZIP fornecido pelo usuário mediante seus direitos de uso.
- Implementado: devocional em 5 etapas com integração ao trecho bíblico local quando importado.
- Preservado: 52 disciplinas, 156 aulas, 40 estudos, 31 sugestões musicais, anotações, lembretes e controle de voz.
- Verificados por scripts Node: testes de versões anteriores e testes novos de mapeamento NT/AT, leitura, devocional e pesquisa.
- Verificado no Chromium: navegação, 156 aulas, rascunhos, devocional, links e nenhum erro JavaScript.
- Pendente: compilação Java/Android e teste real de importação no Samsung.
- Limites: Bíblia ACF protegida por direitos autorais **não** está embutida. A autorização escrita da SBTB para distribuição segue pendente. Não redistribuir texto integral pelo APK. Importação é local e depende de arquivo que usuário possa legitimamente utilizar.
