# Situação verificada em 18/11/2026

## Implementado no novo projeto
- [x] Interface de cinco abas; layout adaptável para Android
- [x] 40 estudos autorais com seções detalhadas
- [x] 31 roteiros devocionais e seleção de referência do dia
- [x] Retorno do leitor para estudo e persistência do último estudo
- [x] Registro de estudos concluídos, notas e backup JSON
- [x] Cinco temas de cores e controle de fonte
- [x] TTS do sistema + botões narrar/parar
- [x] Notificação diária Android configurável (inexata)
- [x] Configuração de pacote de desenvolvimento sem substituir instalação publicada
- [x] Workflow GitHub Actions para gerar APK debug

## Ainda não entregue / não recuperado
- [ ] APK compilado e instalado (Android SDK indisponível nesta execução)
- [ ] Código original e assinatura original da Play Store
- [ ] Texto completo da ACF offline (necessita licença/autorização)
- [ ] Voz offline neural "Dora" original
- [ ] Assistente IA nativo completo
- [ ] Publicação de uma atualização assinada na Play Store

A base gerada é um ponto de retomada verificável, e **não** uma cópia da antiga versão 1.4.0.
