# Jardim 1.6.1 — escopo validado

- 52 disciplinas: mantidas
- 156 aulas: mantidas
- 52 dossiês de interpretação: adicionados
- Todas as aulas mostram dossiê contextual, tradução ou síntese, comentário, idioma original, referências cruzadas, bibliografia e Dora
- Teste estático de telas: executado com Node (156/156)
- Teste nativo no Samsung: pendente
- Leitura ACF integral offline: pendente de licença e aquisição dos textos
- Voz neural exclusiva da Dora: pendente; o TTS atual usa mecanismos do Android
