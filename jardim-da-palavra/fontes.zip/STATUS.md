# Jardim da Palavra 1.6.4 — Devocional restaurado

- [x] Guia de 5 etapas: Acolhimento (1m), Louvor (2m), Palavra/reflexão (3m), Aplicação (2m), Oração (2m)
- [x] Etapas selecionáveis, próxima/anterior, tempo individual com pausa e retomada
- [x] Ao abrir Spotify/YouTube, timer e fala pausam; links são de busca, não reprodução dentro do aplicativo
- [x] Seleção de música por data preservada; 31 sugestões temáticas disponíveis
- [x] Reflexões salvas automaticamente por data e incluídas no backup local
- [x] Narração de cada etapa por síntese de voz Android configurada; não é voz neural exclusiva
- [x] 52 disciplinas/156 aulas e 45 apostilas ampliadas preservadas
- [x] QA navegador 5 etapas, cronômetro, música, nota, progresso, 156 aulas, backup, sem erros JavaScript
- [ ] Teste físico de instalação e voz no Samsung
- [ ] Assinatura permanente para atualizar o mesmo pacote sem desinstalar
- [ ] Texto ACF integral offline e voz neural exclusiva pendentes de direitos/recursos

Não é transcrição da Bíblia ACF. O botão abre a referência para leitura na tradução escolhida.
