# Verificação do Jardim da Palavra 1.6.7

- [x] Código da versão 1.6.6 reutilizado; sem perder estudos, devocionais e assistente
- [x] 52 disciplinas, 156 aulas e 17 cadernos preservados
- [x] ACF offline por importação pessoal, sem texto bíblico protegido incorporado
- [x] Backup Android: exportar para arquivo e importar JSON via seletor de documentos
- [x] Compatibilidade de restauração com backup JSON anterior
- [x] Lembrete: tocar na notificação abre diretamente o devocional
- [x] TTS: preferência por voz pt-BR offline automática
- [x] Regressões JS e navegador em 320, 360, 390, 412, 600 px
- [ ] Compilação, assinatura e identificador Android 1.6.7: verificar no GitHub Actions
- [ ] Instalação e funcionamento em Samsung físico: pendente
- [ ] ACF completa distribuída no APK: pendente de licença SBTB
- [ ] Modelo generativo e voz neural Dora exclusiva: não implementados
- [ ] Assinatura permanente Google Play: pendente
