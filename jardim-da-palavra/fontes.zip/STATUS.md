# Status 1.6.13
- Código e testes de regressão incluídos.
- Textos protegidos não presentes no ZIP público.
- Novo conteúdo: oito seminários e dedicatória.
- Conclusão depende da compilação Android, assinatura pessoal e teste Samsung.
