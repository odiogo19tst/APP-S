# Jardim da Palavra — Teologia 1.6.0

- 5 eixos curriculares
- 52 disciplinas com objetivos, projetos e referências
- 156 aulas de texto autoral, com atividades e perguntas de revisão
- 52 avaliações formativas, com respostas discursivas e gabaritos para autoavaliação
- Retomada, busca, filtros, anotações e narração pelo Android TTS
- 40 estudos e 31 devocionais anteriores preservados
- Curso livre, não equivale a Bacharelado em Teologia; sem certificado reconhecido pelo MEC
- ACF integral ainda por link externo autorizado
- Identificador de teste isolado: com.diogo.jardimbibliaseestudos.curso160
