# Status de desenvolvimento — 1.6.2

- [x] Música temática de volta aos 31 devocionais
- [x] Botões Spotify e YouTube no devocional e Harpa
- [x] Dora anuncia a sugestão musical
- [x] 15 disciplinas com 45 capítulos originais aprofundados
- [x] 52 disciplinas e 156 aulas preservadas
- [x] Progresso/anotações mantidos dentro do mesmo pacote de teste
- [ ] Integração autorizada da ACF integral
- [ ] Voz neural exclusiva da Dora
- [ ] Revisão acadêmica independente das apostilas e checagem edição/página de todas as referências
- [ ] Teste físico em Android/Samsung e continuidade de assinatura de release
