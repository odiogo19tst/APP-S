# Testes da versão 1.6.6

- Assistente integrado: conversa no próprio app, busca e citações das disciplinas, histórico salvo, abrir fonte e narração
- IA generativa on-device: NÃO implementada; recurso é pesquisa local offline com diálogo guiado
- Cursos: 52 disciplinas, 156 aulas e 17 cadernos originais adicionais
- Apostilas comerciais do site: NÃO importadas, disponibilizadas nem copiadas
- Temas: cinco combinações revisadas, devocional e Bíblia acompanham cores globais
- Devocional: 5 etapas e Spotify/YouTube mantidos
- ACF: importação do ZIP pelo usuário, texto protegido NÃO incorporado ao APK
- Assinatura: verificar no GitHub Actions; instalação física em Samsung ainda pendente
