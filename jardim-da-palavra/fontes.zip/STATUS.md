# Status QA 1.6.3

- [x] Fontes JavaScript sintaticamente válidas
- [x] 52 disciplinas / 156 aulas renderizadas em navegador de teste
- [x] 45 capítulos ampliados e 52 dossiês preservados
- [x] 31 músicas com links de Spotify e YouTube
- [x] Salvamento automático de rascunhos, respostas e avaliações
- [x] Retomada da posição de leitura e backup/restauração
- [x] Referências Miqueias/Miquéias reconhecidas
- [x] Aplicação nativa TTS não seleciona vozes não instaladas
- [ ] Instalação e voz testadas fisicamente no Samsung
- [ ] Chave persistente de assinatura de versão final configurada
- [ ] Incorporação licenciada ACF offline
- [ ] Dora neural personalizada
- [ ] 156 aulas com profundidade homogênea e revisão bibliográfica
