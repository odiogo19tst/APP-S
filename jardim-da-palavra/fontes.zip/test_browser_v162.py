from playwright.sync_api import sync_playwright
from pathlib import Path
import subprocess,time
server=subprocess.Popen(['python','-m','http.server','8755','--bind','127.0.0.1'],cwd='/mnt/data/jardim_162_build/app/src/main/assets',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
time.sleep(0.5)
url='http://127.0.0.1:8755/index.html'
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--allow-file-access-from-files'])
 page=browser.new_page(viewport={'width':390,'height':840},device_scale_factor=1)
 errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
 page.goto(url,wait_until='load')
 page.locator('[data-tab="devotional"]').first.click()
 assert page.locator('.music-suggestion').count()==1
 assert page.locator('.music-suggestion a').count()==2
 assert page.locator('.music-suggestion a').nth(0).get_attribute('href').startswith('https://open.spotify.com/search/')
 assert page.locator('.music-suggestion a').nth(1).get_attribute('href').startswith('https://www.youtube.com/results?search_query=')
 page.screenshot(path='/mnt/data/Jardim_1.6.2_devocional.png',full_page=True)
 page.locator('[data-tab="studies"]').last.click()
 page.locator('[data-tab="course"]').first.click()
 assert 'Biblioteca de apostilas ampliadas' in page.locator('main').inner_text()
 page.locator('.extended-grid [data-subject="m10"]').click()
 assert 'Hermenêutica Bíblica' in page.locator('h1').inner_text()
 page.locator('[data-action="open-course-lesson"]').first.click()
 assert 'APOSTILA AMPLIADA' in page.locator('main').inner_text()
 assert 'Filipenses 4' in page.locator('.course-deep').inner_text()
 page.screenshot(path='/mnt/data/Jardim_1.6.2_apostila.png',full_page=True)
 page.locator('#course-check-answer').fill('Ler o contexto antes de aplicar.')
 page.locator('[data-action="course-save-answer"]').click()
 page.reload()
 assert page.locator('#course-check-answer').input_value()=='Ler o contexto antes de aplicar.'
 assert page.locator('.course-deep').count()==1
 page.locator('.course-lesson-body [data-action="speak-screen"]').count()==1
 assert not errors,errors
 print('PASS: navegador - links Spotify/YouTube, apostila, progresso, releitura e JavaScript sem erros')
 browser.close()
 server.terminate()
