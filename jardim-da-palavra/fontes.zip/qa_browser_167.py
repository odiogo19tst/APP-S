from pathlib import Path
from playwright.sync_api import sync_playwright
import re, json
P=Path(__file__).parent
A=P/'app/src/main/assets'
s=(A/'index.html').read_text().replace('</head>', '''<script>window.__store={};Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__store[k]||null,setItem:(k,v)=>{window.__store[k]=v;}}});</script></head>''').replace('<link rel="stylesheet" href="style.css" />','<style>'+ (A/'style.css').read_text()+'</style>')
s=s.replace('<script src="data.js"></script>', '<script>'+ (A/'data.js').read_text()+'</script>')
for f in re.findall(r'<script src="(.*?)"></script>',s):
    s=s.replace(f'<script src="{f}"></script>', '<script>'+ (A/f).read_text()+'</script>')
with sync_playwright() as p:
    b=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=b.new_page(viewport={'width':390,'height':850},locale='pt-BR',device_scale_factor=1)
    errors=[];page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(s,wait_until='load')
    page.locator('[data-tab="more"]').first.click()
    assert page.locator('button[data-action="backup-export"]').count()==1
    assert page.locator('button[data-action="backup-import"]').count()==1
    assert page.locator('button[data-action="show-backup"]').count()==1
    page.evaluate('window.JardimAndroid={exportBackup:(s)=>{window.__exp=s},importBackup:()=>{window.__imp=true},voiceCatalog:()=>JSON.stringify({ready:false,engines:[],voices:[]})}')
    page.locator('button[data-action="backup-export"]').click()
    assert page.evaluate('JSON.parse(window.__exp).version')==2
    page.locator('button[data-action="backup-import"]').click()
    assert page.evaluate('window.__imp')
    page.evaluate('window.jardimBackupLoaded(JSON.stringify({app:"JardimDaPalavra",version:1,data:{notes:[{id:12,title:"Recuperada",text:"Texto guardado"}],studyDone:[1,2],courseDone:["m01-a1"],reminder:true,theme:"forest"}}))')
    assert page.evaluate('JSON.parse(localStorage.getItem("jardim-palavra-local-v1")).notes[0].title')=='Recuperada'
    page.locator('[data-tab="notebook"]').first.click()
    assert page.get_by_text('Recuperada').count()>=1
    page.evaluate('window.jardimOpenDevotional()')
    assert page.locator('h1').first.inner_text()=='Seu devocional de hoje'
    assert page.locator('button[data-action="dev-next"]').count()==1
    page.locator('button[data-action="dev-next"]').click()
    assert page.locator('a[data-devmusic="spotify"]').count()==1
    assert page.locator('a[data-devmusic="youtube"]').count()==1
    page.locator('button[data-action="dev-next"]').click()
    assert page.locator('[data-action="bible-ref"]').count()>=1
    page.screenshot(path='/mnt/data/Jardim_da_Palavra_1_6_7_PREVIA.png',full_page=False)
    for w in [320,360,390,412,600]:
       page.set_viewport_size({'width':w,'height':850})
       for tab in ['home','devotional','bible','assistant','more','studies','course']:
          page.evaluate('(name)=>go(name)',tab)
          overflow=page.evaluate('document.documentElement.scrollWidth > innerWidth+2')
          assert not overflow,(w,tab,page.evaluate('document.documentElement.scrollWidth'))
    # All themes retain readable text colours and different bg
    themes=[]
    for theme in ['plum','forest','ocean','sand','night']:
       page.evaluate('(t)=>{S.theme=t;save();applyTheme();}',theme)
       themes.append(page.evaluate('getComputedStyle(document.body).backgroundColor'))
    assert len(set(themes))==5,themes
    assert not errors,errors
    print(json.dumps({'backupNativeControls':True,'restoreV1':True,'devotionalNotificationRoute':True,'musicPreserved':True,'responsiveBreakpoints':[320,360,390,412,600],'themeCount':5,'uncaughtJSErrors':errors},ensure_ascii=False))
    b.close()
