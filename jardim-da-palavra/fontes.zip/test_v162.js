const fs=require('fs'),vm=require('vm'),assert=require('assert');
const dir=__dirname+'/app/src/main/assets';
const ctx=vm.createContext({window:{},S:{courseDone:[],courseExamDone:[],courseAnswers:{},courseShown:[],courseSubjectId:'m01',courseLessonId:'m01-a1',courseTrack:'all'},esc:s=>String(s??'').replaceAll('&','&amp;').replaceAll('<','&lt;').replaceAll('>','&gt;').replaceAll('"','&quot;'),section:(name)=>name,console});
for(const file of ['curso_data.js','curso_dossie.js','curso_apostilas.js','curso_ui.js','devotional_music.js'])vm.runInContext(fs.readFileSync(dir+'/'+file,'utf8'),ctx,{filename:file});
const subjects=ctx.window.JARDIM_CURSO.subjects,apos=ctx.window.JARDIM_APOSTILAS,ds=ctx.window.JARDIM_DOSSIER,music=ctx.window.JARDIM_MUSIC;
assert.equal(subjects.length,52);assert.equal(Object.keys(ds).length,52);assert.equal(music.length,31);assert.equal(Object.keys(apos).length,15);
let count=0,deepCount=0;
for(const s of subjects){assert(ds[s.id],s.id);for(let i=0;i<3;i++){
 const l=s.lessons[i];ctx.S.courseSubjectId=s.id;ctx.S.courseLessonId=l.id;
 let h=vm.runInContext('courseLesson()',ctx);
 for(let x of ['Comentário e interpretação','Vocabulário bíblico','Referências cruzadas','Leituras para pesquisa','Dora: narrar o estudo','Verifique o que aprendeu'])assert(h.includes(x),`${l.id} missing ${x}`);
 if(apos[s.id]){assert(h.includes('APOSTILA AMPLIADA'),l.id);assert(h.includes(apos[s.id][i].lecture.slice(0,50)),l.id);assert(h.length>4000,`short:${l.id}`);deepCount++}
 count++;
}}
for(const x of music){assert(x.title&&x.artist&&x.why)}
console.log(JSON.stringify({subjects:subjects.length,lessons:count,extendedModules:Object.keys(apos).length,extendedUniqueLessons:deepCount,songSuggestions:music.length}));
