"""E2E regression of the offline HTML/JS embedded in Android WebView.
Chromium is policy-blocked for external and file navigation in this environment,
so this test inlines all first-party assets in a sandboxed browser page.
"""
from pathlib import Path
from playwright.sync_api import sync_playwright
import re, json
A=Path(__file__).parent/'app/src/main/assets'
s=(A/'index.html').read_text()
s=s.replace('<link rel="stylesheet" href="style.css" />','<style>'+ (A/'style.css').read_text()+'</style>')
s=s.replace('<script src="data.js"></script>','<script>Object.defineProperty(window,"localStorage",{configurable:true,value:{getItem:()=>window.__data||null,setItem:(k,v)=>{window.__data=v;}}});</script>\n<script>\n'+(A/'data.js').read_text()+'\n</script>')
for f in re.findall(r'<script src="(.*?)"></script>',s):
 s=s.replace(f'<script src="{f}"></script>','<script>\n'+(A/f).read_text()+'\n</script>')
result={}
with sync_playwright() as p:
 browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':412,'height':915},locale='pt-BR')
 errors=[]
 page.on('pageerror', lambda e: errors.append(str(e)))
 page.set_content(s, wait_until='load')
 assert 'jardim para estudar' in page.locator('h1').first.inner_text().lower()
 result['home']=True
 page.locator('button[data-tab="devotional"]').first.click()
 assert page.locator('.dev-stage-tab').count()==5
 page.locator('[data-action="dev-next"]').first.click()
 assert page.locator('[data-devmusic]').count()==2
 assert 'open.spotify.com/search/' in page.locator('[data-devmusic]').nth(0).get_attribute('href')
 assert 'youtube.com/results?search_query=' in page.locator('[data-devmusic]').nth(1).get_attribute('href')
 result['devotional_and_music']=True
 page.locator('button[data-tab="studies"]').first.click()
 page.locator('button[data-tab="course"]').first.click()
 page.locator('button[data-action="open-course-subject"]').first.click()
 page.locator('button[data-action="open-course-lesson"]').first.click()
 assert 'APOSTILA AMPLIADA' in page.locator('#screen').inner_text()
 page.locator('#course-check-answer').fill('Resposta sem clicar salvar')
 page.locator('button[data-action="open-course-subject"]').first.click()
 page.locator('button[data-action="open-course-lesson"]').first.click()
 assert page.locator('#course-check-answer').input_value()=='Resposta sem clicar salvar'
 result['autosave_lesson_answers']=True
 page.locator('button[data-action="course-open-assessment"]').count()
 page.locator('button[data-action="open-course-subject"]').first.click()
 page.locator('button[data-action="course-open-assessment"]').first.click()
 page.locator('#exam-answer-0').fill('Questão respondida parcial')
 page.locator('button[data-action="open-course-subject"]').first.click()
 page.locator('button[data-action="course-open-assessment"]').first.click()
 assert page.locator('#exam-answer-0').input_value()=='Questão respondida parcial'
 result['autosave_assessments']=True
 page.locator('button[data-tab="more"]').first.click()
 page.locator('button[data-tab="notebook"]').first.click()
 page.locator('#note-title').fill('Rascunho')
 page.locator('#note-text').fill('Uma reflexão que não pode sumir')
 page.locator('button[data-tab="more"]').first.click()
 page.locator('button[data-tab="notebook"]').first.click()
 assert page.locator('#note-text').input_value()=='Uma reflexão que não pode sumir'
 assert page.locator('#note-title').input_value()=='Rascunho'
 page.locator('button[data-action="save-note"]').click()
 assert 'Uma reflexão que não pode sumir' in page.locator('#screen').inner_text()
 assert page.locator('#note-text').input_value()==''
 result['notebook_draft_and_save']=True
 page.locator('button[data-tab="bible"]').first.click()
 page.evaluate('openRef("Miqueias 6:6-8")')
 assert page.locator('#book').input_value()=='Miquéias'
 assert page.locator('#chapter').input_value()=='6'
 assert page.evaluate('acfChapterUrl()')=='https://www.bibliaonline.com.br/acf/mq/6'
 page.evaluate('openRef("Salmos 23:1")')
 assert page.evaluate('acfChapterUrl()')=='https://www.bibliaonline.com.br/acf/sl/23'
 result['bible_aliases_and_verified_links']=True
 # Render every individual lecture through actual DOM, checking cross-references,
 # exception-free JS, and no empty/missing screens.
 total=page.evaluate('''() => { let count=0;for (const s of CURSO.subjects){ for(const l of s.lessons){S.courseSubjectId=s.id;S.courseLessonId=l.id;S.tab='course-lesson';render();const h=document.getElementById('screen').innerText;if(!h.includes('Leituras para pesquisa')||!h.includes(l.title))throw Error('Missing study '+l.id);count++}} return count}''')
 assert total==156
 result['all_156_lessons_render']=total
 page.evaluate('''() => {S.tab='course-lesson';S.courseSubjectId='m01';S.courseLessonId='m01-a1';render()}''')
 page.evaluate('window.scrollTo(0,850)')
 page.wait_for_timeout(450)
 y=page.evaluate('S.courseScrolls["m01-a1"]')
 assert y>=500, y
 page.locator('button[data-tab="studies"]').first.click()
 page.locator('button[data-tab="course"]').first.click()
 page.locator('button[data-resume="1"]').first.click()
 page.wait_for_timeout(250)
 assert page.evaluate('window.scrollY')>=500
 result['reading_position_resume']=True
 page.locator('button[data-tab="more"]').first.click()
 page.locator('button[data-action="show-backup"]').click()
 data=page.locator('#backup-data').input_value()
 assert 'Uma reflexão que não pode sumir' in data
 assert 'Resposta sem clicar salvar' in data
 page.locator('button[data-action="restore-backup"]').click()
 assert page.locator('#toast').inner_text()=='Backup restaurado'
 result['backup_and_restore']=True
 assert not errors, errors
 result['javascript_errors']=errors
 browser.close()
print(json.dumps(result,ensure_ascii=False,indent=2))
