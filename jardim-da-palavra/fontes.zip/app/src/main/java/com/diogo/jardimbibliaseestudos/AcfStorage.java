package com.diogo.jardimbibliaseestudos;

import android.content.Context;
import android.net.Uri;
import android.text.Html;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.text.Normalizer;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Local Bible storage; bundled personal texts, when present, are installed only on the device. */
final class AcfStorage {
    private AcfStorage() {}
    private static final Pattern CHAPTER = Pattern.compile("(?:^|/)acf-json/(at|nt)_book-(\\d+)_chapter-(\\d+)\\.json$", Pattern.CASE_INSENSITIVE);
    private static final int MAX_ENTRY_BYTES = 180_000;
    private static final int MAX_TOTAL_BYTES = 36_000_000;
    private static final int MAX_CHAPTER_FILES = 1400;
    private static final int EXPECTED_CHAPTERS = 1189;

    private static File folder(Context ctx) { return new File(ctx.getFilesDir(), "acf_chapters"); }
    private static File chapterFile(File root, int book, int chapter) { return new File(root, "b"+book+"c"+chapter+".json"); }
    private static boolean valid(int book, int chapter) { return book >= 1 && book <= 66 && chapter >= 1 && chapter <= 150; }
    private static void deleteDirectory(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteDirectory(c);
        }
        if (!f.delete()) throw new IllegalStateException("Não foi possível limpar armazenamento temporário");
    }
    static JSONObject status(Context context) {
        File[] files = folder(context).listFiles((dir, name) -> name.matches("b\\d+c\\d+\\.json"));
        int count = files == null ? 0 : files.length;
        JSONObject result = new JSONObject();
        try {
            result.put("chapters", count);
            result.put("complete", count == EXPECTED_CHAPTERS);
            result.put("version", "ACF (arquivo local do usuário)");
        } catch (Exception ignored) {}
        return result;
    }
    static JSONObject getChapter(Context ctx, int book, int chapter) {
        if (!valid(book, chapter)) return null;
        File f = chapterFile(folder(ctx), book, chapter);
        if (!f.isFile() || f.length() > MAX_ENTRY_BYTES) return null;
        try(FileInputStream in = new FileInputStream(f)) {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192]; int n;
            while((n = in.read(buf))!=-1) { out.write(buf,0,n); if(out.size()>MAX_ENTRY_BYTES)return null; }
            return new JSONObject(out.toString("UTF-8"));
        } catch(Exception ignored) { return null; }
    }
    private static byte[] readChapter(ZipInputStream zip) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192]; int n;
        while((n=zip.read(buf))!=-1) {
            out.write(buf,0,n);
            if(out.size()>MAX_ENTRY_BYTES) throw new Exception("Um capítulo ultrapassou o limite de segurança");
        }
        return out.toByteArray();
    }
    static int importZip(Context ctx, Uri uri) throws Exception {
        InputStream source = ctx.getContentResolver().openInputStream(uri);
        if (source == null) throw new Exception("Arquivo ZIP indisponível");
        return importStream(ctx, source);
    }
    /** Installs the user's privately supplied Bible without any file-picker interaction. */
    static int installBundled(Context ctx) throws Exception {
        if (status(ctx).optInt("chapters") == EXPECTED_CHAPTERS) return EXPECTED_CHAPTERS;
        try (InputStream source = ctx.getAssets().open("acf_personal.zip")) {
            return importStream(ctx, source);
        }
    }
    private static int importStream(Context ctx, InputStream source) throws Exception {
        File base = ctx.getFilesDir();
        File stage = new File(base,"acf_import_stage");
        File backup = new File(base,"acf_import_previous");
        // Se o processo foi interrompido após salvar o acervo anterior, recuperá-lo.
        File currentBefore = folder(ctx);
        if (!currentBefore.exists() && backup.exists() && !backup.renameTo(currentBefore))
            throw new Exception("Não foi possível recuperar a Bíblia anterior");
        if(stage.exists())deleteDirectory(stage);
        if(backup.exists())deleteDirectory(backup);
        if(!stage.mkdirs())throw new Exception("Não foi possível preparar armazenamento da Bíblia");
        int count=0, totalBytes=0;
        Set<String> already = new HashSet<>();
        try {
            try(ZipInputStream zip = new ZipInputStream(source)) {
                ZipEntry entry;
                while((entry=zip.getNextEntry())!=null) {
                    if(entry.isDirectory())continue;
                    String name=entry.getName().replace('\\','/');
                    Matcher match=CHAPTER.matcher(name);
                    if(!match.find())continue;
                    int book=Integer.parseInt(match.group(2)),chapter=Integer.parseInt(match.group(3));
                    if(!valid(book,chapter))throw new Exception("Referência inválida no arquivo");
                    if((book<=27&&!"nt".equalsIgnoreCase(match.group(1))) || (book>27&&!"at".equalsIgnoreCase(match.group(1))))throw new Exception("Testamento divergente");
                    String key=book+":"+chapter;
                    if(!already.add(key))throw new Exception("Capítulo duplicado no ZIP: "+key);
                    if(++count>MAX_CHAPTER_FILES)throw new Exception("Quantidade de capítulos inválida");
                    byte[] bytes = readChapter(zip);
                    totalBytes += bytes.length;
                    if(totalBytes>MAX_TOTAL_BYTES)throw new Exception("Arquivo grande demais para a importação");
                    JSONObject raw = new JSONObject(new String(bytes,StandardCharsets.UTF_8));
                    if(raw.optInt("book")!=book || raw.optInt("chapter")!=chapter)throw new Exception("Número do livro/capítulo divergente");
                    JSONArray inputVerses=raw.optJSONArray("verses");
                    if(inputVerses==null||inputVerses.length()<1||inputVerses.length()>176)throw new Exception("Versículos inválidos em "+key);
                    JSONArray cleanVerses=new JSONArray();
                    for(int i=0;i<inputVerses.length();i++) {
                        JSONObject verse=inputVerses.optJSONObject(i);
                        if(verse==null)continue;
                        java.util.Iterator<String> keys=verse.keys();
                        while(keys.hasNext()) {
                            String number=keys.next();
                            int no;try{no=Integer.parseInt(number);}catch(Exception ex){continue;}
                            if(no<1||no>176)continue;
                            String html=verse.optString(number,"");
                            String plain=Html.fromHtml(html,Html.FROM_HTML_MODE_LEGACY).toString().trim().replace('\u00a0',' ');
                            if(plain.isEmpty())continue;
                            cleanVerses.put(new JSONObject().put("number",no).put("text",plain));
                        }
                    }
                    if(cleanVerses.length()==0)throw new Exception("Capítulo sem texto: "+key);
                    JSONObject clean = new JSONObject().put("book",book).put("chapter",chapter).put("verses",cleanVerses);
                    try(FileOutputStream out=new FileOutputStream(chapterFile(stage,book,chapter))) {
                        out.write(clean.toString().getBytes(StandardCharsets.UTF_8));
                    }
                    zip.closeEntry();
                }
            }
            if(count==0)throw new Exception("Nenhum capítulo encontrado. Selecione o ZIP do repositório com a pasta acf-json.");
            File current=folder(ctx);
            if(current.exists()&&!current.renameTo(backup))throw new Exception("Não foi possível salvar a versão anterior");
            if(!stage.renameTo(current)) {
                if(backup.exists())backup.renameTo(current);
                throw new Exception("Não foi possível ativar a Bíblia importada");
            }
            if(backup.exists())deleteDirectory(backup);
            return count;
        } finally {
            if(stage.exists())deleteDirectory(stage);
        }
    }
    private static String fold(String value) {
        return Normalizer.normalize(value,Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "").toLowerCase(Locale.ROOT);
    }
    static JSONObject search(Context ctx, String query) {
        JSONObject response = new JSONObject();
        try {
            String q=fold(query==null?"":query.trim());
            JSONArray matches=new JSONArray();
            response.put("query",query==null?"":query);
            response.put("results",matches);
            if(q.length()<3||q.length()>80)return response;
            File[] files=folder(ctx).listFiles((dir,name)->name.matches("b\\d+c\\d+\\.json"));
            if(files==null)return response;
            java.util.Arrays.sort(files, java.util.Comparator.comparing(File::getName));
            for(File file:files) {
                String name=file.getName();
                Matcher m=Pattern.compile("b(\\d+)c(\\d+)\\.json").matcher(name);
                if(!m.matches())continue;
                JSONObject chapter=getChapter(ctx,Integer.parseInt(m.group(1)),Integer.parseInt(m.group(2)));
                if(chapter==null)continue;
                JSONArray verses=chapter.optJSONArray("verses");
                if(verses==null)continue;
                for(int i=0;i<verses.length();i++) {
                    JSONObject verse=verses.optJSONObject(i);if(verse==null)continue;
                    String content=verse.optString("text","");
                    if(fold(content).contains(q)) {
                        matches.put(new JSONObject().put("book",chapter.optInt("book"))
                          .put("chapter",chapter.optInt("chapter")).put("number",verse.optInt("number"))
                          .put("text",content));
                        if(matches.length()>=60)return response;
                    }
                }
            }
        }catch(Exception ignored){}
        return response;
    }
}
