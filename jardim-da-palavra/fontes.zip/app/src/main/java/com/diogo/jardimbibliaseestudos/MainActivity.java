package com.diogo.jardimbibliaseestudos;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.ContentResolver;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Toast;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.nio.charset.StandardCharsets;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.ByteArrayOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Set;

/** Jardim da Palavra - a narradora recebe texto dinamico, sem audio pre-gravado. */
public class MainActivity extends Activity {
    private static final Locale BRAZIL = new Locale("pt", "BR");
    private static final int ACF_IMPORT_PICKER = 4273;
    private static final int BACKUP_EXPORT_PICKER = 4274;
    private static final int BACKUP_IMPORT_PICKER = 4275;
    private static final int HARPA_IMPORT_PICKER = 4276;
    private static final int MAX_BACKUP_BYTES = 2_000_000;
    private String pendingBackupJson;
    private WebView web;
    private volatile TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private int ttsGeneration = 0;
    private float narrationRate = 0.96f;
    private float narrationPitch = 1.0f;
    private String selectedVoiceId = "auto";
    private volatile String currentEngineName = "";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF34203F);
        getWindow().setNavigationBarColor(0xFF34203F);
        narrationRate = getPreferences(MODE_PRIVATE).getFloat("speechRate", .96f);
        narrationPitch = getPreferences(MODE_PRIVATE).getFloat("speechPitch", 1.0f);
        selectedVoiceId = getPreferences(MODE_PRIVATE).getString("voiceId", "auto");
        String engine = getPreferences(MODE_PRIVATE).getString("voiceEngine", "auto");
        initializeTts(engine);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                if (getIntent() != null && getIntent().getBooleanExtra("openDevotional", false)) {
                    getIntent().removeExtra("openDevotional");
                    view.evaluateJavascript("window.jardimOpenDevotional && window.jardimOpenDevotional()", null);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return u.toString().startsWith("file:///android_asset/") ? false : true;
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "JardimAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
        // Only a privately installed copy includes this optional asset. It is not
        // committed to GitHub and is never sent to a remote service.
        new Thread(() -> {
            try {
                int count = AcfStorage.installBundled(MainActivity.this);
                notifyAcf("Bíblia ACF pessoal disponível offline: " + count + " capítulos.", true);
            } catch (java.io.FileNotFoundException ignored) {
                // Ordinary public/test build: user can still import a ZIP manually.
            } catch (Exception e) {
                notifyAcf("Não foi possível preparar a Bíblia local: " + e.getMessage(), false);
            }
        }, "jardim-acf-bundled").start();
    }

    private void initializeTts(String engineId) {
        runOnUiThread(() -> {
            final int generation = ++ttsGeneration;
            TextToSpeech previous = tts;
            tts = null;
            ttsReady = false;
            if (previous != null) { previous.stop(); previous.shutdown(); }
            TextToSpeech.OnInitListener listener = status -> runOnUiThread(() -> {
                if (generation != ttsGeneration) return;
                if (status != TextToSpeech.SUCCESS || tts == null) {
                    ttsReady = false;
                    if (!"auto".equals(engineId)) initializeTts("auto");
                    return;
                }
                int available = tts.setLanguage(BRAZIL);
                ttsReady = available >= TextToSpeech.LANG_AVAILABLE;
                if (ttsReady) { currentEngineName = "auto".equals(engineId) ? tts.getDefaultEngine() : engineId; selectCurrentVoice(); }
            });
            try {
                tts = "auto".equals(engineId)
                    ? new TextToSpeech(this, listener)
                    : new TextToSpeech(this, listener, engineId);
            } catch (Exception ignored) {
                if (!"auto".equals(engineId)) initializeTts("auto");
            }
        });
    }

    private static boolean isBrazilian(Voice v) {
        return v != null && "pt".equalsIgnoreCase(v.getLocale().getLanguage())
            && "BR".equalsIgnoreCase(v.getLocale().getCountry());
    }
    private static boolean isInstalled(Voice v) {
        return v.getFeatures() == null || !v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED);
    }
    private static int score(Voice v) {
        return (isBrazilian(v) ? 1000 : 0) + v.getQuality() + (v.isNetworkConnectionRequired() ? -250 : 250);
    }
    private List<Voice> voicesPtBr() {
        List<Voice> available = new ArrayList<>();
        TextToSpeech engine = tts;
        if (engine == null || !ttsReady) return available;
        Set<Voice> all = engine.getVoices();
        if (all != null) for (Voice v : all) if (isBrazilian(v)) available.add(v);
        available.sort(Comparator.comparingInt(MainActivity::score).reversed().thenComparing(Voice::getName));
        return available;
    }
    private void selectCurrentVoice() {
        TextToSpeech engine = tts;
        if (engine == null || !ttsReady) return;
        Voice best = null;
        for (Voice v : voicesPtBr()) {
            if (!"auto".equals(selectedVoiceId) && selectedVoiceId.equals(v.getName()) && isInstalled(v)) {
                best = v;
                break;
            }
            if (best == null && isInstalled(v)) best = v;
        }
        if (best != null) engine.setVoice(best);
    }
    private void speakText(String text) {
        TextToSpeech engine = tts;
        if (!ttsReady || engine == null || text == null || text.trim().isEmpty()) return;
        engine.stop();
        engine.setSpeechRate(narrationRate);
        engine.setPitch(narrationPitch);
        // TextToSpeech has an input length limit. Split at sentence boundaries when possible.
        int i = 0;
        String normalized = text.trim().replaceAll("[\\t ]+", " ").replaceAll("\\n{3,}", "\\n\\n");
        while (i < normalized.length()) {
            int end = Math.min(i + 2100, normalized.length());
            if (end < normalized.length()) {
                int sentence = Math.max(normalized.lastIndexOf(". ", end), Math.max(normalized.lastIndexOf("! ", end), normalized.lastIndexOf("? ", end)));
                int space = normalized.lastIndexOf(' ', end);
                if (sentence > i + 650) end = sentence + 1;
                else if (space > i + 650) end = space;
            }
            String part = normalized.substring(i, end).trim();
            if (!part.isEmpty()) engine.speak(part, i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                null, "dora_" + i);
            i = end;
        }
    }

    private void beginAcfPicker() {
        Intent choose = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        choose.setType("*/*");
        choose.addCategory(Intent.CATEGORY_OPENABLE);
        choose.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        choose.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/zip", "application/x-zip-compressed", "application/octet-stream"});
        try { startActivityForResult(choose, ACF_IMPORT_PICKER); }
        catch(Exception ex) { Toast.makeText(this, "Não foi possível abrir o seletor de arquivos", Toast.LENGTH_LONG).show(); }
    }
    private void notifyAcf(String message, boolean success) {
        try {
            JSONObject payload = new JSONObject().put("message", message).put("success", success);
            runOnUiThread(() -> {
                if(web!=null)web.evaluateJavascript("window.jardimAcfImported && window.jardimAcfImported("+payload.toString()+")", null);
            });
        } catch (Exception ignored) {}
    }
    private void messageBackup(String message, boolean success) {
        try {
            String data = new JSONObject().put("message", message).put("success", success).toString();
            runOnUiThread(() -> { if (web != null)
                web.evaluateJavascript("window.jardimBackupResult && window.jardimBackupResult("+data+")", null);
            });
        } catch (Exception ignored) { }
    }
    private void selectBackupExport(String json) {
        if (json == null || json.getBytes(StandardCharsets.UTF_8).length > MAX_BACKUP_BYTES) {
            messageBackup("Backup ultrapassa o limite de 2 MB", false);return;
        }
        try {
            JSONObject b = new JSONObject(json);
            if (!"JardimDaPalavra".equals(b.optString("app")) || !b.has("data")) {
                messageBackup("Conteúdo de backup inválido",false);return;
            }
            pendingBackupJson = json;
            Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            intent.setType("application/json");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_TITLE,"jardim-palavra-"+
                new SimpleDateFormat("yyyyMMdd-HHmm",Locale.US).format(new Date())+".json");
            startActivityForResult(intent, BACKUP_EXPORT_PICKER);
        } catch(Exception e) { pendingBackupJson=null;messageBackup("Não foi possível exportar: "+e.getMessage(),false); }
    }
    private void selectBackupImport() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{"application/json","text/plain","application/octet-stream"});
            startActivityForResult(intent,BACKUP_IMPORT_PICKER);
        } catch(Exception e) {messageBackup("Não foi possível selecionar backup",false);}
    }
    private void selectHarpaImport() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            intent.putExtra(Intent.EXTRA_MIME_TYPES,
                new String[]{"application/json","text/plain","application/octet-stream"});
            startActivityForResult(intent, HARPA_IMPORT_PICKER);
        } catch(Exception e) {
            Toast.makeText(this,"Não foi possível escolher o arquivo de letras",Toast.LENGTH_LONG).show();
        }
    }
    private void loadHarpaFile(Uri uri) {
        new Thread(() -> {
            try(InputStream in = getContentResolver().openInputStream(uri)) {
                if(in==null)throw new Exception("Arquivo inacessível");
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];int n;
                while((n=in.read(buf))!=-1) {
                    out.write(buf,0,n);
                    if(out.size()>1750000)throw new Exception("Arquivo de letras acima de 1,75 MB");
                }
                String txt = out.toString("UTF-8");
                String filename = "importacao.json";
                try(android.database.Cursor cur = getContentResolver().query(uri,
                        new String[]{android.provider.OpenableColumns.DISPLAY_NAME},null,null,null)) {
                    if(cur!=null&&cur.moveToFirst()) filename=cur.getString(0);
                } catch(Exception ignored) {}
                final String name = filename;
                runOnUiThread(() -> { if(web!=null)
                    web.evaluateJavascript("window.jardimHarpaImported && window.jardimHarpaImported("
                        +JSONObject.quote(txt)+","+JSONObject.quote(name)+")",null);
                });
            } catch(Exception e) {
                String msg=e.getMessage();runOnUiThread(() -> Toast.makeText(this,
                   "Letras: "+msg,Toast.LENGTH_LONG).show());
            }
        },"jardim-harpa-import").start();
    }
    private void saveBackupFile(Uri uri) {
        String json = pendingBackupJson;
        pendingBackupJson = null;
        if (json == null) {messageBackup("Nenhum backup para salvar",false);return;}
        new Thread(() -> {
            try(OutputStream out = getContentResolver().openOutputStream(uri,"wt")) {
                if (out == null)throw new Exception("O arquivo não pode ser escrito");
                out.write(json.getBytes(StandardCharsets.UTF_8));
                out.flush();
                messageBackup("Backup salvo no local escolhido",true);
            }catch(Exception e){messageBackup("Erro ao salvar backup: "+e.getMessage(),false);}
        },"jardim-backup-export").start();
    }
    private void loadBackupFile(Uri uri) {
        new Thread(() -> {
            try(InputStream in = getContentResolver().openInputStream(uri)) {
                if(in == null)throw new Exception("Arquivo indisponível");
                ByteArrayOutputStream out = new ByteArrayOutputStream();
                byte[] buffer = new byte[8192];int n;
                while((n=in.read(buffer))!=-1){out.write(buffer,0,n);
                    if(out.size()>MAX_BACKUP_BYTES)throw new Exception("Backup ultrapassa 2 MB");}
                String json = out.toString("UTF-8");
                runOnUiThread(() -> {if(web!=null)
                    web.evaluateJavascript("window.jardimBackupLoaded && window.jardimBackupLoaded("+JSONObject.quote(json)+")",null);
                });
            }catch(Exception e){messageBackup("Não foi possível ler o backup: "+e.getMessage(),false);}
        },"jardim-backup-import").start();
    }
    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == BACKUP_EXPORT_PICKER) {
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null)saveBackupFile(data.getData());
            else pendingBackupJson=null;
            return;
        }
        if (requestCode == HARPA_IMPORT_PICKER) {
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null)loadHarpaFile(data.getData());
            return;
        }
        if (requestCode == BACKUP_IMPORT_PICKER) {
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null)loadBackupFile(data.getData());
            return;
        }
        if(requestCode!=ACF_IMPORT_PICKER || resultCode!=RESULT_OK || data==null || data.getData()==null)return;
        Uri uri = data.getData();
        new Thread(() -> {
            try {
                int count=AcfStorage.importZip(MainActivity.this,uri);
                notifyAcf(count+" capítulos da ACF importados para leitura offline"+(count==1189?" (Bíblia completa).":" (importação parcial)."),true);
            }catch(Exception ex) {notifyAcf("Não foi possível importar: "+ex.getMessage(),false);}
        },"jardim-acf-import").start();
    }
    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if(intent != null && intent.getBooleanExtra("openDevotional",false) && web != null){
            intent.removeExtra("openDevotional");
            web.evaluateJavascript("window.jardimOpenDevotional && window.jardimOpenDevotional()",null);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(requestCode,permissions,grants);
        if(requestCode==100 && (grants.length==0||grants[0]!=PackageManager.PERMISSION_GRANTED)) {
            Toast.makeText(this,"Ative as notificações para receber o devocional diário",Toast.LENGTH_LONG).show();
        }
    }

    public class Bridge {
        @JavascriptInterface public void exportBackup(String json) {
            runOnUiThread(() -> selectBackupExport(json));
        }
        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> selectBackupImport());
        }
        @JavascriptInterface public void importHarpaLyrics() {
            runOnUiThread(() -> selectHarpaImport());
        }
        @JavascriptInterface public void importHarpaCharts() {
            runOnUiThread(() -> selectHarpaImport());
        }
        @JavascriptInterface public void importAcfZip() {
            runOnUiThread(() -> beginAcfPicker());
        }
        @JavascriptInterface public String acfStatus() { return AcfStorage.status(MainActivity.this).toString(); }
        @JavascriptInterface public String acfChapter(int book, int chapter) {
            JSONObject data=AcfStorage.getChapter(MainActivity.this,book,chapter);
            return data==null?"":data.toString();
        }
        @JavascriptInterface public void acfSearch(String query) {
            new Thread(() -> {
                JSONObject result=AcfStorage.search(MainActivity.this,query);
                runOnUiThread(() -> {
                    if(web!=null)web.evaluateJavascript("window.jardimAcfSearchResults && window.jardimAcfSearchResults("+result.toString()+")",null);
                });
            },"jardim-acf-search").start();
        }
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> speakText(text));
        }
        @JavascriptInterface public boolean isTtsReady() {return ttsReady;}
        @JavascriptInterface public void setSpeechRate(float rate) {
            runOnUiThread(() -> {
                narrationRate = Math.max(.70f, Math.min(1.25f, rate));
                getPreferences(MODE_PRIVATE).edit().putFloat("speechRate", narrationRate).apply();
            });
        }
        @JavascriptInterface public void setSpeechPitch(float pitch) {
            runOnUiThread(() -> {
                narrationPitch = Math.max(.8f, Math.min(1.2f, pitch));
                getPreferences(MODE_PRIVATE).edit().putFloat("speechPitch", narrationPitch).apply();
            });
        }
        @JavascriptInterface public void setVoiceEngine(String engineId) {
            if (engineId == null || engineId.trim().isEmpty()) engineId = "auto";
            final String chosen = engineId;
            runOnUiThread(() -> {
                selectedVoiceId = "auto";
                getPreferences(MODE_PRIVATE).edit().putString("voiceEngine", chosen).putString("voiceId", "auto").apply();
                initializeTts(chosen);
            });
        }
        @JavascriptInterface public void setVoiceId(String id) {
            if (id == null || id.isEmpty()) id = "auto";
            final String chosen = id;
            runOnUiThread(() -> {
                selectedVoiceId = chosen;
                getPreferences(MODE_PRIVATE).edit().putString("voiceId", chosen).apply();
                selectCurrentVoice();
            });
        }
        @JavascriptInterface public String voiceCatalog() {
            JSONObject result = new JSONObject();
            try {
                result.put("ready", ttsReady);
                TextToSpeech engine = tts;
                result.put("engine", currentEngineName);
                result.put("active", engine == null || engine.getVoice() == null ? "" : engine.getVoice().getName());
                JSONArray engines = new JSONArray();
                if (engine != null) for (TextToSpeech.EngineInfo e : engine.getEngines()) {
                    JSONObject o = new JSONObject();
                    o.put("id", e.name);
                    o.put("label", e.label == null ? e.name : e.label);
                    engines.put(o);
                }
                result.put("engines", engines);
                JSONArray voices = new JSONArray();
                for (Voice v : voicesPtBr()) {
                    JSONObject o = new JSONObject();
                    o.put("id", v.getName());
                    o.put("quality", v.getQuality());
                    o.put("online", v.isNetworkConnectionRequired());
                    o.put("installed", isInstalled(v));
                    voices.put(o);
                }
                result.put("voices", voices);
            } catch (Exception ignored) {}
            return result.toString();
        }
        @JavascriptInterface public void openVoiceSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            });
        }
        @JavascriptInterface public void stopSpeech() {
            runOnUiThread(() -> {if (tts != null) tts.stop();});
        }
        @JavascriptInterface public void setDailyReminder(boolean enabled, int hour, int minute) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("dailyReminder", enabled).putInt("hour", hour).putInt("minute", minute).apply();
            DevotionalReceiver.schedule(MainActivity.this, enabled, hour, minute);
            if (enabled && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100));
            }
        }
        @JavascriptInterface public String platform() { return "android"; }
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("window.jardimBack && window.jardimBack()", result -> {
            if ("false".equals(result)) {
                if (web.canGoBack()) web.goBack();
                else MainActivity.super.onBackPressed();
            }
        });
    }
    @Override protected void onDestroy() {
        ++ttsGeneration;
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
