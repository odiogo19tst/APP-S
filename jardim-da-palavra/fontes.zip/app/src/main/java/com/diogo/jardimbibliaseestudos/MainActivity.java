package com.diogo.jardimbibliaseestudos;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.net.Uri;
import java.util.Locale;

public class MainActivity extends Activity {
    private WebView web;
    private TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private float narrationRate = .92f;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF34203F);
        getWindow().setNavigationBarColor(0xFF34203F);
        tts = new TextToSpeech(this, status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = (tts.setLanguage(new Locale("pt", "BR")) >= TextToSpeech.LANG_AVAILABLE);
            }
        });
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    Intent i = new Intent(Intent.ACTION_VIEW, u);
                    try { startActivity(i); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "JardimAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }
    public class Bridge {
        @JavascriptInterface public void speak(String text) {
            if (text == null || text.isEmpty()) return;
            runOnUiThread(() -> { if (ttsReady) {
                tts.stop();
                tts.setSpeechRate(narrationRate);
                // Android TTS supports long text only in chunks.
                int chunk = 3000; int i = 0;
                while (i < text.length()) {
                    int end = Math.min(i + chunk, text.length());
                    if (end < text.length()) { int cut = text.lastIndexOf(' ', end); if (cut > i + 1000) end = cut; }
                    tts.speak(text.substring(i, end), i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD, null, "jardim" + i);
                    i = end;
                }
            }});
        }
        @JavascriptInterface public boolean isTtsReady() {return ttsReady;}
        @JavascriptInterface public void setSpeechRate(float rate) {runOnUiThread(() -> narrationRate = Math.max(.75f,Math.min(1.25f,rate)));}
        @JavascriptInterface public void stopSpeech() { runOnUiThread(() -> {if (tts != null) tts.stop();}); }
        @JavascriptInterface public void setDailyReminder(boolean enabled, int hour, int minute) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("dailyReminder", enabled).putInt("hour",hour).putInt("minute",minute).apply();
            DevotionalReceiver.schedule(MainActivity.this, enabled, hour, minute);
            if (enabled && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100));
            }
        }
        @JavascriptInterface public String platform() { return "android"; }
    }
    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("window.jardimBack && window.jardimBack()", result -> {
            if ("false".equals(result) && web.canGoBack()) web.goBack();
        });
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
