package com.diogo.jardimbibliaseestudos;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.Voice;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;

/** Jardim da Palavra - a narradora recebe texto dinamico, sem audio pre-gravado. */
public class MainActivity extends Activity {
    private static final Locale BRAZIL = new Locale("pt", "BR");
    private WebView web;
    private volatile TextToSpeech tts;
    private volatile boolean ttsReady = false;
    private int ttsGeneration = 0;
    private float narrationRate = 0.96f;
    private float narrationPitch = 1.0f;
    private String selectedVoiceId = "auto";

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(0xFF34203F);
        getWindow().setNavigationBarColor(0xFF34203F);
        narrationRate = getPreferences(MODE_PRIVATE).getFloat("speechRate", .96f);
        narrationPitch = getPreferences(MODE_PRIVATE).getFloat("speechPitch", 1.0f);
        selectedVoiceId = getPreferences(MODE_PRIVATE).getString("voiceId", "auto");
        String engine = getPreferences(MODE_PRIVATE).getString("voiceEngine", "auto");
        initializeTts(engine);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setAllowFileAccess(true);
        web.getSettings().setAllowFileAccessFromFileURLs(false);
        web.getSettings().setAllowUniversalAccessFromFileURLs(false);
        web.getSettings().setMediaPlaybackRequiresUserGesture(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("file".equals(u.getScheme())) return false;
                if ("http".equals(u.getScheme()) || "https".equals(u.getScheme())) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception ignored) {}
                    return true;
                }
                return true;
            }
        });
        web.addJavascriptInterface(new Bridge(), "JardimAndroid");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html");
    }

    private void initializeTts(String engineId) {
        runOnUiThread(() -> {
            final int generation = ++ttsGeneration;
            TextToSpeech previous = tts;
            tts = null;
            ttsReady = false;
            if (previous != null) { previous.stop(); previous.shutdown(); }
            TextToSpeech.OnInitListener listener = status -> runOnUiThread(() -> {
                if (generation != ttsGeneration) return;
                if (status != TextToSpeech.SUCCESS || tts == null) {
                    ttsReady = false;
                    if (!"auto".equals(engineId)) initializeTts("auto");
                    return;
                }
                int available = tts.setLanguage(BRAZIL);
                ttsReady = available >= TextToSpeech.LANG_AVAILABLE;
                if (ttsReady) selectCurrentVoice();
            });
            try {
                tts = "auto".equals(engineId)
                    ? new TextToSpeech(this, listener)
                    : new TextToSpeech(this, listener, engineId);
            } catch (Exception ignored) {
                if (!"auto".equals(engineId)) initializeTts("auto");
            }
        });
    }

    private static boolean isBrazilian(Voice v) {
        return v != null && "pt".equalsIgnoreCase(v.getLocale().getLanguage())
            && "BR".equalsIgnoreCase(v.getLocale().getCountry());
    }
    private static boolean isInstalled(Voice v) {
        return v.getFeatures() == null || !v.getFeatures().contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED);
    }
    private static int score(Voice v) {
        return (isBrazilian(v) ? 1000 : 0) + v.getQuality() + (v.isNetworkConnectionRequired() ? 20 : 0);
    }
    private List<Voice> voicesPtBr() {
        List<Voice> available = new ArrayList<>();
        TextToSpeech engine = tts;
        if (engine == null || !ttsReady) return available;
        Set<Voice> all = engine.getVoices();
        if (all != null) for (Voice v : all) if (isBrazilian(v)) available.add(v);
        available.sort(Comparator.comparingInt(MainActivity::score).reversed().thenComparing(Voice::getName));
        return available;
    }
    private void selectCurrentVoice() {
        TextToSpeech engine = tts;
        if (engine == null || !ttsReady) return;
        Voice best = null;
        for (Voice v : voicesPtBr()) {
            if (!"auto".equals(selectedVoiceId) && selectedVoiceId.equals(v.getName())) {
                best = v;
                break;
            }
            if (best == null && isInstalled(v)) best = v;
        }
        if (best != null) engine.setVoice(best);
    }
    private void speakText(String text) {
        TextToSpeech engine = tts;
        if (!ttsReady || engine == null || text == null || text.trim().isEmpty()) return;
        engine.stop();
        engine.setSpeechRate(narrationRate);
        engine.setPitch(narrationPitch);
        // TextToSpeech has an input length limit. Split at sentence boundaries when possible.
        int i = 0;
        String normalized = text.trim().replaceAll("[\\t ]+", " ").replaceAll("\\n{3,}", "\\n\\n");
        while (i < normalized.length()) {
            int end = Math.min(i + 2100, normalized.length());
            if (end < normalized.length()) {
                int sentence = Math.max(normalized.lastIndexOf(". ", end), Math.max(normalized.lastIndexOf("! ", end), normalized.lastIndexOf("? ", end)));
                int space = normalized.lastIndexOf(' ', end);
                if (sentence > i + 650) end = sentence + 1;
                else if (space > i + 650) end = space;
            }
            String part = normalized.substring(i, end).trim();
            if (!part.isEmpty()) engine.speak(part, i == 0 ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD,
                null, "dora_" + i);
            i = end;
        }
    }

    public class Bridge {
        @JavascriptInterface public void speak(String text) {
            runOnUiThread(() -> speakText(text));
        }
        @JavascriptInterface public boolean isTtsReady() {return ttsReady;}
        @JavascriptInterface public void setSpeechRate(float rate) {
            runOnUiThread(() -> {
                narrationRate = Math.max(.70f, Math.min(1.25f, rate));
                getPreferences(MODE_PRIVATE).edit().putFloat("speechRate", narrationRate).apply();
            });
        }
        @JavascriptInterface public void setSpeechPitch(float pitch) {
            runOnUiThread(() -> {
                narrationPitch = Math.max(.8f, Math.min(1.2f, pitch));
                getPreferences(MODE_PRIVATE).edit().putFloat("speechPitch", narrationPitch).apply();
            });
        }
        @JavascriptInterface public void setVoiceEngine(String engineId) {
            if (engineId == null || engineId.trim().isEmpty()) engineId = "auto";
            final String chosen = engineId;
            runOnUiThread(() -> {
                selectedVoiceId = "auto";
                getPreferences(MODE_PRIVATE).edit().putString("voiceEngine", chosen).putString("voiceId", "auto").apply();
                initializeTts(chosen);
            });
        }
        @JavascriptInterface public void setVoiceId(String id) {
            if (id == null || id.isEmpty()) id = "auto";
            final String chosen = id;
            runOnUiThread(() -> {
                selectedVoiceId = chosen;
                getPreferences(MODE_PRIVATE).edit().putString("voiceId", chosen).apply();
                selectCurrentVoice();
            });
        }
        @JavascriptInterface public String voiceCatalog() {
            JSONObject result = new JSONObject();
            try {
                result.put("ready", ttsReady);
                TextToSpeech engine = tts;
                result.put("engine", engine == null ? "" : engine.getCurrentEngine());
                result.put("active", engine == null || engine.getVoice() == null ? "" : engine.getVoice().getName());
                JSONArray engines = new JSONArray();
                if (engine != null) for (TextToSpeech.EngineInfo e : engine.getEngines()) {
                    JSONObject o = new JSONObject();
                    o.put("id", e.name);
                    o.put("label", e.label == null ? e.name : e.label);
                    engines.put(o);
                }
                result.put("engines", engines);
                JSONArray voices = new JSONArray();
                for (Voice v : voicesPtBr()) {
                    JSONObject o = new JSONObject();
                    o.put("id", v.getName());
                    o.put("quality", v.getQuality());
                    o.put("online", v.isNetworkConnectionRequired());
                    o.put("installed", isInstalled(v));
                    voices.put(o);
                }
                result.put("voices", voices);
            } catch (Exception ignored) {}
            return result.toString();
        }
        @JavascriptInterface public void openVoiceSettings() {
            runOnUiThread(() -> {
                try { startActivity(new Intent("com.android.settings.TTS_SETTINGS")); }
                catch (Exception e) { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); }
            });
        }
        @JavascriptInterface public void stopSpeech() {
            runOnUiThread(() -> {if (tts != null) tts.stop();});
        }
        @JavascriptInterface public void setDailyReminder(boolean enabled, int hour, int minute) {
            getPreferences(MODE_PRIVATE).edit().putBoolean("dailyReminder", enabled).putInt("hour", hour).putInt("minute", minute).apply();
            DevotionalReceiver.schedule(MainActivity.this, enabled, hour, minute);
            if (enabled && Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 100));
            }
        }
        @JavascriptInterface public String platform() { return "android"; }
    }

    @Override public void onBackPressed() {
        if (web != null) web.evaluateJavascript("window.jardimBack && window.jardimBack()", result -> {
            if ("false".equals(result) && web.canGoBack()) web.goBack();
        });
    }
    @Override protected void onDestroy() {
        ++ttsGeneration;
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
