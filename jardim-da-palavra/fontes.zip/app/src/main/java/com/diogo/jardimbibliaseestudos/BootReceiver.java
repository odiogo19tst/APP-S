package com.diogo.jardimbibliaseestudos;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

public class BootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context ctx, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())) {
            SharedPreferences p = ctx.getSharedPreferences("MainActivity",Context.MODE_PRIVATE);
            if (p.getBoolean("dailyReminder",false)) DevotionalReceiver.schedule(ctx,true,p.getInt("hour",7),p.getInt("minute",0));
        }
    }
}
