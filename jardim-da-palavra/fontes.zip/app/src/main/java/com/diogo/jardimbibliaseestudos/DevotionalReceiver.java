package com.diogo.jardimbibliaseestudos;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import java.util.Calendar;

public class DevotionalReceiver extends BroadcastReceiver {
    private static final String CHANNEL="jardim-devocional";
    public static void schedule(Context ctx, boolean enabled, int hour, int minute) {
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        Intent in = new Intent(ctx, DevotionalReceiver.class);
        PendingIntent pi = PendingIntent.getBroadcast(ctx, 43, in, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        if (!enabled) { am.cancel(pi); return; }
        Calendar when = Calendar.getInstance();
        when.set(Calendar.HOUR_OF_DAY, Math.max(0, Math.min(hour, 23)));
        when.set(Calendar.MINUTE, Math.max(0, Math.min(minute, 59)));
        when.set(Calendar.SECOND, 0);
        when.set(Calendar.MILLISECOND, 0);
        if (!when.after(Calendar.getInstance())) when.add(Calendar.DAY_OF_YEAR, 1);
        // Inexact Android alarm: may be delayed by battery optimisation/Doze.
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, when.getTimeInMillis(), AlarmManager.INTERVAL_DAY, pi);
    }
    @Override public void onReceive(Context ctx, Intent intent) {
        NotificationManager mgr = (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) mgr.createNotificationChannel(new NotificationChannel(CHANNEL,"Devocional diário",NotificationManager.IMPORTANCE_DEFAULT));
        Intent launch = new Intent(ctx, MainActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(ctx, 44, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(ctx,CHANNEL) : new Notification.Builder(ctx);
        Notification n = b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Seu tempo com Deus 🌿").setContentText("Vamos separar 10 minutos para o devocional?").setContentIntent(pi).setAutoCancel(true).build();
        try { mgr.notify(43,n); } catch (SecurityException ignored) { }
    }
}
