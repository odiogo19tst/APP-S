'use strict';
/* Jardim da Palavra - base offline. Sem chaves ou serviços comerciais. */
const D = window.JARDIM_DATA;
const KEY = 'jardim-palavra-local-v1';
const defaults = {theme:'plum',font:1,tab:'home',lastStudy:1,lastBook:'Salmos',lastChapter:23,notes:[],studyDone:[],devDone:[],reminder:false,time:'07:00',bibleVersion:'ACF',returnFromBible:null,autoNarration:false,voiceRate:0.96,voicePitch:1,voiceEngine:'auto',voiceId:'auto',courseDone:[],courseExamDone:[],courseSubjectId:'m01',courseLessonId:'m01-a1',courseTrack:'all',courseAnswers:{},courseExamAnswers:{},courseShown:[],courseExamShown:[]};
let S;try{S=Object.assign({},defaults,JSON.parse(localStorage.getItem(KEY)||'{}'));}catch{S={...defaults};}
let screen = document.querySelector('#screen'), toastTimer;
for(const k of ['courseDone','courseExamDone','courseShown','courseExamShown']){if(!Array.isArray(S[k])) S[k]=[];}
for(const k of ['courseAnswers','courseExamAnswers']){if(!S[k]||typeof S[k]!=='object'||Array.isArray(S[k])) S[k]={};}
const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast('Não foi possível salvar. Verifique o espaço do aparelho.')}}
function patch(p){Object.assign(S,p);save();}
function toast(m){let el=document.querySelector('#toast');el.textContent=m;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600);}
function dayIndex(date=new Date()){let start=new Date(date.getFullYear(),0,1);return Math.floor((Date.UTC(date.getFullYear(),date.getMonth(),date.getDate())-Date.UTC(start.getFullYear(),0,1))/86400000)%31;}
const today=()=>D.devotionals[dayIndex()];
function applyTheme(){document.documentElement.dataset.theme=S.theme;document.documentElement.style.setProperty('--font',S.font);document.querySelectorAll('.bottom button').forEach(b=>{b.classList.toggle('selected',b.dataset.tab===(S.tab.startsWith('course')||S.tab==='study'?'studies':S.tab));b.setAttribute('aria-current',b.dataset.tab===(S.tab.startsWith('course')||S.tab==='study'?'studies':S.tab)?'page':'false')});}
function go(tab,{scroll=true}={}){if(!['home','bible','studies','study','devotional','more','notebook','library','assistant','harpa','course','course-subject','course-lesson','course-assessment'].includes(tab))tab='home';patch({tab});render();if(scroll)window.scrollTo(0,0);autoReadScreen();}
function section(head,sub=''){return `<div class="section-label">${esc(sub)}</div><h1>${esc(head)}</h1>`;}
function actionsSpeak(text){return `<button type="button" class="btn secondary" data-action="speak" data-text="${esc(text)}">🔊 Ouvir</button><button type="button" class="btn ghost" data-action="stop">■ Parar</button>`;}
function home(){let v=today(),done=S.studyDone.length;return `<div class="hero"><div class="section-label">SEU TEMPO COM DEUS</div><h1>Um jardim para estudar a Palavra.</h1><p>Leia com calma. Estude com profundidade. Guarde o que florescer.</p><div class="actions"><button class="btn secondary" data-tab="devotional">☼ Devocional de hoje</button></div></div>
<div class="card"><div class="section-label">UMA PALAVRA PARA O CORAÇÃO · ${esc(S.bibleVersion)}</div><div class="daily-verse"><strong>${esc(v.reference)}</strong><p>${esc(v.theme)} — sua passagem de reflexão de hoje.</p><p class="smallprint">A referência muda diariamente. Consulte o texto integral na versão selecionada.</p></div><div class="actions"><button class="btn small" data-action="bible-ref" data-ref="${esc(v.reference)}">Abrir referência</button><button class="btn small secondary" data-action="share" data-text="Jardim da Palavra 🌿 — Reflexão de hoje: ${esc(v.reference)} (${esc(v.theme)}).">Compartilhar</button></div></div>
<div class="card course-feature"><div class="row"><div><div class="section-label">NOVIDADE · CURSO LIVRE</div><h3>Curso de Teologia</h3></div><span class="pill">${coursePercent()}%</span></div><p>5 grandes áreas, 52 disciplinas, 156 aulas, exercícios e avaliações com progresso salvo.</p><button class="btn" data-tab="course">📚 Começar o curso</button></div>
<div class="row"><h2>Por onde começar?</h2><span class="count">${done}/40 concluídos</span></div><div class="mini-grid"><button class="mini" data-tab="bible"><span class="symbol">▤</span><b>Bíblia</b><small>66 livros e referência ACF</small></button><button class="mini" data-tab="studies"><span class="symbol">✧</span><b>40 estudos</b><small>Da interpretação ao ministério</small></button><button class="mini" data-tab="notebook"><span class="symbol">✎</span><b>Meu caderno</b><small>Guarde suas reflexões</small></button><button class="mini" data-tab="harpa"><span class="symbol">♫</span><b>Harpa Cristã</b><small>Louvores e referências</small></button></div>
<div class="card" style="margin-top:16px"><div class="section-label">CONTINUE DE ONDE PAROU</div><h3>${esc(D.studies.find(x=>x.id===S.lastStudy)?.title||D.studies[0].title)}</h3><p class="muted">O aplicativo lembra o último estudo aberto e o ponto do seu caderno.</p><button class="btn" data-action="open-study" data-id="${S.lastStudy}">Retomar estudo</button></div>`;}
function bible(){let book=D.books.find(x=>x.name===S.lastBook)||D.books[18],chapter=Math.max(1,Math.min(book.chapters,Number(S.lastChapter)||1));return `${section('Bíblia','LEITURA E REFERÊNCIAS')}
<div class="card"><div class="fields"><div class="field"><label for="version">Versão preferida</label><select id="version"><option value="ACF" ${S.bibleVersion==='ACF'?'selected':''}>ACF — Almeida Corrigida Fiel</option><option value="BLIVRE" ${S.bibleVersion==='BLIVRE'?'selected':''}>Bíblia Livre (site original)</option><option value="A1819" ${S.bibleVersion==='A1819'?'selected':''}>Almeida 1819 (site original)</option></select></div><div class="field"><label for="book">Livro</label><select id="book">${D.books.map(b=>`<option value="${esc(b.name)}" ${b.name===book.name?'selected':''}>${esc(b.name)}</option>`).join('')}</select></div><div class="field"><label for="chapter">Capítulo</label><select id="chapter">${Array.from({length:book.chapters},(_,i)=>`<option value="${i+1}" ${i+1===chapter?'selected':''}>${i+1}</option>`).join('')}</select></div></div>
<div class="actions"><button class="btn" data-action="save-reading">Salvar leitura</button><button class="btn secondary" data-action="open-original">Abrir Bíblia no site original</button></div></div>
<div class="note"><b>Sobre a versão ACF:</b> ela está definida como preferência padrão. A reprodução integral da ACF exige autorização do detentor dos direitos. Nesta base de recuperação, a leitura do texto integral da ACF é feita pelo aplicativo oficial da Sociedade Bíblica Trinitariana, não por uma cópia não autorizada.</div>
<div class="card" style="margin-top:14px"><h3>${esc(book.name)} ${chapter}</h3><p>Capítulo selecionado e salvo neste aparelho. Use o leitor do app oficial para conferir as palavras exatas da ACF; não substituímos os versículos por paráfrases.</p><div class="actions"><a class="btn" href="https://play.google.com/store/apps/details?id=com.sbtb.FaithfulBible" rel="noopener noreferrer">Ler ACF no app oficial</a>${S.returnFromBible?'<button class="btn secondary" data-action="return-study">Voltar ao estudo</button>':''}</div></div>`;}
function studies(){let q=window._studyQuery||'',filtered=D.studies.filter(x=>(x.title+' '+x.section+' '+x.reference).toLowerCase().includes(q.toLowerCase()));return `${section('Estudos bíblicos','APRENDER COM PROFUNDIDADE')}<div class="card soft"><div class="section-label">CURSO ORGANIZADO</div><h3>Teologia — 5 áreas e 156 aulas</h3><p>Fundamentos bíblicos, doutrinas, história, filosofia e ministério.</p><button class="btn" data-tab="course">Abrir curso de Teologia</button></div><p class="muted">40 estudos com contexto, interpretação, aplicação e perguntas para reflexão. Cada leitura concluída fica registrada no aparelho.</p><div class="card"><div class="row"><strong>Seu progresso</strong><span class="count">${S.studyDone.length} / 40</span></div><div class="progress-track" style="margin-top:10px"><div class="progress-fill" style="width:${Math.min(100,S.studyDone.length*2.5)}%"></div></div></div>
<input id="study-search" class="search" aria-label="Pesquisar estudo" placeholder="Buscar estudo, referência ou tema" value="${esc(q)}" />
<div id="study-results">${studyCards(filtered)}</div>`;}
function studyCards(items){return items.map(x=>`<button class="list-card" data-action="open-study" data-id="${x.id}"><div class="row"><span class="pill">${esc(x.section)}</span><span aria-label="${S.studyDone.includes(x.id)?'Concluído':'Não concluído'}">${S.studyDone.includes(x.id)?'✓':'◯'}</span></div><strong style="margin-top:6px">${esc(x.title)}</strong><small>${esc(x.reference)}</small></button>`).join('')||'<p class="muted">Nenhum estudo encontrado.</p>';}
function study(){let st=D.studies.find(x=>x.id===S.lastStudy)||D.studies[0];return `<button class="back" data-tab="studies">‹ Todos os estudos</button><div class="section-label">ESTUDO ${st.id} DE 40 · ${esc(st.section)}</div><h1>${esc(st.title)}</h1><p><span class="pill">Passagem principal: ${esc(st.reference)}</span></p><div class="actions"><button class="btn small" data-action="open-study-bible" data-ref="${esc(st.reference)}">▤ Abrir na Bíblia</button>${actionsSpeak(`${st.title}. ${st.interpretation} ${st.application} Perguntas para reflexão: ${st.questions.join('. ')}`)}</div>
<div class="card content-prose" style="margin-top:18px"><h3>Contexto e interpretação</h3><p>${esc(st.interpretation)}</p><h3>Para aprofundar</h3><p>${esc(st.context)}</p><p class="note">Confira o texto completo e considere quem escreveu, o gênero literário e a situação histórica. O resumo é material de estudo, não uma transcrição bíblica.</p><h3>Aplicação e prática</h3><p>${esc(st.application)}</p><h3>Perguntas para refletir</h3><ol>${st.questions.map(x=>`<li>${esc(x)}</li>`).join('')}</ol><h3>Oração</h3><p>${esc(st.prayer)}</p><div class="actions"><button class="btn" data-action="complete-study" data-id="${st.id}">${S.studyDone.includes(st.id)?'✓ Estudo concluído':'Marcar como concluído'}</button><button class="btn secondary" data-action="new-note" data-title="${esc(st.title)}">✎ Anotar</button></div></div>`;}
function devotional(){let v=today(),done=S.devDone.includes(new Date().toLocaleDateString('sv-SE'));let speech=`Vamos tirar dez minutos para nosso devocional. ${v.theme}. Leitura sugerida: ${v.reference}. ${v.text} Momento de oração: ${v.prayer} Prática do dia: ${v.practice}`;return `${section('Devocional de hoje','UM ENCONTRO DIÁRIO')}<p class="muted">${new Intl.DateTimeFormat('pt-BR',{dateStyle:'full'}).format(new Date())}</p>
<div class="hero"><div class="section-label">10 MINUTOS COM A PALAVRA</div><h1>${esc(v.theme)}</h1><p>Passagem: ${esc(v.reference)}</p><button class="btn secondary" data-action="speak" data-text="${esc(speech)}">▶ Narrar devocional</button></div>
<div class="card content-prose"><h3>1. Prepare o coração · 1 min</h3><p>Encontre um lugar tranquilo, respire e faça uma oração breve pedindo atenção à Palavra.</p><h3>2. Abra a Bíblia · 3 min</h3><p>Leia <b>${esc(v.reference)}</b> na tradução selecionada: ${esc(S.bibleVersion)}. Releia atentamente uma segunda vez.</p><button class="btn secondary small" data-action="bible-ref" data-ref="${esc(v.reference)}">Abrir referência</button><h3>3. Medite · 3 min</h3><p>${esc(v.text)}</p><h3>4. Oração · 2 min</h3><p>${esc(v.prayer)}</p><h3>5. Um gesto de fé · 1 min</h3><p>${esc(v.practice)}</p><div class="actions">${actionsSpeak(speech)}<button class="btn" data-action="complete-dev">${done?'✓ Realizado hoje':'Marcar devocional realizado'}</button></div></div>
<div class="card"><h3>Alarme diário</h3><p class="smallprint">O lembrete aparece no Android aproximadamente no horário escolhido. O sistema pode atrasar notificações para economizar bateria.</p><div class="row"><div class="field"><label for="reminder-time">Horário</label><input type="time" id="reminder-time" value="${esc(S.time)}" /></div><label class="field"><span>Ativar lembrete</span><input id="reminder" type="checkbox" ${S.reminder?'checked':''} style="width:24px;height:24px" /></label></div><button class="btn small" data-action="set-reminder">Salvar lembrete</button></div>`;}
function notebook(){return `${section('Meu caderno','REFLEXÕES E APRENDIZADOS')}<div class="card"><div class="field"><label for="note-title">Título</label><input id="note-title" placeholder="Minha reflexão" value="${esc(window._noteTitle||'')}"/></div><div class="field" style="margin-top:10px"><label for="note-text">O que Deus tem me ensinado?</label><textarea id="note-text" placeholder="Escreva aqui. Seu conteúdo fica salvo somente neste aparelho.">${esc(window._noteText||'')}</textarea></div><button class="btn" data-action="save-note" style="margin-top:12px">Guardar reflexão</button></div><h2>Anotações (${S.notes.length})</h2>${S.notes.map(n=>`<div class="card"><div class="row"><h3>${esc(n.title)}</h3><button class="btn ghost small" data-action="delete-note" data-id="${n.id}" aria-label="Excluir anotação">Excluir</button></div><p class="smallprint">${esc(n.date)}</p><p class="study-text">${esc(n.text)}</p></div>`).join('')||'<p class="muted">Seu caderno começa com uma página em branco.</p>'}`;}
function harpa(){return `${section('Harpa Cristã','LOUVORES QUE ACOMPANHAM A FÉ')}<div class="card"><h3>Louvor e reflexão</h3><p>Selecione um hino, cante e registre a passagem bíblica associada. Esta base não inclui letras, gravações ou áudio comercial sem autorização.</p><p>Para ouvir seus louvores, use sua biblioteca do Spotify.</p><a class="btn" href="https://open.spotify.com/search/Harpa%20Crist%C3%A3" rel="noopener noreferrer">♫ Buscar na Spotify</a></div><button class="list-card" data-tab="notebook"><strong>Meu repertório e minhas anotações</strong><small>Escreva músicas e reflexões no caderno</small></button>`;}
function library(){return `${section('Biblioteca de estudos','HISTÓRIA, AUTORES E PESQUISA')}<div class="card"><h3>Guia de pesquisa</h3><p>Ao consultar um comentário bíblico, anote o autor, a obra, a edição e a passagem estudada. Compare perspectivas evangélicas e acadêmicas sem confundir opinião com o texto bíblico.</p><h3>Campos de estudo</h3><p>Exegese, hermenêutica, história bíblica, teologia bíblica, teologia sistemática, línguas originais, ética cristã e história da igreja.</p><button class="btn secondary" data-tab="studies">Explorar os 40 estudos</button></div>`;}
function assistant(){return `${section('Assistente de estudos','PESQUISA TEOLÓGICA COM IA')}<div class="card"><p>O assistente de IA do <b>site original</b> continua disponível online. Nesta versão local não incluímos uma chave de API no aplicativo, para evitar cobranças e exposição de credenciais.</p><p class="smallprint">Confirme as referências e as fontes antes de usar uma resposta no ensino ou no púlpito.</p><a class="btn" href="https://jardim-da-palavra-biblia-estudos.odiogo19.chatgpt.site/" rel="noopener noreferrer">Abrir assistente original</a></div>`;}
function more(){const names=[['plum','Ametista','#4a2d58'],['forest','Jardim','#345e42'],['ocean','Mar','#2b5672'],['sand','Areia','#735b42'],['night','Noite','#16151c']];return `${section('Mais recursos','PERSONALIZE SEU JARDIM')}<div class="card"><h3>Temas de cores</h3><div class="theme-list">${names.map(([id,name,color])=>`<button class="theme-choice ${S.theme===id?'selected':''}" data-action="theme" data-theme="${id}" aria-label="Tema ${name}" aria-pressed="${S.theme===id}"><span class="theme-swatch" style="background:${color}"></span>${name}</button>`).join('')}</div><div class="divider"></div><h3>Narração e acessibilidade</h3>
<p class="smallprint"><b>Dora — narradora do Jardim:</b> ela lê dinamicamente os textos exibidos, sem gravar ou cadastrar palavra por palavra. A qualidade depende da voz disponível no dispositivo. A voz original personalizada da Dora ainda não foi recuperada.</p>
<div id="voice-status" class="voice-status" role="status">Buscando vozes disponíveis no celular…</div>
<div class="field" style="margin-top:12px"><label for="voiceEngine">Mecanismo de voz</label><select id="voiceEngine"><option value="auto">Padrão do Android</option></select></div>
<div class="field" style="margin-top:12px"><label for="voiceId">Voz em português do Brasil</label><select id="voiceId"><option value="auto">Automática — melhor disponível</option></select></div>
<p class="smallprint">Prefira as vozes Google de qualidade alta ou, se disponível, uma voz online. Vozes online podem usar dados móveis. A disponibilidade depende do seu celular.</p>
<label class="narration-check"><input id="autoNarration" type="checkbox" ${S.autoNarration?'checked':''} /> Narrar as telas automaticamente ao navegar</label>
<div class="field" style="margin-top:12px"><label for="voiceRate">Velocidade de narração</label><select id="voiceRate"><option value="0.88" ${Number(S.voiceRate)<.91?'selected':''}>Calma</option><option value="0.96" ${Number(S.voiceRate)>=.91&&Number(S.voiceRate)<1.04?'selected':''}>Natural</option><option value="1.10" ${Number(S.voiceRate)>=1.04?'selected':''}>Mais rápida</option></select></div>
<div class="field" style="margin-top:12px"><label for="voicePitch">Tom da voz</label><select id="voicePitch"><option value="0.90" ${Number(S.voicePitch)===.9?'selected':''}>Mais grave</option><option value="1" ${Number(S.voicePitch)===1?'selected':''}>Natural</option><option value="1.10" ${Number(S.voicePitch)===1.1?'selected':''}>Mais agudo</option></select></div>
<div class="actions"><button class="btn secondary small" data-action="speak-demo">▶ Ouvir amostra da Dora</button><button class="btn ghost small" data-action="stop">■ Parar</button><button class="btn ghost small" data-action="refresh-voices">↻ Atualizar lista</button><button class="btn ghost small" data-action="voice-settings">⚙ Vozes do celular</button></div>
<p class="smallprint">Se só aparecer uma voz, atualize o app <a href="https://play.google.com/store/apps/details?id=com.google.android.tts">Síntese de voz do Google</a> e baixe as vozes em português nas configurações do Android.</p>
<div class="divider"></div><h3>Leitura acessível</h3><div class="actions"><button class="btn small secondary" data-action="font-down">A− Menor</button><button class="btn small secondary" data-action="font-up">A+ Maior</button></div></div>
${[['course','📚','Curso de Teologia'],['library','▧','Biblioteca teológica'],['harpa','♫','Harpa Cristã'],['assistant','✧','Assistente IA (site original)'],['notebook','✎','Meu caderno']].map(([tab,ico,title])=>`<button class="list-card" data-tab="${tab}"><strong>${ico} ${title}</strong></button>`).join('')}
<div class="card"><h3>Seus dados e backup</h3><p class="smallprint">Estudos concluídos, notas e preferências são armazenados localmente. Um backup permite recuperar os dados se você trocar de celular.</p><button class="btn secondary small" data-action="show-backup">Mostrar backup JSON</button><div id="backup-panel"></div></div><div class="note">Jardim da Palavra — base Android de recuperação. Conteúdo dos estudos e devocionais escrito para este projeto. ACF: texto protegido, leitura integral pelo aplicativo oficial. Não é a versão já publicada na Play Store.</div>`;}
function render(){applyTheme();let views={home,bible,studies,study,devotional,more,notebook,library,harpa,assistant,course, 'course-subject':courseSubject, 'course-lesson':courseLesson, 'course-assessment':courseAssessment};screen.innerHTML='<div class="voice-toolbar" role="group" aria-label="Narração da tela"><button type="button" class="btn secondary small" data-action="speak-screen">🔊 Dora: ler esta tela</button><button type="button" class="btn ghost small" data-action="stop">■ Parar</button></div>'+(views[S.tab]||home)();screen.setAttribute('data-view',S.tab);if(S.tab==='more')setTimeout(refreshVoiceControls,60);}
function openStudy(id){let st=D.studies.find(x=>x.id===Number(id));if(!st)return;patch({lastStudy:st.id,tab:'study'});render();window.scrollTo(0,0);autoReadScreen();}
function inferBook(ref){let b=D.books.filter(x=>ref.toLowerCase().startsWith(x.name.toLowerCase())).sort((a,z)=>z.name.length-a.name.length)[0];let suffix=b?ref.slice(b.name.length).trim():ref;let m=suffix.match(/^(\d+)/);return {name:b?.name||S.lastBook,chapter:m?Number(m[1]):S.lastChapter};}
function openRef(ref,fromStudy=false){let b=inferBook(ref);patch({lastBook:b.name,lastChapter:b.chapter,returnFromBible:fromStudy?S.lastStudy:null,tab:'bible'});render();window.scrollTo(0,0);autoReadScreen();}
function narrationText(){
  if(S.tab==='course-lesson'){let sub=courseSubjectById(S.courseSubjectId),lesson=courseLessonById(sub,S.courseLessonId);return `Aula de Teologia. ${sub.title}. ${lesson.title}. ${lesson.content}. Atividade: ${lesson.activity}. Questão: ${lesson.question}`;}
  if(S.tab==='course')return `Curso livre de Teologia. Cinco eixos, cinquenta e duas disciplinas e cento e cinquenta e seis aulas. Seu progresso é de ${coursePercent()} por cento.`;
  if(S.tab==='course-subject')return `Disciplina de Teologia: ${courseSubjectById(S.courseSubjectId).title}.`;
  if(S.tab==='course-assessment')return `Avaliação de revisão de ${courseSubjectById(S.courseSubjectId).title}.`;
  if(S.tab==='study'){
    const st=D.studies.find(x=>x.id===S.lastStudy)||D.studies[0];
    return `Estudo ${st.id} de 40. ${st.title}. Texto para consultar na Bíblia: ${st.reference}. Contexto: ${st.context}. Interpretação: ${st.interpretation}. Aplicação: ${st.application}. Perguntas para reflexão: ${st.questions.join('. ')}. Oração: ${st.prayer}`;
  }
  if(S.tab==='devotional'){
    const v=today();
    return `Bem-vinda ao nosso momento de devocional. Vamos separar um tempo para a Palavra. Tema de hoje: ${v.theme}. Leitura sugerida: ${v.reference} na versão ${S.bibleVersion}. Prepare o coração para um momento de oração. Reflexão: ${v.text}. Agora vamos orar. ${v.prayer}. Nosso gesto de fé para hoje: ${v.practice}. Amém.`;
  }
  if(S.tab==='home'){
    const v=today();
    return `Bem-vinda ao Jardim da Palavra. Um jardim para estudar a Palavra. A reflexão de hoje é ${v.theme}, com leitura sugerida em ${v.reference}. Você pode abrir o devocional, continuar seu estudo, consultar a Bíblia ou escrever no caderno.`;
  }
  if(S.tab==='bible')return `Bíblia. Tradução selecionada: ${S.bibleVersion}. Livro ${S.lastBook}, capítulo ${S.lastChapter}. O texto integral desta tradução não está disponível dentro desta versão do aplicativo. Para a leitura dos versículos, abra o leitor oficial. A narração do aplicativo não substitui o texto da Bíblia.`;
  if(S.tab==='studies')return `Estudos bíblicos. Estão disponíveis quarenta estudos com contexto, interpretação, aplicação e perguntas. Você concluiu ${S.studyDone.length} estudos. Selecione um estudo para escutar seu conteúdo.`;
  if(S.tab==='notebook')return `Meu caderno de reflexões. Você tem ${S.notes.length} anotações salvas. ${S.notes.slice(0,5).map(n=>`${n.title}. ${n.text}`).join('. ') || 'Aqui você pode registrar o que aprender com os estudos.'}`;
  if(S.tab==='harpa')return 'Harpa Cristã. Uma seção para acompanhar os louvores. Você pode buscar músicas no Spotify e escrever suas reflexões no caderno.';
  if(S.tab==='library')return 'Biblioteca de estudos. Explore hermenêutica, exegese, teologia bíblica, teologia sistemática, história bíblica e história da igreja. Anote autor e fontes consultadas.';
  if(S.tab==='assistant')return 'Assistente de estudos. Nesta versão, a inteligência artificial está disponível por meio do site original quando houver conexão com a internet.';
  return 'Mais recursos. Escolha um dos temas de cores, ajuste a fonte, ative a narração automática, escolha a velocidade da voz e faça backup das anotações.';
}
/* Textos extraidos da tela atual: sem dicionario de palavras nem arquivos de audio. */
function readableScreenText(){
 const root=document.querySelector('#screen'); if(!root)return '';
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
 let n,parts=[],last='';
 while((n=walker.nextNode())){
  let el=n.parentElement;if(!el||el.closest('button,a,input,select,textarea,script,style,.voice-toolbar,.actions,.smallprint,.theme-list,#voice-status,.note'))continue;
  if(el.hidden||el.closest('[hidden],[aria-hidden="true"]'))continue;
  let txt=(n.textContent||'').replace(/\s+/g,' ').trim();
  if(!txt||txt===last)continue;
  parts.push(txt);last=txt;
 }
 return parts.join('. ').replace(/\. \./g,'.').slice(0,20000);
}
function autoReadScreen(){if(S.autoNarration)narrate(readableScreenText()||narrationText());else stopSpeech();}
function refreshVoiceControls(){
 const statusEl=document.querySelector('#voice-status');if(!statusEl)return;
 const engineEl=document.querySelector('#voiceEngine'), voiceEl=document.querySelector('#voiceId');
 if(!window.JardimAndroid?.voiceCatalog){statusEl.textContent='Prévia web: a escolha das vozes aparece no aplicativo Android.';return;}
 try{
  const info=JSON.parse(window.JardimAndroid.voiceCatalog());
  statusEl.textContent=info.ready?`Mecanismo ativo: ${info.engine||'Android'} · ${info.voices.length} voz(es) pt-BR disponível(is).`:'Inicializando a voz… Se continuar assim, abra as configurações de voz do celular.';
  const engineOptions=[{id:'auto',label:'Padrão do Android'},...(info.engines||[])];
  engineEl.innerHTML=engineOptions.map(x=>`<option value="${esc(x.id)}">${esc(x.label)}</option>`).join('');
  engineEl.value=engineOptions.some(x=>x.id===S.voiceEngine)?S.voiceEngine:'auto';
  const voices=info.voices||[];
  voiceEl.innerHTML='<option value="auto">Automática — melhor disponível</option>'+voices.map((v,i)=>`<option value="${esc(v.id)}">Voz ${i+1} · ${v.quality>=400?'Alta qualidade':v.quality>=300?'Qualidade normal':'Básica'} · ${v.online?'Online':'Offline'} · ${esc(v.id)}${v.installed?'':' · baixar'}</option>`).join('');
  voiceEl.value=voices.some(v=>v.id===S.voiceId)?S.voiceId:'auto';
 }catch(e){statusEl.textContent='Não foi possível consultar as vozes: '+e.message;}
}
function narrate(text){
 if(!text||!text.trim())return;
 if(window.JardimAndroid?.speak){
  if(window.JardimAndroid.isTtsReady && !window.JardimAndroid.isTtsReady()){toast('Voz não pronta. Abra Mais → Narração e veja a configuração.');return;}
  window.JardimAndroid.setSpeechRate?.(Number(S.voiceRate)||.96);
  window.JardimAndroid.setSpeechPitch?.(Number(S.voicePitch)||1);
  window.JardimAndroid.speak(text);toast('Dora está lendo com a voz selecionada');return;
 }
 if('speechSynthesis' in window){speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';u.rate=Number(S.voiceRate)||.96;u.pitch=Number(S.voicePitch)||1;speechSynthesis.speak(u);toast('Leitura iniciada');}
 else toast('Narração indisponível neste aparelho');
}
function stopSpeech(){if(window.JardimAndroid?.stopSpeech)window.JardimAndroid.stopSpeech();if('speechSynthesis'in window)speechSynthesis.cancel();}
function reminder(){let time=document.querySelector('#reminder-time')?.value||'07:00',enabled=!!document.querySelector('#reminder')?.checked;patch({time,reminder:enabled});if(window.JardimAndroid?.setDailyReminder){let [h,m]=time.split(':').map(Number);window.JardimAndroid.setDailyReminder(enabled,h,m);toast(enabled?'Lembrete diário configurado':'Lembrete desligado');}else{toast('Preferência salva. Alarmes automáticos exigem o APK Android.');}}
function maybeCopy(text){if(navigator.clipboard?.writeText){navigator.clipboard.writeText(text).then(()=>toast('Texto copiado'),()=>toast('Selecione o texto para copiar'));}else toast('Selecione o texto para copiar');}
async function share(text){if(navigator.share){try{await navigator.share({title:'Jardim da Palavra',text});return;}catch(e){if(e.name==='AbortError')return;}}maybeCopy(text);}
function backupPanel(){let el=document.querySelector('#backup-panel');if(!el)return;el.innerHTML=`<div class="field" style="margin-top:14px"><label for="backup-data">Copie este backup ou cole um backup anterior</label><textarea id="backup-data" style="min-height:170px">${esc(JSON.stringify({app:'JardimDaPalavra',version:1,data:S},null,2))}</textarea></div><div class="actions"><button class="btn small" data-action="restore-backup">Restaurar backup</button></div>`;}
function restoreBackup(){try{let b=JSON.parse(document.querySelector('#backup-data').value);if(b.app!=='JardimDaPalavra'||!b.data||!Array.isArray(b.data.notes)||!Array.isArray(b.data.studyDone))throw Error('Formato inválido');S={...defaults,...b.data};save();render();toast('Backup restaurado');}catch(e){toast('Backup inválido: '+e.message)}}
function setReminderFromState(){/* Schedules only on explicit user request, never silently request permission. */}
window.jardimBack=function(){if(S.tab==='course-lesson'||S.tab==='course-assessment'){go('course-subject');return true;}if(S.tab==='course-subject'){go('course');return true;}if(S.tab==='course'){go('studies');return true;}if(S.tab==='bible'&&S.returnFromBible){patch({tab:'study',returnFromBible:null});render();return true;}if(S.tab==='study'){go('studies');return true;}if(S.tab!=='home'){go('home');return true;}return false;};
document.querySelector('#fontToggle').addEventListener('click',()=>{S.font=S.font>=1.3?1:Math.round((S.font+.1)*10)/10;save();applyTheme();});
document.addEventListener('input',e=>{handleCourseInput(e);if(e.target.id==='study-search'){window._studyQuery=e.target.value;document.querySelector('#study-results').innerHTML=studyCards(D.studies.filter(x=>(x.title+' '+x.section+' '+x.reference).toLowerCase().includes(window._studyQuery.toLowerCase())));}});
document.addEventListener('change',e=>{if(e.target.id==='book'){patch({lastBook:e.target.value,lastChapter:1});render();}if(e.target.id==='version'){patch({bibleVersion:e.target.value});render();}if(e.target.id==='chapter'){patch({lastChapter:Number(e.target.value)});render();}if(e.target.id==='autoNarration'){patch({autoNarration:!!e.target.checked});if(S.autoNarration)narrate(narrationText());else stopSpeech();}if(e.target.id==='voiceRate'){patch({voiceRate:Number(e.target.value)});toast('Velocidade salva');}
if(e.target.id==='voicePitch'){patch({voicePitch:Number(e.target.value)});toast('Tom da voz salvo');}
if(e.target.id==='voiceEngine'){patch({voiceEngine:e.target.value,voiceId:'auto'});stopSpeech();window.JardimAndroid?.setVoiceEngine?.(e.target.value);toast('Mudando mecanismo de voz…');setTimeout(refreshVoiceControls,1100);}
if(e.target.id==='voiceId'){patch({voiceId:e.target.value});stopSpeech();window.JardimAndroid?.setVoiceId?.(e.target.value);toast('Voz selecionada. Ouça uma amostra.');}});
document.addEventListener('click',e=>{let btn=e.target.closest('[data-tab],[data-action]');if(!btn)return;
 if(btn.dataset.tab){go(btn.dataset.tab);return;}
 const a=btn.dataset.action;
 if(handleCourseAction(a,btn))return;
 if(a==='open-study')openStudy(btn.dataset.id);
 if(a==='complete-study'){let id=Number(btn.dataset.id);if(!S.studyDone.includes(id))S.studyDone.push(id);save();render();toast('Estudo concluído e salvo');}
 if(a==='open-study-bible')openRef(btn.dataset.ref,true);
 if(a==='bible-ref')openRef(btn.dataset.ref,false);
 if(a==='return-study'){patch({tab:'study',returnFromBible:null});render();autoReadScreen();}
 if(a==='save-reading'){patch({lastBook:document.querySelector('#book').value,lastChapter:Number(document.querySelector('#chapter').value)});toast('Leitura salva neste aparelho');}
 if(a==='open-original')window.location.href='https://jardim-da-palavra-biblia-estudos.odiogo19.chatgpt.site/';
 if(a==='speak')narrate(btn.dataset.text);
 if(a==='speak-screen')narrate(readableScreenText()||narrationText());
 if(a==='speak-demo')narrate('Olá, eu sou Dora, a narradora do Jardim da Palavra. É uma alegria acompanhar você em seus estudos e devocionais. Que a paz do Senhor esteja em seu coração.');
 if(a==='refresh-voices')refreshVoiceControls();
 if(a==='voice-settings')window.JardimAndroid?.openVoiceSettings?.();
 if(a==='stop')stopSpeech();
 if(a==='share')share(btn.dataset.text);
 if(a==='complete-dev'){let dt=new Date().toLocaleDateString('sv-SE');if(!S.devDone.includes(dt))S.devDone.push(dt);save();render();toast('Devocional registrado');}
 if(a==='set-reminder')reminder();
 if(a==='theme'){patch({theme:btn.dataset.theme});render();}
 if(a==='font-up'){patch({font:Math.min(1.5,Math.round((S.font+.1)*10)/10)});render();}
 if(a==='font-down'){patch({font:Math.max(.9,Math.round((S.font-.1)*10)/10)});render();}
 if(a==='new-note'){window._noteTitle=btn.dataset.title;go('notebook');}
 if(a==='save-note'){let title=document.querySelector('#note-title').value.trim(),content=document.querySelector('#note-text').value.trim();if(!content){toast('Escreva uma reflexão para salvar');return;}S.notes.unshift({id:Date.now(),title:title||'Minha reflexão',text:content,date:new Date().toLocaleDateString('pt-BR')});window._noteTitle='';window._noteText='';save();render();toast('Reflexão salva');}
 if(a==='delete-note'){if(confirm('Excluir esta reflexão?')){S.notes=S.notes.filter(n=>String(n.id)!==btn.dataset.id);save();render();}}
 if(a==='show-backup')backupPanel();
 if(a==='restore-backup')restoreBackup();
});
render();
