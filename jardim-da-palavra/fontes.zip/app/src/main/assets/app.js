'use strict';
/* Jardim da Palavra - base offline. Sem chaves ou serviços comerciais. */
const D = window.JARDIM_DATA;
const KEY = 'jardim-palavra-local-v1';
const defaults = {theme:'plum',font:1,tab:'home',lastStudy:1,lastBook:'Salmos',lastChapter:23,notes:[],studyDone:[],devDone:[],reminder:false,time:'07:00',bibleVersion:'ACF',returnFromBible:null,bibleReturn:null,autoNarration:false,voiceRate:0.96,voicePitch:1,voiceEngine:'auto',voiceId:'auto',courseDone:[],courseExamDone:[],courseSubjectId:'m01',courseLessonId:'m01-a1',courseTrack:'all',courseAnswers:{},courseExamAnswers:{},courseShown:[],courseExamShown:[],noteDraft:{title:'',text:''},courseScrolls:{},devSession:null,devReflections:{},localChatHistory:[]};
let S;try{S=Object.assign({},defaults,JSON.parse(localStorage.getItem(KEY)||'{}'));}catch{S={...defaults};}
let screen = document.querySelector('#screen'), toastTimer;
for(const k of ['courseDone','courseExamDone','courseShown','courseExamShown']){if(!Array.isArray(S[k])) S[k]=[];}
for(const k of ['courseAnswers','courseExamAnswers','courseScrolls']){if(!S[k]||typeof S[k]!=='object'||Array.isArray(S[k])) S[k]={};}
for(const k of ['notes','studyDone','devDone']){if(!Array.isArray(S[k])) S[k]=[];}
if(!S.noteDraft||typeof S.noteDraft!=='object'||Array.isArray(S.noteDraft))S.noteDraft={title:'',text:''};
S.noteDraft={title:String(S.noteDraft.title||''),text:String(S.noteDraft.text||'')};
if(!Array.isArray(S.notes))S.notes=[];
if(!Array.isArray(S.localChatHistory))S.localChatHistory=[];
if(!S.devReflections||typeof S.devReflections!=='object'||Array.isArray(S.devReflections))S.devReflections={};
const esc = s => String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function save(){try{localStorage.setItem(KEY,JSON.stringify(S))}catch(e){toast('Não foi possível salvar. Verifique o espaço do aparelho.')}}
function patch(p){Object.assign(S,p);save();}
function toast(m){let el=document.querySelector('#toast');el.textContent=m;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600);}
function dayIndex(date=new Date()){let start=new Date(date.getFullYear(),0,1);return Math.floor((Date.UTC(date.getFullYear(),date.getMonth(),date.getDate())-Date.UTC(start.getFullYear(),0,1))/86400000)%31;}
const today=()=>D.devotionals[dayIndex()];
const musicToday=()=>window.JARDIM_MUSIC?.[dayIndex()]||null;
const musicSearch=(platform,item)=>platform==='spotify'
  ?'https://open.spotify.com/search/'+encodeURIComponent(`${item.title} ${item.artist.replace(/ ·.*/, '')}`)
  :'https://www.youtube.com/results?search_query='+encodeURIComponent(`${item.title} ${item.artist.replace(/ ·.*/, '')}`);
function musicSuggestion(){
 const m=musicToday(); if(!m)return '';
 return `<div class="card music-suggestion" aria-label="Louvor sugerido para o devocional">
 <div class="section-label">♫ MOMENTO DE LOUVOR · SUGESTÃO DO DIA</div>
 <h3>${esc(m.title)}</h3><p class="muted">${esc(m.artist)}</p>
 <p>${esc(m.why)}</p><p class="smallprint">Escolha uma gravação na plataforma. O Jardim da Palavra não reproduz nem baixa músicas comerciais. O louvor é opcional e pode continuar após os dez minutos do devocional.</p>
 <div class="actions"><a class="btn" href="${musicSearch('spotify',m)}" rel="noopener noreferrer" aria-label="Buscar ${esc(m.title)} no Spotify">♫ Ouvir no Spotify</a><a class="btn secondary" href="${musicSearch('youtube',m)}" rel="noopener noreferrer" aria-label="Buscar ${esc(m.title)} no YouTube">▶ Ouvir no YouTube</a></div>
 </div>`;
}

function applyTheme(){document.documentElement.dataset.theme=S.theme;document.documentElement.style.setProperty('--font',S.font);document.querySelectorAll('.bottom button').forEach(b=>{b.classList.toggle('selected',b.dataset.tab===(S.tab.startsWith('course')||S.tab==='study'?'studies':S.tab));b.setAttribute('aria-current',b.dataset.tab===(S.tab.startsWith('course')||S.tab==='study'?'studies':S.tab)?'page':'false')});}
function go(tab,{scroll=true}={}){pauseDevTimer();saveCurrentCourseScroll();if(!['home','bible','studies','study','devotional','more','notebook','library','assistant','harpa','course','course-subject','course-lesson','course-assessment'].includes(tab))tab='home';patch({tab});render();if(scroll)window.scrollTo(0,0);autoReadScreen();}
function section(head,sub=''){return `<div class="section-label">${esc(sub)}</div><h1>${esc(head)}</h1>`;}
function actionsSpeak(text){return `<button type="button" class="btn secondary" data-action="speak" data-text="${esc(text)}">🔊 Ouvir</button><button type="button" class="btn ghost" data-action="stop">■ Parar</button>`;}
function home(){let v=today(),done=S.studyDone.length;return `<div class="hero"><div class="section-label">SEU TEMPO COM DEUS</div><h1>Um jardim para estudar a Palavra.</h1><p>Leia com calma. Estude com profundidade. Guarde o que florescer.</p><div class="actions"><button class="btn secondary" data-tab="devotional">☼ Devocional de hoje</button></div></div>
<div class="card"><div class="section-label">REFERÊNCIA BÍBLICA DO DIA · ${esc(S.bibleVersion)}</div><div class="daily-verse"><strong>${esc(v.reference)}</strong><p>${esc(v.theme)} — sua passagem de reflexão de hoje.</p><p class="smallprint">A referência muda diariamente. Consulte o texto integral na versão selecionada.</p></div><div class="actions"><button class="btn small" data-action="bible-ref" data-ref="${esc(v.reference)}">Abrir referência</button><button class="btn small secondary" data-action="share" data-text="Jardim da Palavra 🌿 — Reflexão de hoje: ${esc(v.reference)} (${esc(v.theme)}).">Compartilhar</button></div></div>
<div class="card course-feature"><div class="row"><div><div class="section-label">NOVIDADE · CURSO LIVRE</div><h3>Curso de Teologia</h3></div><span class="pill">${coursePercent()}%</span></div><p>5 grandes áreas, 52 disciplinas, 156 aulas, exercícios e avaliações com progresso salvo.</p><button class="btn" data-tab="course">📚 Começar o curso</button></div>
<div class="row"><h2>Por onde começar?</h2><span class="count">${done}/40 concluídos</span></div><div class="mini-grid"><button class="mini" data-tab="bible"><span class="symbol">▤</span><b>Bíblia</b><small>66 livros e referência ACF</small></button><button class="mini" data-tab="studies"><span class="symbol">✧</span><b>40 estudos</b><small>Da interpretação ao ministério</small></button><button class="mini" data-tab="notebook"><span class="symbol">✎</span><b>Meu caderno</b><small>Guarde suas reflexões</small></button><button class="mini" data-tab="harpa"><span class="symbol">♫</span><b>Harpa Cristã</b><small>Louvores e referências</small></button><button class="mini" data-tab="assistant"><span class="symbol">✦</span><b>Assistente</b><small>Pergunte e encontre fontes</small></button><button class="mini" data-tab="course"><span class="symbol">▧</span><b>Curso completo</b><small>Apostilas e avaliações</small></button></div>
<div class="card" style="margin-top:16px"><div class="section-label">CONTINUE DE ONDE PAROU</div><h3>${esc(D.studies.find(x=>x.id===S.lastStudy)?.title||D.studies[0].title)}</h3><p class="muted">O aplicativo lembra o último estudo aberto e o ponto do seu caderno.</p><button class="btn" data-action="open-study" data-id="${S.lastStudy}">Retomar estudo</button></div>`;}
function bible(){return window.JARDIM_BIBLE?.renderBible(S)||'<div class="card"><h2>Leitor local indisponível</h2></div>';}
function studies(){let q=window._studyQuery||'',filtered=D.studies.filter(x=>(x.title+' '+x.section+' '+x.reference).toLowerCase().includes(q.toLowerCase()));return `${section('Estudos bíblicos','APRENDER COM PROFUNDIDADE')}<div class="card soft"><div class="section-label">CURSO ORGANIZADO</div><h3>Teologia — 5 áreas e 156 aulas</h3><p>Fundamentos bíblicos, doutrinas, história, filosofia e ministério.</p><div class="actions"><button class="btn" data-tab="course">Abrir curso de Teologia</button><button class="btn secondary" data-tab="assistant">✦ Perguntar ao assistente</button></div></div><p class="muted">40 estudos com contexto, interpretação, aplicação e perguntas para reflexão. Cada leitura concluída fica registrada no aparelho.</p><div class="card"><div class="row"><strong>Seu progresso</strong><span class="count">${S.studyDone.length} / 40</span></div><div class="progress-track" style="margin-top:10px"><div class="progress-fill" style="width:${Math.min(100,S.studyDone.length*2.5)}%"></div></div></div>
<input id="study-search" class="search" aria-label="Pesquisar estudo" placeholder="Buscar estudo, referência ou tema" value="${esc(q)}" />
<div id="study-results">${studyCards(filtered)}</div>`;}
function studyCards(items){return items.map(x=>`<button class="list-card" data-action="open-study" data-id="${x.id}"><div class="row"><span class="pill">${esc(x.section)}</span><span aria-label="${S.studyDone.includes(x.id)?'Concluído':'Não concluído'}">${S.studyDone.includes(x.id)?'✓':'◯'}</span></div><strong style="margin-top:6px">${esc(x.title)}</strong><small>${esc(x.reference)}</small></button>`).join('')||'<p class="muted">Nenhum estudo encontrado.</p>';}
function study(){let st=D.studies.find(x=>x.id===S.lastStudy)||D.studies[0];return `<button class="back" data-tab="studies">‹ Todos os estudos</button><div class="section-label">ESTUDO ${st.id} DE 40 · ${esc(st.section)}</div><h1>${esc(st.title)}</h1><p><span class="pill">Passagem principal: ${esc(st.reference)}</span></p><div class="actions"><button class="btn small" data-action="open-study-bible" data-ref="${esc(st.reference)}">▤ Abrir na Bíblia</button>${actionsSpeak(`${st.title}. ${st.interpretation} ${st.application} Perguntas para reflexão: ${st.questions.join('. ')}`)}</div>
<div class="card content-prose" style="margin-top:18px"><h3>Contexto e interpretação</h3><p>${esc(st.interpretation)}</p><h3>Para aprofundar</h3><p>${esc(st.context)}</p><p class="note">Confira o texto completo e considere quem escreveu, o gênero literário e a situação histórica. O resumo é material de estudo, não uma transcrição bíblica.</p><h3>Aplicação e prática</h3><p>${esc(st.application)}</p><h3>Perguntas para refletir</h3><ol>${st.questions.map(x=>`<li>${esc(x)}</li>`).join('')}</ol><h3>Oração</h3><p>${esc(st.prayer)}</p><div class="actions"><button class="btn" data-action="complete-study" data-id="${st.id}">${S.studyDone.includes(st.id)?'✓ Estudo concluído':'Marcar como concluído'}</button><button class="btn secondary" data-action="new-note" data-title="${esc(st.title)}">✎ Anotar</button></div></div>`;}
/* Roteiro em cinco etapas recuperado do layout original, com relógio e progresso próprios. */
const DEV_STEPS=[
 {name:'Acolhimento',seconds:60},
 {name:'Louvor',seconds:120},
 {name:'Palavra e reflexão',seconds:180},
 {name:'Aplicação',seconds:120},
 {name:'Oração',seconds:120}
];
let devTick=null,devStartAt=0;
function devDateKey(){const d=new Date();return [d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');}
function devSession(){
 const day=devDateKey();
 if(!S.devSession||S.devSession.date!==day||!Array.isArray(S.devSession.elapsed)||S.devSession.elapsed.length!==5){
  S.devSession={date:day,step:0,elapsed:[0,0,0,0,0]}; save();
 }
 S.devSession.step=Math.max(0,Math.min(4,Number(S.devSession.step)||0));
 return S.devSession;
}
function devElapsed(){const session=devSession(),i=session.step;return Math.min(DEV_STEPS[i].seconds,Math.max(0,Number(session.elapsed[i])||0)+(devStartAt?Math.max(0,(Date.now()-devStartAt)/1000):0));}
function devFormat(seconds){const s=Math.max(0,Math.ceil(seconds));return String(Math.floor(s/60)).padStart(2,'0')+':'+String(s%60).padStart(2,'0');}
function updateDevClock(){const el=document.querySelector('#dev-clock'),btn=document.querySelector('#dev-timer-toggle');if(!el||S.tab!=='devotional')return;const step=devSession().step;const remaining=DEV_STEPS[step].seconds-devElapsed();el.textContent=devFormat(remaining);if(btn)btn.textContent=devStartAt?'Ⅱ Pausar etapa':(remaining<=0?'↻ Reiniciar etapa':'▷ Começar etapa');if(remaining<=0&&devStartAt){pauseDevTimer();toast('Tempo da etapa concluído. Avance quando desejar.');}}
function pauseDevTimer(){if(devStartAt){const q=devSession(),i=q.step;q.elapsed[i]=Math.min(DEV_STEPS[i].seconds,devElapsed());devStartAt=0;save();}if(devTick){clearInterval(devTick);devTick=null;}updateDevClock();}
function toggleDevTimer(){const q=devSession(),i=q.step;if(devStartAt){pauseDevTimer();return;}if(q.elapsed[i]>=DEV_STEPS[i].seconds)q.elapsed[i]=0;devStartAt=Date.now();save();devTick=setInterval(updateDevClock,500);updateDevClock();}
function devChangeStep(i){pauseDevTimer();const q=devSession();q.step=Math.max(0,Math.min(4,i));save();stopSpeech();render();const active=document.querySelector('.dev-stage-tab.active');const strip=active?.parentElement;if(active&&strip){strip.scrollLeft=Math.max(0,active.offsetLeft-strip.offsetLeft-(strip.clientWidth-active.clientWidth)/2);}document.querySelector('#dev-card')?.scrollIntoView({behavior:'auto',block:'start'});if(S.autoNarration)narrate(devNarrationStep());}
function devNarrationStep(){const v=today(),m=musicToday(),i=devSession().step;
 if(i===0)return `Vamos tirar um tempo para o nosso devocional? Reserve estes minutos para estar com Deus. Respire com calma, diminua as distrações e apresente seu coração ao Senhor. Hoje meditaremos em ${v.reference}.`;
 if(i===1)return `Momento de louvor. A sugestão de hoje é ${m?.title||'um louvor'} ${m?.artist?'de '+m.artist:''}. ${m?.why||''}. Escolha sua gravação no Spotify ou no YouTube.`;
 if(i===2){const local=window.JARDIM_BIBLE?.passage(v.reference);return `Palavra e reflexão. Leitura em ${v.reference}. ${local?.speech||'Abra a Bíblia e importe o ZIP da ACF para ouvir a passagem offline.'} ${v.text}`;}
 if(i===3)return `Aplicação. ${v.practice}. Anote uma pequena decisão e guarde sua reflexão.`;
 return `Oração. ${v.prayer}. Continue a oração com suas próprias palavras.`;
}
function devMusicCard(){const m=musicToday();if(!m)return '<p>Escolha um louvor para este momento.</p>';return `<div class="dev-song"><span class="dev-song-note" aria-hidden="true">♫</span><div><div class="section-label">SUGESTÃO DE LOUVOR</div><h3>${esc(m.title)}</h3><p>${esc(m.artist)}</p></div></div><p>${esc(m.why)}</p><div class="dev-song-links"><a data-devmusic="spotify" class="btn" href="${musicSearch('spotify',m)}" rel="noopener noreferrer" target="_blank">♫ Buscar no Spotify</a><a data-devmusic="youtube" class="btn secondary" href="${musicSearch('youtube',m)}" rel="noopener noreferrer" target="_blank">▷ Buscar no YouTube</a></div><p class="smallprint">Ao abrir o louvor, o cronômetro é pausado para você continuar depois. Nenhuma música é reproduzida sem sua escolha.</p>`;}
function devStageContent(){const v=today();switch(devSession().step){
 case 0:return `<div class="dev-large-copy"><p>Vamos tirar um tempo para o nosso devocional?</p><p>Reserve estes minutos para estar com Deus. Respire com calma, diminua as distrações e apresente seu coração ao Senhor.</p><p>Hoje vamos meditar em <strong>${esc(v.reference)}</strong>. Caminhe pelas etapas no seu ritmo.</p></div><p class="dev-calm-note">A voz lê o conteúdo; as pausas completam o tempo de meditação. Você pode avançar quando desejar.</p>`;
 case 1:return `<div class="dev-large-copy"><p>Separe um momento para louvar. Você pode cantar, ouvir uma gravação ou ficar em silêncio diante de Deus.</p></div>${devMusicCard()}`;
 case 2:{const passage=window.JARDIM_BIBLE?.passage(v.reference);return `<div class="dev-passage"><div class="section-label">${esc(v.reference)} · ${passage?.verses?.length?"ACF IMPORTADA · LEITURA OFFLINE":"ACF — LEITURA AGUARDANDO IMPORTAÇÃO"}</div><h3>Leia a Palavra no contexto</h3>${passage?.verses?.length?window.JARDIM_BIBLE.versesHtml({verses:passage.verses}):'<p>Importe sua cópia da ACF na seção Bíblia para exibir e narrar estes versículos sem internet.</p>'}<div class="actions"><button class="btn secondary" data-action="bible-ref" data-ref="${esc(v.reference)}">▤ Abrir passagem na Bíblia</button></div></div><h3>Para refletir</h3><div class="dev-large-copy"><p>${esc(v.text)}</p></div><p class="dev-calm-note">Releia o trecho e pergunte: o que essa passagem revela sobre Deus e como se aplica a hoje?</p>`;}
 case 3:return `<div class="dev-large-copy"><p>${esc(v.practice)}</p></div><div class="field"><label for="dev-reflection">Minha reflexão de hoje</label><textarea id="dev-reflection" rows="6" placeholder="Uma preocupação, um agradecimento, um próximo passo...">${esc(S.devReflections?.[devDateKey()]||'')}</textarea></div><p class="dev-calm-note">Sua reflexão é salva automaticamente neste aparelho e pode ser recuperada no backup.</p>`;
 default:return `<blockquote class="dev-prayer">${esc(v.prayer)}</blockquote><div class="dev-large-copy"><p>Continue a oração com suas próprias palavras. Leve a Deus seus pedidos, sua gratidão e as pessoas que estão em seu coração.</p></div>`;
}}
function devotional(){const v=today(),session=devSession(),i=session.step,done=S.devDone.includes(devDateKey());const step=DEV_STEPS[i],date=new Intl.DateTimeFormat('pt-BR',{dateStyle:'full'}).format(new Date());return `<section class="devotional-restored" aria-label="Devocional guiado">
<div class="dev-intro"><h1>Seu devocional de hoje</h1><p>${esc(date)} · Uma pausa para louvar, refletir e orar.</p></div>
<div class="dev-hero"><div class="section-label">${esc(v.reference)}</div><h2>${esc(v.theme)}</h2><div class="dev-meta"><span>◷ 10 minutos sugeridos</span><span>◖ Dora · voz configurada no Android</span></div></div>
<div class="dev-stage-strip" role="group" aria-label="Etapas do devocional">${DEV_STEPS.map((x,j)=>`<button type="button" class="dev-stage-tab ${i===j?'active':''}" data-action="dev-step" data-step="${j}" ${i===j?'aria-current="step"':''}><span class="dev-step-num">${j+1}</span><strong>${x.name}</strong><small>${x.seconds/60} min</small></button>`).join('')}</div>
<article class="dev-stage-card" id="dev-card"><div class="dev-stage-head"><div class="section-label">ETAPA ${i+1} DE 5</div><div id="dev-clock" class="dev-clock" role="timer">${devFormat(step.seconds-devElapsed())}</div></div><h2>${step.name}</h2><div class="dev-progress" aria-hidden="true"><div style="width:${(i/5)*100}%"></div></div>
<div class="dev-stage-body">${devStageContent()}</div>
<div class="dev-narration-label">♬ Dora · leitura pela voz selecionada</div>
<div class="dev-stage-buttons"><button type="button" id="dev-timer-toggle" class="btn" data-action="dev-toggle-timer">▷ Começar etapa</button><button type="button" class="btn secondary" data-action="dev-read">◖ Ouvir texto</button><button type="button" class="btn ghost" data-action="stop" aria-label="Parar voz">■</button></div>
<div class="dev-step-footer"><button class="back" data-action="dev-prev" ${i===0?'disabled':''}>← Anterior</button>${i===4?`<button class="btn" data-action="complete-dev">${done?'✓ Devocional concluído':'✓ Concluir devocional'}</button>`:`<button class="back" data-action="dev-next">Próxima etapa →</button>`}</div></article>
<div class="card dev-reminder"><h3>Seu horário de oração</h3><p class="smallprint">O lembrete diário é opcional. As notificações podem atrasar conforme a economia de bateria do Android.</p><div class="row"><div class="field"><label for="reminder-time">Horário</label><input type="time" id="reminder-time" value="${esc(S.time)}" /></div><label class="field"><span>Ativar lembrete</span><input id="reminder" type="checkbox" ${S.reminder?'checked':''}/></label></div><button class="btn small" data-action="set-reminder">Salvar lembrete</button></div></section>`;}

function notebook(){let draft=S.noteDraft||{title:'',text:''};return `${section('Meu caderno','REFLEXÕES E APRENDIZADOS')}<div class="card"><div class="field"><label for="note-title">Título</label><input id="note-title" placeholder="Minha reflexão" value="${esc(draft.title||window._noteTitle||'')}"/></div><div class="field" style="margin-top:10px"><label for="note-text">O que Deus tem me ensinado?</label><textarea id="note-text" placeholder="Escreva aqui. Seu conteúdo fica salvo somente neste aparelho.">${esc(draft.text||window._noteText||'')}</textarea></div><button class="btn" data-action="save-note" style="margin-top:12px">Guardar reflexão</button></div><h2>Anotações (${S.notes.length})</h2>${S.notes.map(n=>`<div class="card"><div class="row"><h3>${esc(n.title)}</h3><button class="btn ghost small" data-action="delete-note" data-id="${n.id}" aria-label="Excluir anotação">Excluir</button></div><p class="smallprint">${esc(n.date)}</p><p class="study-text">${esc(n.text)}</p></div>`).join('')||'<p class="muted">Seu caderno começa com uma página em branco.</p>'}`;}
function harpa(){return `${section('Harpa Cristã','LOUVORES QUE ACOMPANHAM A FÉ')}<div class="card"><h3>Louvor e reflexão</h3><p>Selecione um hino, cante e registre a passagem bíblica associada. Esta base não inclui letras, gravações ou áudio comercial sem autorização.</p><p>Para ouvir seus louvores, use sua biblioteca do Spotify ou do YouTube.</p><a class="btn" href="https://open.spotify.com/search/Harpa%20Crist%C3%A3" rel="noopener noreferrer">♫ Buscar no Spotify</a></div>${musicSuggestion()}<button class="list-card" data-tab="notebook"><strong>Meu repertório e minhas anotações</strong><small>Escreva músicas e reflexões no caderno</small></button>`;}
function library(){return `${section('Biblioteca de estudos','HISTÓRIA, AUTORES E PESQUISA')}<div class="card"><h3>Guia de pesquisa</h3><p>Ao consultar um comentário bíblico, anote o autor, a obra, a edição e a passagem estudada. Compare perspectivas evangélicas e acadêmicas sem confundir opinião com o texto bíblico.</p><h3>Campos de estudo</h3><p>Exegese, hermenêutica, história bíblica, teologia bíblica, teologia sistemática, línguas originais, ética cristã e história da igreja.</p><button class="btn secondary" data-tab="studies">Explorar os 40 estudos</button></div>`;}
function assistant(){return window.JARDIM_ASSIST.render(S,esc);}
function more(){const names=[['plum','Orquídea','#784f68'],['forest','Bosque','#345e42'],['ocean','Azul Sereno','#2b5672'],['sand','Pergaminho','#b2935e'],['night','Noite','#29232e']];return `${section('Mais recursos','PERSONALIZE SEU JARDIM')}<div class="card"><h3>Temas de cores</h3><div class="theme-list">${names.map(([id,name,color])=>`<button class="theme-choice ${S.theme===id?'selected':''}" data-action="theme" data-theme="${id}" aria-label="Tema ${name}" aria-pressed="${S.theme===id}"><span class="theme-swatch" style="background:${color}"></span>${name}${S.theme===id?' ✓':''}</button>`).join('')}</div><p class="smallprint">Os temas mudam todo o aplicativo, inclusive o leitor e o devocional. A escolha fica salva no celular.</p><div class="divider"></div><h3>Narração e acessibilidade</h3>
<p class="smallprint"><b>Dora — narradora do Jardim:</b> ela lê dinamicamente os textos exibidos, sem gravar ou cadastrar palavra por palavra. A qualidade depende da voz disponível no dispositivo. A voz original personalizada da Dora ainda não foi recuperada.</p>
<div id="voice-status" class="voice-status" role="status">Buscando vozes disponíveis no celular…</div>
<div class="field" style="margin-top:12px"><label for="voiceEngine">Mecanismo de voz</label><select id="voiceEngine"><option value="auto">Padrão do Android</option></select></div>
<div class="field" style="margin-top:12px"><label for="voiceId">Voz em português do Brasil</label><select id="voiceId"><option value="auto">Automática — melhor disponível</option></select></div>
<p class="smallprint">Prefira as vozes Google de qualidade alta ou, se disponível, uma voz online. Vozes online podem usar dados móveis. A disponibilidade depende do seu celular.</p>
<label class="narration-check"><input id="autoNarration" type="checkbox" ${S.autoNarration?'checked':''} /> Narrar as telas automaticamente ao navegar</label>
<div class="field" style="margin-top:12px"><label for="voiceRate">Velocidade de narração</label><select id="voiceRate"><option value="0.88" ${Number(S.voiceRate)<.91?'selected':''}>Calma</option><option value="0.96" ${Number(S.voiceRate)>=.91&&Number(S.voiceRate)<1.04?'selected':''}>Natural</option><option value="1.10" ${Number(S.voiceRate)>=1.04?'selected':''}>Mais rápida</option></select></div>
<div class="field" style="margin-top:12px"><label for="voicePitch">Tom da voz</label><select id="voicePitch"><option value="0.90" ${Number(S.voicePitch)===.9?'selected':''}>Mais grave</option><option value="1" ${Number(S.voicePitch)===1?'selected':''}>Natural</option><option value="1.10" ${Number(S.voicePitch)===1.1?'selected':''}>Mais agudo</option></select></div>
<div class="actions"><button class="btn secondary small" data-action="speak-demo">▶ Ouvir amostra da Dora</button><button class="btn ghost small" data-action="stop">■ Parar</button><button class="btn ghost small" data-action="refresh-voices">↻ Atualizar lista</button><button class="btn ghost small" data-action="voice-settings">⚙ Vozes do celular</button></div>
<p class="smallprint">Se só aparecer uma voz, atualize o app <a href="https://play.google.com/store/apps/details?id=com.google.android.tts">Síntese de voz do Google</a> e baixe as vozes em português nas configurações do Android.</p>
<div class="divider"></div><h3>Leitura acessível</h3><div class="actions"><button class="btn small secondary" data-action="font-down">A− Menor</button><button class="btn small secondary" data-action="font-up">A+ Maior</button></div></div>
${[['course','📚','Curso de Teologia'],['library','▧','Biblioteca teológica'],['harpa','♫','Harpa Cristã'],['assistant','✧','Assistente no aplicativo'],['notebook','✎','Meu caderno']].map(([tab,ico,title])=>`<button class="list-card" data-tab="${tab}"><strong>${ico} ${title}</strong></button>`).join('')}
<div class="card"><h3>Seus dados e backup</h3><p class="smallprint">Estudos concluídos, notas e preferências são armazenados localmente. Um backup permite recuperar os dados se você trocar de celular.</p><button class="btn secondary small" data-action="show-backup">Mostrar backup JSON</button><div id="backup-panel"></div></div><div class="note">Jardim da Palavra — base Android de recuperação. Conteúdo dos estudos e devocionais escrito para este projeto. ACF: texto protegido, leitura integral pelo aplicativo oficial. Não é a versão já publicada na Play Store.</div>`;}
function render(){applyTheme();let views={home,bible,studies,study,devotional,more,notebook,library,harpa,assistant,course, 'course-subject':courseSubject, 'course-lesson':courseLesson, 'course-assessment':courseAssessment};screen.innerHTML='<div class="voice-toolbar" role="group" aria-label="Narração da tela"><button type="button" class="btn secondary small" data-action="speak-screen">🔊 Dora: ler esta tela</button><button type="button" class="btn ghost small" data-action="stop">■ Parar</button></div>'+(views[S.tab]||home)();screen.setAttribute('data-view',S.tab);if(S.tab==='more')setTimeout(refreshVoiceControls,60);if(S.tab==='devotional')updateDevClock();}
function openStudy(id){let st=D.studies.find(x=>x.id===Number(id));if(!st)return;patch({lastStudy:st.id,tab:'study'});render();window.scrollTo(0,0);autoReadScreen();}
function normalizeBookName(value){return String(value||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/\s+/g,' ').trim();}
function inferBook(ref){
 const normalized=normalizeBookName(ref);
 const b=D.books.filter(x=>normalized.startsWith(normalizeBookName(x.name))).sort((a,z)=>z.name.length-a.name.length)[0];
 const suffix=b?String(ref).slice(b.name.length).trim():String(ref);
 const m=suffix.match(/^(\d+)/);
 const chapter=m?Number(m[1]):Number(S.lastChapter)||1;
 return {name:b?.name||S.lastBook,chapter:Math.min(b?.chapters||150,Math.max(1,chapter))};
}
/* Links de capítulos verificados. Demais livros levam à lista oficial, sem construir URLs incertas. */
function acfChapterUrl(book=S.lastBook,chapter=S.lastChapter){
 const code={'Salmos':'sl','Gênesis':'gn','Miquéias':'mq','1 João':'1jo'}[book];
 return code?'https://www.bibliaonline.com.br/acf/'+code+'/'+Math.max(1,Number(chapter)||1):'https://www.bibliaonline.com.br/acf/livros';
}
function openRef(ref,fromStudy=false){let b=inferBook(ref);patch({lastBook:b.name,lastChapter:b.chapter,returnFromBible:fromStudy?S.lastStudy:null,bibleReturn:S.tab==='devotional'?'devotional':null,tab:'bible'});render();window.scrollTo(0,0);autoReadScreen();}
function narrationText(){
  if(S.tab==='course-lesson'){let sub=courseSubjectById(S.courseSubjectId),lesson=courseLessonById(sub,S.courseLessonId);return `Aula de Teologia. ${sub.title}. ${lesson.title}. ${lesson.content}. Atividade: ${lesson.activity}. Questão: ${lesson.question}`;}
  if(S.tab==='course')return `Curso livre de Teologia. Cinco eixos, cinquenta e duas disciplinas e cento e cinquenta e seis aulas. Seu progresso é de ${coursePercent()} por cento.`;
  if(S.tab==='course-subject')return `Disciplina de Teologia: ${courseSubjectById(S.courseSubjectId).title}.`;
  if(S.tab==='course-assessment')return `Avaliação de revisão de ${courseSubjectById(S.courseSubjectId).title}.`;
  if(S.tab==='study'){
    const st=D.studies.find(x=>x.id===S.lastStudy)||D.studies[0];
    return `Estudo ${st.id} de 40. ${st.title}. Texto para consultar na Bíblia: ${st.reference}. Contexto: ${st.context}. Interpretação: ${st.interpretation}. Aplicação: ${st.application}. Perguntas para reflexão: ${st.questions.join('. ')}. Oração: ${st.prayer}`;
  }
  if(S.tab==='devotional') return devNarrationStep();
  if(S.tab==='home'){
    const v=today();
    return `Bem-vinda ao Jardim da Palavra. Um jardim para estudar a Palavra. A reflexão de hoje é ${v.theme}, com leitura sugerida em ${v.reference}. Você pode abrir o devocional, continuar seu estudo, consultar a Bíblia ou escrever no caderno.`;
  }
  if(S.tab==='bible'){const ch=window.JARDIM_BIBLE?.chapter(S.lastBook,S.lastChapter);let speech=ch?window.JARDIM_BIBLE.asVerses(ch).map(v=>`Versículo ${v.number}. ${v.text}`).join(' '):'Importe o arquivo da Bíblia ACF para ler sem internet.';return `Bíblia ACF. ${S.lastBook}, capítulo ${S.lastChapter}. ${speech}`;}
  if(S.tab==='studies')return `Estudos bíblicos. Estão disponíveis quarenta estudos com contexto, interpretação, aplicação e perguntas. Você concluiu ${S.studyDone.length} estudos. Selecione um estudo para escutar seu conteúdo.`;
  if(S.tab==='notebook')return `Meu caderno de reflexões. Você tem ${S.notes.length} anotações salvas. ${S.notes.slice(0,5).map(n=>`${n.title}. ${n.text}`).join('. ') || 'Aqui você pode registrar o que aprender com os estudos.'}`;
  if(S.tab==='harpa')return 'Harpa Cristã. Uma seção para acompanhar os louvores. Você pode buscar músicas no Spotify e escrever suas reflexões no caderno.';
  if(S.tab==='library')return 'Biblioteca de estudos. Explore hermenêutica, exegese, teologia bíblica, teologia sistemática, história bíblica e história da igreja. Anote autor e fontes consultadas.';
  if(S.tab==='assistant')return 'Assistente de estudos dentro do Jardim da Palavra. Faça perguntas e consulte as fontes do curso de teologia offline.';
  return 'Mais recursos. Escolha um dos temas de cores, ajuste a fonte, ative a narração automática, escolha a velocidade da voz e faça backup das anotações.';
}
/* Textos extraidos da tela atual: sem dicionario de palavras nem arquivos de audio. */
function readableScreenText(){
 if(S.tab==='devotional')return devNarrationStep();
 const root=document.querySelector('#screen'); if(!root)return '';
 const walker=document.createTreeWalker(root,NodeFilter.SHOW_TEXT);
 let n,parts=[],last='';
 while((n=walker.nextNode())){
  let el=n.parentElement;if(!el||el.closest('button,a,input,select,textarea,script,style,.voice-toolbar,.actions,.smallprint,.theme-list,#voice-status,.note'))continue;
  if(el.hidden||el.closest('[hidden],[aria-hidden="true"]'))continue;
  let txt=(n.textContent||'').replace(/\s+/g,' ').trim();
  if(!txt||txt===last)continue;
  parts.push(txt);last=txt;
 }
 return parts.join('. ').replace(/\. \./g,'.').slice(0,20000);
}
function saveCurrentCourseScroll(){
 if(S.tab==='course-lesson'&&S.courseLessonId){
  S.courseScrolls=S.courseScrolls||{};
  S.courseScrolls[S.courseLessonId]=Math.max(0,Math.round(window.scrollY||0));save();
 }
}
let courseScrollSaveTimer=0;
window.addEventListener('scroll',()=>{
 if(S.tab!=='course-lesson')return;
 clearTimeout(courseScrollSaveTimer);
 courseScrollSaveTimer=setTimeout(saveCurrentCourseScroll,350);
},{passive:true});
function autoReadScreen(){if(S.autoNarration)narrate(S.tab==='devotional'?devNarrationStep():(readableScreenText()||narrationText()));else stopSpeech();}
function refreshVoiceControls(){
 const statusEl=document.querySelector('#voice-status');if(!statusEl)return;
 const engineEl=document.querySelector('#voiceEngine'), voiceEl=document.querySelector('#voiceId');
 if(!window.JardimAndroid?.voiceCatalog){statusEl.textContent='Prévia web: a escolha das vozes aparece no aplicativo Android.';return;}
 try{
  const info=JSON.parse(window.JardimAndroid.voiceCatalog());
  statusEl.textContent=info.ready?`Mecanismo ativo: ${info.engine||'Android'} · ${info.voices.length} voz(es) pt-BR disponível(is).`:'Inicializando a voz… Se continuar assim, abra as configurações de voz do celular.';
  const engineOptions=[{id:'auto',label:'Padrão do Android'},...(info.engines||[])];
  engineEl.innerHTML=engineOptions.map(x=>`<option value="${esc(x.id)}">${esc(x.label)}</option>`).join('');
  engineEl.value=engineOptions.some(x=>x.id===S.voiceEngine)?S.voiceEngine:'auto';
  const voices=info.voices||[];
  voiceEl.innerHTML='<option value="auto">Automática — melhor disponível</option>'+voices.map((v,i)=>`<option value="${esc(v.id)}">Voz ${i+1} · ${v.quality>=400?'Alta qualidade':v.quality>=300?'Qualidade normal':'Básica'} · ${v.online?'Online':'Offline'} · ${esc(v.id)}${v.installed?'':' · baixar'}</option>`).join('');
  voiceEl.value=voices.some(v=>v.id===S.voiceId)?S.voiceId:'auto';
 }catch(e){statusEl.textContent='Não foi possível consultar as vozes: '+e.message;}
}
function narrate(text){
 if(!text||!text.trim())return;
 if(window.JardimAndroid?.speak){
  if(window.JardimAndroid.isTtsReady && !window.JardimAndroid.isTtsReady()){toast('Voz não pronta. Abra Mais → Narração e veja a configuração.');return;}
  window.JardimAndroid.setSpeechRate?.(Number(S.voiceRate)||.96);
  window.JardimAndroid.setSpeechPitch?.(Number(S.voicePitch)||1);
  window.JardimAndroid.speak(text);toast('Dora está lendo com a voz selecionada');return;
 }
 if('speechSynthesis' in window){speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(text);u.lang='pt-BR';u.rate=Number(S.voiceRate)||.96;u.pitch=Number(S.voicePitch)||1;speechSynthesis.speak(u);toast('Leitura iniciada');}
 else toast('Narração indisponível neste aparelho');
}
function stopSpeech(){if(window.JardimAndroid?.stopSpeech)window.JardimAndroid.stopSpeech();if('speechSynthesis'in window)speechSynthesis.cancel();}
function reminder(){let time=document.querySelector('#reminder-time')?.value||'07:00',enabled=!!document.querySelector('#reminder')?.checked;patch({time,reminder:enabled});if(window.JardimAndroid?.setDailyReminder){let [h,m]=time.split(':').map(Number);window.JardimAndroid.setDailyReminder(enabled,h,m);toast(enabled?'Lembrete diário configurado':'Lembrete desligado');}else{toast('Preferência salva. Alarmes automáticos exigem o APK Android.');}}
function maybeCopy(text){if(navigator.clipboard?.writeText){navigator.clipboard.writeText(text).then(()=>toast('Texto copiado'),()=>toast('Selecione o texto para copiar'));}else toast('Selecione o texto para copiar');}
async function share(text){if(navigator.share){try{await navigator.share({title:'Jardim da Palavra',text});return;}catch(e){if(e.name==='AbortError')return;}}maybeCopy(text);}
function backupPanel(){let el=document.querySelector('#backup-panel');if(!el)return;el.innerHTML=`<div class="field" style="margin-top:14px"><label for="backup-data">Copie este backup ou cole um backup anterior</label><textarea id="backup-data" style="min-height:170px">${esc(JSON.stringify({app:'JardimDaPalavra',version:1,data:S},null,2))}</textarea></div><div class="actions"><button class="btn small" data-action="restore-backup">Restaurar backup</button></div>`;}
function restoreBackup(){try{let b=JSON.parse(document.querySelector('#backup-data').value);if(b.app!=='JardimDaPalavra'||!b.data||!Array.isArray(b.data.notes)||!Array.isArray(b.data.studyDone))throw Error('Formato inválido');S={...defaults,...b.data};
 for(const k of ['notes','studyDone','devDone','courseDone','courseExamDone','courseShown','courseExamShown','localChatHistory'])if(!Array.isArray(S[k]))S[k]=[];
 for(const k of ['courseAnswers','courseExamAnswers','courseScrolls','devReflections'])if(!S[k]||typeof S[k]!=='object'||Array.isArray(S[k]))S[k]={};
 if(!S.noteDraft||typeof S.noteDraft!=='object')S.noteDraft={title:'',text:''};
 S.noteDraft={title:String(S.noteDraft.title||''),text:String(S.noteDraft.text||'')};
 save();render();toast('Backup restaurado');}catch(e){toast('Backup inválido: '+e.message)}}
function setReminderFromState(){/* Schedules only on explicit user request, never silently request permission. */}
window.jardimBack=function(){pauseDevTimer();saveCurrentCourseScroll();if(S.tab==='course-lesson'||S.tab==='course-assessment'){go('course-subject');return true;}if(S.tab==='course-subject'){go('course');return true;}if(S.tab==='course'){go('studies');return true;}if(S.tab==='bible'&&S.bibleReturn==='devotional'){patch({tab:'devotional',bibleReturn:null});render();return true;}if(S.tab==='bible'&&S.returnFromBible){patch({tab:'study',returnFromBible:null});render();return true;}if(S.tab==='study'){go('studies');return true;}if(S.tab!=='home'){go('home');return true;}return false;};
document.querySelector('#fontToggle').addEventListener('click',()=>{S.font=S.font>=1.3?1:Math.round((S.font+.1)*10)/10;save();applyTheme();});
document.addEventListener('input',e=>{
 const id=e.target.id||'';
 if(id==='note-title'||id==='note-text'){
  S.noteDraft=S.noteDraft||{title:'',text:''};
  S.noteDraft[id==='note-title'?'title':'text']=e.target.value;save();
 }
 if(id==='dev-reflection'){S.devReflections[devDateKey()]=e.target.value;save();}
 if(id==='course-check-answer'){S.courseAnswers[S.courseLessonId]=e.target.value;save();}
 if(/^exam-answer-[0-2]$/.test(id)){
  const answers=S.courseExamAnswers[S.courseSubjectId]||['','',''];
  answers[Number(id.slice(-1))]=e.target.value;S.courseExamAnswers[S.courseSubjectId]=answers;save();
 }
 handleCourseInput(e);if(e.target.id==='study-search'){window._studyQuery=e.target.value;document.querySelector('#study-results').innerHTML=studyCards(D.studies.filter(x=>(x.title+' '+x.section+' '+x.reference).toLowerCase().includes(window._studyQuery.toLowerCase())));}});
document.addEventListener('change',e=>{if(e.target.id==='book'){patch({lastBook:e.target.value,lastChapter:1});render();}if(e.target.id==='version'){patch({bibleVersion:e.target.value});render();}if(e.target.id==='chapter'){patch({lastChapter:Number(e.target.value)});render();}if(e.target.id==='autoNarration'){patch({autoNarration:!!e.target.checked});if(S.autoNarration)narrate(narrationText());else stopSpeech();}if(e.target.id==='voiceRate'){patch({voiceRate:Number(e.target.value)});toast('Velocidade salva');}
if(e.target.id==='voicePitch'){patch({voicePitch:Number(e.target.value)});toast('Tom da voz salvo');}
if(e.target.id==='voiceEngine'){patch({voiceEngine:e.target.value,voiceId:'auto'});stopSpeech();window.JardimAndroid?.setVoiceEngine?.(e.target.value);toast('Mudando mecanismo de voz…');setTimeout(refreshVoiceControls,1100);}
if(e.target.id==='voiceId'){patch({voiceId:e.target.value});stopSpeech();window.JardimAndroid?.setVoiceId?.(e.target.value);toast('Voz selecionada. Ouça uma amostra.');}});
document.addEventListener('click',e=>{if(e.target.closest('[data-devmusic]')){pauseDevTimer();stopSpeech();return;}let btn=e.target.closest('[data-tab],[data-action]');if(!btn)return;
 if(btn.dataset.tab){go(btn.dataset.tab);return;}
 const a=btn.dataset.action;
 if(a==='chat-send'||a==='chat-prompt'){
    const question=a==='chat-prompt'?btn.dataset.question:(document.querySelector('#chat-input')?.value||'').trim();
    if(!question||question.length<3){toast('Escreva pelo menos 3 caracteres.');return;}
    if(window.JARDIM_ASSIST.append(S,question)){
      save();render();const h=document.querySelector('#chat-history');if(h)h.scrollTop=h.scrollHeight;
    }return;
 }
 if(a==='chat-clear'){S.localChatHistory=[];save();render();return;}
 if(a==='chat-source'){
   if(btn.dataset.kind==='course'){
      const sub=courseSubjectById(btn.dataset.id);patch({courseSubjectId:sub.id,courseLessonId:sub.lessons[0].id,tab:'course-lesson'});render();window.scrollTo(0,0);
   }else openStudy(btn.dataset.id);
   return;
 }
 if(handleCourseAction(a,btn))return;
 if(a==='open-study')openStudy(btn.dataset.id);
 if(a==='complete-study'){let id=Number(btn.dataset.id);if(!S.studyDone.includes(id))S.studyDone.push(id);save();render();toast('Estudo concluído e salvo');}
 if(a==='open-study-bible')openRef(btn.dataset.ref,true);
 if(a==='bible-ref')openRef(btn.dataset.ref,false);
 if(a==='return-study'){patch({tab:'study',returnFromBible:null});render();autoReadScreen();}
 if(a==='save-reading'){patch({lastBook:document.querySelector('#book').value,lastChapter:Number(document.querySelector('#chapter').value)});toast('Leitura salva neste aparelho');}
 if(a==='acf-import') {if(window.JardimAndroid?.importAcfZip){toast('Selecione o arquivo ZIP que contém a pasta acf-json.');window.JardimAndroid.importAcfZip();}else toast('Importação ZIP disponível no APK Android.');}
 if(a==='acf-prev'||a==='acf-next') {const books=D.books;let i=books.findIndex(x=>x.name===S.lastBook);if(i<0)i=0;let n=Number(S.lastChapter)||1;if(a==='acf-prev'){if(n>1)n--;else if(i>0){i--;n=books[i].chapters;}}else{if(n<books[i].chapters)n++;else if(i<books.length-1){i++;n=1;}}patch({lastBook:books[i].name,lastChapter:n});render();window.scrollTo(0,0);}
 if(a==='acf-speak'){let chapter=window.JARDIM_BIBLE?.chapter(S.lastBook,S.lastChapter);if(chapter)narrate(`${S.lastBook}, capítulo ${S.lastChapter}. `+window.JARDIM_BIBLE.asVerses(chapter).map(v=>`Versículo ${v.number}. ${v.text}`).join(' '));}
 if(a==='acf-search'){let q=document.querySelector('#acf-search-input')?.value||'';if(q.trim().length<3){toast('Digite pelo menos 3 caracteres.');return;}let el=document.querySelector('#acf-search-results');if(el)el.innerHTML='<p>Pesquisando offline…</p>';if(!window.JARDIM_BIBLE?.startSearch(q))toast('Pesquisa disponível no aplicativo Android.');}
 if(a==='acf-result'){let name=window.JARDIM_BIBLE?.appBook(Number(btn.dataset.acfBook));if(name){patch({lastBook:name,lastChapter:Number(btn.dataset.acfChapter),bibleVersion:'ACF'});render();let el=document.querySelector('#acf-v-'+btn.dataset.acfVerse);if(el)el.scrollIntoView({block:'center',behavior:'smooth'});}}
 if(a==='acf-return-dev'){patch({tab:'devotional',bibleReturn:null});render();window.scrollTo(0,0);}
 if(a==='open-acf-chapter'){toast('Importe a ACF no próprio aplicativo.');}
 if(a==='speak')narrate(btn.dataset.text);
 if(a==='speak-screen')narrate(readableScreenText()||narrationText());
 if(a==='speak-demo')narrate('Olá, eu sou Dora, a narradora do Jardim da Palavra. É uma alegria acompanhar você em seus estudos e devocionais. Que a paz do Senhor esteja em seu coração.');
 if(a==='refresh-voices')refreshVoiceControls();
 if(a==='voice-settings')window.JardimAndroid?.openVoiceSettings?.();
 if(a==='stop')stopSpeech();
 if(a==='share')share(btn.dataset.text);
 if(a==='dev-step')devChangeStep(Number(btn.dataset.step));
 if(a==='dev-next')devChangeStep(devSession().step+1);
 if(a==='dev-prev')devChangeStep(devSession().step-1);
 if(a==='dev-toggle-timer')toggleDevTimer();
 if(a==='dev-read')narrate(devNarrationStep());
 if(a==='complete-dev'){pauseDevTimer();let dt=devDateKey();if(!S.devDone.includes(dt))S.devDone.push(dt);save();render();toast('Devocional registrado');}
 if(a==='set-reminder')reminder();
 if(a==='theme'){patch({theme:btn.dataset.theme});render();}
 if(a==='font-up'){patch({font:Math.min(1.5,Math.round((S.font+.1)*10)/10)});render();}
 if(a==='font-down'){patch({font:Math.max(.9,Math.round((S.font-.1)*10)/10)});render();}
 if(a==='new-note'){
 S.noteDraft=S.noteDraft||{title:'',text:''};
 if(!S.noteDraft.text.trim())S.noteDraft.title=btn.dataset.title||S.noteDraft.title||'';
 window._noteTitle=S.noteDraft.title;save();go('notebook');
 }
 if(a==='save-note'){let title=document.querySelector('#note-title').value.trim(),content=document.querySelector('#note-text').value.trim();if(!content){toast('Escreva uma reflexão para salvar');return;}S.notes.unshift({id:Date.now(),title:title||'Minha reflexão',text:content,date:new Date().toLocaleDateString('pt-BR')});S.noteDraft={title:'',text:''};window._noteTitle='';window._noteText='';save();render();toast('Reflexão salva');}
 if(a==='delete-note'){if(confirm('Excluir esta reflexão?')){S.notes=S.notes.filter(n=>String(n.id)!==btn.dataset.id);save();render();}}
 if(a==='show-backup')backupPanel();
 if(a==='restore-backup')restoreBackup();
});
render();

/* O cronômetro pausa ao sair para Spotify, YouTube ou outro app. */
document.addEventListener('visibilitychange',()=>{if(document.hidden)pauseDevTimer();});

window.jardimAcfImported=function(result){if(S.tab==='bible'||S.tab==='devotional')render();toast(result?.message||'Importação concluída');};
window.jardimAcfSearchResults=function(result){window.JARDIM_BIBLE?.finishSearch(result||{});};
