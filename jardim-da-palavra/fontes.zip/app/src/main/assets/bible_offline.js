/* Jardim da Palavra - local ACF reader. Deliberately contains NO copyrighted Bible verses. */
(function(root) {
 'use strict';
 const books = root.JARDIM_DATA.books;
 const state = {query:'',results:[],searching:false};
 const escape = text=>String(text??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 function sourceNumber(name) {
  let normalized=s=>String(s).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z\d]/gi,'').toLowerCase();
  const idx=books.findIndex(b=>normalized(b.name)===normalized(name));
  if(idx===-1)return null;
  return idx<39 ? idx+28 : idx-38; // ACF JSON project numbers NT first; normal Bible navigation OT first.
 }
 function appBook(sourceId) {
  let idx=Number(sourceId)<=27?Number(sourceId)+38:Number(sourceId)-28;
  return books[idx]?.name||'';
 }
 function status() {
  try { if(root.JardimAndroid?.acfStatus)return JSON.parse(root.JardimAndroid.acfStatus()); }
  catch(e){return {chapters:0,complete:false,error:e.message};}
  return {chapters:0,complete:false,webOnly:true};
 }
 function chapter(name,chapterNo) {
  let id=sourceNumber(name);
  if(!id||!root.JardimAndroid?.acfChapter)return null;
  try {const payload=root.JardimAndroid.acfChapter(id,Number(chapterNo));return payload?JSON.parse(payload):null;}
  catch(e){return null;}
 }
 function asVerses(ch) {
  return Array.isArray(ch?.verses)?ch.verses.filter(x=>Number.isInteger(x.number)&&x.number>0&&typeof x.text==='string'):[];
 }
 function selectedReference(ref) {
  const str=String(ref||'').replace(/[\u2012-\u2015]/g,'-');
  const m=str.match(/^(.+?)\s+(\d+)(?::(\d+)(?:\s*-\s*(\d+))?)?/);
  if(!m)return null;
  const b=books.find(x=>x.name.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase()===m[1].normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase());
  if(!b)return null;
  return {name:b.name,chapter:Number(m[2]),from:m[3]?Number(m[3]):1,to:m[4]?Number(m[4]):m[3]?Number(m[3]):176};
 }
 function passage(ref) {
  const r=selectedReference(ref);if(!r)return null;
  const ch=chapter(r.name,r.chapter);if(!ch)return null;
  const verses=asVerses(ch).filter(v=>v.number>=r.from&&v.number<=r.to);
  return {reference:ref,verses,speech:verses.map(v=>`Versículo ${v.number}. ${v.text}`).join(' ')};
 }
 function versesHtml(ch,filter=null) {
  const v=asVerses(ch).filter(x=>!filter||x.number>=filter.from&&x.number<=filter.to);
  if(!v.length)return '<p class="muted">Nenhum versículo disponível para essa seleção.</p>';
  return `<div class="acf-verses" aria-label="Texto bíblico importado">${v.map(x=>`<p id="acf-v-${x.number}"><span class="acf-verse-num">${x.number}</span> ${escape(x.text)}</p>`).join('')}</div>`;
 }
 function searchMarkup() {
  if(state.searching)return '<p class="muted">Pesquisando apenas nos capítulos salvos neste aparelho…</p>';
  if(!state.results.length)return state.query?'<p class="muted">Nenhum versículo encontrado.</p>':'<p class="muted">Pesquise por uma palavra ou expressão, sem internet.</p>';
  return `<div class="acf-results">${state.results.map(x=>`<button type="button" class="list-card acf-result" data-action="acf-result" data-acf-book="${x.book}" data-acf-chapter="${x.chapter}" data-acf-verse="${x.number}"><strong>${escape(appBook(x.book))} ${x.chapter}:${x.number}</strong><small>${escape(x.text)}</small></button>`).join('')}</div>`;
 }
 function renderBible(S) {
  const book=books.find(x=>x.name===S.lastBook)||books[18];
  const chno=Math.max(1,Math.min(book.chapters,Number(S.lastChapter)||1));
  const current=status();
  const ch=chapter(book.name,chno);
  const imported=Number(current.chapters||0);
  const isAcf=S.bibleVersion==='ACF';
  return `<div class="section-label">LEITOR BÍBLICO OFFLINE</div><h1>Bíblia Sagrada</h1>
  <div class="card acf-status"><div class="section-label">ALMEIDA CORRIGIDA FIEL · ACF</div>
  <h3>${imported?(current.complete?'Bíblia ACF disponível offline':'Bíblia ACF importada parcialmente'):'Importar Bíblia ACF para leitura offline'}</h3>
  <p>${imported?`${imported} de 1189 capítulos armazenados no celular. A leitura não usa internet.`:'Este APK não distribui o texto da ACF. Escolha uma cópia ZIP que você esteja autorizado a utilizar. A importação fica apenas no seu aparelho.'}</p>
  <div class="actions"><button type="button" class="btn" data-action="acf-import">▣ ${imported?'Importar outro arquivo ZIP':'Importar meu ZIP da ACF'}</button></div>
  <p class="smallprint">A autorização para distribuir a ACF integral no aplicativo está pendente junto à SBTB (protocolo 20261119-000001). A importação pessoal não constitui autorização de redistribuição. O conteúdo não é transmitido a um servidor.</p></div>
  <div class="card"><div class="fields"><div class="field"><label for="version">Versão escolhida</label><select id="version"><option value="ACF" ${S.bibleVersion==='ACF'?'selected':''}>ACF — importada localmente</option><option value="BLIVRE" ${S.bibleVersion==='BLIVRE'?'selected':''}>Bíblia Livre — consulta externa</option><option value="A1819" ${S.bibleVersion==='A1819'?'selected':''}>Almeida 1819 — consulta externa</option></select></div>
  <div class="field"><label for="book">Livro</label><select id="book">${books.map(b=>`<option value="${escape(b.name)}" ${b.name===book.name?'selected':''}>${escape(b.name)}</option>`).join('')}</select></div>
  <div class="field"><label for="chapter">Capítulo</label><select id="chapter">${Array.from({length:book.chapters},(_,i)=>`<option value="${i+1}" ${i+1===chno?'selected':''}>${i+1}</option>`).join('')}</select></div></div>
  <div class="actions"><button class="btn secondary small" data-action="acf-prev">← Anterior</button><button class="btn secondary small" data-action="acf-next">Próximo →</button><button class="btn small secondary" data-action="save-reading">✓ Salvar leitura</button></div></div>
  <article class="card acf-bible-reading"><div class="section-label">${isAcf?'ACF — ALMEIDA CORRIGIDA FIEL':'LEITURA LOCAL: ACF'}</div><h2>${escape(book.name)} ${chno}</h2>
   ${ch?versesHtml(ch):`<p class="muted">Este capítulo ainda não está disponível neste aparelho. ${imported?'Verifique se o ZIP importado contém este capítulo.':'Importe o arquivo ZIP para começar a leitura.'}</p>`}
   ${ch?'<button type="button" class="btn secondary" data-action="acf-speak">🔊 Dora: ler este capítulo</button>':''}
   ${S.returnFromBible?'<button type="button" class="btn secondary" data-action="return-study">Voltar ao estudo</button>':''}
   ${S.bibleReturn==='devotional'?'<button type="button" class="btn secondary" data-action="acf-return-dev">← Voltar ao devocional</button>':''}
  </article>
  <div class="card"><h3>Buscar nas Escrituras</h3><div class="field"><label for="acf-search-input">Palavra ou expressão</label><input id="acf-search-input" type="search" placeholder="Ex.: misericórdia" value="${escape(state.query)}" /></div>
  <div class="actions"><button type="button" class="btn" data-action="acf-search">Buscar offline</button></div><div id="acf-search-results">${searchMarkup()}</div></div>`;
 }
 function startSearch(query) {
  state.query=String(query||'').trim();state.searching=true;state.results=[];
  if(!root.JardimAndroid?.acfSearch) {state.searching=false;return false;}
  root.JardimAndroid.acfSearch(state.query);return true;
 }
 function finishSearch(payload) {
  state.searching=false;state.query=payload.query||state.query;
  state.results=Array.isArray(payload.results)?payload.results:[];
  const el=document.querySelector('#acf-search-results');if(el)el.innerHTML=searchMarkup();
 }
 root.JARDIM_BIBLE={sourceNumber,appBook,status,chapter,asVerses,selectedReference,passage,versesHtml,renderBible,startSearch,finishSearch};
})(window);
