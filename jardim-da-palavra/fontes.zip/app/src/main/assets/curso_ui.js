'use strict';
/* Curso livre de Teologia: aulas originais, sem transcricao integral de traducao biblica. */
const CURSO = window.JARDIM_CURSO;
const DOSSIER = window.JARDIM_DOSSIER || {};
const APOSTILAS = window.JARDIM_APOSTILAS || {};


const ALL_LESSONS = CURSO.subjects.flatMap(subject=>subject.lessons.map(lesson=>({subject,lesson})));
const courseSubjectById = id => CURSO.subjects.find(x=>x.id===id)||CURSO.subjects[0];
const courseLessonById = (subject,id) => subject.lessons.find(x=>x.id===id)||subject.lessons[0];
const courseFinished = () => Array.isArray(S.courseDone)?S.courseDone:[];
const courseExams = () => Array.isArray(S.courseExamDone)?S.courseExamDone:[];
const courseDoneIn = subject => subject.lessons.filter(x=>courseFinished().includes(x.id)).length;
const coursePercent = () => Math.min(100,Math.round(100*courseFinished().length/ALL_LESSONS.length));
const courseDescription = () => `${CURSO.tracks.length} eixos · ${CURSO.subjects.length} disciplinas · ${ALL_LESSONS.length} aulas`;
function courseBar(done,total){return `<div class="progress-track" role="progressbar" aria-label="Progresso do curso" aria-valuenow="${done}" aria-valuemin="0" aria-valuemax="${total}"><div class="progress-fill" style="width:${Math.round(100*done/total)}%"></div></div>`;}
function courseResumeBtn(){
 const sub=courseSubjectById(S.courseSubjectId), l=courseLessonById(sub,S.courseLessonId);
 return `<button class="btn" data-action="open-course-lesson" data-subject="${sub.id}" data-lesson="${l.id}">▶ Continuar: ${esc(l.title)}</button>`;
}
function courseSubjectList(items){
 return items.map(s=>{let n=courseDoneIn(s);let tr=CURSO.tracks.find(t=>t.id===s.track);
 return `<button class="list-card course-subject-card" data-action="open-course-subject" data-subject="${s.id}">
 <div class="row"><span class="pill">${esc(tr?.title||'Teologia')}</span><span class="count">${n}/3 aulas</span></div>
 <strong>${esc(s.title)}</strong><small>${esc(s.objective)}</small>${APOSTILAS[s.id]?'<small class="extended-label">★ Apostila aprofundada · 3 capítulos exclusivos</small>':''}
 ${courseBar(n,3)}
 </button>`;}).join('')||'<div class="note">Nenhuma disciplina encontrada. Remova o filtro ou tente outras palavras.</div>';
}
function courseResults(){
 let term=(window._courseQuery||'').trim().toLocaleLowerCase('pt-BR');
 let track=S.courseTrack||'all';
 let filtered=CURSO.subjects.filter(s=>(track==='all'||s.track===track)&&(!term||(s.title+' '+s.objective+' '+s.reference).toLocaleLowerCase('pt-BR').includes(term)));
 return `<p class="count" aria-live="polite">${filtered.length} disciplina(s) encontrada(s)</p>${courseSubjectList(filtered)}`;
}
function course(){
 return `${section('Curso de Teologia','FORMAÇÃO LIVRE · ESTUDO PROGRESSIVO')}
 <div class="hero course-hero"><div class="section-label">SEU CAMINHO DE APRENDIZAGEM</div><h1>Aprenda, pesquise e pratique.</h1><p>${courseDescription()}. Do panorama bíblico ao ministério, com exegese contextual, análise de hebraico e grego quando pertinente, tradução explicativa, bibliografia e revisão por aula.</p>
 <div class="course-hero-progress"><b>${coursePercent()}% concluído</b>${courseBar(courseFinished().length,ALL_LESSONS.length)}</div>
 </div>
 <div class="card"><div class="row"><strong>Seu progresso</strong><span class="count">${courseFinished().length}/${ALL_LESSONS.length} aulas</span></div>
 <p class="smallprint">Avaliações formativas respondidas: ${courseExams().length}/${CURSO.subjects.length}. O progresso fica neste celular e integra seu backup.</p>
 <div class="actions">${courseResumeBtn()}</div></div>
 <div class="card course-feature"><h3>Biblioteca de apostilas ampliadas</h3><p>Novidade desta edição: ${Object.keys(APOSTILAS).length} disciplinas com três capítulos novos e diferentes, análise contextual, contrapontos, atividades e leituras. As demais continuam disponíveis com seus dossiês, exercícios e bibliografia.</p>
 <p class="smallprint">Os capítulos novos são material original de estudo, não reprodução de comentários protegidos. Esta coleção ainda está em expansão; as 156 aulas não possuem todas a mesma profundidade.</p>
 <div class="extended-grid">${CURSO.subjects.filter(s=>APOSTILAS[s.id]).map(s=>`<button class="btn secondary small" data-action="open-course-subject" data-subject="${s.id}">${esc(s.title)}</button>`).join('')}</div></div>
 <div class="note">Curso livre de estudos teológicos, sem equivalência automática a bacharelado ou diploma reconhecido pelo MEC. As posições doutrinárias divergentes são apresentadas para estudo respeitoso. Referências bíblicas podem ser consultadas na ACF, versão preferida do aplicativo.</div>
 <h2 class="course-heading">Explorar disciplinas</h2><div class="course-track-list" aria-label="Filtrar por área">
 ${[['all','Todas'],...CURSO.tracks.map(t=>[t.id,t.title])].map(([id,title])=>`<button class="course-filter ${S.courseTrack===id?'selected':''}" data-action="course-filter" data-track="${id}" aria-pressed="${S.courseTrack===id}">${esc(title)}</button>`).join('')}
 </div>
 <input id="course-search" class="search" aria-label="Pesquisar disciplina" placeholder="Buscar disciplina ou assunto" value="${esc(window._courseQuery||'')}"/>
 <div id="course-results">${courseResults()}</div>`;
}
function courseSubject(){
 const s=courseSubjectById(S.courseSubjectId), tr=CURSO.tracks.find(t=>t.id===s.track),done=courseDoneIn(s);
 return `<button class="back" data-tab="course">‹ Voltar ao curso</button>
 <div class="section-label">${esc(tr?.title||'Curso livre')} · DISCIPLINA ${CURSO.subjects.indexOf(s)+1}</div>
 <h1>${esc(s.title)}</h1><p class="muted">${esc(s.objective)}</p>${APOSTILAS[s.id]?'<div class="note">★ Três capítulos ampliados desta disciplina: um para cada aula, além dos dossiês exegéticos.</div>':''}
 <div class="card soft"><div class="row"><strong>Aulas realizadas</strong><span class="count">${done}/3</span></div>${courseBar(done,3)}</div>
 <div class="card"><h3>Roteiro da disciplina</h3>${s.lessons.map((l,i)=>`<button class="list-card course-lesson-choice" data-action="open-course-lesson" data-subject="${s.id}" data-lesson="${l.id}"><span class="course-index">${i+1}</span><div><strong>${esc(l.title)}</strong><small>${courseFinished().includes(l.id)?'✓ Aula concluída':'Abrir estudo, comentários e exercícios'}</small></div></button>`).join('')}
 <button class="list-card course-lesson-choice" data-action="course-open-assessment" data-subject="${s.id}"><span class="course-index">✓</span><div><strong>Avaliação de revisão</strong><small>${courseExams().includes(s.id)?'✓ Respostas registradas':'Três perguntas de revisão, com respostas de referência'}</small></div></button></div>
 <div class="card"><h3>Projeto prático</h3><p>${esc(s.project)}</p><button class="btn secondary small" data-action="new-note" data-title="Projeto · ${esc(s.title)}">✎ Registrar no caderno</button></div>
 <div class="card"><h3>Leituras bíblicas sugeridas</h3><p>${esc(s.reference)}</p><p class="smallprint">Abra a Bíblia e confira o texto integral na tradução escolhida, preferencialmente ACF.</p>${s.bibliography?`<div class="divider"></div><h3>Bibliografia para aprofundamento</h3><p>${esc(s.bibliography)}</p>`:''}</div>`;
}
function courseStudyDossier(s,l,idx){
 const d=DOSSIER[s.id];
 if(!d)return '<div class="note">Estudo de referência indisponível nesta disciplina.</div>';
 const stages=[
  ['I — Localizar e compreender','A pergunta inicial é o que o texto comunicava em seu ambiente original, antes de aplicá-lo diretamente ao nosso tempo.'],
  ['II — Explicar e comparar','Nesta etapa, confronte vocabulário, argumento e referências cruzadas. Verifique se a explicação decorre da passagem inteira.'],
  ['III — Dialogar e aplicar','Agora diferencie afirmações do texto, leituras históricas e aplicação contemporânea. Anote objeções e limites da interpretação.']
 ];
 const stage=stages[idx]||stages[0];
 return `<div class="course-study-section">
 <div class="section-label">ESTUDO BÍBLICO COMPLEMENTAR · ${esc(stage[0])}</div>
 <p class="muted">${esc(stage[1])}</p>
 <div class="course-passage">
   <div class="section-label">PASSAGEM CENTRAL</div>
   <strong>${esc(d.passage)}</strong>
   <p class="course-translation">${esc(d.study)}</p>
   <p class="smallprint">Tradução de estudo ou síntese explicativa original. Não é transcrição nem substituto do texto ACF.</p>
   <div class="actions"><a class="btn secondary small" href="https://www.bibliaonline.com.br/acf" target="_blank" rel="noopener noreferrer">📖 Consultar texto ACF</a><a class="btn ghost small" href="https://www.stepbible.org/" target="_blank" rel="noopener noreferrer">🔎 Consultar originais</a></div>
 </div>
 <h3>1. Contexto histórico e literário</h3><p>${esc(d.context)}</p>
 <h3>2. Comentário e interpretação da passagem</h3><p>${esc(d.commentary)}</p>
 <h3>3. Vocabulário bíblico e tradução</h3><p>${esc(d.lexicon)}</p>
 <h3>4. Referências cruzadas comentadas</h3><p>${esc(d.parallels)}</p>
 <p class="smallprint">Use as referências para comparar temas e argumentos. A relação entre textos não significa que sejam idênticos ou que um prove toda a interpretação do outro.</p>
 <h3>5. Método para aprofundar</h3><p>${esc(d.methods)}</p>
 <h3>6. Leituras para pesquisa</h3><p>${esc(d.readings)}</p>
 <div class="note">Bibliografia recomendada para consulta e aprofundamento, não transcrições nem citações verificadas página a página. Compare as posições com o texto bíblico.</div>
 </div>`;
}
function courseApostila(s,idx){
 const a=APOSTILAS[s.id]?.[idx];
 if(!a)return '';
 return `<section class="course-deep" aria-label="Apostila ampliada desta aula">
 <div class="section-label">APOSTILA AMPLIADA · CAPÍTULO ${idx+1}</div>
 <h2>${esc(a.heading)}</h2>
 <p class="course-source"><b>Textos-base:</b> ${esc(a.primary)}</p>
 <h3>Exposição e comentário desenvolvido</h3><p>${esc(a.lecture)}</p>
 <h3>Comparação de passagens e perspectivas</h3><p>${esc(a.comparison)}</p>
 <h3>Exercício orientado</h3><p>${esc(a.exercise)}</p>
 <h3>Bibliografia de aprofundamento</h3><p>${esc(a.readings)}</p>
 <p class="smallprint">Leituras indicadas para consulta. Não há citações de páginas que não tenham sido verificadas. Traduções ou sínteses explicativas são autorais e não substituem o texto ACF.</p>
 </section>`;
}
function courseLesson(){
 const s=courseSubjectById(S.courseSubjectId),l=courseLessonById(s,S.courseLessonId),idx=s.lessons.indexOf(l),done=courseFinished().includes(l.id);
 const answer=(S.courseAnswers||{})[l.id]||'';
 const show=Array.isArray(S.courseShown)&&S.courseShown.includes(l.id);
 return `<button class="back" data-action="open-course-subject" data-subject="${s.id}">‹ ${esc(s.title)}</button>
 <div class="section-label">CURSO DE TEOLOGIA · DISCIPLINA ${CURSO.subjects.indexOf(s)+1} · AULA ${idx+1} DE 3</div>
 <h1>${esc(l.title)}</h1><p><span class="pill">${esc(s.reference)}</span></p>
 <div class="course-lesson-body card content-prose">
 <h3>Objetivo da aula</h3><p>${esc(s.objective)}</p>
 <h3>Introdução ao tema</h3><p>${esc(l.content)}</p>
 ${courseApostila(s,idx)}
 ${courseStudyDossier(s,l,idx)}
 <h3>Atividade de aprendizagem</h3><p>${esc(l.activity)}</p>
 <div class="course-important"><b>Exercício de exegese</b><p>Escreva quatro linhas: (1) o que a passagem afirma; (2) como seu contexto ilumina a frase; (3) o que uma palavra original pode — e não pode — provar; (4) qual aplicação responsável pode ser extraída.</p></div>
 <div class="actions"><button class="btn secondary small" data-action="new-note" data-title="Curso · ${esc(s.title)} · ${esc(l.title)}">✎ Registrar análise</button><button class="btn secondary small" data-action="speak-screen">🔊 Dora: narrar o estudo</button></div></div>
 <div class="card"><h3>Verifique o que aprendeu</h3><p>${esc(l.question)}</p>
 <div class="field"><label for="course-check-answer">Sua resposta (salva neste aparelho)</label><textarea id="course-check-answer" placeholder="Escreva com suas palavras...">${esc(answer)}</textarea></div>
 <div class="actions"><button class="btn secondary" data-action="course-save-answer">Salvar resposta</button><button class="btn ghost" data-action="course-reveal-answer">${show?'Ocultar':'Conferir'} resposta de referência</button></div>
 ${show?`<div class="course-answer"><strong>Resposta de referência</strong><p>${esc(l.answer)}</p><p class="smallprint">Compare suas ideias, não apenas palavras idênticas. Esta é uma autoavaliação sem nota automática.</p></div>`:''}</div>
 <div class="card"><div class="actions"><button class="btn" data-action="complete-course-lesson">${done?'✓ Aula concluída':'✓ Marcar aula concluída'}</button>
 ${idx>0?`<button class="btn secondary" data-action="open-course-lesson" data-subject="${s.id}" data-lesson="${s.lessons[idx-1].id}">‹ Anterior</button>`:''}
 ${idx<2?`<button class="btn secondary" data-action="open-course-lesson" data-subject="${s.id}" data-lesson="${s.lessons[idx+1].id}">Próxima ›</button>`:`<button class="btn secondary" data-action="course-open-assessment" data-subject="${s.id}">Avaliação da disciplina ›</button>`}
 </div></div>`;
}
function courseAssessment(){
 const s=courseSubjectById(S.courseSubjectId),answers=((S.courseExamAnswers||{})[s.id]||['','','']);
 const show=Array.isArray(S.courseExamShown)&&S.courseExamShown.includes(s.id);
 const done=courseExams().includes(s.id);
 return `<button class="back" data-action="open-course-subject" data-subject="${s.id}">‹ Voltar à disciplina</button><div class="section-label">AUTOAVALIAÇÃO · CURSO LIVRE</div>
 <h1>Avaliação: ${esc(s.title)}</h1><div class="note">Responda com suas palavras e depois compare com as respostas de referência. Não há correção automática nem nota atribuída por inteligência artificial. Suas respostas ficam salvas no aparelho.</div>
 ${s.lessons.map((l,i)=>`<div class="card"><div class="section-label">QUESTÃO ${i+1} DE 3</div><h3>${esc(l.title)}</h3><p>${esc(l.question)}</p><div class="field"><label for="exam-answer-${i}">Sua resposta</label><textarea id="exam-answer-${i}" placeholder="Escreva sua resposta">${esc(answers[i]||'')}</textarea></div>${show?`<div class="course-answer"><strong>Resposta de referência</strong><p>${esc(l.answer)}</p></div>`:''}</div>`).join('')}
 <div class="card"><div class="actions"><button class="btn" data-action="course-submit-assessment">${done?'Atualizar respostas':'Salvar avaliação'}</button><button class="btn secondary" data-action="course-toggle-assessment">${show?'Ocultar gabarito':'Conferir gabarito'}</button></div>
 <p class="smallprint">${done?'✓ Avaliação registrada — respostas conferíveis.':'A avaliação será registrada após você responder às três questões.'}</p></div>
 <div class="card"><h3>Projeto integrador</h3><p>${esc(s.project)}</p><button class="btn secondary" data-action="new-note" data-title="Avaliação · ${esc(s.title)}">✎ Elaborar no caderno</button></div>`;
}
function handleCourseAction(a,btn){
 if(a==='open-course-subject') {patch({courseSubjectId:btn.dataset.subject,tab:'course-subject'});render();window.scrollTo(0,0);autoReadScreen();return true;}
 if(a==='open-course-lesson') {patch({courseSubjectId:btn.dataset.subject,courseLessonId:btn.dataset.lesson,tab:'course-lesson'});render();window.scrollTo(0,0);autoReadScreen();return true;}
 if(a==='course-filter') {patch({courseTrack:btn.dataset.track});render();return true;}
 if(a==='complete-course-lesson') {
  if(!S.courseDone.includes(S.courseLessonId)) {S.courseDone.push(S.courseLessonId);save();toast('Aula concluída e progresso salvo.');}
  render();return true;
 }
 if(a==='course-save-answer') {S.courseAnswers[S.courseLessonId]=document.querySelector('#course-check-answer')?.value.trim()||'';save();toast('Sua resposta foi salva.');return true;}
 if(a==='course-reveal-answer') {S.courseAnswers[S.courseLessonId]=document.querySelector('#course-check-answer')?.value||''; S.courseShown=S.courseShown||[];S.courseShown=S.courseShown.includes(S.courseLessonId)?S.courseShown.filter(x=>x!==S.courseLessonId):[...S.courseShown,S.courseLessonId];save();render();return true;}
 if(a==='course-open-assessment') {patch({courseSubjectId:btn.dataset.subject,tab:'course-assessment'});render();window.scrollTo(0,0);autoReadScreen();return true;}
 if(a==='course-submit-assessment'){
  const x=[0,1,2].map(i=>document.querySelector('#exam-answer-'+i)?.value.trim()||'');S.courseExamAnswers[S.courseSubjectId]=x;
  if(x.every(Boolean)){if(!S.courseExamDone.includes(S.courseSubjectId))S.courseExamDone.push(S.courseSubjectId);toast('Avaliação registrada! Compare com o gabarito.');}
  else toast('Responda às três questões para concluir a avaliação.');save();render();return true;
 }
 if(a==='course-toggle-assessment'){
  let x=[0,1,2].map(i=>document.querySelector('#exam-answer-'+i)?.value||'');S.courseExamAnswers[S.courseSubjectId]=x;
  S.courseExamShown=S.courseExamShown||[];
  S.courseExamShown=S.courseExamShown.includes(S.courseSubjectId)?S.courseExamShown.filter(id=>id!==S.courseSubjectId):[...S.courseExamShown,S.courseSubjectId];
  save();render();return true;
 }
 return false;
}
function handleCourseInput(e){
 if(e.target.id==='course-search'){window._courseQuery=e.target.value;let el=document.querySelector('#course-results');if(el)el.innerHTML=courseResults();}
}
