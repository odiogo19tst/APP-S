/* Busca musical: abrimos plataformas oficiais; sem audio, letras ou faixas embutidas. */
window.JARDIM_MUSIC = [
  {
    "title": "Bondade de Deus",
    "artist": "Isaías Saad",
    "why": "O cuidado de Deus é lembrado mesmo quando a caminhada é difícil."
  },
  {
    "title": "Firme nas Promessas",
    "artist": "Harpa Cristã · hino 107",
    "why": "A esperança se apoia nas promessas e não apenas nas circunstâncias."
  },
  {
    "title": "Aquieta Minh’alma",
    "artist": "Ministério Zoe",
    "why": "A oração convida a trocar a agitação pela confiança."
  },
  {
    "title": "Mais Perto Quero Estar",
    "artist": "Harpa Cristã · hino 187",
    "why": "Descansar também é aproximar o coração de Deus."
  },
  {
    "title": "Firme nas Promessas",
    "artist": "Harpa Cristã · hino 107",
    "why": "A confiança pode ser exercitada mesmo sem controlar os resultados."
  },
  {
    "title": "Deus Proverá",
    "artist": "Gabriela Gomes",
    "why": "A providência motiva oração e responsabilidade no presente."
  },
  {
    "title": "Lugar Secreto",
    "artist": "Gabriela Rocha",
    "why": "O recolhimento ajuda a lembrar que Deus é refúgio."
  },
  {
    "title": "Aquieta Minh’alma",
    "artist": "Ministério Zoe",
    "why": "A paz de Cristo orienta a mente e as relações."
  },
  {
    "title": "Ousado Amor",
    "artist": "Isaías Saad",
    "why": "A misericórdia é recebida como graça, não como conquista."
  },
  {
    "title": "Deus Proverá",
    "artist": "Gabriela Gomes",
    "why": "Em momentos de necessidade, buscar ajuda também é ato responsável."
  },
  {
    "title": "Em Fervente Oração",
    "artist": "Harpa Cristã · hino 577",
    "why": "A busca de sabedoria começa pela escuta e pelo discernimento."
  },
  {
    "title": "Rendido Estou",
    "artist": "Aline Barros",
    "why": "A entrega oferece a Deus preocupações e decisões."
  },
  {
    "title": "Porque Ele Vive",
    "artist": "Interpretações cristãs",
    "why": "A esperança em Cristo sustenta o cuidado em tempos de tristeza."
  },
  {
    "title": "Firme nas Promessas",
    "artist": "Harpa Cristã · hino 107",
    "why": "A coragem não precisa negar o medo."
  },
  {
    "title": "Ousado Amor",
    "artist": "Isaías Saad",
    "why": "A graça não é prêmio por força pessoal."
  },
  {
    "title": "Deus Proverá",
    "artist": "Gabriela Gomes",
    "why": "Ler promessas bíblicas com contexto fortalece uma esperança madura."
  },
  {
    "title": "Lugar Secreto",
    "artist": "Gabriela Rocha",
    "why": "O abrigo espiritual convida também à solidariedade."
  },
  {
    "title": "Eu Navegarei",
    "artist": "Interpretações cristãs",
    "why": "O fruto do Espírito aparece em relacionamentos concretos."
  },
  {
    "title": "Firme nas Promessas",
    "artist": "Harpa Cristã · hino 107",
    "why": "A fé se alimenta de perseverança e memória da Palavra."
  },
  {
    "title": "Em Fervente Oração",
    "artist": "Harpa Cristã · hino 577",
    "why": "Perseverança pede oração e práticas diárias possíveis."
  },
  {
    "title": "Mais Perto Quero Estar",
    "artist": "Harpa Cristã · hino 187",
    "why": "Permanecer em Cristo envolve comunhão e fruto."
  },
  {
    "title": "Alvo Mais Que a Neve",
    "artist": "Harpa Cristã · hino 39",
    "why": "A salvação pela graça produz uma vida transformada."
  },
  {
    "title": "Me Ajude a Melhorar",
    "artist": "Eli Soares",
    "why": "A justiça começa também nas escolhas e relações próximas."
  },
  {
    "title": "Rendido Estou",
    "artist": "Aline Barros",
    "why": "A prioridade do Reino orienta o que vem antes do sucesso."
  },
  {
    "title": "Ousado Amor",
    "artist": "Isaías Saad",
    "why": "O amor cristão se comprova em atitude, cuidado e verdade."
  },
  {
    "title": "Em Fervente Oração",
    "artist": "Harpa Cristã · hino 577",
    "why": "Examinar o coração é oportunidade de mudança, não de desespero."
  },
  {
    "title": "Porque Ele Vive",
    "artist": "Interpretações cristãs",
    "why": "A esperança futura encoraja o cuidado de hoje."
  },
  {
    "title": "Bondade de Deus",
    "artist": "Isaías Saad",
    "why": "A gratidão recorda dádivas sem negar dores."
  },
  {
    "title": "Me Ajude a Melhorar",
    "artist": "Eli Soares",
    "why": "O amor ao próximo é compromisso concreto."
  },
  {
    "title": "Mais Perto Quero Estar",
    "artist": "Harpa Cristã · hino 187",
    "why": "O louvor une memória bíblica, oração e presença comunitária."
  },
  {
    "title": "Em Fervente Oração",
    "artist": "Harpa Cristã · hino 577",
    "why": "Estudar as Escrituras com atenção também é um gesto de adoração."
  }
];
