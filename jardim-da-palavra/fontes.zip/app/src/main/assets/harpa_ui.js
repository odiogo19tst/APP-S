'use strict';
/* Harpa Cristã: índice de 640 títulos, leitor simples de letras e favoritos.
   Não distribui letras de terceiros sem comprovação de direitos de uso.
   Importação local de letras pessoais em TXT/JSON, preservando notas anteriores. */
(function () {
  const TITLES = (window.JARDIM_HARPA_TITLES || []);
  // Letras do PDF fornecido pessoalmente pelo usuario. Arquivo carregado antes deste modulo.
  const BUNDLED = window.JARDIM_HARPA_LYRICS || {};
  const SEARCH_DATA = Array.from({length:641}, (_,n) => normalizedRaw(`${TITLES[n] || ''} ${(BUNDLED[n] || {}).text || ''}`));
  function normalizedRaw(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9\s]+/g,' ').replace(/\s+/g,' ').trim(); }
  const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const normalized = normalizedRaw;
  const chordPattern = /\[([A-G](?:#|b)?(?:m|maj|min|dim|aug|sus|add)?[0-9+#/bA-Ga-z-]*)\]/g;
  let current = 0, query = '', onlyFavorites = false, page = 0, editing = false;

  function ensure(S) {
    if (!Array.isArray(S.harpaFav)) S.harpaFav = [];
    for (const field of ['harpaLyrics', 'harpaCharts', 'harpaDrafts']) {
      if (!S[field] || typeof S[field] !== 'object' || Array.isArray(S[field])) S[field] = {};
    }
  }
  function name(n) { return TITLES[n] || `Hino ${n}`; }
  // Compatibilidade com as anotações antigas, removendo os acordes sem perder a letra.
  function plainText(text) {
    return String(text || '')
      .replace(/<\s*br\s*\/?\s*>/gi, '\n')
      .replace(/<\/?(?:p|div|span|strong|em|b|i)\b[^>]*>/gi, '')
      .replace(chordPattern, '')
      .replace(/\r\n?/g, '\n')
      // Ajustes tipográficos mínimos com leitura conferida no PDF; não reescreve estrofes.
      .replace(/^\s*[lI][.]\s*(?=\S)/u, '1. ')
      .replace(/\bSiâo\b/gu, 'Sião')
      .replace(/\bse mpre\b/giu, 'sempre')
      .replace(/Dá-Ihes/gu, 'Dá-lhes')
      .trim();
  }
  function lyricsFor(S,n) { return plainText(S.harpaLyrics[n] || S.harpaCharts[n] || (BUNDLED[n] || {}).text || ''); }
  // O PDF original tem quebras artificiais no meio dos versos. A leitura separa
  // estrofes/refrões semanticamente e deixa o navegador quebrar as linhas pela largura.
  function hymnSections(raw) {
    const lines = plainText(raw).split('\n').map(s => s.trim()).filter(Boolean);
    const sections = [];
    let section = null;
    function push() {
      if (section && section.lines.length) sections.push(section);
      section = null;
    }
    function append(type, number, content) {
      if (!section || section.type !== type || (type === 'verse' && section.number !== number)) {
        push();
        section = {type, number, lines: []};
      }
      if (content) section.lines.push(content);
    }
    for (const line of lines) {
      // A extração pode produzir "2O amor" ou "3Água" sem um espaço após o número.
      const numbered = line.match(/^([1-9]|1[0-9])(?:[.)]\s*|\s+|(?=[A-ZÁÉÍÓÚÂÊÔÃÕÇ]))(?=\S)(.*)$/u);
      if (numbered && numbered[2] && !/^\d/.test(numbered[2])) {
        append('verse', Number(numbered[1]), numbered[2].trim());
        continue;
      }
      if (/^(?:refr[aã]o|coro|estribilho)\s*[:.-]?\s*$/i.test(line)) {
        append('chorus', null, '');
        continue;
      }
      const letters = Array.from(line).filter(c => /[A-Za-zÀ-ÿ]/u.test(c));
      const upper = letters.filter(c => c === c.toLocaleUpperCase('pt-BR')).length;
      const chorus = letters.length >= (section && section.type === 'chorus' ? 3 : 9) && upper / letters.length >= 0.85;
      // A primeira estrofe vem numerada, mas às vezes o PDF começa sem número.
      if (chorus) append('chorus', null, line);
      else append('verse', section && section.type === 'verse' ? section.number : null, line);
    }
    push();
    return sections;
  }
  function stanzaLines(lines) {
    // Recompõe a leitura, preservando as palavras e a pontuação do documento.
    // Um fragmento curto ("Dá-nos, Senhor,") não deve virar três versos.
    const phrase = lines.join(' ').replace(/\s+/g, ' ')
      .replace(/([A-Za-zÀ-ÿ])-\s+([A-Za-zÀ-ÿ])/gu, '$1-$2').trim();
    if (!phrase) return [];
    const segments = phrase.split(/(?<=[,;.!?])\s+(?=[A-ZÀ-Ý])/u);
    const result = [];
    let current = '';
    for (const rawSegment of segments) {
      const piece = rawSegment.trim();
      if (!piece) continue;
      if (!current) current = piece;
      else if (current.length < 24 && /[,;]$/.test(current)) current += ' ' + piece;
      else { result.push(current); current = piece; }
    }
    if (current) result.push(current);
    return result;
  }
  function formattedLyrics(raw) {
    const sections = hymnSections(raw);
    if (!sections.length) return '<p class="harpa-no-lyric">Letra não disponível.</p>';
    return sections.map((section, i) => {
      const lines = stanzaLines(section.lines);
      const chorus = section.type === 'chorus';
      const number = section.number || (i + 1);
      const heading = chorus ? 'Refrão' : 'Estrofe ' + number;
      return `<section class="harpa-stanza ${chorus ? 'harpa-refrain' : ''}">
        <div class="harpa-stanza-heading">${escapeHtml(heading)}</div>
        <div class="harpa-stanza-text">${lines.map(l => `<span class="harpa-stanza-line">${escapeHtml(l)}</span>`).join('')}</div>
      </section>`;
    }).join('');
  }

  function matched(S) {
    const typed = String(query || '').replace(/^(?:hino|harpa)\s*/i, '').trim();
    const q = normalized(typed);
    const words = q.split(' ').filter(Boolean);
    const numbered = /^\d{1,3}$/.test(q);
    const all=[];
    for (let n=1;n<=640;n++) {
      if (onlyFavorites && !S.harpaFav.includes(n)) continue;
      if (numbered) { if (n!==Number(q)) continue; }
      else if (words.length) {
        const userText = S.harpaLyrics[n] || S.harpaCharts[n] || '';
        const data = userText ? normalized(`${name(n)} ${userText}`) : SEARCH_DATA[n];
        if (!words.every(w => data.includes(w))) continue;
      }
      all.push(n);
    }
    return all;
  }
  function results(S) {
    const items = matched(S), end = (page + 1) * 40;
    let html = `<div class="harpa-results-count">${items.length} hino(s) encontrado(s)</div>` + items.slice(0,end).map(n => {
      const available = Boolean(lyricsFor(S,n));
      const fav = S.harpaFav.includes(n);
      return `<button class="harpa-row" data-action="harpa-open" data-n="${n}">
        <span class="harpa-number">${n}</span><span class="harpa-row-body"><strong>${escapeHtml(name(n))}</strong>
        <small>${available ? 'Letra completa offline' : 'Harpa Cristã · nº '+n}</small></span>
        <span class="harpa-row-arrow">${fav ? '♥' : '›'}</span></button>`;
    }).join('');
    if (!items.length) html += '<div class="card"><p>Nenhum hino encontrado.</p></div>';
    if (end < items.length) html += `<button class="btn secondary harpa-more" data-action="harpa-more">Mostrar mais (${items.length} hinos)</button>`;
    return html;
  }
  function renderList(S) {
    const available = Array.from({length:640},(_,i)=>i+1).filter(n=>lyricsFor(S,n)).length;
    return `<div class="harpa-head"><span class="section-label">HINÁRIO PENTECOSTAL · 640 HINOS</span>
      <h1>Harpa Cristã</h1><p>Pesquise por número, título ou palavras da letra. Os hinos estão disponíveis para leitura mesmo sem internet.</p>
      <div class="harpa-stats"><span><b>640</b> hinos no índice</span><span><b>${available}</b> letras no aparelho</span><span><b>${S.harpaFav.length}</b> favoritos</span></div></div>
      <label class="harpa-label" for="harpa-search">Pesquisar hino</label>
      <input id="harpa-search" class="harpa-search" placeholder="Ex.: 1, Chuvas de Graça ou Consolador" value="${escapeHtml(query)}" autocomplete="off" />
      <div class="harpa-filter-bar"><button class="btn ${onlyFavorites?'secondary':''} small" data-action="harpa-all">Todos</button>
      <button class="btn ${onlyFavorites?'':'secondary'} small" data-action="harpa-favorites">♥ Favoritos</button>
      <button class="btn secondary small" data-action="harpa-import">↥ Importar edição</button></div>
      <div id="harpa-results">${results(S)}</div>
      <p class="smallprint">Letras organizadas a partir do PDF fornecido pelo usuário. Algumas grafias do arquivo original podem precisar de revisão.</p>`;
  }
  function renderDetail(S) {
    const n = current, lyric = lyricsFor(S,n);
    const draft = Object.prototype.hasOwnProperty.call(S.harpaDrafts,n) ? S.harpaDrafts[n] : lyric;
    const favorite = S.harpaFav.includes(n);
    return `<div class="harpa-detail"><button class="harpa-back" data-action="harpa-back">← Todos os hinos</button>
      <div class="harpa-detail-hero"><span class="section-label">HARPA CRISTÃ · HINO ${n}</span><h1>${escapeHtml(name(n))}</h1>
      <div class="harpa-filter-bar"><button class="btn secondary small" data-action="harpa-fav">${favorite?'♥ Favorito':'♡ Favoritar'}</button>
      <button class="btn secondary small" data-action="harpa-editor">${editing?'Fechar edição':'✎ Corrigir letra'}</button></div></div>
      ${editing ? `<div class="card harpa-edit-panel"><h3>Letra do hino ${n}</h3><p class="smallprint">Escreva ou cole uma letra que você tem direito de utilizar. Ela ficará disponível sem internet.</p>
      <label for="harpa-lyric-edit">Texto do hino</label><textarea id="harpa-lyric-edit" rows="12" spellcheck="true" placeholder="Primeira estrofe...\n\nRefrão...">${escapeHtml(draft)}</textarea>
      <div class="harpa-filter-bar"><button class="btn" data-action="harpa-save">Salvar letra</button><button class="btn secondary" data-action="harpa-cancel">Cancelar</button></div></div>` : ''}
      ${lyric ? `<div class="card harpa-player"><div class="row"><h3>Letra do hino</h3><span class="pill">Offline</span></div>
      <div class="harpa-lyrics-view">${formattedLyrics(lyric)}</div></div>` : `<div class="card harpa-unavailable"><h3>Letra ainda não disponível</h3>
      <p>O número e o título deste hino estão no índice. Para ler sem internet, adicione uma cópia da letra que você tenha permissão de utilizar.</p>
      <div class="harpa-filter-bar"><button class="btn" data-action="harpa-editor">Adicionar letra</button><button class="btn secondary" data-action="harpa-import">Importar arquivo</button></div></div>`}
      <div class="harpa-detail-nav"><button class="btn secondary small" data-action="harpa-prev" ${n<=1?'disabled':''}>← Anterior</button>
      <button class="btn secondary small" data-action="harpa-next" ${n>=640?'disabled':''}>Próximo →</button></div></div>`;
  }
  function render(S) { ensure(S); return current ? renderDetail(S) : renderList(S); }
  function action(a, btn, S, save, renderMain, toast) {
    ensure(S);
    if (!a.startsWith('harpa-')) return false;
    const redraw = () => { save(); renderMain(); };
    if (a === 'harpa-open') { current=Number(btn.dataset.n); editing=false; redraw(); window.scrollTo(0,0); return true; }
    if (a === 'harpa-back') { current=0; editing=false; redraw(); return true; }
    if (a === 'harpa-prev' || a === 'harpa-next') { current=Math.min(640,Math.max(1,current+(a==='harpa-next'?1:-1)));editing=false;redraw();window.scrollTo(0,0);return true; }
    if (a === 'harpa-all') { onlyFavorites=false;page=0;redraw();return true; }
    if (a === 'harpa-favorites') { onlyFavorites=true;page=0;redraw();return true; }
    if (a === 'harpa-more') { page++; const e=document.querySelector('#harpa-results');if(e)e.innerHTML=results(S);return true; }
    if (a === 'harpa-fav') { S.harpaFav=S.harpaFav.includes(current)?S.harpaFav.filter(n=>n!==current):S.harpaFav.concat(current);redraw();return true; }
    if (a === 'harpa-editor') { editing=!editing;redraw();return true; }
    if (a === 'harpa-cancel') { editing=false;delete S.harpaDrafts[current];redraw();return true; }
    if (a === 'harpa-save') {
      const text=String(document.querySelector('#harpa-lyric-edit')?.value||'').trim();
      if (text.length>25000) { toast('Limite de 25 mil caracteres por hino.');return true; }
      if (text) S.harpaLyrics[current]=plainText(text); else { delete S.harpaLyrics[current];delete S.harpaCharts[current]; }
      delete S.harpaDrafts[current];editing=false;redraw();toast(text?'Letra salva offline.':'Letra removida.');return true;
    }
    if (a === 'harpa-import') {
      if (window.JardimAndroid?.importHarpaLyrics) window.JardimAndroid.importHarpaLyrics();
      else if (window.JardimAndroid?.importHarpaCharts) window.JardimAndroid.importHarpaCharts();
      else {const p=document.querySelector('#harpa-file-picker');if(p)p.click();else toast('Selecione um arquivo TXT ou JSON no Android.');}
      return true;
    }
    return true;
  }
  function input(e,S,save) {
    if (e.target.id==='harpa-search') {query=e.target.value;page=0;const root=document.querySelector('#harpa-results');if(root)root.innerHTML=results(S);return true;}
    if (e.target.id==='harpa-lyric-edit'&&current) {ensure(S);S.harpaDrafts[current]=e.target.value;save();return true;}
    return false;
  }
  function fromObject(v) {
    if (typeof v === 'string') return v;
    if (!v || typeof v !== 'object') return '';
    if (typeof v.letra==='string') return v.letra;
    if (typeof v.texto==='string') return v.texto;
    if (typeof v.lyrics==='string') return v.lyrics;
    if (typeof v.cifra==='string') return v.cifra; // compatibilidade com backups anteriores
    if (typeof v.chordpro==='string') return v.chordpro;
    if (v.verses && typeof v.verses==='object') {
      let verses = Object.entries(v.verses).sort(([a],[b])=>Number(a)-Number(b)).map(([_,text],i)=>`${i+1}. ${plainText(text)}`).join('\n\n');
      return verses+(v.coro?'\n\nRefrão:\n'+plainText(v.coro):'');
    }
    return '';
  }
  function imported(text,filename,S,save,renderMain,toast) {
    ensure(S);
    try {
      if(text.length>2500000)throw Error('Arquivo grande demais (limite de 2,5 MB).');
      let entries={};
      if(filename.toLowerCase().endsWith('.json')) {
        let data=JSON.parse(text);if(data.hinos&&typeof data.hinos==='object')data=data.hinos;
        if(Array.isArray(data)) for(const item of data){const n=Number(item.numero||item.number||item.id);if(n>=1&&n<=640)entries[n]=fromObject(item);}
        else if(data&&typeof data==='object')for(const [k,v] of Object.entries(data)){const n=Number(k);if(Number.isInteger(n)&&n>=1&&n<=640)entries[n]=fromObject(v);}
      } else {
        const m=filename.match(/(?:hino[-_\s]?)?(\d{1,3})(?=\D|$)/i);
        const n=m?Number(m[1]):current;
        if(n<1||n>640)throw Error('Abra um hino ou nomeie o arquivo como hino-001.txt.');
        entries[n]=text;
      }
      let count=0;
      for (const [n,value] of Object.entries(entries)) {
        if(typeof value==='string'&&value.trim()&&value.length<=25000){S.harpaLyrics[n]=plainText(value);count++;}
      }
      if(!count)throw Error('Não foram encontradas letras compatíveis.');
      save();renderMain();toast(count+' letra(s) importada(s) e salva(s) offline.');return count;
    } catch(e) {toast('Importação de letras: '+e.message);return 0;}
  }
  window.JARDIM_HARPA={render,action,input,imported,plainText,lyricsFor,name,results,hymnSections,formattedLyrics};
})();
