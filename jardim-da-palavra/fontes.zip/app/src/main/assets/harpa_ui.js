'use strict';
/* Harpa Cristã: índice de 640 títulos; cifras pessoais em ChordPro.
   Não distribui letras, harmonizações ou gravações de terceiros. */
(function(){
 const H=window.JARDIM_HARPA_TITLES||[];
 const empty=Array.from({length:641},(_,n)=>n&&`Hino ${n}`);
 const TITLES=H.length===641?H:empty;
 const E=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 const searchNormalize=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase();
 const SHARP=['C','C#','D','D#','E','F','F#','G','G#','A','A#','B'];
 const FLAT=['C','Db','D','Eb','E','F','Gb','G','Ab','A','Bb','B'];
 let current=0, query='', justFav=false, page=0, edit=false, chordMode=true;
 function ensure(S){
  if(!Array.isArray(S.harpaFav))S.harpaFav=[];
  if(!S.harpaCharts||typeof S.harpaCharts!=='object'||Array.isArray(S.harpaCharts))S.harpaCharts={};
  if(!S.harpaSteps||typeof S.harpaSteps!=='object'||Array.isArray(S.harpaSteps))S.harpaSteps={};
  if(!S.harpaDrafts||typeof S.harpaDrafts!=='object'||Array.isArray(S.harpaDrafts))S.harpaDrafts={};
 }
 function name(n){return TITLES[n]||`Hino ${n}`;}
 function chordToken(c,shift){
  if(!shift||!/^[A-G]/.test(c))return c;
  const transpose=(letter,acc)=>{
   let v=SHARP.indexOf(letter+(acc||''));if(v<0)v=FLAT.indexOf(letter+(acc||''));
   if(v<0)return letter+(acc||'');
   const target=((v+shift)%12+12)%12;
   return (acc==='b'?FLAT:SHARP)[target];
  };
  let m=c.match(/^([A-G])([#b]?)(.*)$/);if(!m)return c;
  return transpose(m[1],m[2])+m[3].replace(/\/([A-G])([#b]?)/g,(_,r,a)=>'/'+transpose(r,a));
 }
 function chordsFrom(text,shift=0){
  const lines=String(text||'').replace(/\r\n?/g,'\n').split('\n');
  return lines.map(line=>{
   const rg=/\[([A-G](?:#|b)?[^\]]*)\]/g;let m,last=0,out='',found=false;
   while((m=rg.exec(line))){
    found=true;
    if(m.index>last)out+='<span class="harpa-raw">'+E(line.slice(last,m.index))+'</span>';
    let textEnd=line.indexOf('[',rg.lastIndex);if(textEnd<0)textEnd=line.length;
    const lyric=line.slice(rg.lastIndex,textEnd);
    out+='<span class="harpa-chord-word"><span class="harpa-chord">'+E(chordToken(m[1],shift))+'</span><span class="harpa-lyric">'+E(lyric||' ')+'</span></span>';
    rg.lastIndex=textEnd;last=textEnd;
   }
   if(!found)return '<span class="harpa-raw">'+E(line||' ')+'</span>';
   if(last<line.length)out+='<span class="harpa-raw">'+E(line.slice(last))+'</span>';
   return out;
  }).join('\n');
 }
 function matched(S){
  let list=[];const q=searchNormalize(query.replace(/^(hino|harpa)\s*/i,''));
  for(let n=1;n<=640;n++){
   if(justFav&&!S.harpaFav.includes(n))continue;
   if(q&&!searchNormalize(name(n)).includes(q)&&!String(n).includes(q))continue;
   list.push(n);
  }
  return list;
 }
 function results(S){
  const l=matched(S),end=(page+1)*40;
  let html=l.slice(0,end).map(n=>{
   const saved=!!S.harpaCharts[n],fav=S.harpaFav.includes(n);
   return '<button class="harpa-row" data-action="harpa-open" data-n="'+n+'"><span class="harpa-number">'+n+'</span><span class="harpa-row-body"><strong>'+E(name(n))+'</strong><small>'+(saved?'♫ Cifra salva no celular':'Harpa Cristã · nº '+n)+'</small></span><span class="harpa-row-arrow">'+(fav?'♥':'›')+'</span></button>';
  }).join('')||'<div class="card"><p>Nenhum hino encontrado.</p></div>';
  if(end<l.length)html+='<button class="btn secondary harpa-more" data-action="harpa-more">Mostrar mais ('+l.length+' hinos)</button>';
  return html;
 }
 function renderList(S){
  const done=Object.keys(S.harpaCharts).filter(k=>S.harpaCharts[k]).length;
  return `<div class="harpa-head"> <span class="section-label">HINÁRIO PENTECOSTAL · 640 HINOS</span>
   <h1>Harpa Cristã</h1><p>Encontre um hino pelo número ou título. Guarde suas cifras para usar no culto, inclusive sem internet.</p>
   <div class="harpa-stats"><span><b>640</b> hinos no índice</span><span><b>${done}</b> cifras pessoais</span><span><b>${S.harpaFav.length}</b> favoritos</span></div></div>
  <label class="harpa-label" for="harpa-search">Pesquisar hino</label><input id="harpa-search" class="harpa-search" placeholder="Ex.: 1 ou Chuvas de Graça" value="${E(query)}" autocomplete="off" />
  <div class="harpa-filter-bar"><button class="btn ${justFav?'':'secondary'} small" data-action="harpa-all">Todos os hinos</button><button class="btn ${justFav?'secondary':''} small" data-action="harpa-favorites">♥ Favoritos</button><button class="btn secondary small" data-action="harpa-import">↥ Importar minhas cifras</button></div>
  <div id="harpa-results">${results(S)}</div>
  <p class="smallprint">A numeração e os títulos são um índice. Letras e harmonizações não são fornecidas sem licença: você pode guardar suas próprias cifras em formato ChordPro.</p>`;
 }
 function renderDetail(S){
  const n=current;let chart=S.harpaCharts[n]||'';let shift=Number(S.harpaSteps[n]||0);
  const draft=Object.prototype.hasOwnProperty.call(S.harpaDrafts,n)?S.harpaDrafts[n]:chart;
  const fav=S.harpaFav.includes(n);
  return `<div class="harpa-detail"><button class="harpa-back" data-action="harpa-back">← Voltar aos 640 hinos</button>
   <div class="harpa-detail-hero"><span class="section-label">HARPA CRISTÃ · HINO ${n}</span><h1>${E(name(n))}</h1>
    <div class="harpa-filter-bar"><button class="btn small secondary" data-action="harpa-fav">${fav?'♥ Favorito':'♡ Favoritar'}</button><button class="btn small secondary" data-action="harpa-editor">${edit?'Fechar edição':'✎ Editar minha cifra'}</button></div></div>
   ${edit?`<div class="card harpa-edit-panel"><h3>Minha cifra · Hino ${n}</h3><p class="smallprint">Cole a letra que tem direito de utilizar e escreva os acordes antes das sílabas usando colchetes, por exemplo: <code>[C]Exemplo de [G]cifra</code>.</p>
      <label for="harpa-chart-edit">Letra cifrada / ChordPro</label><textarea id="harpa-chart-edit" rows="12" spellcheck="false" placeholder="[C]Minha letra e [G]meus acordes...">${E(draft)}</textarea>
      <div class="harpa-filter-bar"><button class="btn" data-action="harpa-save">Salvar cifra offline</button><button class="btn secondary" data-action="harpa-cancel">Cancelar</button></div></div>`:''}
   ${chart?`<div class="card harpa-player"><div class="row"><h3>Cifra pessoal</h3><span class="pill">Offline</span></div>
     <div class="harpa-filter-bar"><button class="btn small ${chordMode?'':'secondary'}" data-action="harpa-view-cifra">♪ Cifrada</button><button class="btn small ${chordMode?'secondary':''}" data-action="harpa-view-letra">Somente letra</button></div>
     <div class="harpa-key-tools"><button class="harpa-round" data-action="harpa-down" aria-label="Abaixar um semitom">−</button><span>Transposição: <strong>${shift>0?'+':''}${shift}</strong> semitons</span><button class="harpa-round" data-action="harpa-up" aria-label="Subir um semitom">+</button><button class="btn ghost small" data-action="harpa-reset">Tom original</button></div>
     <div class="harpa-chart-view" aria-label="${chordMode?'Cifra transposta':'Letra sem cifra'}">${chordMode?chordsFrom(chart,shift):E(chart.replace(/\[[A-G](?:#|b)?[^\]]*\]/g,''))}</div></div>`:
    `<div class="card harpa-unavailable"><h3>Cifra não cadastrada neste aparelho</h3><p>O hino está no índice, mas não vou inventar harmonização ou reproduzir letras de terceiros sem permissão. Você pode adicionar sua própria cifra, salvá-la e transpor para outros tons.</p><button class="btn" data-action="harpa-editor">✎ Inserir cifra</button></div>`}
   <div class="card harpa-help"><h3>Para acompanhar no culto</h3><p class="smallprint">As cifras adicionadas ficam no aparelho e entram no backup do Jardim da Palavra. O leitor aceita acordes simples e com baixo alternativo, por exemplo G, Em7, F#7 ou C/G.</p>
   <div class="harpa-filter-bar"><a class="btn secondary small" href="https://www.google.com/search?q=${encodeURIComponent('Harpa Cristã cifra hino '+n+' '+name(n))}" rel="noopener noreferrer">Consultar cifra online</a><button class="btn secondary small" data-action="harpa-import">Importar arquivo</button></div></div></div>`;
 }
 function render(S){ensure(S);return current?renderDetail(S):renderList(S);}
 function action(a,btn,S,save,renderMain,toast){ensure(S);if(!a.startsWith('harpa-'))return false;
  const redraw=()=>{save();renderMain();};
  if(a==='harpa-open'){current=Number(btn.dataset.n);edit=false;redraw();window.scrollTo(0,0);return true;}
  if(a==='harpa-back'){current=0;edit=false;redraw();return true;}
  if(a==='harpa-all'){justFav=false;page=0;redraw();return true;}
  if(a==='harpa-favorites'){justFav=true;page=0;redraw();return true;}
  if(a==='harpa-more'){page++;const el=document.querySelector('#harpa-results');if(el)el.innerHTML=results(S);return true;}
  if(a==='harpa-view-cifra'){chordMode=true;redraw();return true;}
  if(a==='harpa-view-letra'){chordMode=false;redraw();return true;}
  if(a==='harpa-fav'){const n=current;S.harpaFav=S.harpaFav.includes(n)?S.harpaFav.filter(x=>x!==n):S.harpaFav.concat(n);redraw();return true;}
  if(a==='harpa-editor'){edit=!edit;redraw();return true;}
  if(a==='harpa-cancel'){edit=false;delete S.harpaDrafts[current];redraw();return true;}
  if(a==='harpa-save'){
    const n=current,v=String(document.querySelector('#harpa-chart-edit')?.value||'').trim();
    if(v.length>25000){toast('Limite de 25 mil caracteres por hino.');return true;}
    if(v){S.harpaCharts[n]=v;delete S.harpaDrafts[n];edit=false;toast('Cifra salva neste aparelho.');}
    else{delete S.harpaCharts[n];delete S.harpaDrafts[n];edit=false;toast('Cifra removida.');}
    redraw();return true;
  }
  if(['harpa-up','harpa-down','harpa-reset'].includes(a)){
    let n=current,v=a==='harpa-reset'?0:Number(S.harpaSteps[n]||0)+(a==='harpa-up'?1:-1);
    S.harpaSteps[n]=Math.max(-11,Math.min(11,v));redraw();return true;
  }
  if(a==='harpa-import'){
    if(window.JardimAndroid?.importHarpaCharts){window.JardimAndroid.importHarpaCharts();}
    else {const inp=document.querySelector('#harpa-file-picker');if(inp)inp.click();else toast('Selecione um arquivo .json ou .txt na versão Android.');}
    return true;
  }
  return true;
 }
 function input(e,S,save){if(e.target.id==='harpa-search'){query=e.target.value;page=0;const el=document.querySelector('#harpa-results');if(el)el.innerHTML=results(S);return true;}
  if(e.target.id==='harpa-chart-edit'&&current){ensure(S);S.harpaDrafts[current]=e.target.value;save();return true;}
  return false;
 }
 function imported(text,filename,S,save,renderMain,toast){ensure(S);
  try{
    if(text.length>1_750_000)throw Error('Arquivo grande demais.');
    let entries={};
    if(filename.toLowerCase().endsWith('.json')){
      let obj=JSON.parse(text);if(obj.hinos&&typeof obj.hinos==='object')obj=obj.hinos;
      if(Array.isArray(obj)){for(let o of obj){let n=Number(o.numero||o.number||o.id);if(n>0&&n<=640)entries[n]=typeof o==='string'?o:(o.cifra||o.chordpro||o.texto||'');}}
      else for(const [key,val] of Object.entries(obj)){
       let n=Number(key);if(n<1||n>640||!Number.isInteger(n))continue;
       entries[n]=typeof val==='string'?val:(val&&typeof val==='object'?(val.cifra||val.chordpro||val.texto||''):'');
      }
    }else{
      let match=filename.match(/(?:hino[-_\s]?)?(\d{1,3})(?=\D|$)/i);let n=match?Number(match[1]):current;
      if(n<1||n>640)throw Error('Abra um hino antes de importar TXT ou use nome como hino-001.txt.');
      entries[n]=text;
    }
    let total=0;for(const [n,val]of Object.entries(entries))if(typeof val==='string'&&val.trim()&&val.length<25001){S.harpaCharts[n]=val.trim();total++;}
    if(total<1)throw Error('Nenhuma cifra compatível.');
    save();renderMain();toast(total+' cifra(s) importada(s) e salva(s) offline.');return total;
  }catch(e){toast('Importação: '+e.message);return 0;}
 }
 window.JARDIM_HARPA={render,action,input,imported,chordToken,chordsFrom,name,results};
})();
