'use strict';
/* Harpa Cristã: índice de 640 títulos, leitor simples de letras e favoritos.
   Não distribui letras de terceiros sem comprovação de direitos de uso.
   Importação local de letras pessoais em TXT/JSON, preservando notas anteriores. */
(function () {
  const TITLES = (window.JARDIM_HARPA_TITLES || []);
  const escapeHtml = (s) => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const normalized = s => String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase();
  const chordPattern = /\[([A-G](?:#|b)?(?:m|maj|min|dim|aug|sus|add)?[0-9+#/bA-Ga-z-]*)\]/g;
  let current = 0, query = '', onlyFavorites = false, page = 0, editing = false;

  function ensure(S) {
    if (!Array.isArray(S.harpaFav)) S.harpaFav = [];
    for (const field of ['harpaLyrics', 'harpaCharts', 'harpaDrafts']) {
      if (!S[field] || typeof S[field] !== 'object' || Array.isArray(S[field])) S[field] = {};
    }
  }
  function name(n) { return TITLES[n] || `Hino ${n}`; }
  // Compatibilidade com as anotações antigas, removendo os acordes sem perder a letra.
  function plainText(text) {
    return String(text || '')
      .replace(/<\s*br\s*\/?\s*>/gi, '\n')
      .replace(/<\/?(?:p|div|span|strong|em|b|i)\b[^>]*>/gi, '')
      .replace(chordPattern, '')
      .replace(/\r\n?/g, '\n')
      .trim();
  }
  function lyricsFor(S,n) { return plainText(S.harpaLyrics[n] || S.harpaCharts[n] || ''); }
  function matched(S) {
    const q = normalized(query.replace(/^(hino|harpa)\s*/i, '').trim());
    const all = [];
    for (let n = 1; n <= 640; n++) {
      if (onlyFavorites && !S.harpaFav.includes(n)) continue;
      if (q && !normalized(name(n)).includes(q) && !String(n).includes(q) && !normalized(lyricsFor(S,n)).includes(q)) continue;
      all.push(n);
    }
    return all;
  }
  function results(S) {
    const items = matched(S), end = (page + 1) * 40;
    let html = items.slice(0,end).map(n => {
      const available = Boolean(lyricsFor(S,n));
      const fav = S.harpaFav.includes(n);
      return `<button class="harpa-row" data-action="harpa-open" data-n="${n}">
        <span class="harpa-number">${n}</span><span class="harpa-row-body"><strong>${escapeHtml(name(n))}</strong>
        <small>${available ? 'Letra disponível offline' : 'Harpa Cristã · nº '+n}</small></span>
        <span class="harpa-row-arrow">${fav ? '♥' : '›'}</span></button>`;
    }).join('') || '<div class="card"><p>Nenhum hino encontrado.</p></div>';
    if (end < items.length) html += `<button class="btn secondary harpa-more" data-action="harpa-more">Mostrar mais (${items.length} hinos)</button>`;
    return html;
  }
  function renderList(S) {
    const available = Array.from({length:640},(_,i)=>i+1).filter(n=>lyricsFor(S,n)).length;
    return `<div class="harpa-head"><span class="section-label">HINÁRIO PENTECOSTAL · 640 HINOS</span>
      <h1>Harpa Cristã</h1><p>Pesquise por número, título ou trecho de uma letra já salva. Leia os hinos e marque seus favoritos para o culto.</p>
      <div class="harpa-stats"><span><b>640</b> hinos no índice</span><span><b>${available}</b> letras no aparelho</span><span><b>${S.harpaFav.length}</b> favoritos</span></div></div>
      <label class="harpa-label" for="harpa-search">Pesquisar hino</label>
      <input id="harpa-search" class="harpa-search" placeholder="Ex.: 1 ou Chuvas de Graça" value="${escapeHtml(query)}" autocomplete="off" />
      <div class="harpa-filter-bar"><button class="btn ${onlyFavorites?'secondary':''} small" data-action="harpa-all">Todos</button>
      <button class="btn ${onlyFavorites?'':'secondary'} small" data-action="harpa-favorites">♥ Favoritos</button>
      <button class="btn secondary small" data-action="harpa-import">↥ Importar letras</button></div>
      <div id="harpa-results">${results(S)}</div>
      <p class="smallprint">O índice de 640 títulos funciona offline. Letras não licenciadas não são distribuídas no APK; você pode adicionar letras de material que tenha direito de utilizar.</p>`;
  }
  function renderDetail(S) {
    const n = current, lyric = lyricsFor(S,n);
    const draft = Object.prototype.hasOwnProperty.call(S.harpaDrafts,n) ? S.harpaDrafts[n] : lyric;
    const favorite = S.harpaFav.includes(n);
    return `<div class="harpa-detail"><button class="harpa-back" data-action="harpa-back">← Todos os hinos</button>
      <div class="harpa-detail-hero"><span class="section-label">HARPA CRISTÃ · HINO ${n}</span><h1>${escapeHtml(name(n))}</h1>
      <div class="harpa-filter-bar"><button class="btn secondary small" data-action="harpa-fav">${favorite?'♥ Favorito':'♡ Favoritar'}</button>
      <button class="btn secondary small" data-action="harpa-editor">${editing?'Fechar edição':'✎ Adicionar letra'}</button></div></div>
      ${editing ? `<div class="card harpa-edit-panel"><h3>Letra do hino ${n}</h3><p class="smallprint">Escreva ou cole uma letra que você tem direito de utilizar. Ela ficará disponível sem internet.</p>
      <label for="harpa-lyric-edit">Texto do hino</label><textarea id="harpa-lyric-edit" rows="12" spellcheck="true" placeholder="Primeira estrofe...\n\nRefrão...">${escapeHtml(draft)}</textarea>
      <div class="harpa-filter-bar"><button class="btn" data-action="harpa-save">Salvar letra</button><button class="btn secondary" data-action="harpa-cancel">Cancelar</button></div></div>` : ''}
      ${lyric ? `<div class="card harpa-player"><div class="row"><h3>Letra do hino</h3><span class="pill">Offline</span></div>
      <div class="harpa-lyrics-view">${escapeHtml(lyric)}</div></div>` : `<div class="card harpa-unavailable"><h3>Letra ainda não disponível</h3>
      <p>O número e o título deste hino estão no índice. Para ler sem internet, adicione uma cópia da letra que você tenha permissão de utilizar.</p>
      <div class="harpa-filter-bar"><button class="btn" data-action="harpa-editor">Adicionar letra</button><button class="btn secondary" data-action="harpa-import">Importar arquivo</button></div></div>`}
      <div class="harpa-detail-nav"><button class="btn secondary small" data-action="harpa-prev" ${n<=1?'disabled':''}>← Anterior</button>
      <button class="btn secondary small" data-action="harpa-next" ${n>=640?'disabled':''}>Próximo →</button></div></div>`;
  }
  function render(S) { ensure(S); return current ? renderDetail(S) : renderList(S); }
  function action(a, btn, S, save, renderMain, toast) {
    ensure(S);
    if (!a.startsWith('harpa-')) return false;
    const redraw = () => { save(); renderMain(); };
    if (a === 'harpa-open') { current=Number(btn.dataset.n); editing=false; redraw(); window.scrollTo(0,0); return true; }
    if (a === 'harpa-back') { current=0; editing=false; redraw(); return true; }
    if (a === 'harpa-prev' || a === 'harpa-next') { current=Math.min(640,Math.max(1,current+(a==='harpa-next'?1:-1)));editing=false;redraw();window.scrollTo(0,0);return true; }
    if (a === 'harpa-all') { onlyFavorites=false;page=0;redraw();return true; }
    if (a === 'harpa-favorites') { onlyFavorites=true;page=0;redraw();return true; }
    if (a === 'harpa-more') { page++; const e=document.querySelector('#harpa-results');if(e)e.innerHTML=results(S);return true; }
    if (a === 'harpa-fav') { S.harpaFav=S.harpaFav.includes(current)?S.harpaFav.filter(n=>n!==current):S.harpaFav.concat(current);redraw();return true; }
    if (a === 'harpa-editor') { editing=!editing;redraw();return true; }
    if (a === 'harpa-cancel') { editing=false;delete S.harpaDrafts[current];redraw();return true; }
    if (a === 'harpa-save') {
      const text=String(document.querySelector('#harpa-lyric-edit')?.value||'').trim();
      if (text.length>25000) { toast('Limite de 25 mil caracteres por hino.');return true; }
      if (text) S.harpaLyrics[current]=plainText(text); else { delete S.harpaLyrics[current];delete S.harpaCharts[current]; }
      delete S.harpaDrafts[current];editing=false;redraw();toast(text?'Letra salva offline.':'Letra removida.');return true;
    }
    if (a === 'harpa-import') {
      if (window.JardimAndroid?.importHarpaLyrics) window.JardimAndroid.importHarpaLyrics();
      else if (window.JardimAndroid?.importHarpaCharts) window.JardimAndroid.importHarpaCharts();
      else {const p=document.querySelector('#harpa-file-picker');if(p)p.click();else toast('Selecione um arquivo TXT ou JSON no Android.');}
      return true;
    }
    return true;
  }
  function input(e,S,save) {
    if (e.target.id==='harpa-search') {query=e.target.value;page=0;const root=document.querySelector('#harpa-results');if(root)root.innerHTML=results(S);return true;}
    if (e.target.id==='harpa-lyric-edit'&&current) {ensure(S);S.harpaDrafts[current]=e.target.value;save();return true;}
    return false;
  }
  function fromObject(v) {
    if (typeof v === 'string') return v;
    if (!v || typeof v !== 'object') return '';
    if (typeof v.letra==='string') return v.letra;
    if (typeof v.texto==='string') return v.texto;
    if (typeof v.lyrics==='string') return v.lyrics;
    if (typeof v.cifra==='string') return v.cifra; // compatibilidade com backups anteriores
    if (typeof v.chordpro==='string') return v.chordpro;
    if (v.verses && typeof v.verses==='object') {
      let verses = Object.entries(v.verses).sort(([a],[b])=>Number(a)-Number(b)).map(([_,text],i)=>`${i+1}. ${plainText(text)}`).join('\n\n');
      return verses+(v.coro?'\n\nRefrão:\n'+plainText(v.coro):'');
    }
    return '';
  }
  function imported(text,filename,S,save,renderMain,toast) {
    ensure(S);
    try {
      if(text.length>2500000)throw Error('Arquivo grande demais (limite de 2,5 MB).');
      let entries={};
      if(filename.toLowerCase().endsWith('.json')) {
        let data=JSON.parse(text);if(data.hinos&&typeof data.hinos==='object')data=data.hinos;
        if(Array.isArray(data)) for(const item of data){const n=Number(item.numero||item.number||item.id);if(n>=1&&n<=640)entries[n]=fromObject(item);}
        else if(data&&typeof data==='object')for(const [k,v] of Object.entries(data)){const n=Number(k);if(Number.isInteger(n)&&n>=1&&n<=640)entries[n]=fromObject(v);}
      } else {
        const m=filename.match(/(?:hino[-_\s]?)?(\d{1,3})(?=\D|$)/i);
        const n=m?Number(m[1]):current;
        if(n<1||n>640)throw Error('Abra um hino ou nomeie o arquivo como hino-001.txt.');
        entries[n]=text;
      }
      let count=0;
      for (const [n,value] of Object.entries(entries)) {
        if(typeof value==='string'&&value.trim()&&value.length<=25000){S.harpaLyrics[n]=plainText(value);count++;}
      }
      if(!count)throw Error('Não foram encontradas letras compatíveis.');
      save();renderMain();toast(count+' letra(s) importada(s) e salva(s) offline.');return count;
    } catch(e) {toast('Importação de letras: '+e.message);return 0;}
  }
  window.JARDIM_HARPA={render,action,input,imported,plainText,lyricsFor,name,results};
})();
