window.JARDIM_HARPA_LYRICS = {}; // Letras do PDF incluidas apenas na montagem pessoal offline.
