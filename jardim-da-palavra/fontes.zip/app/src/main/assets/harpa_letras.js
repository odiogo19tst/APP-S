window.JARDIM_HARPA_LYRICS = {}; // Acervo pessoal do usuário não é publicado neste repositório.
