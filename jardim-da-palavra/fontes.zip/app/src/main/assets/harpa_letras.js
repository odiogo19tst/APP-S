window.JARDIM_HARPA_LYRICS = {}; // Letras do PDF ficam apenas no APK pessoal.
