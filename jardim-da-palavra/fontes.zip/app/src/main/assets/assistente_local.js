'use strict';
/* Pesquisa e diálogo com fontes do acervo local. NÃO é um modelo generativo e NÃO envia dados a servidores. */
(function(){
 const stop=new Set('o a os as um uma de do da dos das e em no na nos nas que como qual quais onde para por sobre com sem seu sua seus suas ao aos é são foi ser ter mais menos entre antes depois sobre esta este esse essa meu minha nossa nosso vamos hoje estudo bíblia biblia texto explique pode voce você quero saber diga acerca me'.split(' '));
 const synonyms={exegese:['interpretacao','hermeneutica','textual'],hermeneutica:['interpretacao','exegese','leitura'],pregacao:['homiletica','sermao','pregador'],pregar:['homiletica','sermao','pregador'],sermao:['homiletica','pregacao'],salvacao:['soteriologia','graca','fe'],espirito:['pneumatologia','pentecostes','dons'],pentecostalismo:['pneumatologia','pentecostal','espirito'],fim:['escatologia','apocalipse'],cristo:['cristologia','jesus'],pecado:['hamartiologia'],pastor:['aconselhamento','pastoral'],familia:['aconselhamento','etica'],grego:['helenico','linguas'],hebraico:['linguas','torah'],missao:['evangelizacao','missiologia'],lideranca:['administracao','ministerial']};
 const clean=s=>String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLowerCase().replace(/[^a-z0-9 ]/g,' ').replace(/\s+/g,' ').trim();
 const terms=s=>{let v=clean(s).split(' ').filter(x=>x.length>2&&!stop.has(x));return [...new Set([...v,...v.flatMap(x=>synonyms[x]||[])])];};
 function documents(){const C=window.JARDIM_CURSO, D=window.JARDIM_DATA, DOS=window.JARDIM_DOSSIER||{},AP=window.JARDIM_APOSTILAS||{},CADE=window.JARDIM_CADERNOS||{};let res=[];
  for(const s of C.subjects){let d=DOS[s.id]||{},c=CADE[s.id]||{},a=AP[s.id]||[];
   let body=[s.objective,...s.lessons.map(l=>l.content),d.context,d.commentary,d.lexicon,d.parallels,c.context,c.discussion,...a.map(x=>x.lecture)].filter(Boolean).join(' ');
   res.push({kind:'course',id:s.id,title:s.title,reference:[s.reference,c.refs,d.passage].filter(Boolean).join(' · '),body,lead:s.lessons[0]?.content||s.objective,deep:c.discussion||d.commentary||a[0]?.lecture||'',subject:s});
  }
  for(const s of D.studies)res.push({kind:'study',id:s.id,title:s.title,reference:s.reference,body:[s.context,s.interpretation,s.application].join(' '),lead:s.interpretation,deep:s.context});
  return res;
 }
 function score(item,q){const t=terms(q),title=clean(item.title),body=clean(item.body),ref=clean(item.reference);let value=0;for(const k of t){if(title.includes(k))value+=8;if(ref.includes(k))value+=5;if(body.includes(k))value+=2;}
  const phrase=clean(q);if(phrase.length>6&&title.includes(phrase))value+=15;if(t.length>1&&t.every(k=>title.includes(k)||body.includes(k)||ref.includes(k)))value+=5;
  return value;
 }
 function makeAnswer(query){const q=String(query||'').trim().slice(0,380);if(q.length<3)return null;const hits=documents().map(d=>({d,score:score(d,q)})).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).slice(0,3);
  if(!hits.length)return {message:'Não encontrei uma explicação suficientemente relacionada no acervo local. Tente citar uma disciplina, como cristologia, hermenêutica, escatologia ou pregação. Também posso ajudar a localizar a passagem na Bíblia offline.',sources:[]};
  const first=hits[0].d;let lines=[];
  lines.push(`Encontrei este assunto no estudo “${first.title}”.`);
  let primary=first.lead||first.body; lines.push(primary.slice(0,700).trim()+(primary.length>700?'…':''));
  if(first.deep){const deep=first.deep.slice(0,440).trim();if(deep&&clean(primary).slice(0,100)!==clean(deep).slice(0,100))lines.push('Para aprofundar: '+deep+(first.deep.length>440?'…':''));}
  if(hits.length>1)lines.push('Também vale comparar com: '+hits.slice(1).map(x=>x.d.title).join(' e ')+'.');
  lines.push('Estas informações foram recuperadas de aulas do aplicativo; confira os textos bíblicos e as fontes de cada aula antes de ensinar.');
  return {message:lines.join('\n\n'),sources:hits.map(x=>({kind:x.d.kind,id:x.d.id,title:x.d.title,reference:x.d.reference}))};
 }
 function render(S,esc){const hist=(S.localChatHistory||[]).slice(-20);const chats=hist.map((m,i)=>`<div class="chat-message ${m.role==='user'?'chat-user':'chat-bot'}"><div class="chat-author">${m.role==='user'?'Você':'✦ Assistente de estudos'}</div><div class="chat-content">${esc(m.text)}</div>${Array.isArray(m.sources)&&m.sources.length?`<div class="chat-sources"><b>Fontes no acervo</b>${m.sources.map(s=>`<button type="button" data-action="chat-source" data-kind="${esc(s.kind)}" data-id="${esc(s.id)}">↗ ${esc(s.title)} <small>${esc(s.reference||'')}</small></button>`).join('')}</div>`:''}${m.role==='bot'?`<button class="chat-read" data-action="speak" data-text="${esc(m.text)}">◖ Dora: ouvir resposta</button>`:''}</div>`).join('');
 return `<section class="assistant-app" aria-label="Assistente dentro do aplicativo"><div class="section-label">ESTUDOS E PESQUISA · SEM SAIR DO APLICATIVO</div><h1>Assistente de estudos</h1><p class="muted">Pergunte sobre Bíblia, teologia e ministério. As respostas mostram as aulas utilizadas.</p>
 <div class="assistant-banner"><span class="assistant-orb">✦</span><div><strong>Pesquisa inteligente do acervo</strong><small>Funciona offline · Sem login · Sem cobranças</small></div></div>
 <div class="assistant-disclosure"><b>Como funciona:</b> este modo consulta os textos locais e combina trechos relevantes. <b>Não é IA generativa</b> nem substitui uma análise crítica das fontes.</div>
 <div class="chat-history" id="chat-history">${chats||'<div class="chat-empty"><span>✧</span><h2>O que vamos estudar?</h2><p>Escolha um assunto ou escreva sua pergunta. Você pode abrir as aulas citadas sem sair do Jardim.</p></div>'}</div>
 <div class="chat-prompts" aria-label="Perguntas sugeridas">${['Qual a diferença entre exegese e hermenêutica?','O que é pneumatologia?','Como preparar um sermão expositivo?','Explique escatologia cristã'].map(q=>`<button type="button" data-action="chat-prompt" data-question="${esc(q)}">${esc(q)}</button>`).join('')}</div>
 <div class="chat-compose"><label for="chat-input">Sua pergunta</label><div class="chat-input-row"><textarea id="chat-input" rows="2" maxlength="380" placeholder="Escreva sua pergunta sobre a Palavra…"></textarea><button type="button" class="btn" data-action="chat-send" aria-label="Enviar pergunta">➤</button></div></div>
 <div class="actions"><button type="button" data-action="chat-clear" class="btn ghost small">↻ Nova conversa</button><button type="button" data-tab="course" class="btn secondary small">▤ Explorar o curso</button></div></section>`;
 }
 function append(S,question){const answer=makeAnswer(question);if(!answer)return false;S.localChatHistory=Array.isArray(S.localChatHistory)?S.localChatHistory:[];S.localChatHistory.push({role:'user',text:String(question).trim().slice(0,380)}, {role:'bot',text:answer.message,sources:answer.sources});S.localChatHistory=S.localChatHistory.slice(-24);return true;}
 window.JARDIM_ASSIST={render,append,makeAnswer,documents};
})();
