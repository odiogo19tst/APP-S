/* Apostilas autorais ampliadas: textos de estudo, não transcrições de livros. */
window.JARDIM_APOSTILAS = {
  "m01": [
    {
      "heading": "A Escritura de Israel e suas coleções",
      "primary": "Gênesis 1:1–2:3; Lucas 24:44",
      "lecture": "A expressão Antigo Testamento é cristã; na tradição judaica, fala-se de Tanakh, formado por Torá (Instrução), Neviim (Profetas) e Ketuvim (Escritos). O mesmo patrimônio literário aparece em sequência diferente em muitas Bíblias cristãs. Essa diferença de organização importa: o último livro da Bíblia Hebraica pode conduzir o leitor à restauração após o exílio; a ordem cristã frequentemente termina com os profetas. Ao estudar Gênesis, não comece supondo que um único gênero domine toda a coleção. Narrativa de origem, lei, genealogia, cântico e oráculo têm modos distintos de comunicar. O prólogo da criação apresenta um mundo ordenado sob a palavra de Deus, com ritmos de repetição e culminando no repouso. O texto oferece visão teológica da existência, embora interpretações cristãs debatam a relação da sequência de dias com cosmologia e cronologia. O leitor deve identificar o que a própria narrativa afirma antes de importá-la para debates modernos.",
      "comparison": "Compare Gênesis 1:1–2:3 e Salmos 104: as duas passagens celebram o Criador, mas uma se organiza em sequência narrativa e a outra em poesia. Lucas 24:44 usa Lei, Profetas e Salmos para se referir às Escrituras de Israel. Não confunda arranjo canônico, data de composição e data dos acontecimentos narrados.",
      "exercise": "Monte uma tabela com as três divisões do Tanakh, seus tipos de livros e um exemplo de gênero em cada divisão. Em seguida anote duas perguntas históricas que Gênesis 1 não pretende responder diretamente.",
      "readings": "John Goldingay, Old Testament Theology; Tremper Longman III, How to Read Genesis; introduções acadêmicas à Bíblia Hebraica."
    },
    {
      "heading": "Aliança, libertação e formação de Israel",
      "primary": "Gênesis 12:1–3; Êxodo 19:4–6; Deuteronômio 6:4–9",
      "lecture": "A história patriarcal introduz promessa de descendência, terra e bênção às famílias da terra. O Êxodo apresenta a libertação como antecedente da obrigação da aliança: a obediência não é descrita simplesmente como preço da libertação. Em Êxodo 19, a comunidade é chamada a uma vocação coletiva e sacerdotal. A Torá contém leis civis, éticas, rituais e narrativas; é necessário contextualizar suas funções em Israel antes de perguntar sobre aplicação cristã. Deuteronômio relê a jornada e destaca memória, escuta e transmissão às novas gerações. Uma leitura responsável registra diferenças entre alianças bíblicas e o modo como o Novo Testamento interpreta a promessa e a lei. O termo hebraico berit, aliança, nomeia uma relação com deveres e promessas, mas não resume sozinho todo o percurso. A teologia cristã da nova aliança demanda confrontar Jeremias 31 e Hebreus 8 sem apagar a história de Israel.",
      "comparison": "Observe três relações: promessa a Abrão, libertação do Egito e instrução no Sinai. Compare Gálatas 3 e Romanos 9–11, reconhecendo que cristãos divergem sobre continuidade, cumprimento e relação com o povo judeu.",
      "exercise": "Leia Gênesis 12, Êxodo 19 e Deuteronômio 6. Registre quem fala, quem recebe, qual a promessa, qual a responsabilidade e como cada texto se encaixa no desenvolvimento da história.",
      "readings": "Gordon J. Wenham, Genesis 1–15; Christopher J. H. Wright, Old Testament Ethics for the People of God."
    },
    {
      "heading": "Profetas, sabedoria e leitura após o exílio",
      "primary": "Isaías 1:10–20; Salmos 1; Jó 1–2; Esdras 7",
      "lecture": "A pregação profética não é apenas um código de previsões distantes. Os profetas falam a comunidades concretas sobre idolatria, justiça, culto e esperança. Isaías 1 denuncia a incoerência entre solenidades religiosas e violência contra vulneráveis. A literatura sapiencial, por sua vez, investiga o viver diante de Deus. Provérbios apresenta padrões de sabedoria, ao passo que Jó contesta a ideia de que sofrimento prove culpa. Os Salmos fornecem linguagem de louvor, memória e lamento; salmos de dor não devem ser censurados quando uma pessoa sofre. A queda de Jerusalém e o exílio ajudam a explicar a releitura de promessas e a centralidade de memória e reconstrução. No período pós-exílico, Esdras e Neemias descrevem formas de reorganização comunitária; suas narrativas exigem atenção ao contexto social, inclusive questões sobre identidade e exclusão. Em todos esses grupos literários, gênero e destinatários fazem diferença.",
      "comparison": "Compare Isaías 1 com Amós 5 e Tiago 1:27. Depois confronte Salmos 1 e o início de Jó: a linguagem do justo próspero não funciona como garantia universal de riqueza ou ausência de sofrimento.",
      "exercise": "Elabore uma leitura de um profeta com cinco colunas: situação histórica, acusação, promessa, linguagem simbólica e implicações éticas possíveis hoje.",
      "readings": "Abraham J. Heschel, The Prophets; John Goldingay, Psalms; Tremper Longman III, How to Read Proverbs."
    }
  ],
  "m02": [
    {
      "heading": "O mundo do Novo Testamento",
      "primary": "Lucas 1:1–4; Marcos 1:14–15",
      "lecture": "O Novo Testamento surge em ambiente judaico atravessado pela dominação romana, pela cultura grega e por debates internos do judaísmo do Segundo Templo. Palestina, Galileia, Judeia e a diáspora não formavam um universo homogêneo. Sinagogas, Templo, grupos sacerdotais e movimentos de resistência aparecem em contextos distintos. O prólogo de Lucas apresenta investigação, tradições anteriores e organização narrativa; a linguagem de testemunho precisa ser estudada segundo práticas antigas de memória e escrita, sem projetar automaticamente os critérios de historiografia contemporânea. Os evangelhos são narrativas teológicas sobre Jesus, não simples transcrições de acontecimentos em ordem idêntica. Marcos inicia com a proclamação do Reino; João inicia com um prólogo teológico. Cada evangelista seleciona episódios e destaca aspectos de identidade, missão e resposta de fé.",
      "comparison": "Compare os começos de Marcos 1, Lucas 1, Mateus 1 e João 1: que pergunta cada autor parece priorizar? Anote o que é dado pelo texto e o que é hipótese sobre datas e fontes.",
      "exercise": "Faça um mapa de personagens e instituições do século I: governantes, Templo, sinagoga, grupos judeus, apóstolos e comunidades gentílicas. Cite uma fonte histórica de apoio.",
      "readings": "Joel B. Green, The Gospel of Luke; Craig S. Keener, The IVP Bible Background Commentary: New Testament."
    },
    {
      "heading": "Evangelhos, Atos e formação de comunidades",
      "primary": "Lucas 24:44–49; Atos 2:42–47; Atos 15",
      "lecture": "Lucas e Atos são dois volumes de uma obra que conecta a missão de Jesus ao testemunho das comunidades iniciais. Atos 2 descreve práticas de ensino, oração, mesa e ajuda mútua; não é uma constituição eclesiástica completa, nem idealiza necessariamente todas as comunidades. Os conflitos de Atos 6 e 15 mostram questões organizacionais e teológicas reais. Os evangelhos apresentam unidade na centralidade de Jesus e diferenças de estilo, ênfase e cronologia. A comparação sinóptica investiga paralelos entre Mateus, Marcos e Lucas; propostas como prioridade de Marcos e fonte Q são hipóteses acadêmicas, com diferentes graus de aceitação, não verdades declaradas no texto. A expansão do evangelho entre gentios suscita perguntas sobre circuncisão, refeições e pertencimento, tratadas também nas cartas apostólicas.",
      "comparison": "Compare a cena do concílio em Atos 15 com Gálatas 2. Analise destinatário, propósito e seleção de detalhes antes de concluir que há contradição ou equivalência absoluta.",
      "exercise": "Escolha uma parábola presente em dois evangelhos e registre similaridades, diferenças e o efeito literário de cada contexto narrativo.",
      "readings": "F. F. Bruce, The Book of the Acts; Richard Bauckham, Jesus and the Eyewitnesses."
    },
    {
      "heading": "Cartas, apocalipse e critérios de interpretação",
      "primary": "Romanos 1:16–17; Filemom 8–21; Apocalipse 1:1–3",
      "lecture": "As cartas respondem a situações pastorais, éticas e doutrinárias. Romanos desenvolve argumento abrangente sobre justiça de Deus, fé, Israel e vida cristã; Filemom trabalha um conflito social concreto envolvendo Onésimo e relações de poder. Para interpretar epístolas, identifique remetente, destinatários, ocasião, estrutura do argumento e os limites de reconstruir a situação original. O Apocalipse combina carta a igrejas, profecia e visão apocalíptica. Animais e números pertencem a um mundo simbólico que se relaciona ao Antigo Testamento e às circunstâncias de comunidades sob o poder imperial. Leituras futuristas, preteristas, historicistas e idealistas divergem na distribuição temporal das visões. Nenhuma deve ignorar a mensagem imediata às sete igrejas nem substituir o texto por listas de manchetes atuais.",
      "comparison": "Compare Daniel 7 e Apocalipse 13; observe como imagens antigas são reempregadas. Contraste uma carta breve como Filemom com Romanos para não aplicar uma regra interpretativa idêntica a todos os gêneros.",
      "exercise": "Construa um esquema de Romanos 1–8 com tese, argumento e conclusão. Para Apocalipse 1–3, registre o que as comunidades concretas ouvem de advertência e consolo.",
      "readings": "Douglas J. Moo, The Epistle to the Romans; G. K. Beale, The Book of Revelation; Gordon D. Fee e Douglas Stuart, Entendes o que Lês?"
    }
  ],
  "m10": [
    {
      "heading": "Observação: o que o texto diz antes do que eu penso",
      "primary": "Neemias 8:8; Filipenses 4:10–13",
      "lecture": "A hermenêutica começa com observação disciplinada. Em Filipenses 4, Paulo fala de contentamento em diferentes condições materiais, e a conhecida afirmação sobre poder enfrentar tudo deve ser lida dentro desse raciocínio, não como promessa irrestrita de sucesso profissional, financeiro ou esportivo. Leia o parágrafo anterior e o seguinte; sublinhe sujeitos, verbos, conectivos e palavras recorrentes. Identifique quem fala, a quem, por qual motivo e com qual propósito. Esse trabalho impede que uma frase isolada receba um significado escolhido antes da leitura. Pergunte também qual é o gênero: a intenção de um provérbio não é igual à de uma narrativa, e a poesia trabalha com metáforas. O princípio de Escritura interpretar Escritura não elimina a necessidade de conhecer contexto e história. Uma passagem clara pode ajudar a iluminar outra, mas relações superficiais entre palavras não bastam para provar uma doutrina.",
      "comparison": "Compare Filipenses 4:13 com 4:11–12 e 4:18–19. Observe o que muda quando a passagem é lida como testemunho de contentamento e dependência de Cristo, em vez de fórmula para atingir qualquer objetivo.",
      "exercise": "Escreva uma interpretação de Filipenses 4:13 em apenas três frases e indique um limite de aplicação. Depois revise sua interpretação a partir do capítulo inteiro.",
      "readings": "Gordon D. Fee, Paul’s Letter to the Philippians; Grant Osborne, The Hermeneutical Spiral."
    },
    {
      "heading": "Interpretação: história, gênero e argumento",
      "primary": "Lucas 10:25–37; Salmos 23",
      "lecture": "Lucas 10 apresenta um diálogo sobre amor a Deus e ao próximo seguido da parábola do samaritano. O texto cria surpresa porque o personagem que demonstra compaixão vem de grupo social cuja relação com os ouvintes era marcada por tensões. A pergunta final desloca a atenção de “quem merece ser meu próximo?” para “quem agiu como próximo?”. Esse movimento narrativo é essencial; identificar cada objeto da parábola como símbolo oculto pode encobrir seu argumento. O Salmo 23, ao contrário, é poesia de confiança: pastor, pastos e vale são imagens estruturadoras de cuidado. O leitor não deve transformar “nada me faltará” em garantia de que pessoas fiéis jamais passem privações. A leitura deve acomodar metáfora, sofrimento e esperança conforme o conjunto das Escrituras.",
      "comparison": "Compare Lucas 10:25–37 com Tiago 2:14–17 e Salmos 23 com Salmos 22. As diferenças de gênero e de voz impedem que se use um texto para apagar o testemunho do outro.",
      "exercise": "Escolha uma parábola e um salmo. Para cada texto, redija gênero, contexto, imagem central, argumento e uma aplicação que não ultrapasse a intenção observável.",
      "readings": "Klyne Snodgrass, Stories with Intent; John Goldingay, Psalms; Craig L. Blomberg, Interpreting the Parables."
    },
    {
      "heading": "Aplicação: ponte entre mundo antigo e vida atual",
      "primary": "Tiago 2:1–9; 1 Coríntios 8",
      "lecture": "Aplicar não é repetir um costume antigo mecanicamente nem substituir uma passagem por opiniões atuais. Tiago denuncia favoritismo em favor de pessoas ricas dentro da reunião; sua crítica fornece critérios para examinar acolhimento, dignidade e distribuição de atenção em comunidades hoje. Em 1 Coríntios 8, Paulo discute alimentação relacionada a ídolos, conhecimento e cuidado com a consciência do irmão. É inadequado retirar uma frase do capítulo e usá-la como regra universal sobre qualquer alimento. Primeiro extraia o princípio sustentado pelo argumento; depois identifique semelhanças e diferenças entre as situações. Em debates entre igrejas, distinga o que o texto ordena explicitamente, o que pode ser inferido e o que decorre de prudência local. A interpretação cristã acontece em comunidade e deve admitir correção, especialmente quando leitura apressada produz culpa indevida ou discriminação.",
      "comparison": "Compare Atos 15 com Romanos 14 e 1 Coríntios 8–10. Observe tanto continuidade de princípios quanto diversidade de problemas pastorais.",
      "exercise": "Escreva uma aplicação de Tiago 2 para o acolhimento de visitantes com critérios verificáveis. Liste um risco de anacronismo e uma salvaguarda.",
      "readings": "Gordon D. Fee e Douglas Stuart, Entendes o que Lês?; Kevin Vanhoozer, Is There a Meaning in This Text?"
    }
  ],
  "m11": [
    {
      "heading": "Do texto à tradução: método de exegese",
      "primary": "Romanos 3:21–26",
      "lecture": "Exegese busca explicar o sentido de uma passagem segundo sua linguagem, gênero, contexto e situação. Em Romanos 3, Paulo conecta justiça divina, fé, pecado e redenção após argumentar sobre a condição de judeus e gentios. A palavra grega dikaiosynē pode ser traduzida por “justiça” ou “retidão” segundo o contexto; nenhum vocabulário isolado decide todo o debate sobre justificação. Observe a progressão: exposição do problema, anúncio de iniciativa divina, apresentação de Cristo e implicações para vanglória humana. Analise quais palavras funcionam como conectivos. Diferencie tradução formal, tradução comunicativa e paráfrase; cada opção explicita alguns aspectos e pode obscurecer outros. A ACF é a preferência do aplicativo para leitura, mas a tradução de estudo deve ser identificada como material explicativo independente. Nunca apresente uma paráfrase como citação literal do texto bíblico.",
      "comparison": "Compare Romanos 3:21–26, Romanos 4 e Tiago 2. Pergunte a que perguntas Paulo e Tiago respondem antes de concluir que um autor simplesmente nega o outro.",
      "exercise": "Produza observações em quatro colunas: forma verbal, ligação argumentativa, opção de tradução e cautela interpretativa. Consulte ao menos duas traduções autorizadas.",
      "readings": "Gordon D. Fee, New Testament Exegesis; Douglas J. Moo, The Epistle to the Romans."
    },
    {
      "heading": "Manuscritos e crítica textual sem alarmismo",
      "primary": "Marcos 16:9–20; João 7:53–8:11",
      "lecture": "Crítica textual compara testemunhos manuscritos para investigar a forma mais antiga recuperável de um texto. Variações surgem por cópia, correção, harmonização, ortografia e outros processos. Os finais de Marcos e o episódio da mulher acusada em João são dois locais em que edições críticas frequentemente sinalizam questões de transmissão. Reconhecer variantes não significa que toda Escritura perdeu o sentido, mas exige honestidade sobre limites das evidências. Também não se deve afirmar que “o manuscrito mais antigo sempre vence”: genealogia de testemunhos, distribuição, coerência e possibilidades de alteração são consideradas. Edições modernas do texto grego incluem aparato crítico com variantes; leitores iniciantes podem começar por notas de traduções confiáveis. É inadequado construir uma doutrina central exclusivamente sobre um trecho com transmissão discutida sem examinar outras passagens.",
      "comparison": "Compare notas editoriais e apresentação da perícope nas traduções acessíveis. Distinguir texto transmitido, evidência manuscrita e valor histórico da tradição evita conclusões sensacionalistas.",
      "exercise": "Crie ficha com passagem, variação principal, testemunhos descritos em bibliografia, impacto da diferença e grau de certeza. Não invente nomes de manuscritos sem verificar.",
      "readings": "Bruce M. Metzger e Bart D. Ehrman, The Text of the New Testament; Kurt e Barbara Aland, The Text of the New Testament."
    },
    {
      "heading": "Da análise ao comentário responsável",
      "primary": "Efésios 2:1–10",
      "lecture": "Um comentário útil combina análise da frase, organização do argumento, contexto da carta, conexões literárias e limites da aplicação. Efésios 2:1–10 contrasta condição anterior e ação divina, destacando graça, fé, salvação e boas obras. O movimento entre os versículos 8–10 é importante: boas obras não aparecem como causa da salvação, mas como dimensão da vida renovada. Há diferenças teológicas sobre a relação precisa entre graça, fé e resposta humana; estudá-las com justiça requer mais do que selecionar um verbo grego. Exegese distingue sentidos possíveis, argumentos de intérpretes e conclusões defendidas. Comentários acadêmicos são recursos para diálogo crítico, não substitutos da leitura direta. Um estudo pastoral precisa informar sem fingir que não existem debates.",
      "comparison": "Compare Efésios 2 com Tiago 2 e Tito 3:4–8. Identifique as perguntas diferentes de cada texto e procure formulação que respeite todas as passagens.",
      "exercise": "Escreva 400 palavras de comentário em cinco partes: observação, interpretação, debate, conclusão e aplicação. Registre referências bibliográficas que de fato consultou.",
      "readings": "Harold W. Hoehner, Ephesians; Frank Thielman, Ephesians; Gordon D. Fee, New Testament Exegesis."
    }
  ],
  "m12": [
    {
      "heading": "Alfabeto, artigo e função das palavras",
      "primary": "João 1:1–3",
      "lecture": "O grego koiné era língua de comunicação ampla no Mediterrâneo oriental. Comece reconhecendo as vinte e quatro letras do alfabeto, suas formas e a diferença entre transliteração e tradução. Em João 1:1, logos designa a Palavra no argumento do prólogo, mas o vocábulo grego pode ter outros significados em contextos diversos. Não basta buscar uma lista de sentidos no dicionário e escolher o mais conveniente. O prólogo apresenta relações entre Palavra, Deus, criação e vida; traduzir exige atenção à ordem, aos artigos e à função de cada expressão. No grego, terminações e casos podem indicar relações sintáticas que o português expressa de outros modos. O estudante iniciante precisa aprender a localizar forma lexical e flexão antes de consultar instrumentos técnicos. Sites interlineares ajudam, mas nenhuma tabela automática substitui leitura de frases completas.",
      "comparison": "Compare João 1:1–3 e 1:14. Discuta por que o sentido de logos no prólogo deve ser determinado pela unidade literária, não apenas por usos filosóficos gregos fora do texto.",
      "exercise": "Escreva o alfabeto grego; localize cinco ocorrências de logos em contextos diferentes usando concordância confiável; anote os limites de cada tradução.",
      "readings": "William D. Mounce, Basics of Biblical Greek; Daniel B. Wallace, Greek Grammar Beyond the Basics."
    },
    {
      "heading": "Substantivos, casos e verbos em contexto",
      "primary": "Filipenses 2:5–11",
      "lecture": "Em grego koiné, substantivos variam com número, gênero e caso; verbos variam em pessoa, número, tempo, modo e voz, com efeitos que dependem do contexto. Em Filipenses 2, palavras como morphē, frequentemente vertida como “forma”, participam de discussão cristológica complexa. Não deduza automaticamente que morphē equivale a “aparência externa” ou a uma definição filosófica específica. A unidade trabalha movimento de humilhação, obediência e exaltação, com possível caráter hínico, embora seu enquadramento literário seja debatido. Analisar formas é etapa da leitura, não resultado final. O intérprete precisa observar que a construção da frase e a sequência do argumento restringem sentidos possíveis. Tradutores podem reorganizar orações para oferecer português natural, sem que isso necessariamente altere a teologia.",
      "comparison": "Leia Filipenses 2:1–11 e confronte traduções. Assinale o sujeito de cada verbo, a ligação com a exortação ética e a diferença entre análise lexical e conclusão cristológica.",
      "exercise": "Com auxílio de léxico e gramática, identifique duas formas nominais e duas verbais; registre lema, forma e papel na oração. Se houver dúvida, sinalize em vez de inventar.",
      "readings": "Daniel B. Wallace, Greek Grammar Beyond the Basics; Gordon D. Fee, Paul’s Letter to the Philippians."
    },
    {
      "heading": "Exercício de tradução responsável",
      "primary": "Efésios 2:8–10; 1 Coríntios 12:4–11",
      "lecture": "Tradução envolve escolhas de sintaxe, campo semântico, estrutura argumentativa e estilo. Em Efésios 2, charis, “graça”, está ligada à ação divina e à resposta de fé. A tradução de um termo não resolve sozinha a controvérsia sobre causalidade entre dom e resposta humana. Em 1 Coríntios 12, charismata designa dons ou capacitações; a relação com o corpo mostra que a finalidade comunitária importa mais que catalogar supostos poderes isolados. Ao preparar uma tradução de estudo, identifique claramente que não se trata de edição bíblica oficial. Escolha termos em português e justifique pelo parágrafo. Resista a criar significados especiais apoiados em etimologias populares; a história de origem da palavra não determina automaticamente seu uso no século I.",
      "comparison": "Compare Efésios 2:8–10 com 1 Coríntios 12:4–11 e Tiago 4:6, verificando usos próximos e diferentes de palavras relacionadas à graça.",
      "exercise": "Prepare uma tradução explicativa de uma oração curta com três alternativas lexicais; escreva por que escolheu cada termo e apresente a fonte lexical consultada.",
      "readings": "Frederick W. Danker, A Greek-English Lexicon of the New Testament and Other Early Christian Literature; Mounce, Basics of Biblical Greek."
    }
  ],
  "m13": [
    {
      "heading": "Alfabeto hebraico e estrutura narrativa",
      "primary": "Gênesis 1:1–5",
      "lecture": "O hebraico bíblico é escrito da direita para a esquerda e usa consoantes, com sinais vocálicos preservados em tradições manuscritas posteriores. Aprender a distinguir letras e formas finais é mais seguro do que associar a cada letra uma doutrina secreta. Em Gênesis 1:1, bereshit frequentemente é traduzido “no princípio”, e bara se refere à ação de criar; discutem-se estruturas sintáticas do início do texto. O intérprete não deve tratar esses termos como prova isolada de cronologia exata ou de todas as explicações cosmológicas possíveis. Na narrativa, a repetição de “Deus disse”, a separação, a nomeação e a avaliação de bondade constroem o sentido. É essencial distinguir o verbo estudado, sua forma flexionada e a função no verso. A leitura exegética começa com observações simples e verificáveis.",
      "comparison": "Compare Gênesis 1:1–5 e Salmos 33:6–9. Pergunte que aspectos da ação criadora aparecem em narrativa e em poesia e como a linguagem de cada gênero funciona.",
      "exercise": "Copie o alfabeto hebraico com auxílio de fonte confiável e registre cinco vocábulos de Gênesis 1 com transliteração e significado contextual.",
      "readings": "Gary D. Pratico e Miles V. Van Pelt, Basics of Biblical Hebrew; Gordon J. Wenham, Genesis 1–15."
    },
    {
      "heading": "Paralelismo, poesia e metáfora",
      "primary": "Salmos 23:1–6; Salmos 19:1–6",
      "lecture": "Poesia hebraica frequentemente constrói significado pela relação entre versos, imagens e paralelismos. Salmos 23 retrata cuidado pastoral, direção e hospitalidade. Uma leitura literalista de pastagens e mesa ignoraria as imagens que sustentam o poema. A palavra hebraica raah pode se relacionar ao pastoreio, mas um comentário sério observa também o sujeito, o movimento do salmo e a mudança de tom entre terceira e segunda pessoa. Salmos 19 liga criação e louvor; a linguagem de céus que proclamam não precisa ser reduzida a comunicação verbal humana. A tradução poética pode preservar imagens mesmo quando sacrifica alguma correspondência formal. Estude o equilíbrio entre termos e efeitos literários, sem criar alegorias para cada pormenor.",
      "comparison": "Compare o cuidado de Salmos 23 com Ezequiel 34 e João 10. A imagem do pastor é reaproveitada em situações diferentes e requer respeito a seus contextos.",
      "exercise": "Marque imagens de movimento, perigo, abundância e companhia em Salmos 23. Reescreva uma estrofe em linguagem explicativa identificando-a como paráfrase, não como ACF.",
      "readings": "Robert Alter, The Art of Biblical Poetry; John Goldingay, Psalms."
    },
    {
      "heading": "Aliança, profecia e cuidado com etimologias",
      "primary": "Miqueias 6:6–8; Deuteronômio 10:12–19",
      "lecture": "Em Miqueias 6, o vocabulário de justiça e misericórdia aparece no interior de uma disputa que contrapõe grandes ofertas ao modo de viver do povo. Mishpat pode abranger julgamento, justiça e ordenamento conforme o uso; hesed pode indicar lealdade, fidelidade amorosa e misericórdia. Nenhuma dessas traduções equivale a definição completa em toda a Bíblia. O compromisso ético nasce da aliança e de preocupações sociais reais. Deuteronômio 10 associa culto, temor a Deus e cuidado com estrangeiro, órfão e viúva, oferecendo comparação literária. Evite o erro de escolher sempre a tradução mais emotiva de um vocábulo ou usar a raiz como substituto do contexto. A investigação deve reunir léxico, frase, unidade e situação histórica.",
      "comparison": "Confronte Miqueias 6 com Amós 5 e Isaías 1. Identifique o alvo da crítica profética e por que ela não significa abolir todo culto ou toda oferta religiosa.",
      "exercise": "Escreva um pequeno comentário de Miqueias 6:8 com duas opções para hesed, explicando o que cada opção enfatiza e o que não pode afirmar.",
      "readings": "Ludwig Koehler e Walter Baumgartner, Hebrew and Aramaic Lexicon of the Old Testament; Abraham J. Heschel, The Prophets."
    }
  ],
  "m17": [
    {
      "heading": "Identidade de Jesus: evangelhos e prólogo",
      "primary": "João 1:1–18; Marcos 8:27–30",
      "lecture": "Cristologia investiga quem é Jesus e o significado de sua vida, morte e ressurreição. João 1 apresenta a Palavra relacionada a Deus desde o princípio e afirma a encarnação; Marcos registra a pergunta decisiva sobre a identidade de Jesus dentro de narrativa marcada por expectativa messiânica e caminho de sofrimento. A leitura não deve misturar os evangelhos como se fossem uma única biografia sem estilo próprio. Em João, a linguagem de luz, vida, testemunho e graça constrói um argumento. Em Marcos, a confissão de Pedro precisa ser lida junto às correções posteriores sobre sofrimento e discipulado. Debates cristológicos históricos envolveram interpretação dessas passagens e o esforço de preservar tanto humanidade quanto divindade de Cristo. O leitor pode afirmar a confissão de fé e, ao mesmo tempo, reconhecer diferenças de ênfase teológica e desafios de tradução.",
      "comparison": "Compare João 1:1–18, Marcos 8:27–33 e Hebreus 1:1–4. Observe como identidade, revelação e missão se conectam e quais inferências exigem discussão adicional.",
      "exercise": "Elabore um quadro com títulos atribuídos a Jesus, narrador que os utiliza, contexto e significado no argumento de cada texto.",
      "readings": "Richard Bauckham, Jesus and the God of Israel; D. A. Carson, The Gospel According to John."
    },
    {
      "heading": "Encarnação e linguagem dos credos",
      "primary": "Filipenses 2:5–11; Colossenses 1:15–20",
      "lecture": "Filipenses 2 liga a narrativa de Cristo à ética comunitária: a humildade recomendada aos leitores é iluminada pelo movimento de entrega e exaltação. Termos gregos como morphē e kenosis participam de debates teológicos extensos, porém não autorizam a conclusão de que Jesus simplesmente deixou de ser divino. O texto não pretende resolver sozinho todos os problemas metafísicos formulados séculos depois. Credos como o niceno-constantinopolitano e definições posteriores procuraram articular afirmações bíblicas sobre a identidade de Cristo diante de interpretações conflitantes. A linguagem de “natureza” e “pessoa” deve ser estudada no contexto histórico dos concílios, sem atribuir anacronicamente cada termo técnico aos apóstolos. Colossenses 1 apresenta Cristo em relação a criação e reconciliação; suas imagens devem ser analisadas como um todo.",
      "comparison": "Compare Filipenses 2 e Colossenses 1 com João 1 e com Lucas 2. Discuta por que a humanidade concreta de Jesus não pode desaparecer de uma cristologia que afirma sua divindade.",
      "exercise": "Redija três parágrafos: o que Filipenses 2 afirma, o que os credos posteriores procuram esclarecer e que perguntas permanecem na pesquisa histórica.",
      "readings": "J. N. D. Kelly, Early Christian Doctrines; Alister E. McGrath, Christian Theology: An Introduction."
    },
    {
      "heading": "Cruz, ressurreição e interpretações da salvação",
      "primary": "1 Coríntios 15:1–28; Romanos 5:6–11",
      "lecture": "Paulo anuncia morte e ressurreição de Cristo como núcleo do evangelho e relaciona a ressurreição à esperança da comunidade. Em Romanos 5, reconciliação, amor e justiça divina entram no argumento sobre a condição humana. Ao longo da história, tradições cristãs desenvolveram diferentes modelos para explicar a expiação: vitória sobre poderes, satisfação, substituição, reconciliação e transformação moral, entre outros. Nenhum esquema isolado esgota todas as metáforas bíblicas. É preciso distinguir o que cada texto efetivamente afirma da organização sistemática produzida por teólogos posteriores. A ressurreição não é tratada por Paulo apenas como consolo subjetivo, mas como evento decisivo na argumentação escatológica. A pesquisa histórica sobre testemunho e a confissão de fé respondem a perguntas relacionadas, porém não idênticas.",
      "comparison": "Compare 1 Coríntios 15 com Lucas 24 e Romanos 6. Identifique como o acontecimento anunciado gera implicações sobre ética, esperança e vida em comunidade.",
      "exercise": "Construa uma tabela de três imagens bíblicas da salvação, suas passagens e seus limites; indique uma pergunta que não pode ser resolvida por mera contagem de versículos.",
      "readings": "Gordon D. Fee, The First Epistle to the Corinthians; N. T. Wright, The Resurrection of the Son of God."
    }
  ],
  "m18": [
    {
      "heading": "Promessa e presença do Espírito",
      "primary": "João 14:16–27; João 16:5–15",
      "lecture": "Nos discursos de despedida, João apresenta a promessa do Paráclito em conexão com consolação, testemunho e lembrança do ensino de Jesus. O grego paraklētos é traduzido de modos diferentes, como Consolador, Auxiliador ou Advogado, conforme as escolhas da tradução. A tradução precisa respeitar o conjunto do discurso, não apenas a etimologia. O Espírito não aparece como mecanismo impessoal que pode ser ativado por fórmula, mas como presença de Deus ligada à vida da comunidade. Tradições cristãs divergem em terminologia sobre a pessoa e a obra do Espírito; a leitura inicial deve localizar os verbos do texto antes de trazer debates sistemáticos. O ensino de João deve ser lido junto à narrativa dos evangelhos e às cartas, sem obrigar cada passagem a abordar exatamente as mesmas funções.",
      "comparison": "Compare João 14–16 com Atos 1:8 e Romanos 8:9–17. Observe relação com Jesus, testemunho, oração e identidade dos filhos de Deus.",
      "exercise": "Escreva um comentário de João 14:26 distinguindo o público imediato do discurso e a aplicação à igreja atual.",
      "readings": "Gordon D. Fee, God’s Empowering Presence; Craig S. Keener, The Gospel of John."
    },
    {
      "heading": "Pentecostes, línguas e missão",
      "primary": "Atos 2:1–21; Atos 10:44–48; Atos 19:1–7",
      "lecture": "Atos 2 descreve a vinda do Espírito no Pentecostes com sinais públicos e proclamação das obras de Deus. O texto registra falas em línguas e a compreensão por ouvintes de diversos lugares, relacionando o acontecimento à profecia de Joel. Atos 10 apresenta o Espírito sobre gentios, com função narrativa ligada à inclusão de novos povos. Há interpretações diferentes sobre se os relatos constituem padrão universal de experiência ou sinais específicos da expansão missionária. Uma perspectiva pentecostal costuma enfatizar a continuidade dos dons e experiências de capacitação; outras tradições entendem os eventos de modo diferente. Estudar os relatos em sequência evita transformar apenas um episódio em manual completo. A finalidade do Espírito em Atos inclui testemunho, comunhão, coragem e superação de barreiras sociais.",
      "comparison": "Compare Atos 2, 8, 10 e 19, identificando presença/ausência de imposição de mãos, falas em línguas, batismo e mensagem missionária. Evite afirmar uniformidade que os próprios relatos não apresentam.",
      "exercise": "Produza um quadro com evento, destinatários, sinais e função no enredo. Depois descreva duas interpretações cristãs com respeito.",
      "readings": "Craig S. Keener, Acts: An Exegetical Commentary; Roger Stronstad, The Charismatic Theology of St. Luke."
    },
    {
      "heading": "Dons e fruto: edificação com discernimento",
      "primary": "1 Coríntios 12–14; Gálatas 5:22–26",
      "lecture": "Paulo aborda dons espirituais em comunidade que convivia com disputas e comparações de status. Os capítulos 12–14 devem ser lidos juntos: diversidade de serviços, amor e ordem na reunião. Um dom não substitui caráter, e o fruto do Espírito em Gálatas 5 descreve orientações éticas relacionais. As listas de dons em Romanos 12, 1 Coríntios 12 e Efésios 4 não são idênticas; sua variação merece análise antes de elaborar catálogos rígidos. No debate entre continuacionistas e cessacionistas, cada posição apresenta argumentos bíblicos e históricos; a aplicação pastoral responsável evita constrangimento e exposição de pessoas vulneráveis. O princípio explícito de 1 Coríntios 14 é que a participação promova edificação e inteligibilidade. O cuidado com dignidade e livre consentimento deve orientar qualquer reunião.",
      "comparison": "Compare 1 Coríntios 12:7, 13:1–13 e 14:26–33. Depois confronte com Gálatas 5:22–23 e Romanos 12:3–8.",
      "exercise": "Desenhe uma reunião de oração com espaço para dons, leitura, silêncio, acolhimento e limites de segurança. Justifique cada decisão com o texto.",
      "readings": "Gordon D. Fee, God’s Empowering Presence; Anthony Thiselton, The First Epistle to the Corinthians."
    }
  ],
  "m21": [
    {
      "heading": "Salvação e iniciativa da graça",
      "primary": "Efésios 2:1–10; Tito 3:4–8",
      "lecture": "Efésios 2 apresenta salvação na linguagem de morte e vida, graça, fé e criação para boas obras. A sequência argumentativa distingue origem e fruto da salvação: a vida transformada é resposta ao dom de Deus, não simples instrumento de compra de favor divino. A expressão “pela graça, mediante a fé” tem sido importante para várias tradições cristãs, que concordam na centralidade da graça e divergem sobre alguns aspectos da resposta humana, perseverança e sacramentos. Em Tito 3, bondade e misericórdia aparecem conectadas à renovação e à vida ética. As traduções precisam preservar essas conexões sem negar diferenças históricas entre tradições. A discussão sistemática deve dialogar com narrativa, cartas e ensino de Jesus, e não isolar Efésios 2 para excluir o restante do cânon.",
      "comparison": "Compare Efésios 2:8–10, Tiago 2:14–26 e Tito 3:4–8. Diferencie “causa”, “meio”, “sinal” e “consequência” na explicação das obras.",
      "exercise": "Redija uma síntese sobre graça e boas obras com três referências cruzadas e uma pergunta aberta para discussão em grupo.",
      "readings": "John Stott, The Message of Ephesians; Frank Thielman, Ephesians."
    },
    {
      "heading": "Justificação, santificação e adoção",
      "primary": "Romanos 5:1–11; Romanos 8:1–17",
      "lecture": "Em Romanos, a linguagem de justificação participa de um argumento sobre justiça de Deus, pecado, fé e nova vida. Santificação aponta para uma existência orientada pelo Espírito, enquanto a adoção em Romanos 8 descreve novo vínculo de pertencimento. São imagens conectadas, não palavras perfeitamente intercambiáveis. Debates sobre imputação, participação em Cristo e relação entre fé e obras precisam ser localizados em autores e tradições. Ler apenas um versículo pode produzir falsas oposições. Paulo mantém a tensão entre anúncio da graça e exigências éticas; o Espírito não elimina sofrimento, mas sustenta esperança. A pesquisa deve reconhecer a argumentação da carta, a relação de judeus e gentios e a continuidade do tema em Romanos 9–11.",
      "comparison": "Compare Romanos 5–8 com Gálatas 3–5. Registre onde Paulo usa linguagem jurídica, familiar e de transformação, destacando a função de cada imagem.",
      "exercise": "Crie um glossário de cinco termos soteriológicos com uma passagem de apoio e uma cautela sobre redução do significado.",
      "readings": "Douglas J. Moo, The Epistle to the Romans; Thomas R. Schreiner, Romans."
    },
    {
      "heading": "Perseverança, segurança e responsabilidade",
      "primary": "João 10:27–30; Hebreus 6:4–12; Filipenses 2:12–13",
      "lecture": "Cristãos compartilham a esperança da fidelidade de Deus, mas divergem quanto à possibilidade de apostasia e às condições de perseverança final. João 10 enfatiza o cuidado de Cristo por suas ovelhas; Hebreus formula advertências fortes dirigidas a uma comunidade sob pressão; Filipenses une ação de Deus e responsabilidade humana. Não é rigoroso apagar as advertências em nome das promessas ou negar as promessas em nome das advertências. Tradições reformadas, arminianas, católicas e outras possuem formulações distintas que merecem descrição precisa. O cuidado pastoral com pessoas angustiadas deve evitar transformar debate doutrinário em ameaça pessoal e distinguir ensino bíblico de situações de ansiedade ou sofrimento. Leitura contextual e diálogo com os textos mais amplos são imprescindíveis.",
      "comparison": "Compare João 10, Romanos 8:31–39, Hebreus 6 e 1 João 2:18–29. Pergunte a quem cada autor se dirige e qual preocupação pastoral está em primeiro plano.",
      "exercise": "Monte uma tabela com duas interpretações do tema, passagens usadas, questões que cada uma responde e dificuldades reconhecidas.",
      "readings": "Thomas R. Schreiner e Ardel B. Caneday, The Race Set Before Us; I. Howard Marshall, Kept by the Power of God."
    }
  ],
  "m26": [
    {
      "heading": "O movimento pentecostal e a interpretação de Atos",
      "primary": "Atos 1:8; Atos 2:1–21",
      "lecture": "O pentecostalismo moderno não nasce no primeiro século, mas se reconhece em narrativas antigas sobre oração, Espírito e missão. Movimentos de santidade, avivamentos e experiências de oração contribuíram para seu surgimento histórico no início do século XX, incluindo eventos associados à rua Azusa em Los Angeles. É preciso distinguir o acontecimento de Pentecostes em Atos 2 das formas posteriores de interpretação e prática eclesiástica. Atos apresenta o Espírito capacitando testemunhas em contexto multicultural; o episódio inclui anúncio público e reação de ouvintes, não apenas uma experiência individual. Igrejas pentecostais desenvolvem doutrinas diferentes sobre batismo no Espírito, sinal inicial e relação entre conversão e capacitação. Uma pesquisa séria identifica textos-chave e formulações denominacionais, sem apresentar todo o pentecostalismo como bloco homogêneo.",
      "comparison": "Compare Atos 2 com Atos 10 e com 1 Coríntios 12–14. Leia uma declaração doutrinária de denominação pentecostal e compare o que ela declara com as passagens citadas.",
      "exercise": "Elabore linha do tempo simplificada com história do movimento, manifestações brasileiras e diferenças entre narrativa bíblica e definição doutrinária contemporânea.",
      "readings": "Allan Anderson, An Introduction to Pentecostalism; Roger Stronstad, The Charismatic Theology of St. Luke."
    },
    {
      "heading": "Batismo no Espírito, oração e dons",
      "primary": "Atos 8:14–17; Atos 19:1–7; 1 Coríntios 12",
      "lecture": "Os relatos de Atos descrevem situações diversas envolvendo batismo, oração, imposição de mãos e manifestação do Espírito. A tentativa de extrair uma sequência cronológica obrigatória de todos os casos esbarra nas diferenças narrativas. Teólogos pentecostais frequentemente enfatizam experiência posterior de capacitação; interlocutores de outras tradições realçam a unidade entre conversão e recebimento do Espírito. O debate requer examinar que papel cada episódio cumpre na expansão para samaritanos e gentios, e como Paulo usa o vocabulário do Espírito nas cartas. Em 1 Coríntios 12, dons são distribuídos para o bem comum; isso oferece critério para avaliação de qualquer prática. Nenhuma comunidade deve coagir participantes a simular manifestações, nem usar experiências extraordinárias como prova de superioridade espiritual.",
      "comparison": "Compare Atos 8, 10 e 19 com Romanos 8:9 e 1 Coríntios 12:13. Registre as perguntas diferentes respondidas por narrativas e cartas.",
      "exercise": "Prepare um estudo em grupo com perguntas abertas sobre dons, zelo, ordem e serviço. Inclua cuidado explícito com pessoas que se sentem pressionadas.",
      "readings": "Gordon D. Fee, God’s Empowering Presence; Craig S. Keener, Acts: An Exegetical Commentary."
    },
    {
      "heading": "Discernimento, história e culto pentecostal",
      "primary": "1 Tessalonicenses 5:19–22; 1 Coríntios 14:26–33",
      "lecture": "Paulo convida a não desprezar manifestações espirituais e, ao mesmo tempo, a examinar tudo. O discernimento exige fidelidade bíblica, cuidado com as pessoas e transparência institucional. Relatos de cura, profecia e experiências incomuns não podem ser transformados automaticamente em afirmações clínicas ou promessas de resultado; necessidades médicas devem continuar recebendo acompanhamento profissional. O culto pentecostal tem expressões variadas no Brasil, com tradições de louvor, oração, testemunho e pregação. Sua vitalidade não elimina responsabilidades de proteger crianças, evitar abusos e prestar contas de decisões pastorais. O estudante pode valorizar a tradição pentecostal sem abandonar a análise histórica e a leitura contextual. Estudar testemunhos implica distinguir experiência narrada, interpretação pessoal e evidência disponível.",
      "comparison": "Compare 1 Tessalonicenses 5 com 1 Coríntios 12–14 e Mateus 7:15–23, observando que discernimento não equivale a cinismo nem aceitação indiscriminada.",
      "exercise": "Elabore um protocolo de discernimento comunitário que inclua leitura bíblica, diálogo, consentimento, acompanhamento e encaminhamento de situações de risco.",
      "readings": "Amos Yong, The Spirit Poured Out on All Flesh; Allan Anderson, An Introduction to Pentecostalism."
    }
  ],
  "m28": [
    {
      "heading": "O que são os Pais da Igreja e como lê-los",
      "primary": "1 Clemente; Inácio de Antioquia; Didachê",
      "lecture": "Patrística é o estudo da literatura cristã antiga e dos autores tradicionalmente chamados Pais da Igreja. A expressão reúne períodos, regiões e tradições muito diferentes. Obras como a Primeira Carta de Clemente, as cartas de Inácio e a Didachê ajudam a compreender preocupações com liderança, culto, ensino e unidade, mas não podem ser tratadas como se fossem todos os cristãos antigos. A datação, autoria e transmissão de cada obra precisam ser verificadas com edições críticas. Os escritos patrísticos não pertencem automaticamente ao cânon bíblico, embora tenham influenciado fortemente debates posteriores. É útil distinguir autores chamados apostólicos, apologistas e teólogos dos séculos seguintes. Quem lê a partir de tradição evangélica pode dialogar respeitosamente com a patrística sem confundir história das doutrinas com obrigação de concordância.",
      "comparison": "Compare a descrição comunitária de Atos 2 e orientações da Didachê, anotando semelhanças e diferenças históricas. Evite afirmar que um texto tardio prova automaticamente prática apostólica universal.",
      "exercise": "Leia introduções e excertos legítimos de uma edição crítica dos Pais Apostólicos. Registre autoria proposta, datação, destinatário, tese e limites da fonte.",
      "readings": "Michael W. Holmes, The Apostolic Fathers; Henry Chadwick, The Early Church."
    },
    {
      "heading": "Cristologia antiga e controvérsias",
      "primary": "Irineu, Contra as Heresias; Atanásio, Sobre a Encarnação",
      "lecture": "Nos séculos II a IV, cristãos discutiram a identidade de Jesus, a leitura das Escrituras e a relação entre o Pai e o Filho. Irineu escreveu em confronto com posições que considerava incompatíveis com a fé cristã e enfatizou unidade do projeto de Deus. Atanásio participou das controvérsias do século IV sobre a divindade do Filho. O estudo histórico deve distinguir os argumentos originais desses autores da forma resumida como aparecem em manuais confessionais. Expressões técnicas amadureceram em debates; não se deve afirmar que todas já possuíam o mesmo significado na época apostólica. O papel de imperadores, concílios e comunidades não pode ser reduzido a conspirações simples. Críticos modernos e crentes confessionais podem concordar sobre cronologias básicas e divergir sobre avaliação teológica.",
      "comparison": "Compare o prólogo de João com Filipenses 2 e resumos históricos das controvérsias arianas. Distinga evidência bíblica, formulação conciliar e leitura contemporânea.",
      "exercise": "Escreva duas páginas sobre a diferença entre uma doutrina bíblica afirmada e sua formulação técnica posterior, citando os textos antigos consultados.",
      "readings": "J. N. D. Kelly, Early Christian Doctrines; Lewis Ayres, Nicaea and Its Legacy."
    },
    {
      "heading": "Leitura, espiritualidade e heranças complexas",
      "primary": "Agostinho, Confissões; Gregório de Nissa; João Crisóstomo",
      "lecture": "Agostinho descreve memória, desejo e conversão em forma de oração e reflexão, oferecendo contribuição à espiritualidade e à filosofia cristã. Gregório de Nissa discute formação e transcendência; João Crisóstomo é conhecido por sua pregação e atuação pastoral. A patrística não constitui uma voz única: existem tensões e desacordos sobre interpretação, autoridade, riqueza e vida cristã. Além disso, autores antigos podem reproduzir preconceitos de seu tempo; estudar com respeito não exige aceitar tudo. A tradução moderna de termos gregos e latinos deve ser conferida na edição utilizada. O objetivo do curso é compreender como cristãos leram a Bíblia em contextos diferentes, percebendo continuidade e mudança, em vez de usar citações soltas para vencer debates modernos.",
      "comparison": "Compare uma homilia patrística sobre uma passagem bíblica com um comentário contemporâneo. Anote diferenças de método e preocupações pastorais, sem rotular uma abordagem como inútil por ser antiga.",
      "exercise": "Crie ficha de leitura de fonte primária com data provável, gênero, argumento, passagens utilizadas e questões que o autor deixa abertas.",
      "readings": "Agostinho, Confissões; Henry Chadwick, The Early Church; Justo L. González, The Story of Christianity."
    }
  ],
  "m31": [
    {
      "heading": "Contexto histórico da Reforma",
      "primary": "Romanos 1:16–17; Efésios 2:8–10",
      "lecture": "A Reforma do século XVI ocorreu em ambiente de mudanças religiosas, culturais, políticas e tecnológicas. Debates sobre indulgências, autoridade, justificação e práticas eclesiásticas já existiam antes de Lutero, mas ganharam nova escala com impressão e disputas institucionais. A história não se resume à oposição entre uma igreja completamente corrupta e reformadores unanimemente corretos. Também houve reformas católicas e movimentos de renovação anteriores e posteriores. O estudante deve distinguir objetivos declarados por cada autor, contexto de circulação e consequências não pretendidas. Romanos 1 e Efésios 2 foram centrais para reflexões sobre justiça divina e graça; seu uso histórico precisa ser analisado junto às interpretações bíblicas concorrentes. Traduzir slogans como sola fide exige explicar o que diferentes tradições entendiam por fé, graça e obras.",
      "comparison": "Compare formulações de Lutero com o contexto de Romanos e Efésios, usando textos históricos datados. Relacione eventos religiosos à imprensa e aos principados europeus sem reduzir teologia a política.",
      "exercise": "Monte cronologia comentada de cinco acontecimentos da Reforma, distinguindo fatos historicamente documentados de interpretações confessionais.",
      "readings": "Alister E. McGrath, Reformation Thought; Diarmaid MacCulloch, The Reformation."
    },
    {
      "heading": "Tradições reformadoras e diferenças internas",
      "primary": "Gálatas 2:15–21; Tiago 2:14–26",
      "lecture": "Luteranos, reformados, anglicanos, anabatistas e outros movimentos apresentaram acordos e conflitos sobre sacramentos, igreja e poder civil. Não é preciso apagar diferenças para reconhecer preocupação compartilhada com Escritura e renovação. A justificação pela fé não pode ser estudada ignorando a função de boas obras na ética; Tiago, Paulo e os reformadores respondem a problemas que exigem distinções. No campo da autoridade, sola Scriptura não significou a mesma coisa para todos os participantes do movimento e não equivale necessariamente a rejeição de toda tradição histórica. Ao estudar confissões e catecismos, registre data, contexto e tradição de origem. A leitura histórica melhora quando se consultam também autores de outras confissões, evitando caricaturas.",
      "comparison": "Compare Confissão de Augsburgo, referências às Institutas de Calvino e um documento católico do Concílio de Trento por meio de edições verificáveis; separe pontos de consenso e desacordo.",
      "exercise": "Elabore tabela de três tradições com compreensão sobre Escritura, ceia, batismo e autoridade eclesiástica, usando uma fonte representativa de cada uma.",
      "readings": "Alister E. McGrath, Reformation Thought; Justo L. González, The Story of Christianity."
    },
    {
      "heading": "Pós-Reforma, missão e relações contemporâneas",
      "primary": "Mateus 28:18–20; 1 Pedro 3:15–16",
      "lecture": "As consequências da Reforma incluem novas instituições, catequese, traduções bíblicas, guerras confessionais e expansão missionária. Nos séculos seguintes, avivamentos e metodismo apresentaram diferentes ênfases sobre santidade, evangelização e experiência de fé. As tradições evangélicas brasileiras não descendem de um único episódio europeu de forma direta; possuem histórias missionárias e sociais diversas, inclusive contribuições de comunidades locais. Um estudo contemporâneo deve avaliar tanto frutos educativos e espirituais quanto situações de intolerância religiosa e relações de poder. Diálogo ecumênico não exige negar convicções; exige representar honestamente o outro. A apologética proposta em 1 Pedro 3 une apresentação de razões e atitude respeitosa, o que fornece critério para debates confessionais.",
      "comparison": "Compare trajetórias históricas de uma comunidade luterana, uma batista e uma pentecostal no Brasil. Observe datas, organizações e adaptações culturais.",
      "exercise": "Escreva ensaio breve sobre uma herança da Reforma que você valoriza e uma decisão histórica que merece crítica, apresentando fontes verificadas.",
      "readings": "Diarmaid MacCulloch, The Reformation; Justo L. González, História Ilustrada do Cristianismo."
    }
  ],
  "m37": [
    {
      "heading": "O que a apologética pode — e não pode — fazer",
      "primary": "1 Pedro 3:15–16; Atos 17:22–31",
      "lecture": "Apologética é apresentação argumentada de razões para a fé, exercida em diálogo com perguntas reais e outras perspectivas. Em 1 Pedro, o conselho de responder com mansidão e respeito aparece em cenário de sofrimento e testemunho. Em Atos 17, Paulo utiliza referências culturais familiares aos ouvintes para apresentar sua mensagem. Nenhuma dessas passagens exige que toda dúvida seja resolvida por um silogismo. Há argumentos filosóficos sobre existência de Deus, moralidade, consciência e historicidade cristã, com objeções importantes. Uma argumentação honesta declara suas premissas, diferencia evidência histórica de convicção religiosa e reconhece limites. O objetivo não é vencer o interlocutor por pressão emocional. Debater com alguém de outra crença exige compreender sua posição por fontes confiáveis e consentimento para a conversa.",
      "comparison": "Compare o discurso de Paulo em Atenas com sua argumentação em uma sinagoga em Atos 13. Observe adaptação do ponto de partida sem confundir apresentação cultural e concessão de todo conteúdo.",
      "exercise": "Escreva um argumento cristão em cinco premissas e faça a melhor objeção possível a ele. Revise o argumento sem ridicularizar quem discorda.",
      "readings": "Alvin Plantinga, Warranted Christian Belief; William Lane Craig, Reasonable Faith; John Hick, Philosophy of Religion."
    },
    {
      "heading": "Historicidade, fontes e avaliação de evidências",
      "primary": "1 Coríntios 15:3–8; Lucas 1:1–4",
      "lecture": "O estudo histórico do cristianismo utiliza textos antigos, evidências arqueológicas e comparações entre fontes. Em 1 Coríntios 15, Paulo transmite uma tradição sobre a morte e ressurreição de Cristo e menciona testemunhas. Isso é relevante para investigar a antiguidade do testemunho, mas o historiador ainda precisa perguntar como tradições foram preservadas e quais conclusões ultrapassam o alcance de métodos históricos. Diferencie afirmações sobre existência de comunidades e crenças antigas de conclusões metafísicas ou confessionais. Fontes cristãs são fontes históricas legítimas que devem ser analisadas criticamente como quaisquer outras. A ausência de testemunho independente para cada detalhe não permite nem comprovação automática nem negação instantânea. Uma apologética madura admite incertezas e evita inventar descobertas arqueológicas.",
      "comparison": "Compare o prólogo de Lucas, a tradição de 1 Coríntios 15 e o uso de fontes em uma obra historiográfica moderna. Identifique interesses, datas aproximadas e perguntas possíveis.",
      "exercise": "Produza uma ficha com “dado da fonte”, “inferência razoável” e “afirmação de fé”. Apresente objeções sem slogans.",
      "readings": "Richard Bauckham, Jesus and the Eyewitnesses; N. T. Wright, The Resurrection of the Son of God; Bart D. Ehrman, Jesus: Apocalyptic Prophet of the New Millennium."
    },
    {
      "heading": "Mal, sofrimento e conversa respeitosa",
      "primary": "Jó 1–2; Salmos 13; Romanos 8:18–27",
      "lecture": "O problema do mal envolve perguntas diferentes: como conciliar sofrimento com um Deus bom, como interpretar injustiças históricas e como acompanhar quem sofre. Jó recusa a simplificação dos amigos que explicam tragédia como consequência proporcional de pecado pessoal. Os salmos de lamento autorizam perguntas dolorosas a Deus e não devem ser reduzidos a falta de fé. Romanos 8 descreve criação que geme e esperança, sem atribuir a cada perda uma causa divina específica. Propostas filosóficas como defesa do livre-arbítrio e teodiceias de formação moral respondem a certas objeções, mas não eliminam a necessidade de compaixão. Em contextos de luto ou enfermidade, a resposta responsável começa pela escuta e não por argumento abstrato que pressione a pessoa. A apologética deve evitar insinuar que a vítima merece sofrimento.",
      "comparison": "Compare o raciocínio dos amigos de Jó com a resposta final do livro e com João 9:1–3. Avalie riscos de aplicar automaticamente causas espirituais a doenças ou acidentes.",
      "exercise": "Escreva diálogo de cuidado de seis falas em que um cristão reconhece limites do conhecimento e oferece apoio prático, sem prometer cura nem resultado.",
      "readings": "Eleonore Stump, Wandering in Darkness; Nicholas Wolterstorff, Lament for a Son; John Goldingay, Psalms."
    }
  ],
  "m42": [
    {
      "heading": "Do texto ao tema da pregação",
      "primary": "Neemias 8:8; 2 Timóteo 4:1–5",
      "lecture": "Pregação expositiva não significa ler muitos versículos sem explicação nem recitar opiniões acompanhadas de uma referência. Seu princípio é permitir que o argumento e a finalidade do texto bíblico governem a mensagem. Comece delimitando uma unidade literária, identificando gênero, contexto e movimento do discurso. Em Neemias 8, a leitura pública aparece ligada à explicação e à compreensão. Em 2 Timóteo 4, a exortação pastoral inclui responsabilidade em ensinar, corrigir e perseverar. A passagem deve ser contextualizada antes de ser transformada em regra técnica de apresentação moderna. Prepare uma proposição central que exprima o texto em linguagem clara. Para um auditório misto, evite jargões não explicados e separe interpretação de sugestão prática.",
      "comparison": "Compare uma mensagem baseada em apenas uma frase com outra que apresenta o movimento completo do parágrafo. Explique como o contexto pode corrigir a ideia inicial.",
      "exercise": "Escolha Marcos 10:42–45; marque a situação, a contraposição feita por Jesus, a ideia central e três aplicações que não acrescentem promessas ao texto.",
      "readings": "Haddon W. Robinson, Biblical Preaching; Bryan Chapell, Christ-Centered Preaching."
    },
    {
      "heading": "Estrutura: introdução, explicação e aplicação",
      "primary": "Lucas 10:25–37; Tiago 2:14–17",
      "lecture": "Uma mensagem pode incluir introdução que apresente a pergunta do texto, exposição que siga a sua organização e aplicação que dialogue com situações reais. A parábola do bom samaritano gira em torno de uma questão sobre quem age como próximo. Uma estrutura que se detenha somente em sentimentos de generosidade pode perder a força da inversão narrativa e o problema das barreiras sociais. Ilustrações devem esclarecer a passagem e não substituí-la; histórias atribuídas a terceiros precisam de fonte ou identificação como hipotéticas. Evite revelar detalhes pessoais de aconselhados, usar medo para forçar decisões ou converter experiências individuais em regras universais. Controle de tempo, clareza vocal e transições ajudam, mas boa comunicação não compensa exegese ruim.",
      "comparison": "Compare Lucas 10 com Tiago 2 e 1 João 3:16–18. Observe que os textos convergem no cuidado concreto embora tenham construções literárias distintas.",
      "exercise": "Monte um esboço de 12 minutos: dois minutos de apresentação, oito de explicação e dois de aplicação. Registre referência para cada afirmação importante.",
      "readings": "John Stott, Between Two Worlds; Haddon W. Robinson, Biblical Preaching."
    },
    {
      "heading": "Revisão teológica e prática pastoral",
      "primary": "1 Coríntios 13; 1 Pedro 5:1–4",
      "lecture": "Uma revisão de sermão examina fidelidade ao texto, clareza, sentido pastoral e possíveis danos de aplicação. Em 1 Coríntios 13, o amor corrige competição espiritual; em 1 Pedro 5, a liderança é orientada a cuidar sem dominar. Sermões sobre sofrimento não devem insinuar que toda dor é falta de fé; sermões sobre generosidade não devem prometer retorno financeiro automático. Pregação pública exige cuidado com crianças, sobreviventes de abuso e pessoas com necessidades de saúde. Um esboço pode ser doutrinariamente cuidadoso e ainda assim falhar ao usar humor humilhante ou exposição indevida de histórias. Peça revisão de alguém confiável, ajuste duração e prepare aplicações que preservem autonomia e dignidade.",
      "comparison": "Compare um texto de consolo e um texto de exortação. Observe diferenças de tom pastoral, destinatário e responsabilidade de quem ensina.",
      "exercise": "Grave um sermão curto e faça lista de verificação: contexto, tese, três referências verificadas, linguagem acessível, tempo e salvaguardas éticas.",
      "readings": "Bryan Chapell, Christ-Centered Preaching; John Stott, Between Two Worlds."
    }
  ],
  "m50": [
    {
      "heading": "Projeto de pesquisa: problema e fontes",
      "primary": "Atos 17:11; Lucas 1:1–4",
      "lecture": "Uma pesquisa teológica acadêmica começa por pergunta delimitada. “A salvação” é amplo demais; “como Efésios 2:8–10 relaciona graça e obras no argumento da carta?” é investigável. O método deve corresponder ao problema: exegese analisa passagens e línguas, história investiga documentos e períodos, pesquisa empírica requer procedimentos éticos com pessoas. Fontes primárias são os documentos examinados; fontes secundárias discutem esses documentos. Cada citação precisa indicar edição, autoria e página quando disponível, sem inventar dados. Uma revisão bibliográfica não consiste em colecionar links; exige mapear argumentos e tensões. Mesmo quando a pesquisa parte de convicção cristã, as afirmações históricas e linguísticas devem ser verificáveis. Ferramentas de IA podem auxiliar organização, mas não substituem leitura e checagem.",
      "comparison": "Compare uma pergunta ampla e uma pergunta recortada. Observe que “provar a Bíblia” e “investigar a recepção de João 1 nos séculos II–IV” exigem procedimentos radicalmente diferentes.",
      "exercise": "Elabore problema, justificativa, objetivo geral, três específicos, corpus delimitado e critérios de seleção de fontes.",
      "readings": "Umberto Eco, Como se Faz uma Tese; Gordon D. Fee, New Testament Exegesis."
    },
    {
      "heading": "Argumento e honestidade bibliográfica",
      "primary": "Romanos 12:2; Provérbios 18:17",
      "lecture": "Uma boa argumentação avança de fontes para afirmações e expõe possíveis contraexemplos. Diferencie descrição (“o autor diz”), interpretação (“essa construção sugere”) e juízo normativo (“a comunidade deveria”). Uma referência bibliográfica deve ser recuperável; quando a edição consultada não informa páginas, não invente paginação. Paráfrase de ideia alheia também precisa ser atribuída. Evite tanto o acúmulo de citações sem análise quanto a ausência de fontes. Para fontes digitais, registre título, autor institucional, endereço e data de acesso quando a norma exigir. Ao usar léxicos e dicionários bíblicos, indique verbete e edição. Uma conclusão cuidadosa pode ser parcialmente negativa: demonstrar que uma tese não encontra apoio suficiente é resultado válido.",
      "comparison": "Compare argumentos sobre o mesmo texto em dois comentários de orientações diferentes e descreva quais evidências cada um prioriza; recuse falsa equivalência quando há diferenças reais de suporte.",
      "exercise": "Escreva um parágrafo de análise com fonte primária, uma secundária e uma objeção. Inclua referências completas de obras realmente consultadas.",
      "readings": "Wayne C. Booth, Gregory G. Colomb e Joseph M. Williams, The Craft of Research; norma ABNT NBR 10520 na edição vigente."
    },
    {
      "heading": "Estrutura final e critérios de avaliação",
      "primary": "2 Timóteo 2:15; 1 Pedro 3:15–16",
      "lecture": "O trabalho final pode reunir resumo, problema, objetivos, metodologia, descrição do corpus, análise, discussão, conclusão e referências. O resumo deve informar a pergunta e a resposta alcançada, não apenas elogiar o tema. A seção de método explica como as passagens e obras foram escolhidas; a análise mostra as evidências e limites. A conclusão responde ao objetivo sem afirmar mais do que os dados permitem. Uma pesquisa teológica livre pode conter aplicação pastoral, desde que distinga essa etapa da análise histórica. Revisão final inclui ortografia, pertinência das fontes, risco de plágio e clareza da bibliografia. A existência de um curso livre não o torna diploma equivalente a bacharelado reconhecido. Um excelente trabalho é aquele que o leitor consegue acompanhar e verificar, mesmo quando discorda da conclusão.",
      "comparison": "Compare uma conclusão que reproduz a introdução com outra que efetivamente responde ao problema e aponta limites. Avalie qual oferece ganho de conhecimento.",
      "exercise": "Crie checklist e cronograma de quatro semanas, revise fichamentos e peça leitura crítica de duas pessoas com perspectivas diferentes.",
      "readings": "Umberto Eco, Como se Faz uma Tese; ABNT NBR 6023 na edição vigente."
    }
  ]
};
