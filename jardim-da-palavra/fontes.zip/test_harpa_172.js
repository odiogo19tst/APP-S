const fs=require('fs'), vm=require('vm'), assert=require('assert');
const A=__dirname+'/app/src/main/assets/';
const ctx={window:{scrollTo(){}},console};vm.createContext(ctx);
for(const f of ['harpa_index.js','harpa_letras.js','harpa_ui.js'])vm.runInContext(fs.readFileSync(A+f,'utf8'),ctx,{filename:f});
const H=ctx.window.JARDIM_HARPA;
const raw=`1 Deus prometeu com certeza, Chuvas\nde graça mandar;\nEle nos dá fortaleza,\nE ricas bênçãos sem par.\nCHUVAS DE GRAÇA, CHUVAS\nPEDIMOS SENHOR,\nMANDA-NOS CHUVAS CONSTANTES,\nCHUVAS DO CONSOLADOR.\n2 Cristo nos tem concedido O santo\nConsolador,\nDe plena paz nos enchido, Para o\nreinado de amor.\n3 Dá-nos, Senhor, amplamente, Teu\ngrande gozo e poder\nFonte de amor permanente, Põe dentro\nde nosso ser.`;
const sections=H.hymnSections(raw);
assert.strictEqual(sections.length,4);
assert.deepStrictEqual(Array.from(sections.map(s=>s.type)),['verse','chorus','verse','verse']);
const html=H.formattedLyrics(raw);
assert(html.includes('Estrofe 1')&&html.includes('Refrão')&&html.includes('Estrofe 3'));
assert(html.includes('Deus prometeu com certeza,</span>'));
assert(html.includes('Chuvas de graça mandar;'));
assert(html.includes('Dá-nos, Senhor, amplamente,'));
assert(!html.includes('Dá-nos,</span><span'));
assert(!html.includes('chuvas\nde graça'));
const tricky='1 Exemplo de texto\nREFRÃO\nOH QUE BOM\nMIM,\nLÁ DE CIMA\n2 Outra estrofe';
const parsed=H.hymnSections(tricky);
assert.strictEqual(parsed.length,3);
assert(parsed[1].type==='chorus' && parsed[1].lines.includes('MIM,'));
assert(H.formattedLyrics('1 <script>alert(1)</script>').includes('&lt;script&gt;'));
for(const n of [1,2,45,237,640]) {
 const letters=ctx.window.JARDIM_HARPA_LYRICS||{};
 if(letters[n]) assert(H.hymnSections(letters[n].text).length>0);
}
console.log('PASS Harpa 1.6.12 — estrofes, refrão, recomposição, caracteres seguros');
