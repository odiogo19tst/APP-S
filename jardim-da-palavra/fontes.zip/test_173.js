'use strict';
const fs=require('fs'),vm=require('vm'),assert=require('assert'),path=require('path');
const dir=path.join(__dirname,'app/src/main/assets');
const content=n=>fs.readFileSync(path.join(dir,n),'utf8');
const ctx={window:{},console};vm.createContext(ctx);
for(const n of ['harpa_index.js','harpa_letras.js','harpa_ui.js','seminarios.js','seminarios_ui.js','curso_data.js','curso_dossie.js'])vm.runInContext(content(n),ctx,{filename:n});
const titles=ctx.window.JARDIM_HARPA_TITLES;
assert.strictEqual(titles.length,641);assert(titles.slice(1).every(x=>typeof x==='string'&&x.trim().length>=3));
assert.strictEqual(titles[40],'A Cidade do Bom Deus');
assert.strictEqual(titles[270],'Louvando ao Nosso Criador');
assert.strictEqual(titles[1],'Chuvas de Graça');
assert.strictEqual(ctx.window.JARDIM_SEMINARS.length,8);
assert(ctx.window.JARDIM_SEMINARS.every(x=>['context','analysis','translation','perspectives','practice','parallels','sources'].every(k=>String(x[k]||'').length>=30)));
assert.strictEqual(ctx.window.JARDIM_CURSO.subjects.length,52);
assert.strictEqual(ctx.window.JARDIM_CURSO.subjects.flatMap(x=>x.lessons).length,156);
const app=content('app.js'),css=content('style.css'),html=content('index.html');
assert(app.includes("function dedication()"));assert(app.includes('Diogo Oliveira'));
assert(app.includes("function seminars()"));assert(app.includes("'seminars','seminar'"));
for(const theme of ['forest','ocean','sand','night','rose','sunrise','teal','lavender']){
 assert(css.includes(`[data-theme="${theme}"]`),'Estilo não encontrado '+theme);
 assert(app.includes(`'${theme}'`),'Tema não disponível '+theme);
}
assert(html.includes('seminarios.js')&&html.includes('seminarios_ui.js'));
let raw='1 O Senhor é bom\nREFRÃO\nAMÉM\n2 Outra estrofe';
assert(ctx.window.JARDIM_HARPA.formattedLyrics(raw).includes('harpa-refrain'));
assert(ctx.window.JARDIM_HARPA.plainText('l.Creio que o Senhor é bom').startsWith('1. Creio'));
const bundled=ctx.window.JARDIM_HARPA_LYRICS||{};
if(Object.keys(bundled).length){assert.strictEqual(Object.keys(bundled).length,640); for(let n=1;n<=640;n++)assert((bundled[n].text||'').length>=20,'hino vazio '+n)}
console.log('PASS 1.6.13: 640 hinos, 52 disciplinas/156 aulas, 8 seminários, 9 temas, dedicatória, formatação e JS básico. Letras no pacote:',Object.keys(bundled).length);
