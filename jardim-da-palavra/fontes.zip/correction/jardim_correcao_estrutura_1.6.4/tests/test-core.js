const assert=require('node:assert/strict'),fs=require('node:fs');const c=require('../src/core.js');
assert.equal(c.STAGES.reduce((s,x)=>s+x.seconds,0),600);
assert.equal(c.bookNumber('Miqueias'),60);assert.equal(c.bookNumber('Miquéias'),60);assert.equal(c.bookNumber('João'),4);
assert.deepEqual(c.acfPath('acf-master/acf-json/at_book-28_chapter-1.json'),{book:28,chapter:1});
assert.deepEqual(c.acfPath('acf-json/nt_book-4_chapter-3.json'),{book:4,chapter:3});
assert.equal(c.acfPath('evil.js'),null);
assert.equal(c.plainText('<span>O</span> <i>Senhor</i> &amp; luz'),'O Senhor & luz');
assert.equal(c.parseAcfChapter({book:28,chapter:1,verses:[{'2':'<b>dois</b>'},{'1':'um'}]},{book:28,chapter:1}).verses[0].text,'um');
let n=1000;const t=c.makeTimer({},()=>n);t.start();n+=62000;assert.equal(t.state().remaining,0);t.pause();assert.equal(t.state().spent,62000);t.next();assert.equal(t.state().stage,1);assert.equal(t.state().remaining,120000);n+=10000;assert.equal(t.state().remaining,120000); // não corre em pausa
assert.equal(c.timeLabel(60999),'01:01');assert.equal(c.todaysKey(new Date(2026,10,19)),'2026-11-19');
(async()=>{const a=fs.readFileSync(__dirname+'/fake-acf.zip');const entries=c.zipEntries(a);assert.equal(entries.length,1);const payload=JSON.parse(await c.unzipEntry(a,entries[0]));assert.equal(c.parseAcfChapter(payload,entries[0]).verses[0].text,'teste');console.log('OK: 13 grupos de testes de fluxo, ZIP, ACF, timer, datas e sanitização');})().catch(e=>{console.error(e);process.exitCode=1});
