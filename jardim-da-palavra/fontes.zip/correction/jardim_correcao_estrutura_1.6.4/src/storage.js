(function(root){'use strict';let dbPromise=null;
 function db(){if(dbPromise)return dbPromise;dbPromise=new Promise((resolve,reject)=>{if(!('indexedDB' in root)){reject(new Error('Armazenamento offline indisponível neste navegador'));return;}const req=indexedDB.open('jardim-palavra-acf-local',1);req.onupgradeneeded=()=>{const d=req.result;if(!d.objectStoreNames.contains('chapters'))d.createObjectStore('chapters',{keyPath:'id'});};req.onsuccess=()=>resolve(req.result);req.onerror=()=>reject(req.error);});return dbPromise;}
 async function write(ch){const d=await db();return new Promise((resolve,reject)=>{const tx=d.transaction('chapters','readwrite');tx.objectStore('chapters').put({...ch,id:`${ch.book}:${ch.chapter}`});tx.oncomplete=()=>resolve();tx.onerror=()=>reject(tx.error);});}
 async function read(book,chapter){const d=await db();return new Promise((resolve,reject)=>{const r=d.transaction('chapters').objectStore('chapters').get(`${book}:${chapter}`);r.onsuccess=()=>resolve(r.result||null);r.onerror=()=>reject(r.error);});}
 async function keys(){const d=await db();return new Promise((resolve,reject)=>{const r=d.transaction('chapters').objectStore('chapters').getAllKeys();r.onsuccess=()=>resolve(r.result||[]);r.onerror=()=>reject(r.error);});}
 root.JardimStore={write,read,keys};
})(globalThis);
