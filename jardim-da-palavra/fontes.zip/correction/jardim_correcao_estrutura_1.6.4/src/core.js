/* Jardim da Palavra: lógica independente de framework; não inclui texto ACF. */
(function(root,factory){
 const api=factory();
 if(typeof module==='object' && module.exports)module.exports=api;
 if(root)root.JardimCore=api;
})(typeof globalThis!=='undefined'?globalThis:this,function(){
 'use strict';
 const STAGES=[
  {key:'acolhimento',label:'Acolhimento',seconds:60},
  {key:'louvor',label:'Louvor',seconds:120},
  {key:'palavra',label:'Palavra e reflexão',seconds:180},
  {key:'aplicacao',label:'Aplicação',seconds:120},
  {key:'oracao',label:'Oração',seconds:120}
 ];
 const BOOKS=['Mateus','Marcos','Lucas','João','Atos','Romanos','I Coríntios','II Coríntios','Gálatas','Efésios','Filipenses','Colossenses','I Tessalonicenses','II Tessalonicenses','I Timóteo','II Timóteo','Tito','Filemom','Hebreus','Tiago','I Pedro','II Pedro','I João','II João','III João','Judas','Apocalipse','Gênesis','Êxodo','Levítico','Números','Deuteronômio','Josué','Juízes','Rute','I Samuel','II Samuel','I Reis','II Reis','I Crônicas','II Crônicas','Esdras','Neemias','Ester','Jó','Salmos','Provérbios','Eclesiastes','Cantares de Salomão','Isaías','Jeremias','Lamentações de Jeremias','Ezequiel','Daniel','Oseias','Joel','Amós','Obadias','Jonas','Miqueias','Naum','Habacuque','Sofonias','Ageu','Zacarias','Malaquias'];
 function canonicalBook(s){return String(s||'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-zA-Z0-9]/g,'').toLowerCase()}
 function bookNumber(s){let i=BOOKS.findIndex(x=>canonicalBook(x)===canonicalBook(s));return i<0?null:i+1}
 function acfPath(name){const m=String(name).replace(/\\/g,'/').match(/(?:^|\/)acf-json\/(at|nt)_book-(\d+)_chapter-(\d+)\.json$/i);if(!m)return null;const book=Number(m[2]),chapter=Number(m[3]);return book>=1&&book<=66&&chapter>0&&chapter<=150?{book,chapter}:null}
 function plainText(html){return String(html).replace(/<[^>]*>/g,'').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>').replace(/&quot;/gi,'\"').replace(/&#39;/g,"'").trim()}
 function parseAcfChapter(obj,expected){if(!obj||!Array.isArray(obj.verses))throw Error('Capítulo ACF inválido');const book=Number(obj.book),chapter=Number(obj.chapter);if(expected && (book!==expected.book||chapter!==expected.chapter))throw Error('Referência divergente no arquivo');if(book<1||book>66||chapter<1||chapter>150)throw Error('Referência fora do intervalo');let verses=[];for(const row of obj.verses){if(!row||typeof row!=='object')continue;for(const [key,value] of Object.entries(row)){const n=Number(key);if(Number.isInteger(n)&&n>0&&n<=176&&typeof value==='string')verses.push({number:n,text:plainText(value)});}}verses.sort((a,b)=>a.number-b.number);if(!verses.length)throw Error('Capítulo sem versículos');return {book,chapter,bookName:BOOKS[book-1],verses};}
 function todaysKey(date=new Date()){return [date.getFullYear(),String(date.getMonth()+1).padStart(2,'0'),String(date.getDate()).padStart(2,'0')].join('-')}
 function timeLabel(milliseconds){const total=Math.max(0,Math.ceil(milliseconds/1000));return `${String(Math.floor(total/60)).padStart(2,'0')}:${String(total%60).padStart(2,'0')}`}
 // Timer monotônico: só conta tempo ativo, e nunca continua oculto por engano.
 function makeTimer(saved={},clock=()=>Date.now()){
  let stage=Math.min(4,Math.max(0,Number(saved.stage)||0)),spent=Math.max(0,Number(saved.spent)||0),running=false,started=null;
  function elapsed(){return spent+(running?Math.max(0,clock()-started):0)}
  function state(){return {stage,spent:elapsed(),running,remaining:Math.max(0,STAGES[stage].seconds*1000-elapsed())}}
  function pause(){if(running){spent=elapsed();running=false;started=null}return state()}
  return {state,start(){if(!running&&elapsed()<STAGES[stage].seconds*1000){running=true;started=clock()}return state()},pause,reset(){pause();spent=0;return state()},next(){pause();stage=Math.min(4,stage+1);spent=0;return state()},prev(){pause();stage=Math.max(0,stage-1);spent=0;return state()},go(index){pause();if(!Number.isInteger(index)||index<0||index>4)throw Error('Etapa inválida');stage=index;spent=0;return state()}};
 }
 // Leitura do diretório central ZIP. Somente arquivos que vierem do usuário.
 function zipEntries(bytes){const b=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes);const v=new DataView(b.buffer,b.byteOffset,b.byteLength);let end=-1;for(let i=b.length-22;i>=Math.max(0,b.length-65557);--i){if(v.getUint32(i,true)===0x06054b50){end=i;break;}}if(end<0)throw Error('ZIP inválido');const total=v.getUint16(end+10,true);let p=v.getUint32(end+16,true);if(total>7000)throw Error('ZIP muito grande');let arr=[],totalSize=0;for(let i=0;i<total;i++){
 if(p+46>b.length||v.getUint32(p,true)!==0x02014b50)throw Error('Diretório ZIP danificado');const method=v.getUint16(p+10,true),csize=v.getUint32(p+20,true),usize=v.getUint32(p+24,true),nl=v.getUint16(p+28,true),extra=v.getUint16(p+30,true),comment=v.getUint16(p+32,true),local=v.getUint32(p+42,true),name=new TextDecoder().decode(b.slice(p+46,p+46+nl));
 p+=46+nl+extra+comment;if(p>b.length)throw Error('Diretório fora do arquivo');const info=acfPath(name);if(info){if(method!==0&&method!==8)throw Error('Compressão ZIP não suportada');if(usize>1000000)throw Error('Capítulo excede limite');totalSize+=usize;if(totalSize>30000000)throw Error('Conteúdo excede limite');arr.push({name,method,csize,usize,local,...info});}
 }return arr;}
 async function unzipEntry(bytes,e){const b=bytes instanceof Uint8Array?bytes:new Uint8Array(bytes),v=new DataView(b.buffer,b.byteOffset,b.byteLength),p=e.local;if(p+30>b.length||v.getUint32(p,true)!==0x04034b50)throw Error('Cabeçalho ZIP ausente');const start=p+30+v.getUint16(p+26,true)+v.getUint16(p+28,true);if(start+e.csize>b.length)throw Error('Arquivo ZIP incompleto');const input=b.slice(start,start+e.csize);let result;
 if(e.method===0)result=input;
 else {if(typeof DecompressionStream==='undefined')throw Error('Seu navegador não suporta importação ZIP; use Android/Chrome atualizado');const dataStream=new Blob([input]).stream().pipeThrough(new DecompressionStream('deflate-raw'));result=new Uint8Array(await new Response(dataStream).arrayBuffer());}
 if(result.length!==e.usize)throw Error('Tamanho do capítulo inválido');return new TextDecoder().decode(result);
 }
 return {STAGES,BOOKS,canonicalBook,bookNumber,acfPath,plainText,parseAcfChapter,todaysKey,timeLabel,makeTimer,zipEntries,unzipEntry};
});
