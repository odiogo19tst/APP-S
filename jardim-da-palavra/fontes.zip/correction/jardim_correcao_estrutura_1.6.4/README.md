# Jardim da Palavra — Correção experimental do leitor e do devocional

**Este pacote é um módulo demonstrativo, não um APK 1.6.5 nem uma atualização instalada do aplicativo 1.6.4.** O código original 1.6.4 e sua chave de assinatura não estavam disponíveis nesta sessão. Não substitua o app anterior por este pacote nem desinstale nada.

## O que já funciona neste protótipo

- Devocional de **cinco etapas isoladas** (1+2+3+2+2 = 10 minutos), com avanço e retorno; controles acessíveis sem depender de rolagem longa.
- Cronômetro pausa ao trocar de etapa e ao ocultar o aplicativo; não continua rodando inadvertidamente. Reinício manual de etapa; sem avanço automático inesperado.
- Louvor sugerido com **Spotify e YouTube**, mantendo a música como parte do devocional.
- Reflexão com salvamento automático por dia, mesmo ao navegar para a Bíblia.
- Leitor interno por livro/capítulo, com navegação entre capítulos e leitura narrada pelo sintetizador de voz do sistema.
- Importação **local, no aparelho**, do ZIP `acf-master.zip` baixado pelo próprio usuário, usando a estrutura `acf-json/{at|nt}_book-N_chapter-M.json`. Não há transmissão do arquivo ao servidor. O ZIP é descompactado em memória, capítulos são verificados e armazenados no IndexedDB.
- Referências bíblicas com a indicação correta de tradução. Até a importação, o protótipo não finge exibir ACF nem redireciona a pesquisa web.
- Os dados são persistidos no domínio/origem em que o projeto é aberto. É necessário garantir persistência de origem no WebView Android que integre o módulo.

## Compatibilidade, limites e licenciamento

A ACF é protegida por direitos autorais da **Sociedade Bíblica Trinitariana do Brasil (SBTB)**. O repositório `WilliamSampaio/acf` é público, mas não exibe licença autorizando redistribuir a íntegra da tradução. Por isso este pacote **não contém textos ACF** e não pode ser publicado na Play Store com a íntegra da ACF sem licença expressa. Consulte https://www.biblias.com.br/direitos-autorais. O leitor permite importar dados fornecidos localmente pelo usuário; o responsável deve observar os direitos de utilização dos arquivos.

A base anterior do Jardim 1.6.4 (156 aulas, 52 disciplinas, anotações e 31 devocionais) **não está contida neste protótipo**. Integre os componentes de leitura e as melhorias de navegação ao app completo existente, preservando o banco de dados, assinatura e histórico. O exemplo vem com apenas o tema *Misericórdia para um novo dia* e a indicação de Lamentações 3:21–26, sem texto bíblico até a importação.

## Como testar

Abra `index.html` em um navegador Android/Chrome atualizado ou sirva o diretório por HTTP local (`python -m http.server 8000`). Abra a seção **Bíblia**, selecione um ZIP no formato do repositório, e leia o capítulo importado. Depois retorne ao devocional, avance entre as cinco etapas e confirme que anotações e tempo salvo permanecem. Uma instalação definitiva deverá incorporar esses componentes ao projeto Android original.

## Testes automatizados

`node tests/test-core.js` valida etapas, durações, nomes com acentos, formato de capítulos, extração ZIP, sanitização do texto, cronômetro e datas. `tests/fake-acf.zip` contém somente dados artificiais para testes, sem conteúdo bíblico.

## Repositórios/fonte consultados

- Formato ACF: https://github.com/WilliamSampaio/acf (pasta `acf-json`)
- Direitos SBTB: https://www.biblias.com.br/direitos-autorais
- Alternativa para futura Bíblia offline completa: https://github.com/blivre/BibliaLivre (Creative Commons com atribuição; não confundir com ACF)
