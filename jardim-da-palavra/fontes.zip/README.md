# Jardim da Palavra 1.6.4 — Devocional em 5 etapas

Projeto Android local baseado na versão 1.6.3. Mantém os estudos e o curso teológico. Restaura o devocional em 5 etapas guiadas, como no aplicativo de referência mostrado nas capturas.

Requisitos: JDK 17, Android SDK 35, Gradle 8.9. Compile com `gradle :app:assembleDebug` na pasta raiz do projeto. O fluxo GitHub Actions da ramificação `jardim-apk-dev` faz isso automaticamente, verifica assinatura v2 e armazena o APK temporário como artefato.

Esta versão usa `com.diogo.jardimbibliaseestudos.curso164` na variante debug, para instalar ao lado das versões de teste anteriores. Não reinstale no mesmo pacote para preservar dados sem uma assinatura de publicação permanente.

A síntese é feita pelo Android e sua voz selecionada. O texto integral ACF não é reproduzido sem autorização. O Spotify/YouTube abre pesquisa da música escolhida, sem streaming embutido.
