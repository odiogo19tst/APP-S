# Jardim da Palavra 1.6.4 — Devocional em 5 etapas

Projeto Android local baseado na versão 1.6.3. Mantém os estudos e o curso teológico. Restaura o devocional em 5 etapas guiadas, como no aplicativo de referência mostrado nas capturas.

Requisitos: JDK 17, Android SDK 35, Gradle 8.9. Compile com `gradle :app:assembleDebug` na pasta raiz do projeto. O fluxo GitHub Actions da ramificação `jardim-apk-dev` faz isso automaticamente, verifica assinatura v2 e armazena o APK temporário como artefato.

Esta versão usa `com.diogo.jardimbibliaseestudos.curso164` na variante debug, para instalar ao lado das versões de teste anteriores. Não reinstale no mesmo pacote para preservar dados sem uma assinatura de publicação permanente.

A síntese é feita pelo Android e sua voz selecionada. O texto integral ACF não é reproduzido sem autorização. O Spotify/YouTube abre pesquisa da música escolhida, sem streaming embutido.

## 1.6.5 — Leitor ACF totalmente offline após importação

**O APK não contém o texto integral da ACF.** Sua reprodução/distribuição depende de autorização escrita da Sociedade Bíblica Trinitariana do Brasil (pedido protocolado em 19/11/2026). Esta versão fornece um leitor pessoal que aceita um ZIP fornecido pelo usuário, mediante os direitos aplicáveis. A cópia ACF é importada exclusivamente no armazenamento privado do dispositivo; o app não envia capítulos a servidores nem os busca em tempo de leitura.

Na aba **Bíblia**, selecione **Importar meu ZIP da ACF** e escolha um ZIP válido que contenha arquivos `acf-json/nt_book-1_chapter-1.json`, etc., conforme a estrutura do repositório `WilliamSampaio/acf`. O Android descompacta os arquivos localmente, remove a marcação HTML e guarda os capítulos com sua referência. Em seguida, é possível navegar pelos 66 livros, pesquisar palavras, ouvir os capítulos com a síntese de voz instalada e consultar os trechos nos devocionais offline. Se importar menos de 1189 capítulos, o leitor avisa que a importação é parcial.

A referência de numeração **do projeto ACF é Novo Testamento 1–27 e Antigo Testamento 28–66**, enquanto a navegação comum apresenta Antigo Testamento primeiro. O código mapeia essas duas ordens e testa os pontos críticos.

Os dados de anotações e progresso do APK 1.6.4 não são importados automaticamente para o pacote de teste 1.6.5; faça backup antes de substituir ou desinstalar versões anteriores. Spotify, YouTube, assistente IA externo e links web exigem conexão. A voz offline só funciona se o motor do Android tiver pacote local de pt-BR.

Executar testes estáticos: `node test_acf_offline.js && node test_v162.js && node test_app_v162.js && node test_deep.js && node test_dev_v164.js`. A validação de compilação e assinatura será feita via GitHub Actions. Os testes não substituem validação em dispositivo físico, especialmente o seletor SAF e o desempenho de importação.
