# Jardim da Palavra — Versão 1.6.13 (revisão de conteúdo)

Aplicativo Android de estudos bíblicos, leitura, devocionais e consulta pessoal da Harpa Cristã.

## Mudanças

- Dedicatória do criador, Diogo Oliveira, acessível na tela inicial e em Mais.
- 9 temas, incluindo Rosas, Aurora, Águas e Lavanda, com contraste auditado em 4 larguras de celular.
- 8 seminários originais com comentários, contexto, termos bíblicos, perspectivas e bibliografia.
- Títulos do índice da Harpa conferidos com o PDF fornecido; diferenciações de edição permanecem registradas no relatório interno.
- Revisões tipográficas conservadoras das letras; busca por número, título e palavras e editor pessoal preservados.
- Identificador de app de teste `.harpa172` mantido, versionCode 173, para atualização com a mesma assinatura da edição pessoal anterior.

## Limites

O repositório público **não inclui** a Bíblia ACF integral nem as letras completas da Harpa; ambas estão sujeitas a termos de direitos autorais. Uma edição pessoal pode ser preparada a partir de arquivos fornecidos pelo usuário, sem publicação ou redistribuição. A obtenção de autorização não foi confirmada. Não há modelo de IA generativo local nem voz neural exclusiva da Dora; a leitura usa TTS do Android. A instalação e a locução no aparelho físico precisam ser confirmadas.

## Testes

`node test_173.js` e os testes anteriores de regressão; Playwright em 9 temas x 4 tamanhos de tela. Para gerar APK, compilação GitHub Actions com Gradle e Java 17.
