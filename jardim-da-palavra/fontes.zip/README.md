# Jardim da Palavra — 1.6.7 (revisão final de testes)

APK Android de testes com pesquisa teológica e assistente local integrado (não é modelo generativo), 52 disciplinas/156 aulas, 17 cadernos originais, devocional guiado de cinco etapas, links de louvor Spotify/YouTube, leitura bíblica ACF via importação pessoal de ZIP autorizado e narração com vozes instaladas no Android.

## Melhorias sobre a versão 1.6.6

- Exportar e importar backup JSON **como arquivo do celular**, sem depender de copiar o conteúdo para a área de transferência, usando seletor nativo Android. Continua compatível com JSON da 1.6.6 e versões anteriores.
- Ao tocar na notificação de devocional, abrir diretamente as cinco etapas, inclusive se o app já estiver em execução.
- Preferir vozes pt-BR **offline** quando a seleção estiver no modo Automática; permitir seleção manual de outras vozes disponíveis, inclusive online.
- Preservar/restaurar o acervo bíblico anterior se uma importação de ZIP tiver sido interrompida num estágio intermediário.
- Pressionar Voltar na tela inicial permite sair; nas telas internas, retorna aos níveis anteriores.
- Validação reforçada no backup, temas e campos opcionais, mantendo anotações e estudos anteriores. O backup **não inclui os capítulos ACF** porque estes são armazenados à parte e precisam ser importados novamente.

## Limitações e conformidade

**Atenção:** Bíblia ACF integral **não está incluída** no APK. A solicitação de licença SBTB, protocolo 20261119-000001, foi recebida, mas nenhuma autorização foi concedida até a verificação atual. A importação de cópia legalmente obtida pelo próprio usuário é um recurso técnico, não uma licença de redistribuição.

**Dora** usa o sistema TTS Android; não é uma voz neural proprietária criada para este app. Algumas vozes de melhor qualidade podem exigir internet. O assistente é recuperação de conteúdo e respostas extrativas orientadas por fontes; não implementa IA generativa local. Spotify e YouTube exigem conexão.

Este APK é uma versão de testes assinada por certificado **debug** temporário. O identificador Android 1.6.7 é `com.diogo.jardimbibliaseestudos.acf167`, diferente do app original e dos testes anteriores para evitar conflito de assinatura. As anotações não migram automaticamente por isso: no app antigo use **Mais > Mostrar backup JSON**, copie o texto, depois no 1.6.7 use **Mais > Mostrar ou colar backup JSON > Restaurar**. A partir da 1.6.7 é possível salvar e abrir diretamente um arquivo de backup. Os lembretes devem ser reativados após restaurar backup.

Não é uma versão de produção Google Play, nem atesta teste em Samsung físico. O build e os testes automatizados devem passar no GitHub Actions. A distribuição futura deve usar assinatura permanente e trilha de atualização do pacote original.

## Testes

`node test_backup_167.js` e `python qa_browser_167.py` validam backup, compatibilidade com backup anterior, encaminhamento por notificação, telas, temas, devocional e ausência de rolagem horizontal. Rodar os testes anteriores `node test_*.js` para regressão do acervo e leitor bíblico.
