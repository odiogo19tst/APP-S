# Jardim da Palavra — v1.6.1 | Estudos Exegéticos

## O que foi acrescentado

- 52 dossiês de estudo bíblico e teológico, um por disciplina, integrados às **156 aulas existentes**.
- Cada aula mantém seu conteúdo e atividade originais e passa a exibir: passagem central, tradução de trabalho ou síntese explicativa **de autoria deste projeto**, contexto histórico e literário, comentário, vocabulário hebraico/grego quando pertinente, referências cruzadas, orientação metodológica e leituras de aprofundamento.
- As 156 aulas preservam respostas e progresso. As 3 aulas de uma disciplina compartilham o dossiê central, mas mantêm títulos, explicações, atividades e avaliações distintos; **não são 156 comentários exegéticos independentes**.
- A função Dora continua a narrar o conteúdo exibido usando o mecanismo de síntese de voz escolhido no Android.
- Links para consultar a Bíblia ACF em serviço externo autorizado e o STEP Bible para estudo de línguas originais.

## Direitos e rigor

A **Almeida Corrigida Fiel (ACF)**, de titularidade da Sociedade Bíblica Trinitariana do Brasil, **não foi incorporada integralmente** a este pacote. O texto identificado como *tradução de estudo* ou *síntese explicativa* é uma formulação original em português, NÃO uma reprodução ou uma edição oficial da ACF. O aplicativo permanece com a ACF como preferência de leitura, com link para consulta externa.

As indicações de livros são bibliografia recomendada, e **não** prova de que cada proposição tenha sido auditada página a página. As palavras bíblicas e glossas devem ser verificadas no contexto das passagens, e não usadas isoladamente para estabelecer doutrinas. Este é um curso livre, sem certificação acadêmica/MEC.

## Testes

`node test_deep.js` valida os 52 dossiês e as 156 telas de aula, conferindo se há contexto, comentário, léxico, referências, bibliografia e controle de narração.

O APK é gerado por GitHub Actions (Android SDK 35, Java 17, Gradle 8.9):

`gradle :app:assembleDebug`

Pacote de teste separado: `com.diogo.jardimbibliaseestudos.curso161`.

## Material de referência

- Bíblia ACF e política de uso: https://www.biblias.com.br/direitos-autorais
- Leitura online ACF (com licença atribuída pelo serviço): https://www.bibliaonline.com.br/acf
- Ferramentas de grego/hebraico: https://www.stepbible.org/
