# Jardim da Palavra — 1.6.3 | Versão revisada de teste

## Correções verificadas nesta revisão

- Respostas de aulas, avaliações e rascunhos de notas são salvos automaticamente durante a digitação; o botão **Guardar reflexão** arquiva a nota definitivamente.
- Retomada de aula volta ao ponto de rolagem salvo, evitando perder a posição em aulas longas.
- Reconhecimento de nomes bíblicos sem acentuação, como **Miqueias** e **Miquéias**.
- Botão de leitura ACF na web indica seu destino corretamente. Links diretos verificados para Salmos, Gênesis, Miquéias e 1 João; outros livros usam a lista de livros, para não criar endereços inválidos.
- Importação de backup mais tolerante a dados legados e seleção TTS que evita selecionar voz marcada como não instalada.
- Interface retém os **31 louvores** do devocional, com busca Spotify e YouTube; os **52 dossiês** de Teologia; **156 aulas**; e as **45 apostilas expandidas** em 15 disciplinas.

## Como reproduzir os testes

```bash
node test_v162.js
node test_app_v162.js
node test_deep.js
python qa_browser.py
```

A suíte E2E usa Chromium sem chamadas de rede: verifica navegação, salvamento, backup, links, leitura, e renderização de todas as 156 aulas. O APK é compilado com GitHub Actions, que também executa `apksigner verify` e `aapt dump badging`.

## Instalação

Esta é uma nova build Android **de teste**, com identificador `com.diogo.jardimbibliaseestudos.curso163`, separada do Jardim original e das versões 1.6.0–1.6.2. Por isso **não migra automaticamente os dados** dos outros APKs. Exporte/copiei o backup JSON do aplicativo antigo e restaure-o nesta versão, quando necessário. Não exclua o aplicativo original.

**Não é a versão de produção assinada pela chave de publicação da Play Store.** Para futuras atualizações no mesmo pacote, é necessário configurar uma chave de assinatura persistente em local privado e protegido (por exemplo, GitHub Actions Secrets). Não há garantia de atualização por cima dos testes atuais.

## Limitações conhecidas

- Voz neural exclusiva da Dora: não implantada; a narração usa o mecanismo TTS do Android.
- Texto integral da Bíblia ACF offline: não incluído por restrições de reprodução; leitura integral via SBTB/Bíblia Online.
- O aplicativo inclui 45 capítulos aprofundados em 15 disciplinas. As outras 37 disciplinas têm dossiês menores; não é um bacharelado completo ou reconhecido.
- Assistente de IA: depende do site original; não há API paga nem modelo de IA local embutido.
- Louvores abrem buscas nas plataformas, não reproduzem áudio no aplicativo.
- Notificações são aproximadas (economia de bateria / permissão do Android).
- A compilação e os testes locais **não substituem** um teste físico de instalação, notificações e voz em aparelho Samsung.
- Bibliografia é sugestão de pesquisa; citações de edições/páginas ainda precisam de auditoria acadêmica.
