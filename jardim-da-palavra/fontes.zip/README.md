# Jardim da Palavra — Android (base de recuperação)

Esta pasta contém um **novo projeto de recuperação** criado a partir do escopo do app anterior. Não é uma exportação do código original da Play Store: o código-fonte e a chave de assinatura dessa edição não estão disponíveis aqui.

## O que funciona nesta base

- Interface Android com WebView local, acesso offline ao catálogo autoral de **40 estudos bíblicos**, seus contextos, aplicações e perguntas.
- Índice dos 66 livros bíblicos, capítulos e preferência ACF persistida. A reprodução integral da ACF é feita por redirecionamento ao **aplicativo oficial** da SBTB; o texto integral não vem embutido sem licença.
- 31 roteiros originais de devocionais de 10 minutos, com escolha do dia pelo calendário; o cartão do dia muda todos os dias.
- Narração pelo TTS do Android, quando disponível, com botão em todas as telas, velocidade ajustável e leitura automática opcional. **Não é a voz neural personalizada “Dora”** da versão anterior.
- Lembrete diário configurável, inicialmente 07:00, implementado com AlarmManager e notificações (aproximado; pode sofrer atrasos do Android).
- Cinco temas de cores, tamanho da fonte, 40 marcadores de estudos, notas do usuário, exportação/restauração de backup JSON por copiar e colar.
- Voltar do índice bíblico para o mesmo estudo e retomar o último estudo após reabrir.
- Links para o site publicado, seu assistente de IA e para músicas no Spotify; IA online não duplicada no APK para evitar incluir credenciais e gastos.
- Código-fonte sem bibliotecas adicionais para o app Android além do Android Gradle Plugin.

## Geração do APK de teste (GitHub Actions)

1. Coloque **todo o conteúdo desta pasta** na raiz de um repositório GitHub seu (de preferência privado).
2. Abra **Actions → Android APK de teste → Run workflow**.
3. Aguarde o término do workflow, abra a execução e baixe o artefato **Jardim-da-Palavra-debug-apk**.
4. Extraia o ZIP do artefato e instale o arquivo `app-debug.apk` no Android.

O APK de teste usa o ID `com.diogo.jardimbibliaseestudos.dev`, podendo ser instalado **ao lado** da versão original sem apagá-la. Esta base não é uma atualização da versão da Play Store. Para gerar atualização com o ID oficial `com.diogo.jardimbibliaseestudos`, é indispensável recuperar o código/release completo e configurar a **assinatura correta** (Play App Signing/chave de upload).

## Geração local (caso tenha Android Studio)

Abra a pasta no Android Studio, permita que ele sincronize as dependências e selecione **Build → Build APK(s)**, tipo Debug. Requisitos: JDK 17, SDK Android 35 e Gradle 8.9. O projeto utiliza AGP 8.7.3. Ou use terminal com Gradle 8.9: `gradle :app:assembleDebug`.

## Privacidade, direitos e limites

- Notas e progresso locais ficam somente no aparelho. O backup é um JSON de texto **sem criptografia**, mantenha-o em local privado.
- A ACF possui direitos reservados da Sociedade Bíblica Trinitariana do Brasil (SBTB); a autorização para citar trechos é limitada e não equivale a autorização para redistribuir sua Bíblia inteira. Fonte: https://www.biblias.com.br/direitos-autorais
- Outras traduções (Bíblia Livre e Almeida 1819) apontam ao **site original**, e não são embutidas neste projeto.
- Lembretes dependem da permissão do Android para notificações e podem ocorrer com atraso (modo economia de bateria).
- A narração usa a voz TTS configurada no aparelho e não lê integralmente as traduções bíblicas que não foram incorporadas ao APK. A voz "Dora" neural offline não foi recuperada.
- A IA do original é aberta pelo site existente. Não foi recriada sem fonte nem API.
- Compilação Android não foi executada no ambiente de geração, pois o SDK/Gradle Android não estão instalados nele. O projeto foi validado com verificações estáticas e fluxo da interface por navegador headless.

## Estrutura

- `app/src/main/assets/`: tela, estilo, lógica e dados autorais locais
- `app/src/main/java/`: Activity, notificações, reinício e narração nativa
- `app/src/main/AndroidManifest.xml`: permissões e componentes Android
- `.github/workflows/android-debug.yml`: compilação e entrega de APK de teste
- `make_data.py`: gerador do catálogo de estudos/roteiros

**Não apague o aplicativo original** para instalar este projeto de teste. Ele não usa a mesma assinatura da versão instalada.
