# Jardim da Palavra — Android (base de recuperação)

Esta pasta contém um **novo projeto de recuperação** criado a partir do escopo do app anterior. Não é uma exportação do código original da Play Store: o código-fonte e a chave de assinatura dessa edição não estão disponíveis aqui.

## O que funciona nesta base

- Interface Android com WebView local, acesso offline ao catálogo autoral de **40 estudos bíblicos** e ao **curso livre de Teologia com 5 eixos, 52 disciplinas e 156 aulas**, seus contextos, aplicações e perguntas.
- Índice dos 66 livros bíblicos, capítulos e preferência ACF persistida. A reprodução integral da ACF é feita por redirecionamento ao **aplicativo oficial** da SBTB; o texto integral não vem embutido sem licença.
- 31 roteiros originais de devocionais de 10 minutos, com escolha do dia pelo calendário; o cartão do dia muda todos os dias.
- Narração dinâmica Dora pelo TTS do Android: lê diretamente o texto das telas, permite escolher mecanismo Google/Samsung (quando instalados), vozes pt-BR, qualidade, velocidade e tom; leitura automática opcional. **Não é o timbre neural exclusivo da Dora** da versão anterior.
- Lembrete diário configurável, inicialmente 07:00, implementado com AlarmManager e notificações (aproximado; pode sofrer atrasos do Android).
- Cinco temas de cores, tamanho da fonte, 40 marcadores de estudos, notas do usuário, exportação/restauração de backup JSON por copiar e colar.
- Curso livre de 156 aulas com objetivos, leituras, aplicação, questões e respostas de referência. Avanço por aula, avaliações formativas com três perguntas discursivas por disciplina e retomada após reabrir. **Não emite diploma de graduação nem certificado reconhecido pelo MEC.**
- Voltar do índice bíblico para o mesmo estudo e retomar o último estudo após reabrir.
- Links para o site publicado, seu assistente de IA e para músicas no Spotify; IA online não duplicada no APK para evitar incluir credenciais e gastos.
- Código-fonte sem bibliotecas adicionais para o app Android além do Android Gradle Plugin.

## Geração do APK de teste (GitHub Actions)

1. Coloque **todo o conteúdo desta pasta** na raiz de um repositório GitHub seu (de preferência privado).
2. Abra **Actions → Android APK de teste → Run workflow**.
3. Aguarde o término do workflow, abra a execução e baixe o artefato **Jardim-da-Palavra-debug-apk**.
4. Extraia o ZIP do artefato e instale o arquivo `app-debug.apk` no Android.

O APK de teste usa o ID `com.diogo.jardimbibliaseestudos.curso160`, podendo ser instalado **ao lado** da versão original sem apagá-la. Esta base não é uma atualização da versão da Play Store. Para gerar atualização com o ID oficial `com.diogo.jardimbibliaseestudos`, é indispensável recuperar o código/release completo e configurar a **assinatura correta** (Play App Signing/chave de upload).

## Geração local (caso tenha Android Studio)

Abra a pasta no Android Studio, permita que ele sincronize as dependências e selecione **Build → Build APK(s)**, tipo Debug. Requisitos: JDK 17, SDK Android 35 e Gradle 8.9. O projeto utiliza AGP 8.7.3. Ou use terminal com Gradle 8.9: `gradle :app:assembleDebug`.

## Privacidade, direitos e limites

- Notas e progresso locais ficam somente no aparelho. O backup é um JSON de texto **sem criptografia**, mantenha-o em local privado.
- A ACF possui direitos reservados da Sociedade Bíblica Trinitariana do Brasil (SBTB); a autorização para citar trechos é limitada e não equivale a autorização para redistribuir sua Bíblia inteira. Fonte: https://www.biblias.com.br/direitos-autorais
- Outras traduções (Bíblia Livre e Almeida 1819) apontam ao **site original**, e não são embutidas neste projeto.
- Lembretes dependem da permissão do Android para notificações e podem ocorrer com atraso (modo economia de bateria).
- A narração usa as vozes TTS efetivamente instaladas no celular, sem API paga e sem mapear palavras; vozes online dependem do mecanismo de TTS e da conexão. Não lê traduções bíblicas integrais que não foram incorporadas. O timbre neural exclusivo da Dora ainda não foi recuperado.
- A IA do original é aberta pelo site existente. Não foi recriada sem fonte nem API.
- Neste ambiente local não há SDK/Gradle; o APK pode ser compilado pelo GitHub Actions. A interface do curso foi validada com verificações estáticas e testes automatizados de lógica; o APK final requer teste físico.

## Estrutura

- `app/src/main/assets/`: tela, estilo, lógica e dados autorais locais
- `app/src/main/java/`: Activity, notificações, reinício e narração nativa
- `app/src/main/AndroidManifest.xml`: permissões e componentes Android
- `.github/workflows/android-debug.yml`: compilação e entrega de APK de teste
- `make_data.py`: gerador do catálogo de estudos/roteiros
- `app/src/main/assets/curso_data.js`: trilha curricular autoral com 52 disciplinas e 156 aulas
- `app/src/main/assets/curso_ui.js`: telas, avaliações e progresso do curso

**Não apague o aplicativo original** para instalar este projeto de teste. Ele não usa a mesma assinatura da versão instalada.
