# Jardim da Palavra — 1.6.2 | Apostilas e Louvor

## Alterações desta versão

- **Restauração do louvor diário:** 31 sugestões temáticas, uma por devocional, com links funcionais para as buscas do Spotify e do YouTube. Não há cópia, reprodução interna nem download de áudio/ letras. O louvor é opcional e aparece após o roteiro de dez minutos.
- **Apostilas novas e exclusivas:** 15 disciplinas receberam **45 capítulos originais distintos**, com explicação, comentário, comparações, exercícios de análise e bibliografia. Aproximadamente 9 mil palavras de material adicional foram integradas nesta etapa.
- As **52 disciplinas e 156 aulas** originais continuam com os **52 dossiês** de exegese, referências cruzadas, vocabulário bíblico, perguntas, avaliação e progresso salvo. O acréscimo profundo foi feito em 45 aulas, e não nas 156 por igual.
- A narradora Dora usa Text-to-Speech disponível no Android e pode ler os capítulos exibidos; o timbre exclusivo da Dora continua não implementado.
- Os textos bíblicos da ACF integral continuam acessados fora do app porque não temos autorização de reprodução integral.

## Disciplinas com apostilas ampliadas

Introdução ao Antigo Testamento, Introdução ao Novo Testamento, Hermenêutica Bíblica, Exegese e Crítica Textual, Grego Bíblico, Hebraico Bíblico, Cristologia, Pneumatologia, Soteriologia, Teologia Pentecostal, Patrística, Reforma e Pós-Reforma, Apologética, Homilética e Metodologia de Pesquisa Científica.

## Instalação e segurança

- Identificador de teste: `com.diogo.jardimbibliaseestudos.curso162`. Instalação separada evita conflito de assinatura com testes anteriores. Os dados de outros pacotes **não são migrados automaticamente**; use backup JSON quando aplicável.
- APK de teste compilado por GitHub Actions. **Não é um pacote de produção assinado com a chave da Play Store**.
- O uso do Spotify/YouTube depende de internet e da disponibilidade de cada plataforma e gravação.
- Curso livre; não emite diploma de graduação reconhecido pelo MEC.

## Testes locais

`node test_v162.js`: confere 52 disciplinas, 156 aulas, 52 dossiês, 45 apostilas distintas e 31 músicas.

`node test_app_v162.js`: confere HTML do devocional, links externos e interface geral do curso.

`gradle :app:assembleDebug`: compilação Android em CI.

## Fontes e direitos

Não houve transcrição integral de livros, comentários, letras ou gravações comerciais. As apostilas são textos originais acompanhados de indicações bibliográficas, **não citações verificadas por edição/página**. Para consulta da ACF: https://www.bibliaonline.com.br/acf ; instrumentos de línguas originais: https://www.stepbible.org/. Para músicas: apenas links de busca nas plataformas oficiais, permitindo ao usuário escolher a gravação.
