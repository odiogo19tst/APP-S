# Jardim da Palavra 1.6.6 — Assistente integrado, visual refinado e cadernos originais

Versão de teste Android com assistente de pesquisa **dentro do aplicativo**. Ele realiza **recuperação lexical de informação do acervo** (52 disciplinas, 156 aulas, 40 estudos, 17 novos cadernos e dossiês). Mostra fontes e permite abrir as aulas citadas. **Não é um modelo de linguagem generativo**: sem backend ou modelo local instalado, não promete gerar respostas livres com raciocínio de IA. É gratuito e não envia perguntas a servidor.

Inclui cinco temas redesenhados (Orquídea, Bosque, Azul Sereno, Pergaminho e Noite), cartões mais legíveis, leitor bíblico ACF por importação pessoal offline, devocional de 5 etapas, música Spotify/YouTube, TTS Dora via voz Android e backup. Preserva as funcionalidades da 1.6.5, mas o novo identificador Android `com.diogo.jardimbibliaseestudos.acf166` **não migra automaticamente** as anotações do app anterior. Exportar e importar backup JSON. Certifique-se de que a permissão de redistribuição da ACF esteja formalmente concedida antes de incluí-la em qualquer APK distribuído.

A referência pública https://apostilasdeteologia.com/ oferece grade comercial de apostilas (indicada no site para compra), **não** conteúdo livre integral. A versão 1.6.6 foi reorganizada considerando temas gerais clássicos da formação teológica e inclui **textos novos escritos para o projeto**; nenhuma apostila paga foi copiada ou distribuída. Não confundir a quantidade de cadernos novos com 60 apostilas completas licenciadas ou um curso superior credenciado.

## Testes

```
node test_assistente_166.js
node test_acf_offline.js
node test_v162.js
node test_app_v162.js
node test_deep.js
node test_dev_v164.js
python qa_166.py
python qa_browser.py
```

Compilação Android via GitHub Actions (`gradle --no-daemon :app:assembleDebug` Java 17 / Android SDK 35). APK debug com assinatura v2. Para atualização estável no mesmo aplicativo de produção, é necessária uma chave de assinatura permanente protegida; os builds de debug em runners diferentes podem ter chaves diferentes.
