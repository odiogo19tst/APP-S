from playwright.sync_api import sync_playwright
from pathlib import Path
import re
A=Path(__file__).parent/'app/src/main/assets'
s=(A/'index.html').read_text().replace('<link rel="stylesheet" href="style.css" />','<style>'+ (A/'style.css').read_text()+'</style>')
for f in re.findall(r'<script src="(.*?)"></script>',s):
    s=s.replace(f'<script src="{f}"></script>','<script>'+ (A/f).read_text()+'</script>')
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':380,'height':780},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(s,wait_until='load')
    page.locator('button[data-tab="harpa"]').first.click()
    assert page.get_by_text('Harpa Cristã',exact=True).count()>0
    page.locator('#harpa-search').fill('chuvas')
    page.locator('#harpa-results button[data-n="1"]').click()
    assert page.get_by_text('Letra ainda não disponível').count()==1
    page.locator('button[data-action="harpa-editor"]').first.click()
    page.locator('#harpa-lyric-edit').fill('Primeira estrofe\nDeus é bom\n\nRefrão\nCantamos juntos')
    page.locator('button[data-action="harpa-save"]').click()
    assert 'Deus é bom' in page.locator('.harpa-lyrics-view').inner_text()
    assert page.get_by_text('Transposição').count()==0
    page.locator('button[data-action="harpa-fav"]').click()
    assert page.get_by_text('♥ Favorito').count()==1
    page.screenshot(path='/mnt/data/Jardim_Harpa_170_Normal_PREVIA.png',full_page=True)
    assert not errors,errors
    print('PASS interface Harpa normal, busca, leitura, editor de letra, favoritos; zero erros JS')
    browser.close()
