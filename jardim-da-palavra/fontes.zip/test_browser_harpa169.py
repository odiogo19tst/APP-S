from playwright.sync_api import sync_playwright
from pathlib import Path
import re
A=Path('/mnt/data/Jardim_169_Harpa_Build/app/src/main/assets')
s=(A/'index.html').read_text()
s=s.replace('<link rel="stylesheet" href="style.css" />','<style>'+ (A/'style.css').read_text()+'</style>')
for f in re.findall(r'<script src="(.*?)"></script>',s):
 s=s.replace(f'<script src="{f}"></script>','<script>'+ (A/f).read_text()+'</script>')
with sync_playwright() as playwright:
    browser=playwright.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
    page=browser.new_page(viewport={'width':380,'height':780},device_scale_factor=1)
    errors=[]
    page.on('pageerror',lambda e:errors.append(str(e)))
    page.set_content(s,wait_until='load')
    page.locator('button[data-tab="harpa"]').first.click()
    assert page.get_by_text('Harpa Cristã',exact=True).count()>0
    assert page.locator('#harpa-results').count()==1
    page.locator('#harpa-search').fill('chuvas')
    assert page.locator('#harpa-results button[data-n="1"]').count()==1
    page.locator('#harpa-results button[data-n="1"]').click()
    assert page.get_by_text('Cifra não cadastrada neste aparelho').count()==1
    page.locator('button[data-action="harpa-editor"]').first.click()
    page.locator('#harpa-chart-edit').fill('[C]Chuva de [G]graça\n[Am]Alelui[F]a')
    page.locator('button[data-action="harpa-save"]').click()
    assert page.locator('.harpa-chart-view .harpa-chord').count()==4
    page.locator('button[data-action="harpa-up"]').click()
    assert page.locator('.harpa-chart-view .harpa-chord').first.inner_text()=='C#'
    page.locator('button[data-action="harpa-fav"]').click()
    page.screenshot(path='/mnt/data/Jardim_Harpa_169_Preview.png',full_page=True)
    assert not errors,errors
    print('PASS navegador 380px, cifra salva, favoritos, transposição e zero erros JS')
    browser.close()
