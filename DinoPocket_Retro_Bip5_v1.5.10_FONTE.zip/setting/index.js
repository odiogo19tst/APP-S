import { DEFAULT_SETTINGS, PHONE_SETTINGS_KEY, PHONE_REV_KEY, normalizeSettings, updateSettings } from '../src/phone_settings'

// Roda dentro do Zepp no smartphone; atualizacoes sao sincronizadas pelo app-side.
AppSettingsPage({
  build(props) {
    const storage=props.settingsStorage
    const current=normalizeSettings(storage.getItem(PHONE_SETTINGS_KEY))
    const save=(patch)=>{
      const next=updateSettings(current,patch)
      const currentRev=Number(storage.getItem(PHONE_REV_KEY)) || 0
      const nextRev=Math.max(Date.now(),currentRev+1)
      storage.setItem(PHONE_SETTINGS_KEY,JSON.stringify(next))
      storage.setItem(PHONE_REV_KEY,String(nextRev))
    }
    const label=(value)=>Text({style:{fontSize:'14px',color:'#405446',padding:'5px 0'}},value)
    const section=(title,children)=>View({style:{background:'#ffffff',padding:'14px',borderRadius:'14px',marginBottom:'12px'}},[
      Text({bold:true,style:{fontSize:'16px',color:'#183e32',marginBottom:'8px'}},title),...children
    ])
    return View({style:{padding:'16px',background:'#eef5e8'}},[
      Text({bold:true,style:{fontSize:'23px',color:'#183e32',marginBottom:'6px'}},'DinoPocket Retro'),
      label('Central de configuracoes | Zepp + Bip 5'),
      section('Evolucao',[
        Select({title:'Modo de evolucao',label:'Modo',value:current.mode,
          options:[{name:'Classico (alimentacao)',value:'classic'},{name:'Personalizado (proxima evolucao)',value:'custom'},{name:'Livre (proxima evolucao)',value:'free'}],
          onChange:(value)=>save({mode:value})}),
        Select({title:'Especie adulta desejada',label:'Especie',value:current.species,
          options:[{name:'Surpresa - dieta',value:'random'},{name:'T-Rex',value:'rex'},{name:'Brontossauro',value:'bronto'},{name:'Triceratopo',value:'trike'}],
          onChange:(value)=>save({species:value})}),
        label('Etapas de evolucao: 5 (ovo > bebe > pequeno > jovem > adulto).'),
        label('Modo classico ignora escolha de especie. Nos outros modos, especie escolhida so vale na proxima evolucao natural para adulto.'),
      ]),
      section('Interacao e avisos',[
        label('No Bip 5 (Zepp OS 2.1): som e movimento do pulso indisponiveis.'),
        Toggle({label:'Alertas de cuidados no jogo',value:current.alerts,onChange:(value)=>save({alerts:value})}),
      ]),
      section('Progresso protegido',[
        label('As preferencias sao armazenadas separadamente do ovo, idade, personalidade e geracao.'),
        label('Sincroniza quando o Zepp esta conectado e o jogo e aberto. Sem conexao: usa a ultima configuracao salva.'),
        Button({label:'Restaurar preferencias padrao',color:'secondary',onClick:()=>save(DEFAULT_SETTINGS)})
      ])
    ])
  }
})
