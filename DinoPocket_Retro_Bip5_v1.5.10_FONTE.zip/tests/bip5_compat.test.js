import test from 'node:test'
import assert from 'node:assert/strict'
import {readFileSync} from 'node:fs'
const app=JSON.parse(readFileSync(new URL('../app.json',import.meta.url)))
const code=readFileSync(new URL('../page/index.js',import.meta.url),'utf8')
test('Bip 5 original is targeted only with Zepp OS 2.1 and 320x380',()=>{
  assert.equal(app.configVersion,'v2')
  assert.equal(app.runtime.apiVersion.minVersion,'2.0')
  assert.equal(app.runtime.apiVersion.target,'2.1')
  const target=app.targets['320x380-bip5']
  assert.ok(target)
  assert.deepEqual(target.platforms.map(x=>x.deviceSource),[8454400,8454401])
  assert.equal(target.designWidth,320)
  assert.equal(app.app.appId,29318764)
  assert.deepEqual(app.app.version,{name:'1.5.10',code:17})
})
test('Bip 5 contains no runtime import requiring API 3.0',()=>{
  assert.ok(!code.includes("from '@zos/media'"))
  assert.ok(!code.includes('new Accelerometer()'))
  assert.ok(!code.includes('FREQ_MODE_NORMAL'))
  assert.ok(code.includes("'dinopocket.state.v1'"))
  assert.ok(code.includes("tap('TESTES'"))
  assert.ok(code.includes('scaledOptions(options)'))
})
