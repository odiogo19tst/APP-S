import test from 'node:test'
import assert from 'node:assert/strict'
import vm from 'node:vm'
import { readFileSync } from 'node:fs'
import {
  PHONE_SETTINGS_KEY, PHONE_REV_KEY,DEFAULT_SETTINGS,
  normalizeSettings,updateSettings,encodePacket,decodePacket,makeEnvelope
} from '../src/phone_settings.js'

const pure={PHONE_SETTINGS_KEY,PHONE_REV_KEY,DEFAULT_SETTINGS,normalizeSettings,updateSettings,encodePacket,decodePacket,makeEnvelope}
function render(code,globals){
  const source=readFileSync(new URL(code,import.meta.url),'utf8').replace(/^import .*\n/gm,'')
  vm.runInNewContext(source,{...globals,...pure, console,Date,JSON,Number,Array,Uint8Array,ArrayBuffer,Math})
}
function children(view){
  const list=[]
  function walk(item){if(!item)return; if(Array.isArray(item)){item.forEach(walk);return}if(typeof item==='object'){list.push(item);walk(item.children)}}
  walk(view)
  return list
}
function mockStorage(){
 const values=new Map();const handlers=[]
 return {
  getItem:(key)=>values.get(key)||null,
  setItem:(key,value)=>{const oldValue=values.get(key)||null;values.set(key,value);handlers.forEach(h=>h({key,newValue:value,oldValue}))},
  addListener:(event,h)=>{if(event==='change')handlers.push(h)},
  removeListener:(event,h)=>{const i=handlers.indexOf(h);if(i>=0)handlers.splice(i,1)}
 }
}
test('Settings UI stores configuration independently, Side Service propagates it',()=>{
  const storage=mockStorage();let page=null,service=null,fromWatch=null
  const received=[]
  const makeNode=(type)=> (props={}, kids)=>({type,props,children:kids})
  render('../setting/index.js',{
    AppSettingsPage:(def)=>{page=def},
    View:makeNode('View'),Text:makeNode('Text'),Select:makeNode('Select'),
    Toggle:makeNode('Toggle'),Button:makeNode('Button')
  })
  render('../app-side/index.js',{
    AppSideService:(def)=>{service=def},
    settings:{settingsStorage:storage},
    messaging:{peerSocket:{
      addListener:(event,cb)=>{if(event==='message')fromWatch=cb},
      removeListener:()=>{},
      send:(buf)=>{received.push(decodePacket(buf))}
    }}
  })
  service.onInit()
  let items=children(page.build({settingsStorage:storage}))
  const alerts=items.find(x=>x.type==='Toggle' && x.props.label==='Alertas de cuidados no jogo')
  assert.ok(alerts)
  assert.equal(items.some(x=>x.type==='Toggle' && x.props.label==='Sons do Dino'),false)
  alerts.props.onChange(false)
  assert.equal(normalizeSettings(storage.getItem(PHONE_SETTINGS_KEY)).alerts,false)
  assert.ok(Number(storage.getItem(PHONE_REV_KEY))>0)
  assert.ok(received.some(x=>x.type==='DINO_CONFIG' && x.config.alerts===false))
  items=children(page.build({settingsStorage:storage}))
  const mode=items.find(x=>x.type==='Select' && x.props.label==='Modo')
  mode.props.onChange('free')
  items=children(page.build({settingsStorage:storage}))
  items.find(x=>x.type==='Select' && x.props.label==='Especie').props.onChange('rex')
  assert.equal(normalizeSettings(storage.getItem(PHONE_SETTINGS_KEY)).species,'rex')
  const before=received.length
  fromWatch(encodePacket({type:'GET_DINO_CONFIG'}).buffer)
  assert.equal(received.length,before+1)
  assert.equal(received.at(-1).config.species,'rex')
  // Two-way: switch toggled on the watch, then transmitted to phone.
  fromWatch(encodePacket({type:'SET_DINO_CONFIG',patch:{sounds:true}}).buffer)
  assert.equal(normalizeSettings(storage.getItem(PHONE_SETTINGS_KEY)).sounds,true)
  service.onDestroy()
})
