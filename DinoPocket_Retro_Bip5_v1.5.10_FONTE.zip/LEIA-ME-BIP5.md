# DinoPocket Retro 1.5.10 — Amazfit Bip 5 original

**Relógio:** Amazfit Bip 5 (não é Bip 5 Unity), 320×380, Zepp OS 2.1.
**Identidade:** app ID 29318764, versão 1.5.10 (código 17).
**Armazenamento:** chave `dinopocket.state.v1`, schema 1. Não limpar dados para atualizar.

Ajustes: configVersion v2, deviceSource 8454400/8454401, 320x380 pixels.
Widgets escalados na mesma proporção, com margem vertical de 5px. Foram redimensionados todos os 982 PNGs com nearest-neighbor para manter pixel art.

**Funcionam no código:** salvar o Dino, cinco estágios (ovo→bebê→filhote→jovem→adulto), evolução natural, Menu→Mais→TESTES→Avançar evolução, cuidados, status, brincadeiras por toque, minijogo, vibração e configurações de evolução no Zepp.

**Limitações do Bip 5 original:** o áudio de `@zos/media` e a brincadeira com aceleração via `new Accelerometer` requerem API_LEVEL 3.0, não oferecido pelo Zepp OS 2.1. Estas funções ficam desligadas; o jogo utiliza vibração. Bip 5 Unity não está incluído neste alvo.

**Testes de software:** execute `npm test` nesta pasta. **Instalação física ainda não validada no Bip 5**; confirmação só após `zeus preview` e teste no relógio.

**Gerar QR de teste no Codespaces** (Zeus instalado):

```sh
cd /tmp/dinopocket-bip5
zeus preview
```

Após executar `zeus preview`, selecione Amazfit Bip 5 e use no Zepp o scanner QR de desenvolvedor. NÃO abra o ZIP como código texto nem use o ZIP como pacote de instalação; o Zeus compila o projeto. Use atualização sem desinstalar quando compatível para preservar progresso.
