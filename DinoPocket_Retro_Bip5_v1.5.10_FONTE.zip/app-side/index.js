import { DEFAULT_SETTINGS, PHONE_SETTINGS_KEY, PHONE_REV_KEY, normalizeSettings, encodePacket, decodePacket, makeEnvelope, updateSettings } from '../src/phone_settings'

// Roda no Zepp (celular). Ponte SettingsStorage <-> canal Bluetooth do app.
let listener=null
let messageListener=null
function readConfig() {
  let raw=null,rev=0
  try {raw=settings.settingsStorage.getItem(PHONE_SETTINGS_KEY)}catch(e){}
  try {rev=Number(settings.settingsStorage.getItem(PHONE_REV_KEY))||0}catch(e){}
  return makeEnvelope(normalizeSettings(raw),rev)
}
function sendConfig() {
  try {messaging.peerSocket.send(encodePacket(readConfig()).buffer)} catch(e) {
    // Se o Bip 5 nao estiver conectado, as preferencias ficam persistidas no Zepp.
  }
}
AppSideService({
  onInit() {
    messageListener=(data)=>{
      const message=decodePacket(data)
      if(message && message.type==='GET_DINO_CONFIG') sendConfig()
      if(message && message.type==='SET_DINO_CONFIG' && message.patch && typeof message.patch==='object'){
        // Opcao alterada no relogio. Zepp e a origem do relogio de revisoes.
        const old=readConfig()
        const next=updateSettings(old.config,{sounds:message.patch.sounds})
        const nextRev=Math.max(Date.now(),old.revision+1)
        try{
          settings.settingsStorage.setItem(PHONE_SETTINGS_KEY,JSON.stringify(next))
          settings.settingsStorage.setItem(PHONE_REV_KEY,String(nextRev))
        }catch(e){}
        sendConfig()
      }
    }
    listener=({key})=>{
      if(key===PHONE_SETTINGS_KEY || key===PHONE_REV_KEY) sendConfig()
    }
    try {messaging.peerSocket.addListener('message',messageListener)} catch(e){}
    try {settings.settingsStorage.addListener('change',listener)} catch(e){}
  },
  onRun(){},
  onDestroy(){
    try {if(listener) settings.settingsStorage.removeListener('change',listener)} catch(e){}
    try {if(messageListener) messaging.peerSocket.removeListener('message',messageListener)} catch(e){}
  }
})
