import { createWidget, deleteWidget, widget, align, text_style, prop, anim_status, event } from '@zos/ui'
import { LocalStorage } from '@zos/storage'
import { advanceForTest } from '../src/advance_for_test'
import { cleanCare, giveDessert, playGuess, playParity, questionFor, answerStudy, sceneFor } from '../src/expansion'
import { createConnect, disConnect, send as sendBluetooth } from '@zos/ble'
import { DEFAULT_SETTINGS, DEVICE_SETTINGS_KEY, normalizeSettings, normalizeEnvelope, encodePacket, decodePacket, shouldAccept, adjustNaturalEvolution } from '../src/phone_settings'
import { Accelerometer, FREQ_MODE_NORMAL, Vibrator, VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_NOTIFICATION } from '@zos/sensor'
import { create as createMedia, id as mediaId } from '@zos/media'
import { FX, entryCue, feedbackForAction, shouldPlaySound, feedbackSettings, isQuietHour, expressiveCue, soundMode } from '../src/sound_rules'
import { createHoldDetector } from '../src/touch_rules'
import { characterStem, restingPose, actionPose } from '../src/visual_rules'
import {
  newGame, revive, spriteName, describe, speciesName,
  act, enhance, advance, setPause, isPaused, needsAttention,
  giveDiscipline, setTemperature, playRps, petAgeString,
  createShakeDetector, wristInteraction, personalityOf, personalityMessage, touchInteraction
} from '../src/game'

// DinoPocket v1.5 - sprites animados, pet vivo, sons suaves e cuidados ampliados.
// Apenas componentes oficiais Zepp OS. O progresso da v1.0/v1.1 e mantido.
const COLOR = {
  bg:0x142831, shell:0x376b70, lcd:0xf4f4dc, white:0xffffff,
  light:0xfcf9e9, ink:0x243f42, shade:0x94c6b8,
  button:0x357f81, pressed:0x216c72, alert:0xbb4e42, text:0xffffff
}
const store = new LocalStorage()
const KEY = 'dinopocket.state.v1'
let pet = null
let dinoConfig = normalizeSettings(store.getItem(DEVICE_SETTINGS_KEY, DEFAULT_SETTINGS))
let configRevision=Number(store.getItem(DEVICE_SETTINGS_KEY+'.rev',0))||0
let bleStarted=false
let configRequestTimers=[]
let controls = []
let screen = 'home'
let result = ''
let lastAction = ''
let reactionAction = ''
let reactionOpponent = ''
let motion = null
let motionCallback = null
let player = null
let vibrator = null
let currentSound = null
let pendingStartupCue = null
let holdTimer = null
let speechTimer = null
let lifeTimer = null
let speechLine = ''
let voiceIndex = 0
let activeQuiz = null
let parityChoice = 'par'
const touchDetector = createHoldDetector(700, 26)

function initFeedback() {
  try {
    if (!player) {
      player = createMedia(mediaId.PLAYER)
      player.addEventListener(player.event.PREPARE, (ready) => {
        if(ready) { try { player.start() } catch(e) {} }
      })
      player.addEventListener(player.event.COMPLETE, () => {
        try { player.stop() } catch(e) {}
      })
    }
  } catch(e) { player = null }
  try { if (!vibrator) vibrator = new Vibrator() } catch(e) { vibrator = null }
}
function feedback(cue, passive=false) {
  if(!cue || !pet || pet.dead || isPaused(pet)) return
  const pref=feedbackSettings(pet)
  // Night silence on passive reminders; user-initiated actions can still sound.
  if(passive && (!dinoConfig.alerts || isQuietHour(new Date()))) return
  if(pref.vibration && vibrator) {
    try { vibrator.start({mode: cue===FX.alert || cue===FX.sick ? VIBRATOR_SCENE_NOTIFICATION : VIBRATOR_SCENE_SHORT_LIGHT}) } catch(e) {}
  }
  if(!dinoConfig.sounds || !shouldPlaySound({...pet,soundEnabled:true},passive) || !player) return
  const selected=expressiveCue(pet,cue,personalityOf(pet),voiceIndex++)
  if(currentSound===selected && passive) return
  try {
    player.stop()
    currentSound=selected
    player.setSource(player.source.FILE,{file:'sfx/'+selected+'.mp3'})
    player.prepare()
  } catch(e) { currentSound=null }
}
function releaseFeedback(){
  try { if(player) player.stop() } catch(e) {}
  player=null
  vibrator=null
  currentSound=null
}

const shakes = createShakeDetector()

function rect(x,y,w,h,color,radius=0) {
  controls.push(createWidget(widget.FILL_RECT,{x,y,w,h,color,radius}))
}
function txt(message,x,y,w,h,size=18,color=COLOR.ink,position=align.CENTER_H) {
  controls.push(createWidget(widget.TEXT,{
    text:String(message),x,y,w,h,text_size:size,color,
    align_h:position,align_v:align.CENTER_V,text_style:text_style.ELLIPSIS
  }))
}
function tap(label,x,y,w,h,action,danger=false,size=17) {
  controls.push(createWidget(widget.BUTTON,{
    x,y,w,h,text:label,text_size:size,color:COLOR.text,
    radius:11,normal_color:danger?COLOR.alert:COLOR.button,
    press_color:COLOR.pressed,click_func:action
  }))
}
function picture(src,x,y) { controls.push(createWidget(widget.IMG,{x,y,src})) }
function menuRow(label,icon,y,action,size=16) {
  picture('icons/'+icon+'.png',47,y+1)
  tap(label,99,y,244,43,action,false,size)
}
function categoryPage(header,rows,target='menu') {
  backdrop(header)
  rows.forEach((a,i)=>menuRow(a[0],a[1],91+i*47,a[2],a[3]||16))
  bottom(target==='menu'?'MENU':'VOLTAR',target)
}
function spriteAnim(name,pose='idle',x=51,y=131) {
  const anim=createWidget(widget.IMG_ANIM,{
    x:x+29,y:y+16,anim_path:'anim/'+name+'/'+pose,anim_prefix:'frame',anim_ext:'png',
    anim_fps:3,anim_size:4,repeat_count:0,anim_repeat:true,anim_status:3
  })
  controls.push(anim)
  anim.setProperty(prop.ANIM_STATUS,anim_status.START)
}
function clearHoldTimer() {
  if(holdTimer !== null) { try { clearTimeout(holdTimer) } catch(e) {} }
  holdTimer=null
}
function clear() {
  clearHoldTimer()
  for(let i=controls.length-1;i>=0;i--) deleteWidget(controls[i])
  controls=[]
}
function save() { store.setItem(KEY,pet) }
function update() { const prior=pet;pet=adjustNaturalEvolution(prior,advance(pet,Date.now()),dinoConfig);save() }
function backdrop(header) {
  rect(0,0,390,450,COLOR.bg)
  rect(12,12,366,427,COLOR.shell,22)
  rect(23,23,344,365,COLOR.lcd,14)
  rect(29,29,332,37,COLOR.light,7)
  txt(header,36,30,318,35,22)
  rect(29,395,332,31,COLOR.bg,8)
  txt('DINOPOCKET  //  90s EDITION',32,398,326,26,12,COLOR.lcd)
}
function bottom(label='VOLTAR',target='home') {
  tap(label,114,337,162,44,()=>{screen=target;render()})
}
function lcdFrame() {
  rect(38,91,314,188,COLOR.shade,7)
  rect(43,95,304,179,COLOR.light,7)
  // Marcacoes LCD, como no brinquedo original
  for(let y=118;y<262;y+=24){ rect(48,y,5,5,COLOR.shade,1);rect(337,y,5,5,COLOR.shade,1) }
}
function petTouch() {
  if(!pet || pet.dead) return
  if(pet.awake===false) {
    speechLine='Zzz... deixe o Dino descansar.'
    render()
    return
  }
  pet=touchInteraction(pet,Date.now())
  save()
  speechLine=pet.message
  if(speechTimer!==null) {try{clearTimeout(speechTimer)}catch(e){}}
  render()
  feedback(pet.stage===0?FX.egg:FX.happy)
  speechTimer=setTimeout(()=>{
    speechTimer=null
    speechLine=''
    if(screen==='home') render()
  },2500)
}
function touchArea() {
  // Captura os toques acima dos sprites para que o Dino ocupe a tela inteira.
  // Grupo foi escolhido conforme a documentacao oficial do Zepp OS.
  const group=createWidget(widget.GROUP,{x:30,y:69,w:330,h:315})
  controls.push(group)
  group.createWidget(widget.FILL_RECT,{
    x:0,y:0,w:330,h:315,color:COLOR.lcd,alpha:0
  })
  group.addEventListener(event.CLICK_DOWN,(info)=>{
    clearHoldTimer()
    touchDetector.down(info,Date.now())
    holdTimer=setTimeout(()=>{
      holdTimer=null
      if(touchDetector.trigger(Date.now())==='hold' && screen==='home'){
        speechLine=''
        go('menu')
      }
    },710)
  })
  group.addEventListener(event.MOVE,(info)=>{
    if(!touchDetector.move(info))clearHoldTimer()
  })
  group.addEventListener(event.MOVE_OUT,()=>{
    touchDetector.cancel();clearHoldTimer()
  })
  group.addEventListener(event.CLICK_UP,()=>{
    clearHoldTimer()
    const action=touchDetector.up(Date.now())
    if(action==='hold' && screen==='home'){speechLine='';go('menu')}
    else if(action==='tap' && screen==='home')petTouch()
  })
}
function sleepHome() {
  // Tela LCD noturna: sem painel claro, sem animações brilhantes.
  rect(0,0,390,450,0x03050b)
  rect(12,12,366,426,0x0c1320,24)
  rect(23,24,344,402,0x070d18,15)
  txt('DINOPOCKET  //  BOA NOITE',33,32,323,34,15,0x8795b2)
  picture('scenes/night.png',42,80)
  picture('scenes/sleep_'+characterStem(pet)+'.png',89,146)
  txt('Z z z...  DESCANSANDO',50,310,290,35,18,0x92a1bd)
  txt('DORMINDO ATE ACORDAR',51,352,288,25,13,0x667792)
  controls.push(createWidget(widget.BUTTON,{x:96,y:387,w:198,h:32,text:'ACORDAR',text_size:15,
    color:0xa6bacb,radius:10,normal_color:0x1b2a3e,press_color:0x314764,
    click_func:()=>perform('acordar')}))
  tap('MENU',308,36,54,30,()=>go('menu'),false,11)
}
function home() {
  if(pet.awake===false && !pet.dead && pet.stage>0){sleepHome();return}
  // Cenários reagem a ovo, crescimento, espécie adulta, doença e sujeira.
  rect(0,0,390,450,COLOR.bg)
  rect(12,12,366,426,COLOR.shell,24)
  rect(23,24,344,402,COLOR.lcd,15)
  rect(32,31,326,34,COLOR.light,6)
  txt('DINOPOCKET',41,33,175,29,17,COLOR.ink,align.LEFT)
  txt(petAgeString(pet),207,33,97,29,14,COLOR.ink)
  rect(37,75,316,299,COLOR.shade,11)
  picture('scenes/'+sceneFor(pet)+'.png',42,80)
  spriteAnim(characterStem(pet),speechLine && pet.awake!==false && pet.stage>0 ? 'touch' : restingPose(pet),51,133)
  const currentMessage=speechLine || (isPaused(pet)?'PAUSADO':describe(pet))
  rect(48,306,295,42,0xddeadd,7)
  txt(currentMessage,51,306,288,42,17,COLOR.ink)
  if(pet.stage>0 && pet.poop>0) txt('COCO: '+pet.poop+' | MENU > HIGIENE',56,350,277,22,12,COLOR.alert)
  if(pet.dead) {
    tap('NOVO OVO',107,379,177,37,()=>{
      pet=enhance(revive(pet,Date.now()));save();speechLine='';render()
    },false,15)
  } else {
    txt('TOQUE: CARINHO   |   SEGURE: MENU',47,388,296,25,12,COLOR.ink)
  }
  const attention=dinoConfig.alerts ? needsAttention(pet):null
  if(attention) txt('! '+attention+' !',92,353,206,19,15,COLOR.alert)
  touchArea()
  tap('MENU',307,32,53,31,()=>{speechLine='';go('menu')},false,11)
}

function go(name) {screen=name;if(name!=='reaction')result='';render()}
function choose(label,x,y,target){tap(label,x,y,148,47,()=>go(target),false,15)}
function menu() {
  backdrop('CENTRAL DO DINO')
  txt('Escolha uma categoria',43,70,305,25,17)
  const actions=[
    ['ALIMENTACAO','food','alimento'],['JOGOS','games','gamesMenu'],
    ['HIGIENE','hygiene','hygieneMenu'],['ESTUDOS','study','studiesMenu'],
    ['DESCANSO','sleep','restMenu'],['SAUDE','health','healthMenu'],
    ['STATUS','status','status'],['FERRAMENTAS','tools','more']
  ]
  actions.forEach((a,i)=>{
    const x=i%2===0?37:198,y=102+Math.floor(i/2)*61
    rect(x,y,155,53,0xe4ebe0,10)
    picture('icons/'+a[1]+'.png',x+5,y+5)
    tap(a[0],x+49,y+6,100,40,()=>go(a[2]),false,a[0]==='ALIMENTACAO'||a[0]==='FERRAMENTAS'?10:12)
  })
  bottom('DINO','home')
}
function alimento(){categoryPage('ALIMENTACAO',[
  ['BEBIDAS','drink',()=>go('drinks')],
  ['COMIDAS','fooditem',()=>go('food')],
  ['SOBREMESAS','dessert',()=>go('dessert')]
])}
function gamesMenu(){categoryPage('JOGOS',[
  ['PEDRA PAPEL TESOURA','games',()=>go('game'),12],
  ['0 OU 1','games',()=>go('binary')],
  ['PAR OU IMPAR','games',()=>go('parity')],
  ['BRINCAR COM DINO','games',()=>perform('brincar'),14]
])}
function hygieneMenu(){categoryPage('HIGIENE',[
  ['LIMPAR COCO','hygiene',()=>perform('limpar_coco')],
  ['DAR BANHO','hygiene',()=>perform('banho')],
  ['ESCOVAR DENTES','hygiene',()=>perform('escovar')],
  ['LAVAR AS MAOS','hygiene',()=>perform('lavar_maos')]
])}
function studiesMenu(){categoryPage('ESTUDOS',[
  ['MATEMATICA','study',()=>startQuiz('matematica')],
  ['INGLES','study',()=>startQuiz('ingles')],
  ['PORTUGUES','study',()=>startQuiz('portugues')],
  ['BOAS MANEIRAS','study',()=>perform('educar')],
  ['ESTUDO LIVRE','study',()=>perform('estudar')]
])}
function restMenu(){categoryPage('DESCANSO',[
  [pet.awake===false?'ACORDAR':'DORMIR','sleep',()=>perform(pet.awake===false?'acordar':'dormir')],
  ['AJUSTAR PAUSA','tools',()=>go('pause')]
])}
function healthMenu(){categoryPage('SAUDE',[
  ['DAR REMEDIO','health',()=>perform('remedio')],
  ['VER STATUS','status',()=>go('status')]
])}
function moreScreen(){categoryPage('FERRAMENTAS',[
  ['SONS E ALERTAS','tools',()=>go('alerts')],
  ['TEMPERATURA','tools',()=>go('temp')],
  ['PAUSA','tools',()=>go('pause')],
  ['RELOGIO','tools',()=>go('clock')],
  ['TESTES','test',()=>go('tests')]
])}

function testsScreen(){
  backdrop('TESTES DE EVOLUCAO')
  const phases=['OVO','BEBE','FILHOTE','JOVEM','ADULTO']
  txt('FASE: '+phases[pet.stage],43,91,304,35,22)
  txt('Cada toque avanca uma fase.',43,146,304,30,17)
  txt('Cuidados e conquistas mantidos.',38,183,314,30,16)
  if(pet.dead) txt('Dino sem vida: teste indisponivel.',38,251,314,40,16)
  else if(pet.stage>=4) txt('ADULTO - ciclo concluido.',38,251,314,40,18)
  else tap('AVANCAR EVOLUCAO',43,246,304,54,()=>{
    const prior=pet
    pet=adjustNaturalEvolution(prior,advanceForTest(pet,Date.now()),dinoConfig)
    save();render()
  },false,16)
  bottom('MAIS','more')
}
function alertSettings(){
  backdrop('SONS E ALERTAS')
  txt('Dino com voz propria!',38,74,314,29,19)
  txt('Som: '+(dinoConfig.sounds?'ON':'OFF'),42,110,306,27,19)
  tap('LIGAR / DESLIGAR',51,143,288,40,()=>{
    dinoConfig=normalizeSettings({...dinoConfig,sounds:!dinoConfig.sounds})
    store.setItem(DEVICE_SETTINGS_KEY,dinoConfig)
    sendConfigUpdate({sounds:dinoConfig.sounds})
    render();feedback(FX.happy)
  },false,14)
  txt('ESTILO: '+(soundMode(pet)==='expressivo'?'EXPRESSIVO':'CLASSICO'),40,196,310,28,16)
  tap('TROCAR ESTILO',51,226,288,40,()=>{
    pet.soundStyle=soundMode(pet)==='classico'?'expressivo':'classico'
    save();render();feedback(FX.happy)
  },false,14)
  txt('VIBRACAO: '+(pet.vibrationEnabled===false?'OFF':'ON'),39,273,312,25,16)
  tap('ALTERNAR VIBRA',51,304,288,37,()=>{
    pet.vibrationEnabled=pet.vibrationEnabled===false;save();render();feedback(FX.care)
  },false,14)
  bottom('MENU','menu')
}
function food() {
  backdrop('ALIMENTAR')
  txt('O Dino vai mastigar na tela!',43,78,305,27,17)
  tap('CARNE',49,119,292,49,()=>perform('carne'))
  tap('FRUTAS E VERDURAS',49,177,292,49,()=>perform('vegetais'),false,16)
  tap('MASSA',49,235,292,49,()=>perform('massa'))
  bottom('MENU','menu')
}
function drinks() {
  backdrop('BEBIDAS')
  txt('Agora o Dino tem sede!',42,78,306,28,18)
  tap('AGUA',49,119,292,49,()=>perform('agua'))
  tap('SUCO',49,177,292,49,()=>perform('suco'))
  tap('LEITE',49,235,292,49,()=>perform('leite'))
  bottom('MENU','menu')
}
function dessert(){categoryPage('SOBREMESAS',[
  ['SALADA DE FRUTAS','dessert',()=>perform('doce_fruta'),14],
  ['PUDIM','dessert',()=>perform('doce_pudim')],
  ['SORVETE','dessert',()=>perform('doce_sorvete')]
],'alimento')}
function ensureReady(){
  if(pet.stage===0 || pet.dead || isPaused(pet) || pet.awake===false){
    result='Acorde o Dino ou aguarde chocar!';lastAction='AVISO';reactionAction='';go('reaction');return false
  }
  return true
}
function binaryScreen(){
  backdrop('0 OU 1')
  txt('ADIVINHE A ESCOLHA DO DINO',43,84,304,35,17)
  txt('O Dino vai mostrar 0 ou 1.',43,132,304,29,16)
  tap('0',46,198,142,76,()=>doBinary(0),false,32)
  tap('1',202,198,142,76,()=>doBinary(1),false,32)
  bottom('JOGOS','gamesMenu')
}
function doBinary(choice){
  if(!ensureReady())return
  const played=playGuess(pet,choice,Math.floor(Math.random()*2),Date.now())
  pet=played.state;save();result=pet.message;lastAction='0 OU 1';reactionAction='jogo'
  reactionOpponent='';go('reaction');feedback(played.result==='ganhou'?FX.win:FX.lose)
}
function parityScreen(){categoryPage('PAR OU IMPAR',[
  ['ESCOLHER PAR','games',()=>{parityChoice='par';go('parityNumber')}],
  ['ESCOLHER IMPAR','games',()=>{parityChoice='impar';go('parityNumber')}]
],'gamesMenu')}
function parityNumberScreen(){
  backdrop('PAR OU IMPAR')
  txt('ESCOLHEU '+parityChoice.toUpperCase(),40,78,310,32,21)
  txt('Escolha de 0 a 5.',45,112,300,25,17)
  for(let n=0;n<6;n++){
    const x=45+(n%3)*104,y=154+Math.floor(n/3)*75
    tap(String(n),x,y,93,60,()=>doParity(n),false,25)
  }
  bottom('VOLTAR','parity')
}
function doParity(number){
  if(!ensureReady())return
  const played=playParity(pet,parityChoice,number,Math.floor(Math.random()*6),Date.now())
  pet=played.state;save();result=pet.message;lastAction='PAR OU IMPAR';reactionAction='jogo'
  reactionOpponent='';go('reaction');feedback(played.result==='ganhou'?FX.win:FX.lose)
}
function startQuiz(topic){
  if(!ensureReady())return
  activeQuiz=questionFor(topic,Math.floor(Math.random()*100))
  go('quiz')
}
function quizScreen(){
  backdrop('ESTUDOS: '+activeQuiz.topic.toUpperCase())
  txt(activeQuiz.question,39,83,311,59,18)
  activeQuiz.choices.forEach((option,i)=>tap(option,48,160+i*54,294,46,()=>answerQuiz(i),false,17))
  bottom('ESTUDOS','studiesMenu')
}
function answerQuiz(i){
  if(!ensureReady())return
  const checked=answerStudy(pet,activeQuiz,i,Date.now());pet=checked.state
  save();result=pet.message;lastAction='ESTUDOS';reactionAction='estudar'
  go('reaction');feedback(checked.result==='certo'?FX.win:FX.lose)
}
function statusBar(label,value,y){
  txt(label,42,y,125,25,16,COLOR.ink,align.LEFT)
  rect(171,y+6,174,13,COLOR.shade,5)
  rect(171,y+6,Math.round(174*Math.max(0,Math.min(100,Number(value)||0))/100),13,COLOR.ink,5)
}
function status() {
  backdrop('STATUS DO DINO')
  txt(pet.stage>=4?speciesName(pet.species):petAgeString(pet),42,68,306,23,17)
  statusBar('SACIEDADE',pet.hunger,98)
  statusBar('SEDE',pet.thirst,126)
  statusBar('ALEGRIA',pet.joy,154)
  statusBar('HIGIENE',pet.hygiene,182)
  statusBar('ENERGIA',pet.energy,210)
  statusBar('SAUDE',pet.health,238)
  statusBar('ESTUDOS',pet.intelligence,266)
  txt('COCO: '+pet.poop+'  |  BOCA: '+Math.round(pet.teethCare||0)+'  |  MAOS: '+Math.round(pet.handCare||0),43,290,305,22,13)
  txt('LIVROS: '+pet.studyCount+'  |  ACERTOS: '+(pet.studyCorrect||0),43,314,304,20,13)
  bottom()
}
function gameScreen() {
  backdrop('PEDRA PAPEL TESOURA')
  txt('Escolha sua jogada!',48,81,294,34,19)
  txt('Dino x Voce',47,128,296,38,23)
  tap('PEDRA',42,206,96,57,()=>play('pedra'),false,15)
  tap('PAPEL',147,206,96,57,()=>play('papel'),false,15)
  tap('TESOURA',252,206,96,57,()=>play('tesoura'),false,14)
  txt('Vitorias: '+pet.gamesWon+'/'+pet.gamesPlayed,60,282,270,28,17)
  bottom('MENU','menu')
}
function play(choice) {
  if(pet.stage===0 || pet.dead || isPaused(pet) || pet.awake===false){result='Acorde o Dino antes de jogar!';reactionAction='';go('reaction');return}
  const data=playRps(pet,choice,Date.now())
  pet=data.state;save();result=pet.message;lastAction='JOGO';reactionAction='jogo';reactionOpponent=data.opponent;go('reaction');feedback(data.result==='ganhou'?FX.win:data.result==='perdeu'?FX.lose:FX.tie)
}
function perform(action) {
  if(pet.stage===0 || pet.dead || isPaused(pet)){
    result='Dino ainda nao pode!';lastAction='AVISO';reactionAction='';go('reaction');return
  }
  if(pet.awake===false && !['acordar'].includes(action)) {
    result='Shhh! Primeiro acorde o Dino.';lastAction='SONO';reactionAction='dormir';go('reaction');return
  }
  const now=Date.now()
  if(action==='educar')pet=giveDiscipline(pet,now)
  else if(action==='escovar'||action==='lavar_maos')pet=cleanCare(pet,action)
  else if(action.startsWith('doce_'))pet=giveDessert(pet,action.slice(5),now)
  else pet=enhance(act(pet,action,now))
  reactionAction=action
  reactionOpponent=''
  const labels={
    carne:'NHAC!',vegetais:'NHAC!',massa:'NHAC!',
    agua:'GLUP!',suco:'GLUP!',leite:'GLUP!',
    estudar:'ESTUDANDO',brincar:'BRINCANDO',
    banho:'BANHO',limpar_coco:'LIMPANDO COCO',dormir:'SONINHO',
    acordar:'ACORDANDO',remedio:'REMEDIO',educar:'EDUCANDO',
    escovar:'DENTINHOS',lavar_maos:'MAOS LIMPAS',doce_fruta:'FRUTINHAS',doce_pudim:'PUDIM',doce_sorvete:'SORVETE'
  }
  lastAction=labels[action]||'CUIDADO'
  result=pet.message
  save()
  if(action==='dormir'){speechLine='';go('home');return}
  if(action==='acordar'){speechLine='';go('home');feedback(FX.happy);return}
  go('reaction');feedback(feedbackForAction(action))
}
function reaction() {
  backdrop(lastAction||'DINO REAGE!')
  const pose=reactionAction?actionPose(reactionAction,reactionOpponent):restingPose(pet)
  txt(lastAction||'CUIDADO',48,72,296,25,18)
  lcdFrame()
  spriteAnim(characterStem(pet),pose,51,99)
  txt(result||pet.message,49,262,293,27,16)
  if(reactionAction==='jogo' && reactionOpponent) txt('DINO FAZ: '+reactionOpponent.toUpperCase(),53,288,284,23,14,COLOR.ink)
  tap('OK',80,318,230,51,()=>go('home'))
}
function tempScreen() {
  backdrop('TEMPERATURA')
  txt('Controle o ambiente',42,89,306,31,19)
  txt(String(pet.temperature)+' C',76,141,238,57,38)
  tap('MENOS',43,224,144,54,()=>changeTemp(-1))
  tap('MAIS',203,224,144,54,()=>changeTemp(1))
  bottom('MENU','menu')
}
function changeTemp(n){pet=setTemperature(pet,n,Date.now());save();render();feedback(FX.care)}
function pauseScreen() {
  backdrop('PAUSA')
  txt(isPaused(pet)?'SEU DINO ESTA PAUSADO':'PAUSE OS CUIDADOS',43,82,304,42,19)
  txt('Quando pausar, a idade e as',43,138,304,28,16)
  txt('necessidades ficam congeladas.',43,170,304,28,16)
  tap(isPaused(pet)?'CONTINUAR':'PAUSAR DINO',55,224,280,58,()=>{
    pet=setPause(pet,!isPaused(pet),Date.now());save();go('home')
  })
  bottom('MENU','menu')
}
function clockScreen() {
  backdrop('RELOGIO')
  const now=new Date()
  const clock=(n)=>String(n).padStart(2,'0')
  txt(clock(now.getHours())+':'+clock(now.getMinutes()),42,104,306,76,48)
  txt('Tempo de vida: '+pet.ageDays+' dia(s)',42,207,306,29,18)
  txt('GERACAO '+pet.generation,42,253,306,30,20)
  bottom('MENU','menu')
}
function onMotion() {
  if(!pet || !dinoConfig.wrist || screen!=='home' || pet.dead || pet.awake===false || isPaused(pet) || !motion) return
  let sample
  try { sample=motion.getCurrent() } catch(error) { return }
  if(!shakes.feed(sample,Date.now())) return
  pet=enhance(wristInteraction(pet,Date.now()))
  save()
  result=pet.message
  lastAction=pet.stage===0?'OVO MEXEU!':'BRINCADEIRA!'
  reactionAction='pulso'
  go('reaction')
  feedback(pet.stage===0?FX.egg:FX.happy)
}
function startMotion() {
  if(!dinoConfig.wrist || motion) return
  try {
    motion=new Accelerometer()
    motionCallback=onMotion
    motion.setFreqMode(FREQ_MODE_NORMAL)
    motion.onChange(motionCallback)
    motion.start()
  } catch(error) {
    // Sem permissao ou acelerometro: o restante do jogo continua normalmente.
    stopMotion()
  }
}
function stopMotion() {
  if(motion){
    try { if(motionCallback) motion.offChange(motionCallback) } catch(error) {}
    try { motion.stop() } catch(error) {}
  }
  motion=null
  motionCallback=null
  shakes.reset()
}
// Mensagens compactas entre Zepp no telefone e app no relogio.
// Nao enviamos o estado do Dino para a nuvem nem alteramos o save do bichinho.
function receiveConfig(index,data,size){
  const msg=normalizeEnvelope(decodePacket(data,size))
  if(!msg || !shouldAccept(configRevision,msg.revision))return
  for(const timer of configRequestTimers){try{clearTimeout(timer)}catch(e){}}
  configRequestTimers=[]
  configRevision=msg.revision
  dinoConfig=msg.config
  store.setItem(DEVICE_SETTINGS_KEY,dinoConfig)
  store.setItem(DEVICE_SETTINGS_KEY+'.rev',configRevision)
  if(!dinoConfig.wrist)stopMotion()
  else startMotion()
  if(pet)render()
}
function requestConfig(){
  if(!bleStarted)return
  try{
    const bytes=encodePacket({type:'GET_DINO_CONFIG'})
    sendBluetooth(bytes.buffer,bytes.length)
  }catch(e){console.log('Zepp sync indisponivel, usando config local')}
}
function sendConfigUpdate(patch){
  if(!bleStarted)return
  try { const bytes=encodePacket({type:'SET_DINO_CONFIG',patch});sendBluetooth(bytes.buffer,bytes.length) }catch(e){}
}
function startSync(){
  if(bleStarted)return
  try{
    createConnect(receiveConfig)
    bleStarted=true
    // Pequena espera para o canal entre relogio e telefone estabelecer conexao.
    // Repetimos a consulta brevemente, caso o Bluetooth ainda esteja estabelecendo a sessao.
    for(const wait of [700,2400,5500,10000]){
      configRequestTimers.push(setTimeout(()=>{requestConfig()},wait))
    }
  }catch(e){bleStarted=false}
}
function stopSync(){
  for(const timer of configRequestTimers){try{clearTimeout(timer)}catch(e){}}
  configRequestTimers=[]
  if(bleStarted){try{disConnect()}catch(e){}}
  bleStarted=false
}

function startLifeTimer() {
  if(lifeTimer !== null) return
  lifeTimer=setInterval(()=>{
    if(!pet || pet.dead || isPaused(pet) || screen!=='home') return
    const before=pet
    update()
    if(before.stage!==pet.stage || before.awake!==pet.awake ||
       before.poop!==pet.poop || restingPose(before)!==restingPose(pet)) {
      render()
      const cue=entryCue(before,pet)
      if(cue) feedback(cue,true)
    }
  },60000)
}
function stopLifeTimer(){
  if(lifeTimer !== null){try{clearInterval(lifeTimer)}catch(e){}}
  lifeTimer=null
}
function render() {
  if(!pet) return
  update();clear()
  if(screen==='menu') menu()
  else if(screen==='alimento') alimento()
  else if(screen==='gamesMenu') gamesMenu()
  else if(screen==='hygieneMenu') hygieneMenu()
  else if(screen==='studiesMenu') studiesMenu()
  else if(screen==='restMenu') restMenu()
  else if(screen==='healthMenu') healthMenu()
  else if(screen==='dessert') dessert()
  else if(screen==='binary') binaryScreen()
  else if(screen==='parity') parityScreen()
  else if(screen==='parityNumber') parityNumberScreen()
  else if(screen==='quiz') quizScreen()
  else if(screen==='more') moreScreen()
  else if(screen==='tests') testsScreen()
  else if(screen==='drinks') drinks()
  else if(screen==='food') food()
  else if(screen==='status') status()
  else if(screen==='game') gameScreen()
  else if(screen==='reaction') reaction()
  else if(screen==='temp') tempScreen()
  else if(screen==='pause') pauseScreen()
  else if(screen==='clock') clockScreen()
  else if(screen==='alerts') alertSettings()
  else home()
}
Page({
  onInit(){
    const saved=store.getItem(KEY,null)
    pet=enhance(saved&&saved.schema===1?saved:newGame(Date.now()))
    const before={...pet}
    update()
    pendingStartupCue=entryCue(before,pet)
  },
  build(){
    initFeedback();render();startMotion();startSync();startLifeTimer()
    if(pendingStartupCue) {feedback(pendingStartupCue,true);pendingStartupCue=null}
  },
  onDestroy(){
    stopLifeTimer();stopSync();stopMotion();releaseFeedback()
    clearHoldTimer()
    if(speechTimer!==null){try{clearTimeout(speechTimer)}catch(e){}}
    if(pet)save();clear()
  }
})
