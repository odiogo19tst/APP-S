# DinoPocket Retro 1.5.3 — revisão de anatomia dos sprites

Atualização **de teste** para Amazfit Bip 6. Mesma identificação do aplicativo (`29318764`) e mesma chave de salvamento (`dinopocket.state.v1`). A versão submetida à Zepp App Store **não foi modificada**.

## O que mudou
- Todos os desenhos animados da versão 1.5.2 foram **regenerados** a partir de `scripts/make_v15_sprites.py`, agora com as mãos e os braços desenhados **antes do rosto** (ficam atrás da cabeça) e reposicionados para os lados. Não atravessam olhos, bochechas ou boca nas poses comuns.
- Braços levantados em felicidade, carinho, brincadeira e ao acordar aparecem ao lado da cabeça, não por cima dos olhos.
- Leitura, copo, comida e gestos de pedra-papel-tesoura são objetos propositais em primeiro plano, e não braços atravessando a face.
- Piscada adicional na animação de repouso, gestos do minijogo com movimento de balanço e quatro quadros por pose para reduzir o tamanho do pacote.
- Ciclo e estados do pet não foram modificados; idade, geração e evoluções mantidas.

## Auditoria e testes
- Cobertura: 9 variantes gráficas (ovo, bebê, pequeno, jovem, T-Rex, Brontossauro, Tricerátopo, doente e fantasma), 25 poses/ações e 4 quadros cada = **900 PNGs animados regenerados**.
- Cada quadro gerado: 288x164 PNG RGBA.
- Testes locais `npm test`: 69 passaram, 0 falharam.
- Inspeção visual das principais poses e das variantes de dinossauro realizada. É preciso confirmar no relógio real após compilar, especialmente a apresentação das mãos no jogo e o progresso salvo.

## Como compilar
Substitua no repositório APP-S **somente** o arquivo `DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip` pelo ZIP distribuído com esta versão, sem extraí-lo. O workflow `DinoPocket Retro - Amazfit Bip 6` fará os testes e a compilação `zeus build`.

No Codespaces, para atualizar a cópia e produzir QR de teste:
```
cd /workspaces/APP-S && git pull --ff-only && mkdir -p dinopocket-v1.5.3 && unzip -o -q DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip -d dinopocket-v1.5.3 && cd dinopocket-v1.5.3 && zeus preview
```
Selecione `Amazfit Bip 6` quando solicitado. Não desinstale o DinoPocket antes de testar atualização e progresso.

A compilação Zepp e a instalação física desta 1.5.3 ainda não foram validadas. Se aparecer erro, envie o print do Terminal/Zepp.
