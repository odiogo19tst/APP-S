# DinoPocket Retro 1.5.6 — PNG8 sem perda visual (build experimental)

> Objetivo: reduzir o peso das imagens sem sacrificar os desenhos ou os 4 quadros animados por ação.

- Base: 1.5.5 de Bip 6; aplicativo ID 29318764.
- Mantidos: 5 etapas de evolução, especies, expressoes, audio, regras de game, chaves de progresso e pagina Settings.
- Todos os 936 sprites PNG em `assets/390x450-bip6/anim` foram convertidos de RGBA 32 bits para modo paletizado PNG8.
- Foram verificados os pixels RGBA de cada arquivo antes e depois: igualdade exata, incluindo transparência.
- PNG originais: 1,546,967 bytes; PNG otimizados: 1,063,895 bytes (31.2% de reducao).
- Aviso: documentacao Zepp recomenda recursos RGB/RGBA de 24/32 bits. PNG8 e valido e tem uso em projetos Zepp, mas a compatibilidade com o empacotador/modelo deve ser testada. Nao instalar apagando a versao anterior.
- O tamanho do ZIP de desenvolvimento nao equivale ao `.zab` final; Zepp pode converter imagens para recursos nativos. "Failed to unzip the package" nao confirma problema de tamanho: verificar logs do Zepp se continuar.

Compilacao: `npm test` e `zeus preview` para Amazfit Bip 6.
