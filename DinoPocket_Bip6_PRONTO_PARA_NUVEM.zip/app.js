App({
  onCreate() { console.log('DinoPocket iniciado') },
  onDestroy() { console.log('DinoPocket encerrado') }
})
