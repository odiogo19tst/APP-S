"""Previews prepared from actual 1.5.1 watch sprites (never concept art)."""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ASSET=ROOT/'assets'/'390x450-bip6'
PUB=Path('/mnt/data')
COLOR={'shell':'#28565C','lcd':'#F3F6E8','ink':'#253D3B','teal':'#6CBBAB'}
FONT=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',19)
SMALL=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
BOLD=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',19)

def sprite(form,pose,n):
    return Image.open(ASSET/'anim'/form/pose/f'frame_{n}.png').convert('RGBA')

def icon():
    im=Image.new('RGB',(128,128),'#276A66'); d=ImageDraw.Draw(im)
    d.rounded_rectangle((8,8,119,119),radius=19,fill='#F4F6DE',outline='#89BEA7',width=3)
    s=sprite('baby','happy',3)
    s.thumbnail((115,88),Image.Resampling.NEAREST)
    im.paste(s,((128-s.width)//2,18),s)
    d.text((20,100),'DINO',font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',19),fill='#275A57')
    im.save(ASSET/'icon.png')
    for form in ['egg','baby','small','young','rex','bronto','trike','sick','ghost']:
        pix=sprite(form,'idle',0)
        pix.thumbnail((146,121),Image.Resampling.NEAREST)
        out=Image.new('RGBA',(146,146))
        out.paste(pix,((146-pix.width)//2,(146-pix.height)//2),pix)
        out.save(ASSET/f'{form}.png')

def screen(form,pose,n,title,subtitle):
    im=Image.new('RGB',(390,450),'#152B35');d=ImageDraw.Draw(im)
    d.rounded_rectangle((12,12,377,438),radius=25,fill='#387477')
    d.rounded_rectangle((23,23,367,426),radius=16,fill=COLOR['lcd'])
    d.rounded_rectangle((32,31,358,65),radius=7,fill='#FFFCEF')
    d.text((40,38),'DINOPOCKET',font=SMALL,fill=COLOR['ink'])
    d.text((215,38),'DIA 01',font=SMALL,fill=COLOR['ink'])
    d.rounded_rectangle((37,75,353,375),radius=12,fill='#A0CBB9')
    d.rounded_rectangle((42,80,348,368),radius=8,fill='#FEFDF1')
    for y in range(107,324,32):
        d.rounded_rectangle((47,y,52,y+7),radius=1,fill='#9FBDAF')
        d.rounded_rectangle((337,y,342,y+7),radius=1,fill='#9FBDAF')
    asset=sprite(form,pose,n)
    im.paste(asset,(51,133),asset)
    bbox=d.textbbox((0,0),title,font=BOLD);w=bbox[2]
    d.text(((390-w)//2,307),title,font=BOLD,fill=COLOR['ink'])
    d.text((58,347),subtitle,font=SMALL,fill='#4B6764')
    d.text((48,392),'TOQUE: CARINHO  |  SEGURE: MENU',font=SMALL,fill=COLOR['ink'])
    return im

def gallery():
    display=[('idle','ACORDADO',1),('happy','FELIZ',2),('sleep','SONO',3),('hunger','FOME',2),('sad','TRISTE',3),('play','BRINCANDO',2),('eat_carne','COMENDO',3),('drink_agua','BEBENDO',4),('study','ESTUDANDO',4),('dirty','SUJO',2),('bath','BANHO',5),('rps_tesoura','TESOURA',4)]
    canvas=Image.new('RGB',(1120,1160),'#F8F9EF');d=ImageDraw.Draw(canvas)
    for i,(pose,label,t) in enumerate(display):
        x=20+(i%3)*367;y=20+(i//3)*286
        d.rounded_rectangle((x,y,x+350,y+270),radius=18,fill='#EDF5E6',outline='#71AF9F',width=2)
        pic=sprite('baby',pose,t)
        canvas.paste(pic,(x+30,y+22),pic)
        d.text((x+20,y+220),label,font=BOLD,fill=COLOR['ink'])
    canvas.save(PUB/'DinoPocket_1_5_1_Graficos_Reais.png',optimize=True)

def animated_preview():
    labels={
      'idle':('ACORDADO','Pisca, respira e olha'),
      'happy':('FELIZ','Sorri e levanta os braços'),
      'sleep':('DORMINDO','Deitado, respirando e Zzz'),
      'eat_carne':('COMENDO','Leva comida à boca'),
      'drink_agua':('BEBENDO','Bebe do copinho'),
      'study':('ESTUDANDO','Folheia o livro'),
      'play':('BRINCANDO','Corre atrás da bolinha'),
      'bath':('BANHO','Bolhas e limpeza'),
      'rps_tesoura':('TESOURA','Faz o gesto com a mão')
    }
    frames=[]
    for pose,(title,subtitle) in labels.items():
        for n in range(8):
            frames.append(screen('baby',pose,n,title,subtitle).resize((390,450)))
    frames[0].save(PUB/'DinoPocket_1_5_1_Animacoes_Reais.gif',save_all=True,append_images=frames[1:],duration=230,loop=0,optimize=True)
    screen('baby','happy',2,'AGORA ESTOU VIVO!','Animações de verdade no Bip 6').save(PUB/'DinoPocket_1_5_1_Tela_Bip6.png')
    gallery()

if __name__=='__main__':
    icon();animated_preview()
