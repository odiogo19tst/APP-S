"""DinoPocket 1.5.3: correcao da anatomia e sobreposicao dos bracos.

Bracos e patas ficam ATRAS do rosto; apenas objetos em uso vao a frente.
Grade logica 96x54 -> tela transparente 288x164 (nearest).
Nao acessa nem modifica o estado salvo do animal.
"""
from pathlib import Path
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]/'assets'/'390x450-bip6'/'anim'
STEMS=['egg','baby','small','young','rex','bronto','trike','sick','ghost']
POSES=['idle','happy','sleep','hunger','sad','dirty','sick','eat','drink','study','play','bath','poop','rps_pedra','rps_papel','rps_tesoura','evolve','touch','wake','eat_carne','eat_vegetais','eat_massa','drink_agua','drink_suco','drink_leite']
INK='#293C39'; WHITE='#FFFAE9'; SILK='#FFFEF5'; SHADOW='#475E55'
PALETTES={
    'egg': ('#F6DDA7','#FFF6D1','#D7AB79','#C78F69'),
    'baby':('#E6F3D8','#C9E6D3','#629E85','#EBAE9F'),
    'small':('#BBEACD','#A3DDBB','#4F9978','#ECAFA8'),
    'young':('#93D7CA','#75C6C4','#398E87','#E99B94'),
    'rex':('#F4BE85','#FFE3AE','#BA774D','#E99A93'),
    'bronto':('#B9E3E8','#D8F6E9','#5A99B1','#EFA9A0'),
    'trike':('#D9C7F4','#F6E9F8','#9974BC','#EDA8B5'),
    'sick':('#CED6C3','#E9EAD2','#92A49C','#C9AA9D'),
    'ghost':('#E9F5F1','#FDFEFE','#A9C0BE','#D9D9D9')
}

def render(stem,pose,tick):
    img=Image.new('RGBA',(96,54),(0,0,0,0))
    d=ImageDraw.Draw(img)
    skin,belly,spike,cheek=PALETTES[stem]
    fast=pose in ('happy','play','touch','wake','evolve')
    shift=([0,1,2,2,0,-1,-2,-1][tick] if pose=='play' else [0,0,0,1,1,0,-1,0][tick] if fast else [0,1,1,0][tick] if pose.startswith('rps_') else 0)
    bob=([0,-2,-3,-2,0,1,0,-1][tick] if fast else [0,0,-1,-1,0,0,1,0][tick])
    if pose=='sad':bob+=2
    # independent motion for food, bubbles, hearts, Zs, etc.
    dx,dy=shift,bob
    def ell(q,fill,outline=INK,w=2,move=True):
        x1,y1,x2,y2=q
        if move:x1+=dx;x2+=dx;y1+=dy;y2+=dy
        d.ellipse((x1,y1,x2,y2),fill=fill,outline=outline,width=w if outline else 1)
    def rect(q,fill,outline=None,w=1,move=True):
        x1,y1,x2,y2=q
        if move:x1+=dx;x2+=dx;y1+=dy;y2+=dy
        d.rectangle((x1,y1,x2,y2),fill=fill,outline=outline,width=w)
    def poly(points,fill,outline=INK,w=2,move=True):
        pts=[(x+dx,y+dy) if move else (x,y) for x,y in points]
        d.polygon(pts,fill=fill)
        if outline:d.line(pts+[pts[0]],fill=outline,width=w,joint='curve')
    def line(points,fill=INK,w=2,move=True):
        pts=[(x+dx,y+dy) if move else (x,y) for x,y in points]
        d.line(pts,fill=fill,width=w,joint='curve')
    def pixel(x,y,c=INK):rect((x,y,x+1,y+1),c,None)
    def shadow(x=28,y=50,r=26):
        d.ellipse((x-r,y-2,x+r,y+1),fill=(55,90,80,42))

    if stem=='egg':
        shadow(47,50,18)
        rot=[0,-1,0,1,0,-1,0,1][tick]
        ell((30+rot,7,65+rot,47),skin)
        ell((34+rot,10,60+rot,41),belly,None)
        poly([(32+rot,29),(40+rot,27),(45+rot,32),(52+rot,29),(62+rot,32)],WHITE,spike,1)
        ell((40+rot,13,48+rot,19),WHITE,None)
        if pose in ('touch','evolve','wake'):
            line([(42+rot,11),(48+rot,19),(44+rot,25),(54+rot,32)],INK,2)
            for sx,sy in [(26,15),(73,19),(70,7)]:pixel(sx,sy,'#F2B969')
        else:
            ell((46+rot,30,49+rot,33),spike,None)
        # little shaking traces
        if tick in (2,5):line([(23,24),(21,21)],spike,1,False)
    elif stem=='ghost':
        shadow(50,50,22)
        ell((33,11,76,43),skin)
        poly([(34,33),(31,49),(39,44),(46,50),(53,44),(62,50),(69,43),(76,49),(76,34)],skin)
        ell((47,22,50,27),INK,None);ell((63,22,66,27),INK,None)
        line([(51,33),(56,35),(61,33)],INK,2)
        if tick in (1,5):pixel(79,11,'#ACC6B9')
    elif pose=='sleep':
        # actual reclined silhouette - different from idle, with visible eyelids.
        shadow(48,50,35)
        poly([(36,36),(8,39),(16,44),(43,46)],skin)
        for x,y in [(21,37),(27,35),(33,34),(39,31)]:
            poly([(x,y+3),(x-2,y-2),(x+5,y+2)],spike)
        ell((28,31+(tick in (2,3,4)),70,48),skin)
        ell((37,39,60,47),belly,None)
        ell((55,25,84,47),skin)
        ell((56,27,74,34),WHITE,None)
        ell((70,44,79,48),belly)
        line([(64,37),(68,39),(72,37)],INK,2)  # real shut eye
        line([(76,38),(78,40),(80,38)],INK,1)
        ell((59,42,63,44),cheek,None)
        # soft breathing belly and rolling feet
        ell((43,46-(tick in (3,4)),53,49),skin)
        if tick in (1,2,5,6):
            line([(34,38),(37,39)],WHITE,1)
        zpositions=[(79,16),(80,14),(81,12),(83,9),(83,7),(84,8),(81,11),(79,13)]
        zx,zy=zpositions[tick]
        line([(zx,zy),(zx+5,zy),(zx,zy+6),(zx+5,zy+6)],'#687F92',1,False)
        if tick in (3,4,5):
            line([(88,1),(93,1),(88,6),(93,6)],'#8491AB',1,False)
    else:
        shadow(48,51,28)
        # big tail curl, belly + individually outlined dinosaur back plates
        tailtip=8 + (1 if tick%4>=2 else 0)
        poly([(37,32),(21,34),(tailtip,27+(tick%4>=2)*2),(11,39),(25,46),(42,42)],skin)
        poly([(21,36),(12,32),(12,38),(25,43)],spike,None)
        # plates align with body, independent of head
        for x,y in [(30,26),(36,20),(42,15),(48,11)]:
            poly([(x-2,y+7),(x-4,y-2),(x+6,y+5)],spike)
            line([(x-2,y+5),(x-3,y+1)],WHITE,1)
        # round pear-like body (more chibi and upright than v1.5)
        ell((28,22,70,48),skin)
        ell((42,28,65,44),belly,spike,1)
        ell((34,26,39,30),WHITE,None)
        # leg positions change in happy/play
        footkick = -4 if pose in ('play','happy') and tick in (1,2,3) else 0
        ell((33,43+footkick,47,51+footkick),skin)
        ell((57,43-footkick//2,72,51-footkick//2),skin)
        for fx,fy in [(38,49+footkick),(42,50+footkick),(63,50-footkick//2),(68,50-footkick//2)]:line([(fx,fy),(fx,fy-2)],spike,1)
        # Arms are drawn behind the head, preserving both eyes, cheeks and mouth.
        # Avoid hand overlap with the face. Gesture props are rendered separately.
        if pose in ('happy','play','touch','wake') and tick in (1,2,3):
            # Arms raised visibly OUTSIDE the head silhouette; all skin is behind it.
            poly([(37,35),(29,29),(27,20),(30,18),(36,25),(44,31)],skin)
            poly([(63,38),(80,30),(87,18),(91,20),(89,28),(74,43)],skin)
        elif pose.startswith('rps_'):
            # Body-to-hand connection beneath the snout, hand appears to the right.
            poly([(61,40),(75,42),(85,33),(91,36),(78,46),(62,45)],skin)
            poly([(37,34),(32,37),(35,44),(43,43)],skin)
        elif pose=='study':
            # Paws below the cheeks, book later appears in front of them.
            poly([(39,37),(35,41),(43,46),(52,43),(49,39)],skin)
            poly([(60,41),(68,39),(74,44),(70,47),(60,45)],skin)
        elif pose.startswith('drink'):
            poly([(39,36),(34,41),(41,45),(48,43)],skin)
            poly([(60,41),(72,42),(84,33),(87,37),(76,47),(62,46)],skin)
        else:
            # Idle / food / bath: arms low and away from facial features.
            ell((33,35,44,43),skin)
            ell((57,41,69,47),skin)
            line([(38,42),(37,44)],spike,1)
            line([(64,44),(65,46)],spike,1)

        # large expressive face with frontal 3/4 angle
        if stem=='bronto':
            ell((49,11,66,36),skin)
            ell((49,6,82,34),skin)
        elif stem=='rex':
            ell((43,9,84,40),skin)
            ell((69,29,89,41),skin)
        elif stem=='trike':
            poly([(45,13),(40,9),(53,10),(55,4),(63,9),(73,3),(77,12),(87,12),(80,31)],spike)
            ell((46,10,81,39),skin)
            # triceratops horns, viewed from front
            poly([(53,15),(48,2),(58,11)],WHITE)
            poly([(72,13),(80,2),(80,16)],WHITE)
        else:
            ell((44,7,83,39),skin)
        if stem not in ('trike','bronto'):
            for x,y in [(47,8),(54,5),(60,7)]:
                poly([(x-3,y+7),(x-2,y-2),(x+5,y+5)],spike)
        ell((49,11,64,16),WHITE,None)
        # nose / frontal snout; rex has broader mouth
        if stem=='rex':
            ell((67,29,88,38),belly,INK,1)
        else:
            ell((65,29,82,38),belly,INK,1)
        # cheeks (rounded and visible)
        ell((49,27,55,31),cheek,None)
        ell((77,27,81,31),cheek,None)
        if stem=='trike':
            poly([(80,31),(89,30),(84,35)],WHITE,spike,1)
        # eyebrows + TWO distinct eyes instead of the v1.5 single dot
        if pose in ('happy','touch') and (tick%4<3):
            line([(55,23),(59,20),(62,23)],INK,2)
            line([(69,23),(73,20),(77,23)],INK,2)
        elif pose=='sad':
            line([(54,22),(61,24)],INK,2)
            line([(69,24),(76,22)],INK,2)
            rect((57,26,60,27),INK)
            rect((72,26,75,27),INK)
        elif pose=='sick':
            line([(55,25),(62,25)],INK,2)
            line([(70,25),(77,25)],INK,2)
        elif pose in ('study','rps_pedra','rps_papel','rps_tesoura'):
            line([(55,17),(61,18)],INK,1)
            ell((56,19,61,24),INK,None)
            ell((70,19,75,24),INK,None)
            pixel(58,19,WHITE);pixel(72,19,WHITE)
        elif pose.startswith('eat') and tick%3==2:
            line([(55,23),(62,23)],INK,2)
            line([(70,23),(77,23)],INK,2)
        elif pose=='idle' and tick==3:
            line([(55,23),(62,23)],INK,2)
            line([(70,23),(77,23)],INK,2)
        else:
            ell((55,19,62,26),INK,None)
            ell((70,19,77,26),INK,None)
            rect((56,20,58,22),WHITE,None)
            rect((71,20,73,22),WHITE,None)
        # big animated mouth. Open mouth has little tongue.
        if pose in ('happy','play','wake') and tick in (1,2,3,4,5):
            ell((66,31,75,38),INK,None)
            rect((68,36,73,37),'#F4A3A0',None)
        elif pose in ('eat','eat_carne','eat_vegetais','eat_massa'):
            if tick%2:
                ell((70,31,76,37),INK,None)
                rect((72,35,74,36),cheek,None)
            else:line([(68,33),(73,35),(78,33)],INK,2)
        elif pose in ('sad','sick','hunger'):
            line([(67,37),(71,34),(75,37)],INK,2)
        elif pose=='poop':
            ell((69,33,73,36),INK,None)
        else:
            line([(67,33),(70,35),(74,35),(77,33)],INK,2)
        for xx in (76,80): pixel(xx,31,spike)
        # No additional arm is drawn on top of the face. This was the visual
        # regression in 1.5.2: the foreground arm crossed the cheek and muzzle.
        # coat markings make each breed distinct
        if stem=='rex':
            for tx in (76,81,86):line([(tx,37),(tx-2,40)],WHITE,1)
        elif stem=='bronto':
            for q in ((31,31,35,33),(39,36,42,38)):rect(q,spike,None)
        elif stem=='trike':
            ell((38,35,42,38),spike,None)

        if pose in ('dirty','poop'):
            for sx,sy in [(36,36),(47,43),(42,22),(55,42),(29,40)]:
                ell((sx,sy,sx+4,sy+3),'#977655',None)
            if pose=='poop' or tick%4<3:
                ell((4,44,21,50),'#72533C')
                ell((8,39,18,47),'#94704A')
                poly([(10,39),(13,35),(16,40)],'#94704A')
                pixel(7,46,WHITE)
        if pose=='sick':
            rect((21,12,26,26),WHITE,INK,1,False)
            rect((23,21,24,24),'#DD7774',None,1,False)
            ell((21,22,26,27),'#DD7774',INK,1,False)
            line([(81,17),(83,21)],'#88B3DE',2)
        if pose=='sad':
            line([(80,26),(82,32),(84,35)],'#74B8D3',2)
        if pose=='hunger':
            # thought bubble with food icon
            ell((2,4,25,22),WHITE,INK,1,False)
            ell((31,23,34,26),WHITE,INK,1,False)
            ell((19,26,21,28),WHITE,INK,1,False)
            ell((7,10,15,15),'#E6A16C',INK,1,False)
            line([(16,11),(21,10)],INK,1,False)
            ell((19,8,22,11),WHITE,INK,1,False)
        if pose in ('eat','eat_carne','eat_vegetais','eat_massa'):
            # food moves from bowl into mouth, becomes smaller as it is eaten
            foodkind='carne' if pose in ('eat_carne','eat') else 'vegetais' if pose=='eat_vegetais' else 'massa'
            dist=[9,9,6,3,1,3,5,8][tick]
            fx=77+dist;fy=37-(tick in (2,3,4))*5
            if foodkind=='carne':
                ell((fx-4,fy-2,fx+3,fy+4),'#C7785D',INK,1)
                line([(fx+3,fy+1),(fx+8,fy-3)],WHITE,2)
            elif foodkind=='vegetais':
                ell((fx-4,fy-3,fx+4,fy+4),'#87C56B',INK,1)
                poly([(fx-1,fy-4),(fx,fy-8),(fx+3,fy-6)],'#468B62',None)
            else:
                ell((fx-4,fy-2,fx+4,fy+4),'#EDC06D',INK,1)
                line([(fx-2,fy+1),(fx+3,fy+1)],'#CE9A46',1)
            if tick in (4,5,6):
                pixel(84,43,'#DFB46F');pixel(88,46,'#E8CB88')
        if pose in ('drink','drink_agua','drink_suco','drink_leite'):
            content= '#94CFEF' if pose in ('drink','drink_agua') else '#F6B35B' if pose=='drink_suco' else '#F7F5E5'
            cupshift=(1 if tick in (2,3,4,5) else 0)
            rect((80,34-cupshift,92,50-cupshift),WHITE,INK,2)
            rect((82,39-cupshift,90,48-cupshift),content,None)
            line([(85,35-cupshift),(82,28-cupshift),(76,29)],'#87B4C5',2)
            if tick in (3,5):
                ell((92,31,94,33),content,None,1,False)
        if pose=='study':
            # comic book, with turning page each 4 frames
            poly([(31,39),(46,35),(57,39),(69,35),(82,40),(82,51),(57,47),(31,51)],WHITE,INK,1)
            line([(57,39),(57,47)],INK,1)
            for yy in (40,43,46):
                line([(35,yy),(48-(tick%3),yy-1)],'#8BBDD3',1,False)
                line([(65,yy),(78-(tick%2),yy-1)],'#8BBDD3',1,False)
            if tick==5:
                poly([(57,39),(68,33),(75,40)],'#FFF0C9',INK,1,False)
        if pose=='play':
            x=[76,80,84,83,79,75,73,74][tick]
            y=[43,39,42,45,43,39,41,44][tick]
            ell((x,y-7,x+8,y+1),'#F3A18D',INK,1,False)
            line([(x+2,y-7),(x+6,y)],WHITE,1,False)
            if tick in (1,5):
                line([(x-7,y-9),(x-4,y-11)],spike,1,False)
        if pose=='bath':
            # water running, moving bubbles + sparkle
            for i in range(7):
                xx=(i*13+tick*3+6)%95
                yy=(i*9+tick*2+2)%49
                ell((xx,yy,xx+4,yy+4),(204,243,254,155),'#71B8CF',1,False)
            for px,py in [(23,11),(82,17)]:
                if tick%3==0:line([(px-3,py),(px+3,py),(px,py-3),(px,py+3)],'#5AB5D2',1,False)
        if pose.startswith('rps_'):
            # Distinct deliberate RPS hand gestures are outside the head outline.
            # The arm remains below/behind the jaw; hand is on the screen right.
            action=pose.split('_')[1]
            if action=='pedra':
                ell((85,28,94,39),skin)
                for y in (31,35):line([(87,y),(92,y)],spike,1)
            elif action=='papel':
                poly([(85,40),(84,23),(87,21),(89,30),(89,18),(91,18),(92,31),(93,24),(93,25),(93,40)],skin)
            else:
                poly([(85,40),(86,30),(85,21),(88,20),(90,29),(91,18),(94,18),(92,32),(93,36),(93,41)],skin)
                line([(88,32),(92,36)],spike,1)
        if pose in ('happy','touch','evolve','wake'):
            if tick in (1,3,5,7):
                for sx,sy in ((18,8),(87,7),(10,25)):
                    line([(sx-2,sy),(sx+2,sy)],'#E5BA6B',1,False)
                    line([(sx,sy-2),(sx,sy+2)],'#E5BA6B',1,False)
            if pose=='evolve':
                for xx,yy in [(13,13),(22,6),(87,15)]:pixel(xx+(tick%3),yy,'#A69DDA')

    # triple pixel scale, 2 transparent lines so Zepp dimensions remain identical.
    large=img.resize((288,162),Image.Resampling.NEAREST)
    out=Image.new('RGBA',(288,164),(0,0,0,0));out.paste(large,(0,1))
    return out


def main():
    n=0
    for stem in STEMS:
        for pose in POSES:
            folder=ROOT/stem/pose;folder.mkdir(parents=True,exist_ok=True)
            for tick in range(4):
                render(stem,pose,tick).save(folder/f'frame_{tick}.png',optimize=True)
                n+=1
    print(f'DinoPocket 1.5.3: {n} quadros em {len(STEMS)} evolucoes x {len(POSES)} reacoes (288x164)')
if __name__=='__main__':main()
