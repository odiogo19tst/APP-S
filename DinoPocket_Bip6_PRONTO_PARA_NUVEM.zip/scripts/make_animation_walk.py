"""Cria quadros autorais LCD: dinossauro move-se pelo visor e pisca.
Mantem os arquivos originais para garantir retrocompatibilidade da identidade visual.
"""
from PIL import Image, ImageDraw
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]/'assets'/'390x450-bip6'
NAMES=['egg','baby','small','young','rex','bronto','trike','sick','ghost']
ink=(35,58,49,255)
for name in NAMES:
    icon=Image.open(ROOT/f'{name}.png').convert('RGBA')
    folder=ROOT/'anim'/name
    folder.mkdir(parents=True,exist_ok=True)
    for i in range(8):
        frame=Image.new('RGBA',(290,166),(0,0,0,0))
        # Walk left/right in the old LCD style, 3 fps; egg sways without jumping.
        x=[57,63,70,77,84,77,70,63][i]
        y=10 if name=='egg' else [8,8,7,8,8,9,8,7][i]
        if name=='egg':
            egg=icon.rotate([-5,-3,0,3,5,3,0,-3][i],resample=Image.Resampling.NEAREST,expand=False)
            frame.alpha_composite(egg,(x,y))
            if i>=6:
                d=ImageDraw.Draw(frame)
                d.line([(x+75,y+10),(x+80,y+17),(x+75,y+23)],fill=ink,width=3)
        else:
            frame.alpha_composite(icon,(x,y))
            if name!='ghost' and i in (3,7):
                # Pequeno piscar pontual no sprite LCD; minimo para nao apagar o desenho.
                d=ImageDraw.Draw(frame)
                d.line([(x+58,y+81),(x+66,y+81)],fill=ink,width=3)
            if name not in ('sick','ghost') and i in (1,5):
                d=ImageDraw.Draw(frame)
                d.rectangle([x+47,y+152,x+53,y+156],fill=ink)
        frame.save(folder/f'frame_{i}.png',optimize=True)
print('Gerados',len(NAMES)*8,'quadros de animacao')
