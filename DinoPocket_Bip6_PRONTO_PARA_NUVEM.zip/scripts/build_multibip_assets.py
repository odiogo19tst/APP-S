"""Generate resolution-specific assets for Bip 5, Bip 5 Unity, and Bip Max.
Nearest-neighbor scales the actual sprites; native Bip 6 artwork stays untouched.
"""
from pathlib import Path
from PIL import Image
import shutil

root = Path(__file__).resolve().parents[1]
source = root / 'assets' / '390x450-bip6'
profiles = [
    ('320x380-bip5', 320,380, False),
    ('320x380-bip5unity', 320,380, True),
    ('432x514-bipmax', 432,514, True),
]
for target, width,height, sound in profiles:
    dest = root / 'assets' / target
    xscale=width/390
    yscale=height/450
    for img in source.rglob('*.png'):
        relative=img.relative_to(source)
        out=dest/relative
        out.parent.mkdir(parents=True,exist_ok=True)
        with Image.open(img) as base:
            # Character sprite sheets are pixel art; preserve the pixels as crisp blocks
            # Use a single scale factor so the animal stays anatomically proportionate.
            scale = min(xscale, yscale)
            factor = 1 if relative.name=='icon.png' else scale
            size=(max(1,round(base.width*factor)),max(1,round(base.height*factor)))
            if size == base.size:
                base.save(out,optimize=True)
            else:
                base.resize(size, Image.Resampling.NEAREST).save(out,optimize=True)
    if sound:
        shutil.copytree(source/'sfx',dest/'sfx',dirs_exist_ok=True)
    print(target, 'images',len(list(dest.rglob('*.png'))),'sound', sound)
