"""Gera sprites autorais monocromáticos LCD para o DinoPocket."""
from PIL import Image, ImageDraw, ImageFont
from pathlib import Path
OUT=Path(__file__).resolve().parent.parent/'assets'/'390x450-bip6'
OUT.mkdir(parents=True,exist_ok=True)
D='#24382d'; G='#8da28a'; H='#d9e6cb'; A='#5b7058'

def sprite(name, body):
    im=Image.new('RGBA',(36,36),(0,0,0,0));d=ImageDraw.Draw(im)
    body(d)
    # modo pixel art: pixels 4x, sem suavizacao
    im=im.resize((144,144),Image.Resampling.NEAREST)
    res=Image.new('RGBA',(146,146),(0,0,0,0));res.alpha_composite(im,(1,1))
    res.save(OUT/(name+'.png'))

def poly(d,points,c=D):d.polygon(points,fill=c)
def rect(d,x1,y1,x2,y2,c=D):d.rectangle((x1,y1,x2,y2),fill=c)
def ell(d,coords,c=D):d.ellipse(coords,fill=c)
def eye(d,x,y):
    rect(d,x,y,x+1,y+1,D)

def feet(d,x=8,y=27,n=2):
    for i in range(n):
        xx=x+i*14
        rect(d,xx,y,xx+5,y+3,D)

def egg(d):
    ell(d,(9,3,28,32),D);ell(d,(11,5,26,30),H)
    for x,y in [(14,15),(24,18),(18,25),(15,28)]:rect(d,x,y,x+1,y+1,A)

def baby(d):
    ell(d,(5,11,31,29),D);ell(d,(7,13,29,27),H)
    poly(d,[(25,20),(34,23),(33,25),(27,26)],D);poly(d,[(26,22),(30,23),(26,24)],H)
    eye(d,14,21);eye(d,24,21);rect(d,17,26,20,26,A)
    feet(d,8,28)

def small(d):
    ell(d,(4,10,30,29),D);ell(d,(6,12,28,27),H)
    poly(d,[(25,20),(34,20),(33,26),(27,26)],D);rect(d,28,23,31,24,H)
    poly(d,[(9,14),(7,11),(13,13)],D);eye(d,15,20);eye(d,24,20)
    feet(d,8,28)

def young(d):
    ell(d,(4,8,29,29),D);ell(d,(6,10,27,27),H)
    poly(d,[(22,19),(35,20),(35,25),(24,25)],D);rect(d,28,22,33,23,H)
    for xx,yy in [(10,12),(15,9),(20,10)]:poly(d,[(xx,yy+4),(xx+3,yy),(xx+5,yy+4)],D)
    eye(d,14,19);feet(d,8,29)

def rex(d):
    # Dinossauro carnivoro: cabeca grande, bracos pequenos, cauda
    poly(d,[(12,7),(27,7),(30,12),(32,13),(33,20),(28,22),(24,20),(25,27),(21,30),(13,30),(10,26),(11,20),(7,19),(7,14)],D)
    poly(d,[(14,9),(25,9),(27,13),(31,15),(31,19),(25,19),(23,24),(20,28),(15,28),(12,25),(13,19),(9,18),(9,14)],H)
    poly(d,[(11,24),(3,21),(6,26),(14,28)],D)
    eye(d,19,14)
    for x in (26,29): rect(d,x,20,x,21,D)
    rect(d,25,25,29,26,D);feet(d,12,29)
    rect(d,26,12,30,13,D)

def bronto(d):
    poly(d,[(3,21),(10,16),(20,17),(22,7),(25,3),(32,4),(33,10),(28,12),(27,23),(24,29),(10,29)],D)
    poly(d,[(6,22),(11,18),(21,19),(24,9),(26,5),(31,6),(31,9),(26,10),(25,24),(23,27),(10,27)],H)
    poly(d,[(8,22),(1,16),(3,26),(10,27)],D)
    eye(d,28,7);feet(d,10,28)

def trike(d):
    ell(d,(5,12,29,28),D);ell(d,(7,14,27,26),H)
    poly(d,[(23,10),(34,12),(33,23),(23,24)],D)
    poly(d,[(24,13),(32,14),(31,21),(24,21)],H)
    poly(d,[(24,14),(25,6),(29,13)],D);poly(d,[(30,17),(34,13),(33,19)],D)
    poly(d,[(4,23),(1,18),(2,27)],D)
    eye(d,22,17);feet(d,8,27)

def sick(d):
    small(d);rect(d,11,5,15,7,D);rect(d,13,3,13,9,D)

def ghost(d):
    ell(d,(7,8,29,30),D)
    ell(d,(9,10,27,28),H)
    for x in (10,15,20,25):rect(d,x,27,x+2,32,H)
    eye(d,14,17);eye(d,22,17)
    rect(d,18,22,20,24,D)

for name,fn in [('egg',egg),('baby',baby),('small',small),('young',young),('rex',rex),('bronto',bronto),('trike',trike),('sick',sick),('ghost',ghost)]:sprite(name,fn)
# Ícone do lançador de apps: fundo LCD e moldura com dino no centro.
im=Image.new('RGB',(128,128),'#293c30');d=ImageDraw.Draw(im)
d.rounded_rectangle((8,8,119,119),radius=22,fill='#b8cbaa')
d.rounded_rectangle((22,16,105,93),radius=10,fill='#dbe5ce')
pixel=Image.open(OUT/'baby.png').convert('RGBA').resize((78,78),Image.Resampling.NEAREST)
im.paste(pixel,(25,17),pixel)
d.rounded_rectangle((28,98,99,110),radius=6,fill='#293c30')
im.save(OUT/'icon.png')

# Exemplo da UI real, em dimensoes 390x450, para visualizar no celular.
p=Image.new('RGB',(390,450),'#14201c'); d=ImageDraw.Draw(p)
d.rounded_rectangle((14,14,376,434),radius=22,fill='#313e38')
d.rounded_rectangle((25,25,365,391),radius=10,fill='#c3ceab')
d.rounded_rectangle((25,25,365,67),radius=8,fill='#e4ebd8')
f='/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf'
font=lambda size: ImageFont.truetype(f,size)
def center(t,top,size,ink='#233a31'):
    bb=d.textbbox((0,0),t,font=font(size));d.text(((390-bb[2]+bb[0])/2,top),t,font=font(size),fill=ink)
center('DINOPOCKET',30,23);center('DIA 2  |  GERACAO 1',72,16)
d.rounded_rectangle((49,95,341,299),radius=10,fill='#e4ebd8')
sp=Image.open(OUT/'small.png').convert('RGBA');p.paste(sp,(122,107),sp)
center('Estou crescendo!',260,18)
for x,t in [(38,'CUIDAR'),(204,'STATUS')]:
    d.rounded_rectangle((x,315,x+148,368),radius=12,fill='#42574a')
    bb=d.textbbox((0,0),t,font=font(18));d.text((x+(148-bb[2])/2,330),t,font=font(18),fill='white')
d.rounded_rectangle((39,400,351,422),radius=8,fill='#17231e')
center('DINOPOCKET  //  90s EDITION',401,12,'#c3ceab')
p.save(OUT.parent.parent/'DinoPocket_PREVIA.png')
print('sprites',len(list(OUT.glob('*.png'))))
