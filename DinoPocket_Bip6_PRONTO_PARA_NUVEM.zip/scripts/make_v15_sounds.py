"""DinoPocket 1.5: tons originais, curtos, suaves, sem distorcao e com envelope musical.
Generates device-compatible mono MP3 at 22.05 kHz.
"""
from pathlib import Path
import subprocess, wave, numpy as np
ROOT=Path(__file__).resolve().parents[1]/'assets'/'390x450-bip6'/'sfx'
RATE=22050
# nome -> (notas midi, duracao total, onda)
MELODIES={
 'soft_egg':([60,64],.42,'sine'), 'soft_hatch':([60,64,67,72],.77,'bell'),
 'soft_evolve':([55,60,64,67,72],1.01,'bell'),
 'soft_happy':([67,72,76],.54,'bell'),
 'soft_nibble':([50,54,50],.45,'pop'),
 'soft_drink':([62,66,71],.58,'sine'),
 'soft_bubble':([64,69,74,79],.67,'pop'),
 'soft_alert':([68,64,68],.7,'bell'),
 'soft_sick':([60,57],.54,'sine'),
 'soft_study':([65,69,72],.71,'bell'),
 'soft_play':([64,69,73,76],.66,'pop'),
 'soft_sleep':([67,62,59],.90,'sine'),
 'soft_wake':([60,64,69],.56,'bell'),
 'soft_win':([64,67,72,79],.76,'bell'),
 'soft_lose':([65,62,59],.63,'sine'),
 'soft_tie':([65,65,67],.5,'pop'),
 'soft_touch':([69,76],.36,'pop'),
 'soft_poop':([53,49],.4,'pop'),
 'soft_egg_b':([62,65],.44,'pop'),
 'soft_mischief':([64,61,66,64],.48,'pop'),
 'soft_giggle':([69,74,69,76],.62,'pop'),
 'soft_hungry':([55,53,57],.55,'sine')
}
def midi_hz(note):return 440*2**((note-69)/12)
def synth(notes,duration,kind):
    samples=np.zeros(int(RATE*duration),dtype=np.float64)
    m=len(notes)
    segment=duration/m*0.80
    for i,note in enumerate(notes):
        start=int(i*(duration/m)*RATE)
        ln=int(segment*RATE)
        t=np.arange(ln)/RATE
        freq=midi_hz(note)
        # mix a soft fundamental with a small filtered upper harmonic
        wave1=np.sin(2*np.pi*freq*t)
        overtone=.16*np.sin(2*np.pi*2*freq*t) if kind=='bell' else .06*np.sin(2*np.pi*2*freq*t)
        if kind=='pop':wave1=np.sin(2*np.pi*(freq*t+1.2*t*np.exp(-t*18)))
        attack=np.minimum(1,t/.012)
        decay=np.exp(-t*(7.8 if kind=='pop' else 3.8))
        release=np.minimum(1,(segment-t)/.075)
        env=attack*decay*np.maximum(0,release)
        length=min(ln,len(samples)-start)
        samples[start:start+length]+=(wave1[:length]+overtone[:length])*env[:length]
    # 5 ms fades, peak below -11 dBFS, minimal sibilance
    peak=max(1,float(np.max(np.abs(samples))))
    return np.int16(samples/peak*.27*32767)

def make_sound(name,notes,length,kind):
    data=synth(notes,length,kind)
    raw=Path('/tmp')/(name+'_dino.wav')
    with wave.open(str(raw),'wb') as out:
        out.setnchannels(1);out.setsampwidth(2);out.setframerate(RATE);out.writeframes(data.tobytes())
    mp3=ROOT/(name+'.mp3')
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(raw),'-ar','22050','-ac','1','-b:a','64k',str(mp3)],check=True)
    raw.unlink()
    return data

if __name__=='__main__':
    output=[]
    for name,params in MELODIES.items():
        output.append(make_sound(name,*params))
    print('Sons suaves gerados:',len(output))
    # mp3 preview as all samples with pauses
    silence=np.zeros(int(RATE*.25),dtype=np.int16)
    preview=np.concatenate([z for section in output for z in (section,silence)])
    sample=Path('/tmp/dinopocket_audio_v15_preview.wav')
    with wave.open(str(sample),'wb') as out:
        out.setnchannels(1);out.setsampwidth(2);out.setframerate(RATE);out.writeframes(preview.tobytes())
    dest=Path(__file__).resolve().parents[2]/'DinoPocket_1_5_Preview_Sons.mp3'
    subprocess.run(['ffmpeg','-hide_banner','-loglevel','error','-y','-i',str(sample),'-ar','22050','-ac','1','-b:a','64k',str(dest)],check=True)
    sample.unlink()
    print('Previa:',dest)
