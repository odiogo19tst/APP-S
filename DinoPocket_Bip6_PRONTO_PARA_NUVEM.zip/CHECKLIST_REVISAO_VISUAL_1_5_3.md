# Auditoria visual — DinoPocket 1.5.3

## Concluído no código-fonte e nos PNGs gerados
- [x] Revisar desenho-base nas 9 variantes gráficas.
- [x] Inspecionar posições de braço e mão em idle, happy, touch, wake, play, sleep.
- [x] Posicionar os braços abaixo/atrás da cabeça para não cortar os olhos, as bochechas ou a boca.
- [x] Manter livro e copo sobre as mãos (objetos intencionais no primeiro plano).
- [x] Manter mãos e sinais do pedra-papel-tesoura visíveis fora do rosto.
- [x] Revisar os 25 estados/ações em quatro quadros por pose, por variante.
- [x] Preservar ovo, bebê, filhote, jovem, rex, bronto e trike, incluindo doente e fantasma.
- [x] Preservar ID do pacote e chave de salvamento do pet.
- [x] Regenerar 900 PNGs com dimensões corretas.
- [x] Passar nos 69 testes automatizados.

## Ainda falta validar no Amazfit Bip 6 físico
- [ ] Compilar versão 1.5.3 no GitHub Actions.
- [ ] Instalar por QR do Zepp sem desinstalar a 1.5.2.
- [ ] Confirmar que idade, geração e evolução não reiniciaram.
- [ ] Confirmar que braços não atravessam rosto nas poses de carinho, felicidade, brincadeira e minijogo.
- [ ] Confirmar fluidez dos 4 quadros e sons em todo o dia de uso.
