import { createWidget, deleteWidget, widget, align, text_style } from '@zos/ui'
import { LocalStorage } from '@zos/storage'
import { newGame, revive, tick, act, spriteName, describe, speciesName } from '../src/game'

// 390 x 450 - Amazfit Bip 6. UI inspirada em LCD, com botoes grandes para toque.
const C = {
  black: 0x14201c, frame: 0x313e38, lcd: 0xc3ceab, light: 0xe4ebd8,
  ink: 0x233a31, soft: 0x879885, button: 0x42574a, white: 0xffffff,
  alert: 0x852e38, dark: 0x17231e
}
const store = new LocalStorage()
const KEY = 'dinopocket.state.v1'
let game = null
let elements = []
let screen = 'home'

function box(x, y, w, h, color, radius = 0) {
  elements.push(createWidget(widget.FILL_RECT, {x, y, w, h, color, radius}))
}
function label(text, x, y, w, h, size = 21, color = C.ink, where = align.CENTER_H) {
  elements.push(createWidget(widget.TEXT, {
    text, x, y, w, h, color, text_size: size, align_h: where,
    align_v: align.CENTER_V, text_style: text_style.ELLIPSIS
  }))
}
function picture(filename, x, y, w, h) {
  elements.push(createWidget(widget.IMG, {src: filename, x, y, w, h}))
}
function button(text, x, y, w, h, fn, danger = false) {
  elements.push(createWidget(widget.BUTTON, {
    x, y, w, h, text, text_size: 18, color: C.white, radius: 13,
    normal_color: danger ? C.alert : C.button,
    press_color: C.ink,
    click_func: fn
  }))
}
function persist() { store.setItem(KEY, game) }
function update() { game = tick(game, Date.now()); persist() }
function clear() {
  for (let i = elements.length - 1; i >= 0; i--) deleteWidget(elements[i])
  elements = []
}
function base(title) {
  box(0, 0, 390, 450, C.black)
  box(14, 14, 362, 420, C.frame, 20)
  box(25, 25, 340, 366, C.lcd, 10)
  box(25, 25, 340, 42, C.light, 8)
  label(title, 34, 27, 322, 36, 24)
  box(39, 400, 312, 22, C.dark, 10)
  label('DINOPOCKET  //  90s EDITION', 39, 400, 312, 22, 12, C.lcd)
}
function footerBack() { button('VOLTAR', 106, 335, 178, 42, () => {screen = 'home'; render()}) }
function statusLine(txt, val, y) {
  label(txt, 53, y, 128, 25, 17, C.ink, align.LEFT)
  box(177, y + 6, 159, 13, C.soft, 4)
  box(177, y + 6, Math.round(159 * val / 100), 13, C.ink, 4)
}
function home() {
  base('DINOPOCKET')
  label('DIA ' + game.ageDays + '  |  GERACAO ' + game.generation, 45, 67, 300, 28, 16)
  box(49, 95, 292, 204, C.light, 10)
  picture(spriteName(game), 122, 107, 146, 146)
  label(game.dead ? 'FIM DA JORNADA' : describe(game), 56, 262, 280, 32, 17)
  if (game.dead) {
    button('NOVO OVO', 80, 313, 230, 57, () => {
      game = revive(game, Date.now()); persist(); screen = 'home'; render()
    })
  } else if (game.stage === 0) {
    button('STATUS', 80, 313, 230, 57, () => {screen = 'status'; render()})
  } else {
    button('CUIDAR', 38, 315, 148, 53, () => {screen='care'; render()})
    button('STATUS', 204, 315, 148, 53, () => {screen='status'; render()})
  }
}
function care() {
  base('CUIDAR DO DINO')
  label(game.message, 37, 71, 316, 35, 17)
  button('ALIMENTAR', 51, 116, 288, 48, () => {screen='food'; render()})
  button('BRINCAR', 51, 174, 138, 48, () => apply('brincar'))
  button('BANHO', 201, 174, 138, 48, () => apply('banho'))
  button('DORMIR', 51, 232, 138, 48, () => apply('dormir'))
  button('REMEDIO', 201, 232, 138, 48, () => apply('remedio'))
  footerBack()
}
function food() {
  base('HORA DE COMER')
  label('A comida define a evolucao!', 40, 74, 310, 32, 17)
  button('CARNE', 51, 114, 288, 55, () => feed('carne'))
  button('FRUTAS / VEGETAIS', 51, 180, 288, 55, () => feed('vegetais'))
  button('MASSA', 51, 246, 288, 55, () => feed('massa'))
  footerBack()
}
function status() {
  base('STATUS DO DINO')
  label(game.dead ? 'DESCANSOU' : game.stage === 4 ? speciesName(game.species) : 'DIA ' + game.ageDays, 42, 70, 305, 33, 20)
  statusLine('SACIEDADE', game.hunger, 111)
  statusLine('FELICIDADE', game.joy, 147)
  statusLine('HIGIENE', game.hygiene, 183)
  statusLine('ENERGIA', game.energy, 219)
  statusLine('SAUDE', game.health, 255)
  label('Carne ' + game.meals.carne + '  Fruta ' + game.meals.vegetais + '  Massa ' + game.meals.massa, 40, 289, 312, 28, 14)
  footerBack()
}
function apply(name) {
  game = act(game, name, Date.now()); persist(); screen='care'; render()
}
function feed(name) {
  game = act(game, name, Date.now()); persist(); screen='care'; render()
}
function render() {
  if (!game) return
  update()
  clear()
  if (screen === 'food') food()
  else if (screen === 'care') care()
  else if (screen === 'status') status()
  else home()
}

Page({
  onInit() {
    const loaded = store.getItem(KEY, null)
    game = loaded && loaded.schema === 1 ? loaded : newGame(Date.now())
    game = tick(game, Date.now()); persist()
  },
  build() { render() },
  onDestroy() { if (game) persist(); clear() },
  onResume() { if (game) render() }
})
