import { createWidget, deleteWidget, widget, align, text_style, prop, anim_status, event } from '@zos/ui'
import { LocalStorage } from '@zos/storage'
import { Accelerometer, FREQ_MODE_NORMAL, Vibrator, VIBRATOR_SCENE_SHORT_LIGHT, VIBRATOR_SCENE_NOTIFICATION } from '@zos/sensor'
import { create as createMedia, id as mediaId } from '@zos/media'
import { FX, entryCue, feedbackForAction, shouldPlaySound, feedbackSettings, isQuietHour, expressiveCue, soundMode } from '../src/sound_rules'
import { createHoldDetector } from '../src/touch_rules'
import {
  newGame, revive, spriteName, describe, speciesName,
  act, enhance, advance, setPause, isPaused, needsAttention,
  giveDiscipline, setTemperature, playRps, petAgeString,
  createShakeDetector, wristInteraction, personalityOf, personalityMessage, touchInteraction
} from '../src/game'

// DinoPocket v1.3 - tela LCD imersiva, toque longo e voz expressiva.
// Apenas componentes oficiais Zepp OS. O progresso da v1.0/v1.1 e mantido.
const COLOR = {
  bg:0x16221b, shell:0x344b40, lcd:0xb9c9a4, white:0xdce8c9,
  light:0xd2dfbc, ink:0x263e30, shade:0x8ba286,
  button:0x405948, pressed:0x26382d, alert:0x9a3e3e, text:0xffffff
}
const store = new LocalStorage()
const KEY = 'dinopocket.state.v1'
let pet = null
let controls = []
let screen = 'home'
let result = ''
let lastAction = ''
let motion = null
let motionCallback = null
let player = null
let vibrator = null
let currentSound = null
let pendingStartupCue = null
let holdTimer = null
let speechTimer = null
let speechLine = ''
let voiceIndex = 0
const touchDetector = createHoldDetector(700, 26)

function initFeedback() {
  try {
    if (!player) {
      player = createMedia(mediaId.PLAYER)
      player.addEventListener(player.event.PREPARE, (ready) => {
        if(ready) { try { player.start() } catch(e) {} }
      })
      player.addEventListener(player.event.COMPLETE, () => {
        try { player.stop() } catch(e) {}
      })
    }
  } catch(e) { player = null }
  try { if (!vibrator) vibrator = new Vibrator() } catch(e) { vibrator = null }
}
function feedback(cue, passive=false) {
  if(!cue || !pet || pet.dead || isPaused(pet)) return
  const pref=feedbackSettings(pet)
  // Night silence on passive reminders; user-initiated actions can still sound.
  if(passive && isQuietHour(new Date())) return
  if(pref.vibration && vibrator) {
    try { vibrator.start({mode: cue===FX.alert || cue===FX.sick ? VIBRATOR_SCENE_NOTIFICATION : VIBRATOR_SCENE_SHORT_LIGHT}) } catch(e) {}
  }
  if(!shouldPlaySound(pet,passive) || !player) return
  const selected=expressiveCue(pet,cue,personalityOf(pet),voiceIndex++)
  if(currentSound===selected && passive) return
  try {
    player.stop()
    currentSound=selected
    player.setSource(player.source.FILE,{file:'sfx/'+selected+'.mp3'})
    player.prepare()
  } catch(e) { currentSound=null }
}
function releaseFeedback(){
  try { if(player) player.stop() } catch(e) {}
  player=null
  vibrator=null
  currentSound=null
}

const shakes = createShakeDetector()

function rect(x,y,w,h,color,radius=0) {
  controls.push(createWidget(widget.FILL_RECT,{x,y,w,h,color,radius}))
}
function txt(message,x,y,w,h,size=18,color=COLOR.ink,position=align.CENTER_H) {
  controls.push(createWidget(widget.TEXT,{
    text:String(message),x,y,w,h,text_size:size,color,
    align_h:position,align_v:align.CENTER_V,text_style:text_style.ELLIPSIS
  }))
}
function tap(label,x,y,w,h,action,danger=false,size=17) {
  controls.push(createWidget(widget.BUTTON,{
    x,y,w,h,text:label,text_size:size,color:COLOR.text,
    radius:11,normal_color:danger?COLOR.alert:COLOR.button,
    press_color:COLOR.pressed,click_func:action
  }))
}
function spriteAnim(name,x=51,y=103) {
  const anim=createWidget(widget.IMG_ANIM,{
    x,y,anim_path:'anim/'+name,anim_prefix:'frame',anim_ext:'png',
    anim_fps:3,anim_size:8,repeat_count:0,anim_repeat:true,anim_status:3
  })
  controls.push(anim)
  anim.setProperty(prop.ANIM_STATUS,anim_status.START)
}
function clearHoldTimer() {
  if(holdTimer !== null) { try { clearTimeout(holdTimer) } catch(e) {} }
  holdTimer=null
}
function clear() {
  clearHoldTimer()
  for(let i=controls.length-1;i>=0;i--) deleteWidget(controls[i])
  controls=[]
}
function save() { store.setItem(KEY,pet) }
function update() { pet=advance(pet,Date.now());save() }
function backdrop(header) {
  rect(0,0,390,450,COLOR.bg)
  rect(12,12,366,427,COLOR.shell,22)
  rect(23,23,344,365,COLOR.lcd,14)
  rect(29,29,332,37,COLOR.light,7)
  txt(header,36,30,318,35,22)
  rect(29,395,332,31,COLOR.bg,8)
  txt('DINOPOCKET  //  90s EDITION',32,398,326,26,12,COLOR.lcd)
}
function bottom(label='VOLTAR',target='home') {
  tap(label,114,337,162,44,()=>{screen=target;render()})
}
function lcdFrame() {
  rect(38,91,314,188,COLOR.shade,7)
  rect(43,95,304,179,COLOR.light,7)
  // Marcacoes LCD, como no brinquedo original
  for(let y=118;y<262;y+=24){ rect(48,y,5,5,COLOR.shade,1);rect(337,y,5,5,COLOR.shade,1) }
}
function petTouch() {
  if(!pet || pet.dead) return
  pet=touchInteraction(pet,Date.now())
  save()
  speechLine=pet.message
  if(speechTimer!==null) {try{clearTimeout(speechTimer)}catch(e){}}
  render()
  feedback(pet.stage===0?FX.egg:FX.happy)
  speechTimer=setTimeout(()=>{
    speechTimer=null
    speechLine=''
    if(screen==='home') render()
  },2500)
}
function touchArea() {
  // Captura os toques acima dos sprites para que o Dino ocupe a tela inteira.
  // Grupo foi escolhido conforme a documentacao oficial do Zepp OS.
  const group=createWidget(widget.GROUP,{x:30,y:69,w:330,h:315})
  controls.push(group)
  group.createWidget(widget.FILL_RECT,{
    x:0,y:0,w:330,h:315,color:COLOR.lcd,alpha:0
  })
  group.addEventListener(event.CLICK_DOWN,(info)=>{
    clearHoldTimer()
    touchDetector.down(info,Date.now())
    holdTimer=setTimeout(()=>{
      holdTimer=null
      if(touchDetector.trigger(Date.now())==='hold' && screen==='home'){
        speechLine=''
        go('menu')
      }
    },710)
  })
  group.addEventListener(event.MOVE,(info)=>{
    if(!touchDetector.move(info))clearHoldTimer()
  })
  group.addEventListener(event.MOVE_OUT,()=>{
    touchDetector.cancel();clearHoldTimer()
  })
  group.addEventListener(event.CLICK_UP,()=>{
    clearHoldTimer()
    const action=touchDetector.up(Date.now())
    if(action==='hold' && screen==='home'){speechLine='';go('menu')}
    else if(action==='tap' && screen==='home')petTouch()
  })
}
function home() {
  // Tela imersiva. O menu fica escondido (segurar), exceto atalho discreto.
  rect(0,0,390,450,COLOR.bg)
  rect(12,12,366,426,COLOR.shell,24)
  rect(23,24,344,402,COLOR.lcd,15)
  rect(32,31,326,34,COLOR.light,6)
  txt('DINOPOCKET',41,33,175,29,17,COLOR.ink,align.LEFT)
  txt(petAgeString(pet),212,33,91,29,14,COLOR.ink)
  // LCD grande com marcacoes laterais do brinquedo classico.
  rect(37,75,316,299,COLOR.shade,11)
  rect(42,80,306,288,COLOR.light,8)
  for(let y=106;y<324;y+=32){rect(47,y,6,7,COLOR.shade,1);rect(336,y,6,7,COLOR.shade,1)}
  spriteAnim(spriteName(pet).replace('.png',''),51,134)
  const currentMessage = speechLine || (isPaused(pet)?'PAUSADO':describe(pet))
  txt(currentMessage,64,308,264,42,17,COLOR.ink)
  if(pet.dead) {
    tap('NOVO OVO',107,379,177,37,()=>{
      pet=enhance(revive(pet,Date.now()));save();speechLine='';render()
    },false,15)
  } else {
    txt('TOQUE: CARINHO   |   SEGURE: MENU',47,386,296,27,12,COLOR.ink)
  }
  const attention=needsAttention(pet)
  if(attention) txt('! '+attention+' !',92,354,206,20,15,COLOR.alert)
  // Registro por ultimo: widgets acima nao bloqueiam o gesto do LCD.
  touchArea()
  // Atalho redundante caso algum firmware reserve o gesto longo.
  tap('MENU',307,32,53,31,()=>{speechLine='';go('menu')},false,11)
}

function go(name) {screen=name;if(name!=='reaction')result='';render()}
function choose(label,x,y,target){tap(label,x,y,148,47,()=>go(target),false,15)}
function menu() {
  backdrop('MENU LCD')
  txt('Escolha um cuidado',47,73,298,28,18)
  const items=[
    ['COMIDA','food'],['JOGO','game'],
    ['LIMPAR','clean'],['DORMIR','sleep'],
    ['REMEDIO','heal'],['EDUCAR','discipline'],
    ['TEMP.','temp'],['STATUS','status'],
    ['PAUSA','pause'],['RELOGIO','clock']
  ]
  items.forEach((item,index)=>{
    const x=index%2===0?41:201
    const y=106+Math.floor(index/2)*42
    tap(item[0],x,y,148,36,()=>{
      if(item[1]==='clean'){perform('banho');return}
      if(item[1]==='sleep'){perform('dormir');return}
      if(item[1]==='heal'){perform('remedio');return}
      if(item[1]==='discipline'){perform('educar');return}
      go(item[1])
    },false,15)
  })
  tap('ALERTAS',41,314,308,34,()=>go('alerts'),false,14)
  tap('VOLTAR',112,355,166,32,()=>go('home'),false,14)
}
function alertSettings(){
  backdrop('SONS E ALERTAS')
  txt('Dino com voz propria!',38,74,314,29,19)
  txt('Som: '+(pet.soundEnabled===false?'OFF':'ON'),42,110,306,27,19)
  tap('LIGAR / DESLIGAR',51,143,288,40,()=>{
    pet.soundEnabled=pet.soundEnabled===false;save();render();feedback(FX.happy)
  },false,14)
  txt('ESTILO: '+(soundMode(pet)==='expressivo'?'EXPRESSIVO':'CLASSICO'),40,196,310,28,16)
  tap('TROCAR ESTILO',51,226,288,40,()=>{
    pet.soundStyle=soundMode(pet)==='classico'?'expressivo':'classico'
    save();render();feedback(FX.happy)
  },false,14)
  txt('VIBRACAO: '+(pet.vibrationEnabled===false?'OFF':'ON'),39,273,312,25,16)
  tap('ALTERNAR VIBRA',51,304,288,37,()=>{
    pet.vibrationEnabled=pet.vibrationEnabled===false;save();render();feedback(FX.care)
  },false,14)
  bottom('MENU','menu')
}
function food() {
  backdrop('ALIMENTAR')
  txt('A comida define a evolucao!',45,76,300,30,17)
  tap('CARNE',49,118,292,51,()=>perform('carne'))
  tap('FRUTAS E VERDURAS',49,177,292,51,()=>perform('vegetais'),false,16)
  tap('MASSA',49,236,292,51,()=>perform('massa'))
  bottom('MENU','menu')
}
function statusBar(label,value,y){
  txt(label,42,y,125,25,16,COLOR.ink,align.LEFT)
  rect(171,y+6,174,13,COLOR.shade,5)
  rect(171,y+6,Math.round(174*Math.max(0,Math.min(100,Number(value)||0))/100),13,COLOR.ink,5)
}
function status() {
  backdrop('STATUS')
  txt(pet.stage>=4?speciesName(pet.species):petAgeString(pet),45,69,300,28,17)
  statusBar('SACIEDADE',pet.hunger,105)
  statusBar('ALEGRIA',pet.joy,136)
  statusBar('HIGIENE',pet.hygiene,167)
  statusBar('ENERGIA',pet.energy,198)
  statusBar('SAUDE',pet.health,229)
  statusBar('DISCIPLINA',pet.discipline,260)
  txt('C '+pet.meals.carne+'    F '+pet.meals.vegetais+'    M '+pet.meals.massa,53,286,284,26,16)
  txt('JEITO: '+personalityOf(pet).toUpperCase(),48,313,294,22,14)
  bottom()
}
function gameScreen() {
  backdrop('PEDRA PAPEL TESOURA')
  txt('Escolha sua jogada!',48,81,294,34,19)
  txt('Dino x Voce',47,128,296,38,23)
  tap('PEDRA',42,206,96,57,()=>play('pedra'),false,15)
  tap('PAPEL',147,206,96,57,()=>play('papel'),false,15)
  tap('TESOURA',252,206,96,57,()=>play('tesoura'),false,14)
  txt('Vitorias: '+pet.gamesWon+'/'+pet.gamesPlayed,60,282,270,28,17)
  bottom('MENU','menu')
}
function play(choice) {
  if(pet.stage===0 || pet.dead || isPaused(pet)){result='Espere o nascimento!';go('reaction');return}
  const data=playRps(pet,choice,Date.now())
  pet=data.state;save();result=pet.message;lastAction='JOGO';go('reaction');feedback(FX.happy)
}
function perform(action) {
  if(pet.stage===0 || pet.dead || isPaused(pet)){result='Dino ainda nao pode!';lastAction='AVISO';go('reaction');return}
  if(action==='educar') pet=giveDiscipline(pet,Date.now())
  else pet=enhance(act(pet,action,Date.now()))
  result=pet.message
  lastAction=action==='banho'?'BANHO':action==='dormir'?'SONO':action==='remedio'?'REMEDIO':action==='educar'?'EDUCAR':'NHAC!'
  save();go('reaction');feedback(feedbackForAction(action))
}
function reaction() {
  backdrop('DINO REAGE!')
  txt(lastAction||'CUIDADO',50,69,290,28,18)
  lcdFrame()
  spriteAnim(spriteName(pet).replace('.png',''),51,103)
  txt(result||pet.message,52,252,286,26,17)
  tap('OK',80,313,230,54,()=>go('home'))
}
function tempScreen() {
  backdrop('TEMPERATURA')
  txt('Controle o ambiente',42,89,306,31,19)
  txt(String(pet.temperature)+' C',76,141,238,57,38)
  tap('MENOS',43,224,144,54,()=>changeTemp(-1))
  tap('MAIS',203,224,144,54,()=>changeTemp(1))
  bottom('MENU','menu')
}
function changeTemp(n){pet=setTemperature(pet,n,Date.now());save();render();feedback(FX.care)}
function pauseScreen() {
  backdrop('PAUSA')
  txt(isPaused(pet)?'SEU DINO ESTA PAUSADO':'PAUSE OS CUIDADOS',43,82,304,42,19)
  txt('Quando pausar, a idade e as',43,138,304,28,16)
  txt('necessidades ficam congeladas.',43,170,304,28,16)
  tap(isPaused(pet)?'CONTINUAR':'PAUSAR DINO',55,224,280,58,()=>{
    pet=setPause(pet,!isPaused(pet),Date.now());save();go('home')
  })
  bottom('MENU','menu')
}
function clockScreen() {
  backdrop('RELOGIO')
  const now=new Date()
  const clock=(n)=>String(n).padStart(2,'0')
  txt(clock(now.getHours())+':'+clock(now.getMinutes()),42,104,306,76,48)
  txt('Tempo de vida: '+pet.ageDays+' dia(s)',42,207,306,29,18)
  txt('GERACAO '+pet.generation,42,253,306,30,20)
  bottom('MENU','menu')
}
function onMotion() {
  if(!pet || screen!=='home' || pet.dead || isPaused(pet) || !motion) return
  let sample
  try { sample=motion.getCurrent() } catch(error) { return }
  if(!shakes.feed(sample,Date.now())) return
  pet=enhance(wristInteraction(pet,Date.now()))
  save()
  result=pet.message
  lastAction=pet.stage===0?'OVO MEXEU!':'BRINCADEIRA!'
  go('reaction')
  feedback(pet.stage===0?FX.egg:FX.happy)
}
function startMotion() {
  if(motion) return
  try {
    motion=new Accelerometer()
    motionCallback=onMotion
    motion.setFreqMode(FREQ_MODE_NORMAL)
    motion.onChange(motionCallback)
    motion.start()
  } catch(error) {
    // Sem permissao ou acelerometro: o restante do jogo continua normalmente.
    stopMotion()
  }
}
function stopMotion() {
  if(motion){
    try { if(motionCallback) motion.offChange(motionCallback) } catch(error) {}
    try { motion.stop() } catch(error) {}
  }
  motion=null
  motionCallback=null
  shakes.reset()
}
function render() {
  if(!pet) return
  update();clear()
  if(screen==='menu') menu()
  else if(screen==='food') food()
  else if(screen==='status') status()
  else if(screen==='game') gameScreen()
  else if(screen==='reaction') reaction()
  else if(screen==='temp') tempScreen()
  else if(screen==='pause') pauseScreen()
  else if(screen==='clock') clockScreen()
  else if(screen==='alerts') alertSettings()
  else home()
}
Page({
  onInit(){
    const saved=store.getItem(KEY,null)
    pet=enhance(saved&&saved.schema===1?saved:newGame(Date.now()))
    const before={...pet}
    update()
    pendingStartupCue=entryCue(before,pet)
  },
  build(){
    initFeedback();render();startMotion()
    if(pendingStartupCue) {feedback(pendingStartupCue,true);pendingStartupCue=null}
  },
  onDestroy(){
    stopMotion();releaseFeedback()
    clearHoldTimer()
    if(speechTimer!==null){try{clearTimeout(speechTimer)}catch(e){}}
    if(pet)save();clear()
  }
})
