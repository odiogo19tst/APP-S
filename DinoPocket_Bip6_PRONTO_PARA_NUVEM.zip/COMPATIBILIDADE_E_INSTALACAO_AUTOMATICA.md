# DinoPocket Retro 1.5.4 — instalação por modelo (beta)

## Como funciona para o usuário após aprovação na Zepp App Store

O usuário acessa o aplicativo **DinoPocket Retro** na loja do Zepp com o relógio vinculado. O pacote distribui os alvos (`targets`) configurados no `app.json` para que o Zepp ofereça a versão correspondente aos dispositivos suportados. Não há necessidade de o usuário escolher manualmente um pacote de imagens, um tamanho de tela ou uma versão de som.

## Perfis disponíveis no código

| Aparelho | Alvo | Resolução | Sistema oficial | Áudio |
| --- | --- | --- | --- | --- |
| Amazfit Bip 5 | `320x380-bip5` | 320×380 | Zepp OS 2.1 | efeitos visuais/vibração sem API de áudio 3.0 |
| Amazfit Bip 5 Unity | `320x380-bip5unity` | 320×380 | Zepp OS 3.0 | áudio quando disponível no hardware |
| Amazfit Bip 6 | `390x450-bip6` | 390×450 | Zepp OS 5.0 | áudio quando disponível no hardware |
| Amazfit Bip Max | `432x514-bipmax` | 432×514 | Zepp OS 5.0 | áudio quando disponível no hardware |

Na build de desenvolvimento, `zeus preview` requer seleção manual do dispositivo, mas isso é um procedimento do desenvolvedor, não do usuário final da loja.

## Atualização futura para novos modelos

Quando a linha Bip ganhar novos dispositivos, conferir `deviceSource`, versão do Zepp OS, APIs e resolução na documentação oficial da Zepp; criar/adaptar o alvo e sprites; validar o pacote no simulador ou equipamento; enviar atualização para revisão. O suporte a um modelo novo não é automático antes dessa etapa.

## Segurança e evolução

O identificador `29318764` e a chave `dinopocket.state.v1` são preservados. Para evitar risco de perder o Dino, instalar como atualização e não desinstalar a versão anterior. Fazer conferência da idade, espécie e geração após atualizar. Manter a versão que está sob revisão na loja inalterada.

## Publicação e validação

Este é um candidato **BETA**, com testes locais de lógica/recursos, ainda não compilado/validado em todos os modelos. A configuração de múltiplos alvos não dispensa a compilação Zeus nem os testes físicos e a revisão oficial da Zepp. O erro anterior de instalação por excesso de recursos justifica conferir tamanho do ZAB de cada alvo e limites do relógio antes do envio à loja.
