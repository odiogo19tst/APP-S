# Compilacao na nuvem — DinoPocket Retro v1.2

Para instalar e compilar, veja `LEIA-ME-v1.2.md`.

**Sempre reutilize o repositório `odiogo19tst/APP-S`.** O workflow existente extrai o arquivo `DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip` e disponibiliza o ZAB compilado. Antes de instalar a v1.2 no Bip 6, confirme que o GitHub Actions concluiu com sucesso.

- `npm test` = validacao de regras do jogo.
- `zeus build` = gera `.zab`.
- `zeus preview` = fluxo oficial Zepp para gerar QR Code de instalacao.
- A compilacao bem-sucedida nao equivale a teste no relogio fisico.
