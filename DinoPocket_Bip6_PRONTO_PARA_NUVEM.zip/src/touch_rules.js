// Gesto na tela LCD: tap = carinho; 700ms parado = abrir menu.
export function createHoldDetector(thresholdMs=700,maxTravelPx=26){
  let start=0,point=null,cancelled=false,held=false
  function coords(p){return {x:Number(p?.x)||0,y:Number(p?.y)||0}}
  return {
    down(p,now){point=coords(p);start=now;cancelled=false;held=false},
    move(p){
      if(!point||cancelled)return false
      const n=coords(p)
      if(Math.hypot(n.x-point.x,n.y-point.y)>maxTravelPx){cancelled=true;return false}
      return true
    },
    trigger(now){
      if(!point||cancelled)return null
      if(now-start>=thresholdMs){held=true;return 'hold'}
      return null
    },
    up(now){
      if(!point)return null
      const result=cancelled?null:(held||now-start>=thresholdMs?'hold':'tap')
      point=null;cancelled=false;held=false
      return result
    },
    cancel(){point=null;cancelled=true;held=false},
  }
}
