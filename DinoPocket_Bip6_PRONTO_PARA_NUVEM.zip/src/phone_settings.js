// Configuracoes separadas da vida do pet. Campos simples para Bluetooth (ASCII JSON).
export const PHONE_SETTINGS_KEY = 'dinopocket.settings.v1'
export const PHONE_REV_KEY = 'dinopocket.settings.rev.v1'
export const DEVICE_SETTINGS_KEY = 'dinopocket.config.v1'
export const PET_SAVE_KEY = 'dinopocket.state.v1' // NAO alterar esta chave.
export const DEFAULT_SETTINGS = Object.freeze({
  mode: 'classic', species: 'random', stages: 5,
  sounds: true, wrist: true, alerts: true
})
const MODES = ['classic', 'custom', 'free']
const SPECIES = ['random', 'rex', 'bronto', 'trike']
export function normalizeSettings(input) {
  let v = input
  if(typeof input === 'string') { try {v=JSON.parse(input)} catch(e){v=null} }
  if(!v || typeof v !== 'object' || Array.isArray(v)) v={}
  const mode = MODES.includes(v.mode) ? v.mode : DEFAULT_SETTINGS.mode
  return {
    mode,
    species: mode === 'classic' ? 'random' : (SPECIES.includes(v.species) ? v.species : 'random'),
    // cinco fases disponiveis nesta versao: ovo, bebe, pequeno, jovem e adulto.
    stages: 5,
    sounds: v.sounds === false ? false : true,
    wrist: v.wrist === false ? false : true,
    alerts: v.alerts === false ? false : true
  }
}
export function updateSettings(current, patch) {
  return normalizeSettings({...normalizeSettings(current), ...patch})
}
export function decodePacket(data, size) {
  try {
    if(typeof data === 'string') return JSON.parse(data)
    let bytes
    if(data instanceof ArrayBuffer) bytes=new Uint8Array(data)
    else if(ArrayBuffer.isView(data)) bytes=new Uint8Array(data.buffer,data.byteOffset,data.byteLength)
    else if(Array.isArray(data)) bytes=Uint8Array.from(data)
    else return null
    const length = size && size>0 ? Math.min(size,bytes.length) : bytes.length
    let content=''
    for(let i=0;i<length;i++) content+=String.fromCharCode(bytes[i])
    return JSON.parse(content)
  } catch(e) {return null}
}
export function encodePacket(message) {
  const json=JSON.stringify(message)
  // Codigo e valores de configuracao sao ASCII, evitando dependencias no Zepp.
  const bytes=new Uint8Array(json.length)
  for(let i=0;i<json.length;i++) {const c=json.charCodeAt(i);if(c>127) throw new Error('Packet requires ASCII');bytes[i]=c}
  return bytes
}
export function normalizeEnvelope(value) {
  if(!value || value.type!=='DINO_CONFIG') return null
  const revision=Number(value.revision)
  if(!Number.isSafeInteger(revision) || revision<0) return null
  return {type:'DINO_CONFIG',revision,config:normalizeSettings(value.config)}
}
export function makeEnvelope(config, revision) {
  return normalizeEnvelope({type:'DINO_CONFIG',revision:Math.max(0,Math.floor(Number(revision)||0)),config})
}
export function shouldAccept(currentRevision, receivedRevision) {
  return Number.isSafeInteger(receivedRevision) && receivedRevision>=0 && receivedRevision>=Math.max(0,Number(currentRevision)||0)
}
// A especie forçada só atua na transicao NATURAL para adulto.
// Nao regride idade, nao troca especie de adulto ja criado, nem altera geracao.
export function adjustNaturalEvolution(before, after, config) {
  if(!before || !after || !config) return after
  const p=normalizeSettings(config)
  const canChoose=p.mode!=='classic' && p.species!=='random'
  if(canChoose && before.stage<4 && after.stage>=4 && !after.dead) return {...after,species:p.species}
  return after
}
