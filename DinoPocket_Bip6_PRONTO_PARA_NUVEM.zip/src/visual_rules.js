// Regras visuais puras. Uma imagem animada = 8 quadros diferentes na pasta.
// Nao consultamos sensores na renderizacao e nao alteramos o progresso salvo.
export const POSES = Object.freeze([
  'idle','happy','sleep','hunger','sad','dirty','sick','eat','drink','study',
  'play','bath','poop','rps_pedra','rps_papel','rps_tesoura','evolve','touch',
  'wake','eat_carne','eat_vegetais','eat_massa','drink_agua','drink_suco','drink_leite'
])
export function characterStem(state){
  if(!state || state.dead) return 'ghost'
  if(state.stage===0) return 'egg'
  if(state.sick) return 'sick'
  if(state.stage===1) return 'baby'
  if(state.stage===2) return 'small'
  if(state.stage===3) return 'young'
  return ['rex','bronto','trike'].includes(state.species) ? state.species : 'trike'
}
export function restingPose(state){
  if(!state || state.dead || state.stage===0) return 'idle'
  if(state.awake===false) return 'sleep'
  if(state.sick) return 'sick'
  if(state.poop>0 || state.hygiene<40) return 'dirty'
  if(state.hunger<30 || (typeof state.thirst==='number' && state.thirst<26)) return 'hunger'
  if(state.energy<20) return 'sad'
  if(state.joy<35) return 'sad'
  if(state.joy>90) return 'happy'
  return 'idle'
}
export function actionPose(action,opponent){
  if(['carne','vegetais','massa'].includes(action)) return 'eat_'+action
  if(['agua','suco','leite'].includes(action)) return 'drink_'+action
  if(action==='brincar') return 'play'
  if(action==='estudar' || action==='educar') return 'study'
  if(action==='banho' || action==='limpar_coco') return 'bath'
  if(action==='dormir') return 'sleep'
  if(action==='acordar') return 'wake'
  if(action==='remedio') return 'sick'
  if(action==='jogo' && ['pedra','papel','tesoura'].includes(opponent)) return 'rps_'+opponent
  if(action==='pulso'||action==='toque')return 'touch'
  return 'idle'
}
