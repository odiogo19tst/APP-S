/** DinoPocket Retro - engine determinística, sem dependência Zepp OS */
export const HOUR = 3600000
export const DAY = 24 * HOUR
export const MAX = 100
export const FOOD = ['carne', 'vegetais', 'massa']

function clamp(value, min = 0, max = 100) { return Math.min(max, Math.max(min, value)) }
function finite(value, fallback) { return typeof value === 'number' && Number.isFinite(value) ? value : fallback }
const round = (n) => Math.round(n * 10) / 10

export function newGame(now = Date.now()) {
  return {
    schema: 1, bornAt: now, updatedAt: now, ageDays: 0,
    hunger: 82, joy: 78, hygiene: 90, energy: 85, health: 100,
    meals: { carne: 0, vegetais: 0, massa: 0 },
    sick: false, dead: false, poop: 0, awake: true,
    stage: 0, species: null, message: 'Um ovo misterioso apareceu!',
    generation: 1, lives: 0, lastPlayedAt: 0
  }
}

// Cronologia de 24h: ovo, bebê, filhote, jovem, adulto.
export function stageForAge(days) {
  return days < 1 ? 0 : days < 2 ? 1 : days < 3 ? 2 : days < 4 ? 3 : 4
}

export function determineSpecies(meals) {
  const meat = Number(meals.carne) || 0
  const veg = Number(meals.vegetais) || 0
  const pasta = Number(meals.massa) || 0
  if (meat > veg && meat > pasta) return 'rex'
  if (veg > meat && veg > pasta) return 'bronto'
  return 'trike'
}

export function revive(old, now = Date.now()) {
  const fresh = newGame(now)
  fresh.generation = (Number(old && old.generation) || 1) + 1
  fresh.lives = (Number(old && old.lives) || 0) + 1
  return fresh
}

export function tick(state, now = Date.now()) {
  if (!state || state.schema !== 1) return newGame(now)
  if (state.dead) return { ...state, updatedAt: now }
  // Relógio alterado ou timestamp inválido: nunca contar tempo negativo.
  let hours = clamp((now - finite(state.updatedAt, now)) / HOUR, 0, 24 * 90)
  // O ovo nao sofre abandono nas suas primeiras 24 horas de vida.
  if (state.stage === 0) {
    const hoursUntilHatch = Math.max(0, (state.bornAt + DAY - state.updatedAt) / HOUR)
    hours = Math.max(0, hours - hoursUntilHatch)
  }
  const days = Math.max(0, Math.floor((now - finite(state.bornAt, now)) / DAY))
  let s = { ...state, meals: { ...state.meals } }
  // Acumula necessidades proporcionalmente ao tempo real, sem execução em background.
  if (hours > 0) {
    s.hunger = round(clamp(s.hunger - 2.1 * hours))
    s.joy = round(clamp(s.joy - 1.15 * hours))
    s.hygiene = round(clamp(s.hygiene - 1.3 * hours))
    // A energia recupera parcialmente durante a noite simulada.
    s.energy = round(clamp(s.energy - 0.9 * hours))
    s.poop = clamp(s.poop + Math.floor(hours / 7), 0, 5)
    if (s.hunger < 18 || s.hygiene < 18 || s.energy < 12) {
      s.health = round(clamp(s.health - (hours * 1.25)))
      if (s.health < 40) s.sick = true
    }
    if (s.sick && hours > 12) s.health = round(clamp(s.health - (hours * 0.35)))
  }
  // Um ovo não adoece nem morre; os valores de cuidado começam após o nascimento.
  if (s.stage === 0 && days === 0) {
    s.health = 100
    s.hunger = Math.max(s.hunger, 70)
    s.joy = Math.max(s.joy, 70)
  }
  if (s.health <= 0 && days >= 1) {
    s.dead = true
    s.health = 0
    s.message = 'Seu Dino virou uma estrelinha...'
  }
  const before = s.stage
  s.ageDays = days
  s.stage = stageForAge(days)
  if (s.stage >= 4 && !s.species) s.species = determineSpecies(s.meals)
  if (!s.dead && s.stage !== before) {
    s.message = s.stage === 1 ? 'O ovo chocou! Um bebe Dino!' :
      s.stage === 4 ? 'Seu Dino virou um ' + speciesName(s.species) + '!' :
      'Seu Dino evoluiu! Dia ' + days
  }
  s.updatedAt = now
  return s
}

export function speciesName(species) {
  return species === 'rex' ? 'T-Rex' : species === 'bronto' ? 'Brontossauro' : 'Triceratopo'
}

export function spriteName(state) {
  if (state.dead) return 'ghost.png'
  if (state.stage === 0) return 'egg.png'
  if (state.sick) return 'sick.png'
  if (state.stage === 1) return 'baby.png'
  if (state.stage === 2) return 'small.png'
  if (state.stage === 3) return 'young.png'
  return (state.species || 'trike') + '.png'
}

export function describe(state) {
  if (state.dead) return 'Seu Dino descansou. Novo ovo?'
  if (state.stage === 0) return 'Um ovo! Volte amanha.'
  if (state.sick) return 'Seu Dino precisa de remedio!'
  if (state.hunger < 30) return 'Estou com fome!'
  if (state.hygiene < 28) return 'Preciso de banho!'
  if (state.energy < 25) return 'Hora de dormir...'
  if (state.joy < 35) return 'Vamos brincar?'
  return state.stage >= 4 ? 'Sou um ' + speciesName(state.species) + '!' : 'Estou crescendo!'
}

export function act(state, action, now = Date.now()) {
  const s = tick(state, now)
  if (s.dead || s.stage === 0) return s
  const t = { ...s, meals: { ...s.meals } }
  if (FOOD.indexOf(action) >= 0) {
    t.hunger = round(clamp(t.hunger + 19))
    t.joy = round(clamp(t.joy + 3))
    t.hygiene = round(clamp(t.hygiene - 4))
    t.meals[action] += 1
    t.message = action === 'carne' ? 'Nhac! Carne!' : action === 'vegetais' ? 'Hmmm! Frutinhas!' : 'Oba! Macarrao!'
  } else if (action === 'brincar') {
    t.joy = round(clamp(t.joy + 18))
    t.energy = round(clamp(t.energy - 12))
    t.hunger = round(clamp(t.hunger - 7))
    t.lastPlayedAt = now
    t.message = 'Que divertido!'
  } else if (action === 'banho') {
    t.hygiene = round(clamp(t.hygiene + 55))
    t.poop = 0
    t.message = 'Limpinho!'
  } else if (action === 'dormir') {
    t.energy = round(clamp(t.energy + 48))
    t.joy = round(clamp(t.joy + 3))
    t.message = 'Zzz... Boa noite!'
  } else if (action === 'remedio') {
    if (t.sick) {
      t.sick = false
      t.health = round(clamp(t.health + 32))
      t.message = 'Ja me sinto melhor!'
    } else {
      t.message = 'Nao preciso de remedio.'
    }
  }
  if (t.poop >= 3) t.hygiene = round(clamp(t.hygiene - 4))
  if (t.health > 0 && !t.sick && t.hunger >= 50 && t.hygiene >= 45) {
    t.health = round(clamp(t.health + 2))
  }
  // A especie adulta eh definitiva; novas refeicoes nao mudam a especie.
  return t
}
