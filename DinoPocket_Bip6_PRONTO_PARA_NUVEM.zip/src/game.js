/** DinoPocket Retro - engine determinística, sem dependência Zepp OS */
export const HOUR = 3600000
export const DAY = 24 * HOUR
export const MAX = 100
export const FOOD = ['carne', 'vegetais', 'massa']

function clamp(value, min = 0, max = 100) { return Math.min(max, Math.max(min, value)) }
function finite(value, fallback) { return typeof value === 'number' && Number.isFinite(value) ? value : fallback }
const round = (n) => Math.round(n * 1000) / 1000

export function newGame(now = Date.now()) {
  return {
    schema: 1, bornAt: now, updatedAt: now, ageDays: 0,
    hunger: 82, joy: 78, hygiene: 90, energy: 85, health: 100,
    thirst: 88, intelligence: 0, drinks: { agua:0, suco:0, leite:0 },
    studyCount: 0, poopProgress: 0, sleepingSince: 0, sleepUntil: 0,
    meals: { carne: 0, vegetais: 0, massa: 0 },
    sick: false, dead: false, poop: 0, awake: true,
    stage: 0, species: null, message: 'Um ovo misterioso apareceu!',
    generation: 1, lives: 0, lastPlayedAt: 0
  }
}

// Cronologia de 24h: ovo, bebê, filhote, jovem, adulto.
export function stageForAge(days) {
  return days < 1 ? 0 : days < 2 ? 1 : days < 3 ? 2 : days < 4 ? 3 : 4
}

export function determineSpecies(meals) {
  const meat = Number(meals.carne) || 0
  const veg = Number(meals.vegetais) || 0
  const pasta = Number(meals.massa) || 0
  if (meat > veg && meat > pasta) return 'rex'
  if (veg > meat && veg > pasta) return 'bronto'
  return 'trike'
}

export function revive(old, now = Date.now()) {
  const fresh = enhance(newGame(now))
  fresh.generation = (Number(old && old.generation) || 1) + 1
  fresh.lives = (Number(old && old.lives) || 0) + 1
  return fresh
}

export function tick(state, now = Date.now()) {
  if (!state || state.schema !== 1) return newGame(now)
  if (state.dead) return { ...state, updatedAt: now }
  // Relógio alterado ou timestamp inválido: nunca contar tempo negativo.
  let hours = clamp((now - finite(state.updatedAt, now)) / HOUR, 0, 24 * 90)
  // O ovo nao sofre abandono nas suas primeiras 24 horas de vida.
  if (state.stage === 0) {
    const hoursUntilHatch = Math.max(0, (state.bornAt + DAY - state.updatedAt) / HOUR)
    hours = Math.max(0, hours - hoursUntilHatch)
  }
  const days = Math.max(0, Math.floor((now - finite(state.bornAt, now)) / DAY))
  let s = enhance({ ...state, meals: { ...state.meals } })
  // Sono real: dura ate oito horas, recupera energia e permanece visivel
  // mesmo ao fechar o aplicativo. Horarios guardados no mesmo save schema=1.
  const sleeping = s.awake === false && s.stage > 0
  const wakeAt = sleeping ? (s.sleepUntil || (s.updatedAt + 8 * HOUR)) : 0
  const asleepHours = sleeping ? Math.max(0, Math.min(hours, (wakeAt - finite(s.updatedAt, now)) / HOUR)) : 0
  if (hours > 0) {
    s.hunger = round(clamp(s.hunger - 2.1 * hours))
    s.joy = round(clamp(s.joy - (sleeping ? 0.45 : 1.15) * hours))
    s.hygiene = round(clamp(s.hygiene - (1.3 + (s.poop ? 0.65 : 0)) * hours))
    s.energy = round(clamp(s.energy + 10 * asleepHours - 0.9 * (hours - asleepHours)))
    s.thirst = round(clamp(s.thirst - 1.8 * hours))
    // Acumulador fracionario: a limpeza continua funcionando com atualizacoes
    // curtas de 30 min (antes, floor(hours/7) perdia esse progresso).
    const needs = s.poopProgress + hours * 0.19
    const events = Math.floor(needs)
    s.poopProgress = Math.round((needs - events) * 100000) / 100000
    s.poop = clamp(s.poop + events, 0, 5)
    if (s.hunger < 18 || s.hygiene < 18 || s.energy < 12 || s.thirst < 12) {
      s.health = round(clamp(s.health - hours * 1.25))
      if (s.health < 40) s.sick = true
    }
    if (s.sick && hours > 12) s.health = round(clamp(s.health - hours * 0.35))
  }
  if (sleeping && (now >= wakeAt || s.energy >= 100)) {
    s.awake = true
    s.sleepingSince = 0
    s.sleepUntil = 0
    s.message = 'Bom dia! Descansei bem!'
  }
  // Um ovo não adoece nem morre; os valores de cuidado começam após o nascimento.
  if (s.stage === 0 && days === 0) {
    s.health = 100
    s.hunger = Math.max(s.hunger, 70)
    s.joy = Math.max(s.joy, 70)
  }
  if (s.health <= 0 && days >= 1) {
    s.dead = true
    s.health = 0
    s.message = 'Seu Dino virou uma estrelinha...'
  }
  const before = s.stage
  s.ageDays = days
  s.stage = stageForAge(days)
  if (s.stage >= 4 && !s.species) s.species = determineSpecies(s.meals)
  if (!s.dead && s.stage !== before) {
    s.message = s.stage === 1 ? 'O ovo chocou! Um bebe Dino!' :
      s.stage === 4 ? 'Seu Dino virou um ' + speciesName(s.species) + '!' :
      'Seu Dino evoluiu! Dia ' + days
  }
  s.updatedAt = now
  return s
}

export function speciesName(species) {
  return species === 'rex' ? 'T-Rex' : species === 'bronto' ? 'Brontossauro' : 'Triceratopo'
}

export function spriteName(state) {
  if (state.dead) return 'ghost.png'
  if (state.stage === 0) return 'egg.png'
  if (state.sick) return 'sick.png'
  if (state.stage === 1) return 'baby.png'
  if (state.stage === 2) return 'small.png'
  if (state.stage === 3) return 'young.png'
  return (state.species || 'trike') + '.png'
}

export function describe(state) {
  if (state.dead) return 'Seu Dino descansou. Novo ovo?'
  if (state.stage === 0) return 'Um ovo! Volte amanha.'
  if (state.awake === false) return 'Zzz... dormindo de verdade!'
  if (state.sick) return 'Seu Dino precisa de remedio!'
  if (state.poop > 0) return 'Ops! Fiz coco. Vamos limpar?'
  if (state.thirst < 28) return 'Estou com sede!'
  if (state.hunger < 30) return 'Estou com fome!'
  if (state.hygiene < 28) return 'Preciso de banho!'
  if (state.energy < 25) return 'Hora de dormir...'
  if (state.joy < 35) return 'Vamos brincar?'
  return state.stage >= 4 ? 'Sou um ' + speciesName(state.species) + '!' : 'Estou crescendo!'
}

export function act(state, action, now = Date.now()) {
  const s = tick(state, now)
  if (s.dead || s.stage === 0) return s
  const t = enhance({ ...s, meals: { ...s.meals } })
  if (FOOD.indexOf(action) >= 0) {
    t.hunger = round(clamp(t.hunger + 19))
    t.joy = round(clamp(t.joy + 3))
    t.hygiene = round(clamp(t.hygiene - 4))
    t.meals[action] += 1
    t.poopProgress = round(t.poopProgress + 0.40)
    if (t.poopProgress >= 1) { t.poop = clamp(t.poop + 1, 0, 5); t.poopProgress -= 1 }
    t.message = action === 'carne' ? 'Nhac! Carne!' : action === 'vegetais' ? 'Hmmm! Frutinhas!' : 'Oba! Macarrao!'
  } else if (['agua','suco','leite'].includes(action)) {
    t.thirst = round(clamp(t.thirst + (action === 'agua' ? 35 : 26)))
    t.energy = round(clamp(t.energy + (action === 'suco' ? 5 : 2)))
    t.joy = round(clamp(t.joy + (action === 'leite' ? 5 : 2)))
    t.drinks[action] += 1
    t.message = action === 'agua' ? 'Glup glup! Que agua gostosa!' :
      action === 'suco' ? 'Hummm! Suquinho gelado!' : 'Delicia! Leite fresquinho!'
  } else if (action === 'estudar') {
    t.intelligence = round(clamp(t.intelligence + 8))
    t.discipline = round(clamp(t.discipline + 6))
    t.energy = round(clamp(t.energy - 8))
    t.joy = round(clamp(t.joy + 2))
    t.studyCount += 1
    t.message = 'Aprendi uma coisa nova!'
  } else if (action === 'limpar_coco') {
    if(t.poop>0){
      t.poop = 0
      t.poopProgress = 0
      t.hygiene = round(clamp(t.hygiene + 22))
      t.message = 'Tudo limpinho, obrigado!'
    } else t.message = 'Nao tem coco para limpar!'

  } else if (action === 'brincar') {
    t.joy = round(clamp(t.joy + 18))
    t.energy = round(clamp(t.energy - 12))
    t.hunger = round(clamp(t.hunger - 7))
    t.lastPlayedAt = now
    t.message = 'Que divertido!'
  } else if (action === 'banho') {
    t.poopProgress = 0
    t.hygiene = round(clamp(t.hygiene + 55))
    t.poop = 0
    t.message = 'Limpinho!'
  } else if (action === 'dormir') {
    t.awake = false
    t.sleepingSince = now
    t.sleepUntil = now + 8 * HOUR
    t.energy = round(clamp(t.energy + 6))
    t.message = 'Zzz... Boa noite!'
  } else if (action === 'acordar') {
    t.awake = true
    t.sleepingSince = 0
    t.sleepUntil = 0
    t.message = 'Bom dia! Vamos brincar!'
  } else if (action === 'remedio') {
    if (t.sick) {
      t.sick = false
      t.health = round(clamp(t.health + 32))
      t.message = 'Ja me sinto melhor!'
    } else {
      t.message = 'Nao preciso de remedio.'
    }
  }
  if (t.poop >= 3) t.hygiene = round(clamp(t.hygiene - 4))
  if (t.health > 0 && !t.sick && t.hunger >= 50 && t.hygiene >= 45) {
    t.health = round(clamp(t.health + 2))
  }
  // A especie adulta eh definitiva; novas refeicoes nao mudam a especie.
  return t
}

// Extensoes v1.2 - todas as chaves originais sao preservadas.
// O save permanece em dinopocket.state.v1 e schema=1 para atualizar sem apagar o Dino.
export function enhance(saved) {
  const state = saved && saved.schema === 1 ? saved : newGame()
  return {
    ...state,
    pausedAt: finite(state.pausedAt, 0),
    thirst: clamp(finite(state.thirst, 88)),
    intelligence: clamp(finite(state.intelligence, 0)),
    drinks: { agua: Math.max(0, finite(state.drinks?.agua, 0)),
      suco: Math.max(0, finite(state.drinks?.suco, 0)),
      leite: Math.max(0, finite(state.drinks?.leite, 0)) },
    studyCount: Math.max(0, finite(state.studyCount, 0)),
    poopProgress: clamp(finite(state.poopProgress, 0),0,0.99999),
    sleepingSince: Math.max(0,finite(state.sleepingSince, 0)),
    sleepUntil: Math.max(0,finite(state.sleepUntil, 0)),
    discipline: clamp(finite(state.discipline, 65)),
    temperature: finite(state.temperature, 24),
    gamesPlayed: Math.max(0, finite(state.gamesPlayed, 0)),
    gamesWon: Math.max(0, finite(state.gamesWon, 0)),
    lastCallAt: finite(state.lastCallAt, 0),
    lastGameAt: finite(state.lastGameAt, 0),
    theme: state.theme === 'classico' ? 'classico' : 'verde',
    wristPlays: Math.max(0, finite(state.wristPlays, 0)),
    eggShakes: Math.max(0, finite(state.eggShakes, 0)),
    careCount: Math.max(0, finite(state.careCount, 0)),
    temperament: typeof state.temperament === 'string' ? state.temperament : 'curioso'
  }
}

export function isPaused(state) { return !!(state && state.pausedAt > 0) }

// No modo pausa nenhuma necessidade ou fase progride. Ao voltar, deslocamos
// ambos os marcos para frente, sem aplicar tempo retroativo de abandono.
export function setPause(state, pause, now = Date.now()) {
  const s = enhance(state)
  if (pause && !isPaused(s)) return {...tick(s,now), pausedAt:now, message:'Dino em pausa. Ate logo!'}
  if (!pause && isPaused(s)) {
    const elapsed=Math.max(0,now-s.pausedAt)
    return {...s, pausedAt:0, bornAt:s.bornAt+elapsed,
      updatedAt:now, sleepUntil:s.sleepUntil>0?s.sleepUntil+elapsed:0,
      sleepingSince:s.sleepingSince>0?s.sleepingSince+elapsed:0, message:'Ola, voltei!'}
  }
  return s
}

export function advance(state, now = Date.now()) {
  const s=enhance(state)
  return isPaused(s) ? s : tick(s,now)
}

export function needsAttention(state) {
  if (!state || state.dead || state.stage === 0 || isPaused(state)) return null
  if (state.awake===false) return null
  if (state.sick) return 'DOENCA'
  if (state.hunger < 30) return 'FOME'
  if (state.thirst < 25) return 'SEDE'
  if (state.hygiene < 35 || state.poop >= 3) return 'SUJEIRA'
  if (state.energy < 22) return 'SONO'
  if (state.joy < 25) return 'TRISTEZA'
  return null
}

export function giveDiscipline(state, now = Date.now()) {
  const s=advance(state,now)
  if(s.stage===0 || s.dead || isPaused(s)) return s
  return {...s,discipline:clamp(s.discipline+14),joy:clamp(s.joy-4),
    careCount:s.careCount+1,
    message:'Aprendi a me comportar!'}
}

export function setTemperature(state, delta, now = Date.now()) {
  const s=advance(state,now)
  if(s.stage===0 || s.dead || isPaused(s)) return s
  const value=clamp(s.temperature+(delta>0?1:-1),18,32)
  return {...s,temperature:value,joy:clamp(s.joy+(value>=21 && value<=27?2:-3)),
    message:value+' C - temperatura ajustada.'}
}

const CHOICES=['pedra','papel','tesoura']
export function playRps(state, choice, now = Date.now(), opponent = Math.floor(Math.random()*3)) {
  const s=advance(state,now)
  if(s.dead || s.stage===0 || isPaused(s)) return {state:s,result:'indisponivel'}
  if(!CHOICES.includes(choice)) return {state:s,result:'invalido'}
  const index=Math.min(2,Math.max(0,Math.floor(opponent)))
  const p=CHOICES.indexOf(choice)
  const result=p===index?'empate':(p-index+3)%3===1?'ganhou':'perdeu'
  const score=result==='ganhou'?14:result==='empate'?6:3
  const next={...s,joy:clamp(s.joy+score),energy:clamp(s.energy-5),
    hunger:clamp(s.hunger-3),gamesPlayed:s.gamesPlayed+1,
    gamesWon:s.gamesWon+(result==='ganhou'?1:0),lastGameAt:now,
    message:'Dino: '+CHOICES[index]+' | '+(result==='ganhou'?'Vitoria!':result==='empate'?'Empate!':'Perdeu!')}
  return {state:next,result,opponent:CHOICES[index]}
}

export function petAgeString(state) {
  if(!state) return 'DIA 0'
  return 'DIA '+Math.max(0,state.ageDays)+' | G'+(state.generation||1)
}


// Jeito proprio: o carater evolui conforme alegria, cuidados, disciplina e brincadeiras.
// Nao e IA externa: tudo e calculado localmente e guardado no save antigo.
export function personalityOf(state) {
  const s = enhance(state)
  if(s.dead) return 'saudoso'
  if(s.stage === 0) return 'misterioso'
  if(s.joy < 30 || s.hunger < 25) return 'manhoso'
  if(s.discipline < 40 && s.wristPlays + s.gamesPlayed >= 3) return 'travesso'
  if(s.wristPlays + s.gamesPlayed >= 4 && s.energy > 24) return 'brincalhao'
  if(s.discipline >= 85 && s.careCount >= 3) return 'tranquilo'
  return 'curioso'
}

export function personalityMessage(state) {
  const p=personalityOf(state)
  if(p === 'manhoso') return 'Pssiu! Quero carinho!'
  if(p === 'travesso') return 'Hehe! Me pega se puder!'
  if(p === 'brincalhao') return 'Oba! De novo, de novo!'
  if(p === 'tranquilo') return 'Adoro ficar com voce!'
  if(p === 'misterioso') return 'Toc toc... quem esta ai?'
  return 'O que vamos descobrir?'
}

// O gesto e opcional: jamais choca o ovo antes das 24h.
// O sensor funciona somente com a tela do aplicativo aberta.
export function wristInteraction(state, now = Date.now()) {
  const s=advance(state, now)
  if(s.dead || isPaused(s) || s.awake===false) return s
  if(s.stage === 0) {
    return {...s,eggShakes:s.eggShakes+1,
      message:s.eggShakes % 2 === 0 ? 'Toc toc... falta pouco!' : 'Ovo balancou! O que sera?'}
  }
  const base=personalityOf(s)
  const lines={
    curioso:'Que foi isso? Oba, brincadeira!',
    manhoso:'Ei! Quero um abraco!',
    travesso:'Ahaha! Nao me pega!',
    brincalhao:'Eba! Mais uma rodada!',
    tranquilo:'Que carinho divertido!'
  }
  return {...s,wristPlays:s.wristPlays+1,lastPlayedAt:now,
    joy:clamp(s.joy+11),energy:clamp(s.energy-4),hunger:clamp(s.hunger-2),
    message:lines[base] || 'Que divertido!'}
}

// Detector isolado: permite testar falsos positivos sem depender do relogio.
// 3 impactos de aceleracao dentro de 1,3s e intervalo minimo de 10s.
export function createShakeDetector(options={}) {
  const threshold=finite(options.threshold, 520) // cm/s², a calibrar no Bip 6
  const minGap=finite(options.minGap, 130)
  const windowMs=finite(options.windowMs, 1300)
  const cooldownMs=finite(options.cooldownMs, 10000)
  let previousMagnitude=null, lastPeak=-Infinity, firstPeak=-Infinity
  let peaks=0, lastTrigger=-Infinity
  return {
    feed(sample, now=Date.now()) {
      if(!sample || ![sample.x,sample.y,sample.z].every(v=>typeof v==='number' && Number.isFinite(v))) return false
      const mag=Math.sqrt(sample.x**2+sample.y**2+sample.z**2)
      const delta=previousMagnitude===null?0:Math.abs(mag-previousMagnitude)
      previousMagnitude=mag
      if(now-lastTrigger<cooldownMs) return false
      if(now-firstPeak>windowMs) {peaks=0;firstPeak=-Infinity}
      if(delta<threshold || now-lastPeak<minGap) return false
      if(peaks===0) firstPeak=now
      peaks++
      lastPeak=now
      if(peaks<3) return false
      peaks=0
      firstPeak=-Infinity
      lastTrigger=now
      return true
    },
    reset() { previousMagnitude=null;peaks=0;lastPeak=-Infinity;firstPeak=-Infinity }
  }
}

// Interacao por toque: nao acelera a evolucao nem alimenta o Dino.
// O intervalo evita ganhos infinitos por taps repetidos.
export function touchInteraction(state,now=Date.now()) {
  const s=advance(state,now)
  if(s.dead||isPaused(s))return s
  const last=finite(s.lastTouchAt,0)
  const ready=now-last>=4000
  if(s.stage===0) return {...s,lastTouchAt:now,
    message:'Toc toc! Tem alguem ai?'}
  const mode=personalityOf(s)
  const lines={
    curioso:'Oi! O que vamos fazer?',
    manhoso:'Ahhh... mais carinho!',
    travesso:'Hehe! Me faz cosquinha!',
    brincalhao:'Eba! Gosto de voce!',
    tranquilo:'Que carinho gostoso!'
  }
  return {...s,lastTouchAt:now,joy:clamp(s.joy+(ready?2:0)),
    message:lines[mode]||'Que carinho!'}
}
