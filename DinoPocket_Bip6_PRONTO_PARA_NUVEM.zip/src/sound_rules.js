// Audio cues for DinoPocket: pure mapping, independently testable.
export const FX = Object.freeze({
  egg:'egg', hatch:'hatch', evolve:'evolve', happy:'happy',
  feed:'feed', care:'care', alert:'alert', sick:'sick'
})
export function feedbackSettings(state) {
  return { sounds: state?.soundEnabled !== false, vibration: state?.vibrationEnabled !== false }
}
export function feedbackForAction(action) {
  if (action === 'carne' || action === 'vegetais' || action === 'massa') return FX.feed
  if (action === 'banho' || action === 'dormir' || action === 'remedio' || action === 'educar') return FX.care
  if (action === 'brincar' || action === 'jogo' || action === 'pulso') return FX.happy
  if (action === 'ovo') return FX.egg
  return null
}
export function entryCue(before, after) {
  if (!after || after.dead || after.pausedAt > 0) return null
  if (before && after.stage > before.stage) return after.stage === 1 ? FX.hatch : FX.evolve
  if (!after.stage) return null
  if (after.sick) return FX.sick
  if (after.hunger < 25 || after.hygiene < 25 || after.energy < 16) return FX.alert
  return null
}
export function isQuietHour(date) {
  const h=date.getHours()
  return h>=22 || h<8
}
export function shouldPlaySound(state, passive=false, date=new Date()) {
  return feedbackSettings(state).sounds && (!passive || !isQuietHour(date))
}

// Seleciona uma voz 8-bit com entonacao baseada em contexto e personalidade.
// O modo classico conserva rigorosamente os arquivos anteriores.
export function soundMode(state) {
  return state?.soundStyle === 'classico' ? 'classico' : 'expressivo'
}
export function expressiveCue(state, original, personality='curioso', iteration=0){
  if(soundMode(state)==='classico')return original
  if(original===FX.egg)return iteration%2?'voice_egg_b':'voice_egg_a'
  if(original===FX.hatch)return 'voice_birth'
  if(original===FX.evolve)return 'voice_evolve'
  if(original===FX.feed)return 'voice_nham'
  if(original===FX.sick)return 'voice_sick'
  if(original===FX.alert){
    if(state?.hunger<30)return 'voice_hungry'
    if(state?.energy<25)return 'voice_sleep'
    return 'voice_help'
  }
  if(original===FX.care)return iteration%2?'voice_calm':'voice_grunt'
  if(original===FX.happy){
    if(personality==='manhoso')return 'voice_need'
    if(personality==='travesso')return 'voice_mischief'
    if(personality==='tranquilo')return 'voice_calm'
    if(personality==='brincalhao')return iteration%2?'voice_giggle':'voice_happy'
    return iteration%2?'voice_curious':'voice_happy'
  }
  return original
}
