// Audio cues for DinoPocket: pure mapping, independently testable.
export const FX = Object.freeze({
  egg:'egg', hatch:'hatch', evolve:'evolve', happy:'happy',
  feed:'feed', care:'care', alert:'alert', sick:'sick'
})
export function feedbackSettings(state) {
  return { sounds: state?.soundEnabled !== false, vibration: state?.vibrationEnabled !== false }
}
export function feedbackForAction(action) {
  if (action === 'carne' || action === 'vegetais' || action === 'massa') return FX.feed
  if (action === 'banho' || action === 'dormir' || action === 'remedio' || action === 'educar') return FX.care
  if (action === 'brincar' || action === 'jogo' || action === 'pulso') return FX.happy
  if (action === 'ovo') return FX.egg
  return null
}
export function entryCue(before, after) {
  if (!after || after.dead || after.pausedAt > 0) return null
  if (before && after.stage > before.stage) return after.stage === 1 ? FX.hatch : FX.evolve
  if (!after.stage) return null
  if (after.sick) return FX.sick
  if (after.hunger < 25 || after.hygiene < 25 || after.energy < 16) return FX.alert
  return null
}
export function isQuietHour(date) {
  const h=date.getHours()
  return h>=22 || h<8
}
export function shouldPlaySound(state, passive=false, date=new Date()) {
  return feedbackSettings(state).sounds && (!passive || !isQuietHour(date))
}
