// Audio cues for DinoPocket: pure mapping, independently testable.
export const FX = Object.freeze({
  egg:'egg', hatch:'hatch', evolve:'evolve', happy:'happy',
  feed:'feed', care:'care', alert:'alert', sick:'sick',
  drink:'drink', study:'study', play:'play', sleep:'sleep',wake:'wake',
  poop:'poop', win:'win', lose:'lose', tie:'tie', touch:'touch'
})
export function feedbackSettings(state) {
  return { sounds: state?.soundEnabled !== false, vibration: state?.vibrationEnabled !== false }
}
export function feedbackForAction(action) {
  if (action === 'carne' || action === 'vegetais' || action === 'massa') return FX.feed
  if (['agua','suco','leite'].includes(action)) return FX.drink
  if (action === 'estudar') return FX.study
  if (action === 'limpar_coco') return FX.poop
  if (action === 'dormir') return FX.sleep
  if (action === 'acordar') return FX.wake
  if (action === 'banho' || action === 'remedio' || action === 'educar') return FX.care
  if (action === 'brincar' || action === 'jogo' || action === 'pulso') return FX.happy
  if (action === 'ovo') return FX.egg
  return null
}
export function entryCue(before, after) {
  if (!after || after.dead || after.pausedAt > 0) return null
  if (before && after.stage > before.stage) return after.stage === 1 ? FX.hatch : FX.evolve
  if (!after.stage) return null
  if (after.sick) return FX.sick
  if (after.hunger < 25 || after.hygiene < 25 || after.energy < 16) return FX.alert
  return null
}
export function isQuietHour(date) {
  const h=date.getHours()
  return h>=22 || h<8
}
export function shouldPlaySound(state, passive=false, date=new Date()) {
  return feedbackSettings(state).sounds && (!passive || !isQuietHour(date))
}

// Seleciona uma voz 8-bit com entonacao baseada em contexto e personalidade.
// O modo classico conserva rigorosamente os arquivos anteriores.
export function soundMode(state) {
  return state?.soundStyle === 'classico' ? 'classico' : 'expressivo'
}
export function expressiveCue(state,original,personality='curioso',iteration=0){
  if(soundMode(state)==='classico'){
    const fallback={drink:'care',study:'care',sleep:'care',wake:'hatch',
      poop:'care',win:'happy',lose:'alert',tie:'care',play:'happy',touch:'happy'}
    return fallback[original]||original
  }
  const expressive={
    egg:'soft_egg',hatch:'soft_hatch',evolve:'soft_evolve',
    happy:'soft_happy',feed:'soft_nibble',care:'soft_bubble',
    alert:'soft_alert',sick:'soft_sick',drink:'soft_drink',
    study:'soft_study',play:'soft_play',sleep:'soft_sleep',
    wake:'soft_wake',poop:'soft_poop',win:'soft_win',
    lose:'soft_lose',tie:'soft_tie',touch:'soft_touch'
  }
  if(original===FX.egg) return iteration%2?'soft_egg_b':'soft_egg'
  if(original===FX.alert && state?.hunger<30) return 'soft_hungry'
  if(original===FX.alert && state?.energy<25) return 'soft_sleep'
  // pequenas variacoes por comportamento, sempre com som baixo e suave
  if(original===FX.happy && personality==='manhoso' && iteration%2) return 'soft_touch'
  if(original===FX.happy && personality==='travesso') return 'soft_mischief'
  if(original===FX.happy && personality==='brincalhao' && iteration%2) return 'soft_giggle'
  return expressive[original]||'soft_touch'
}
