import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')

test('draw arms before face and never repaint arms above eyes and muzzle', () => {
  const generator = readFileSync(path.join(root, 'scripts/make_v15_sprites.py'), 'utf8')
  const arms = generator.indexOf('# Arms are drawn behind the head')
  const face = generator.indexOf('# large expressive face')
  const endFace = generator.indexOf('# coat markings make each breed distinct')
  assert.ok(arms >= 0 && arms < face && face < endFace, 'arms must be drawn behind facial details')
  assert.ok(!generator.slice(face,endFace).includes('poly([(46,33)'), 'legacy arm occluding head is still present')
  assert.ok(generator.includes('for tick in range(4)'), 'optimized animations must use four frames')
})

test('all five life stages still exist, face animations cover each dinosaur variety', () => {
  const stages=['egg','baby','small','young','rex','bronto','trike','sick','ghost']
  const poses=['idle','happy','sleep','hunger','sad','dirty','sick','eat','drink','study','play','bath','poop',
    'rps_pedra','rps_papel','rps_tesoura','evolve','touch','wake','eat_carne','eat_vegetais','eat_massa','drink_agua','drink_suco','drink_leite']
  for(const stage of stages){
    for(const pose of poses){
      for(let i=0;i<4;i++){
        const bytes=readFileSync(path.join(root,'assets','390x450-bip6','anim',stage,pose,`frame_${i}.png`))
        assert.equal(bytes.toString('hex',0,8),'89504e470d0a1a0a')
        assert.equal(bytes.readUInt32BE(16),288)
        assert.equal(bytes.readUInt32BE(20),164)
      }
    }
  }
})
