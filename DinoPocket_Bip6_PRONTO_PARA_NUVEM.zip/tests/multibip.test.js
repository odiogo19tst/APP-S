import test from 'node:test'
import assert from 'node:assert/strict'
import { readFileSync, existsSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
const base = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..')
const app = JSON.parse(readFileSync(path.join(base,'app.json'), 'utf8'))
const targets = [
  ['320x380-bip5',[8454400,8454401],320,380,false],
  ['320x380-bip5unity',[8782081,8782088,8782089],320,380,true],
  ['390x450-bip6',[9765120,9765121,10158337],390,450,true],
  ['432x514-bipmax',[11206915],432,514,true]
]
test('Bip 5/5 Unity/6/Max variants use real deviceSource and matching assets',()=>{
  assert.equal(app.app.appId,29318764)
  assert.equal(app.runtime.apiVersion.minVersion,'2.1')
  assert.equal(app.app.version.code,10)
  assert.ok(app.permissions.includes('data:os.device.info'))
  for(const [target,ids,width,height,hasAudio] of targets){
    const conf=app.targets[target]
    assert.deepEqual(conf.platforms.map(p=>p.deviceSource),ids)
    assert.equal(conf.designWidth,width)
    const assets=path.join(base,'assets',target)
    assert.ok(existsSync(path.join(assets,'icon.png')))
    assert.equal(existsSync(path.join(assets,'sfx','feed.mp3')),hasAudio)
    for(const stage of ['baby','young','rex','bronto','trike']){
      for(const pose of ['idle','sleep','eat_carne','drink_agua','study','rps_pedra']){
        for(let i=0;i<4;i++){
          const filename=path.join(assets,'anim',stage,pose,`frame_${i}.png`)
          const bytes=readFileSync(filename)
          assert.equal(bytes.toString('hex',0,8),'89504e470d0a1a0a')
          assert.ok(bytes.readUInt32BE(16)<width && bytes.readUInt32BE(20)<height)
        }
      }
    }
  }
})
test('legacy Bip 5 page is responsive and does not import Zepp OS 3.0-only audio API',()=>{
  const src=readFileSync(path.join(base,'page','bip5','index.js'),'utf8')
  assert.ok(src.includes("from '@zos/device'"))
  assert.ok(src.includes('scaleX'))
  assert.ok(!src.includes("from '@zos/media'"))
  assert.ok(app.targets['320x380-bip5'].module.page.pages.includes('page/bip5/index'))
})
test('shared game state remains unchanged for upgrades on the same watch',()=>{
  const src=readFileSync(path.join(base,'page','index.js'),'utf8')
  assert.ok(src.includes("const KEY = 'dinopocket.state.v1'"))
  assert.ok(src.includes('drawHabitat()'))
  assert.equal(app.targets['390x450-bip6'].module.page.pages[0],'page/index')
})
