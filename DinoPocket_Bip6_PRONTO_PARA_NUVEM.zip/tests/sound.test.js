import test from 'node:test'
import assert from 'node:assert/strict'
import { feedbackSettings, feedbackForAction, entryCue, isQuietHour, shouldPlaySound } from '../src/sound_rules.js'
const pet={stage:1,dead:false,pausedAt:0,hunger:90,hygiene:95,energy:90,sick:false}
test('som e vibracao habilitados por padrao, com possibilidade de mutar',()=>{
  assert.deepEqual(feedbackSettings(pet),{sounds:true,vibration:true})
  assert.deepEqual(feedbackSettings({...pet,soundEnabled:false,vibrationEnabled:false}),{sounds:false,vibration:false})
})
test('efeito certo para sacudir pulso e comer',()=>{
  assert.equal(feedbackForAction('pulso'),'happy')
  assert.equal(feedbackForAction('carne'),'feed')
  assert.equal(feedbackForAction('banho'),'care')
})
test('som de nascimento somente na mudanca de fase',()=>{
  assert.equal(entryCue({...pet,stage:0},{...pet,stage:1}),'hatch')
  assert.equal(entryCue({...pet,stage:1},{...pet,stage:1}),null)
  assert.equal(entryCue({...pet,stage:3},{...pet,stage:4}),'evolve')
})
test('alerta para doenca ou necessidade critica',()=>{
  assert.equal(entryCue(pet,{...pet,sick:true}),'sick')
  assert.equal(entryCue(pet,{...pet,hunger:10}),'alert')
  assert.equal(entryCue(pet,{...pet,pausedAt:Date.now(),hunger:10}),null)
})
test('intervalo noturno restringe somente sons passivos',()=>{
  const t=new Date(2026,9,10,23,15)
  assert.equal(isQuietHour(t),true)
  assert.equal(shouldPlaySound(pet,true,t),false)
  assert.equal(shouldPlaySound(pet,false,t),true)
})
