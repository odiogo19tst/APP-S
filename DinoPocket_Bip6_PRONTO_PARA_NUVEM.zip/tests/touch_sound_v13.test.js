import test from 'node:test'
import assert from 'node:assert/strict'
import {createHoldDetector} from '../src/touch_rules.js'
import {newGame,enhance,touchInteraction,DAY} from '../src/game.js'
import {FX,soundMode,expressiveCue} from '../src/sound_rules.js'
const t=Date.UTC(2026,9,10,10)
test('toque rapido faz carinho, toque de 700ms abre menu',()=>{
 const d=createHoldDetector(700,26); d.down({x:100,y:100},t)
 assert.equal(d.up(t+170),'tap');d.down({x:100,y:100},t)
 assert.equal(d.trigger(t+710),'hold');assert.equal(d.up(t+810),'hold')
})
test('arrastar nao ativa o toque longo',()=>{
 const d=createHoldDetector(700,26);d.down({x:50,y:40},t)
 assert.equal(d.move({x:90,y:40}),false);assert.equal(d.trigger(t+1000),null)
 assert.equal(d.up(t+1000),null)
})
test('soltar depois de 700ms abre menu mesmo se timer atrasar',()=>{
 const d=createHoldDetector(700,26);d.down({x:50,y:40},t)
 assert.equal(d.up(t+780),'hold')
})
test('gesto cancelado nao dispara carinho',()=>{
 const d=createHoldDetector();d.down({x:1,y:1},t);d.cancel()
 assert.equal(d.up(t+100),null)
})
test('carinho do ovo preserva geracao e nascimento',()=>{
 const s=enhance(newGame(t)),r=touchInteraction(s,t+10000)
 assert.equal(r.stage,0);assert.equal(r.bornAt,s.bornAt)
 assert.equal(r.generation,s.generation)
})
test('carinho aumenta felicidade com protecao contra repeticao',()=>{
 const s=enhance({...newGame(t),bornAt:t-DAY,updatedAt:t,stage:1,ageDays:1,joy:20})
 const a=touchInteraction(s,t),b=touchInteraction(a,t+250)
 assert.ok(a.joy>s.joy);assert.equal(b.joy,a.joy)
})
test('voz classica mantém efeito anterior',()=>{
 assert.equal(expressiveCue({soundStyle:'classico'},FX.happy,'travesso',4),FX.happy)
})
test('voz expressiva varia por personalidade e estado',()=>{
 assert.equal(soundMode({}),'expressivo')
 assert.equal(expressiveCue({},FX.happy,'travesso',1),'soft_mischief')
 assert.equal(expressiveCue({},FX.happy,'brincalhao',1),'soft_giggle')
 assert.equal(expressiveCue({hunger:17},FX.alert),'soft_hungry')
})
test('voz de ovo alterna expressoes',()=>{
 assert.notEqual(expressiveCue({},FX.egg,'misterioso',0),expressiveCue({},FX.egg,'misterioso',1))
})
