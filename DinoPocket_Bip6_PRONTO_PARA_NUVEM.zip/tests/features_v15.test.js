import test from 'node:test'
import assert from 'node:assert/strict'
import { existsSync, readFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import path from 'node:path'
import {newGame,tick,act,enhance,playRps,DAY,HOUR,stageForAge,needsAttention} from '../src/game.js'
import {characterStem,restingPose,actionPose,POSES} from '../src/visual_rules.js'
import {FX,expressiveCue,feedbackForAction} from '../src/sound_rules.js'
import {PET_SAVE_KEY} from '../src/phone_settings.js'

const t=Date.UTC(2026,9,8,12,0,0)
const born=()=>enhance(tick(newGame(t),t+DAY))
const root=path.join(path.dirname(fileURLToPath(import.meta.url)),'..')

test('1.5 preserva schema=1, ID 29318764, save e cinco etapas',()=>{
  const app=JSON.parse(readFileSync(path.join(root,'app.json')))
  assert.equal(app.app.appId,29318764)
  assert.equal(app.app.version.name,'1.5.2')
  assert.equal(PET_SAVE_KEY,'dinopocket.state.v1')
  assert.deepEqual([0,1,2,3,4].map(x=>stageForAge(x)),[0,1,2,3,4])
})
test('migracao do save antigo sem perder animal, idade e comida',()=>{
  const antigo={...born(),schema:1,ageDays:2,generation:7,meals:{carne:5,vegetais:2,massa:0},stage:2}
  delete antigo.thirst;delete antigo.drinks;delete antigo.poopProgress
  const migrated=enhance(JSON.parse(JSON.stringify(antigo)))
  assert.equal(migrated.generation,7)
  assert.equal(migrated.stage,2)
  assert.deepEqual(migrated.meals,antigo.meals)
  assert.equal(migrated.thirst,88)
  assert.equal(migrated.drinks.agua,0)
})
test('sono real permanece após reabrir e recupera energia gradualmente',()=>{
  let pet=born();pet.energy=26
  pet=act(pet,'dormir',t+DAY)
  assert.equal(pet.awake,false)
  assert.equal(restingPose(pet),'sleep')
  const after2h=tick(JSON.parse(JSON.stringify(pet)),t+DAY+2*HOUR)
  assert.equal(after2h.awake,false)
  assert.ok(after2h.energy>pet.energy)
  assert.equal(restingPose(after2h),'sleep')
  const after9h=tick(after2h,t+DAY+9*HOUR)
  assert.equal(after9h.awake,true)
  assert.equal(after9h.sleepUntil,0)
})
test('acordar manualmente interrompe o sono sem perder a evolução',()=>{
  let pet=act(born(),'dormir',t+DAY)
  pet=act(pet,'acordar',t+DAY+HOUR)
  assert.equal(pet.awake,true)
  assert.equal(pet.stage,1)
})
test('água, suco e leite têm contadores sem interferir nas espécies',()=>{
  let pet=born();pet.thirst=25
  pet=act(pet,'agua',t+DAY)
  pet=act(pet,'suco',t+DAY)
  pet=act(pet,'leite',t+DAY)
  assert.equal(pet.drinks.agua,1)
  assert.equal(pet.drinks.suco,1)
  assert.equal(pet.drinks.leite,1)
  assert.ok(pet.thirst>25)
  assert.deepEqual(pet.meals,{carne:0,vegetais:0,massa:0})
})
test('estudar aumenta inteligencia e usa animação de livro',()=>{
  const pet=born(),next=act(pet,'estudar',t+DAY)
  assert.equal(next.studyCount,1)
  assert.ok(next.intelligence>pet.intelligence)
  assert.equal(actionPose('estudar'),'study')
})
test('poop aparece gradualmente mesmo entre atualizações curtas e limpeza retira',()=>{
  let pet=born()
  pet.poopProgress=.93
  pet=tick(pet,t+DAY+30*60*1000)
  assert.ok(pet.poop>0)
  assert.equal(restingPose(pet),'dirty')
  pet=act(pet,'limpar_coco',t+DAY+30*60*1000)
  assert.equal(pet.poop,0)
  assert.equal(pet.poopProgress,0)
})
test('visual de sujeira e expressões refletem saúde e humor',()=>{
  let pet=born()
  assert.equal(restingPose({...pet,hygiene:32}),'dirty')
  assert.equal(restingPose({...pet,joy:15}),'sad')
  assert.equal(restingPose({...pet,sick:true}),'sick')
  assert.equal(restingPose({...pet,hunger:12}),'hunger')
})
test('pedra papel tesoura tem gestos diferentes em sprites',()=>{
  for(const key of ['pedra','papel','tesoura']){
    assert.equal(actionPose('jogo',key),'rps_'+key)
    assert.equal(POSES.includes(actionPose('jogo',key)),true)
  }
  assert.equal(playRps(born(),'papel',t+DAY,0).result,'ganhou')
})
test('comidas e bebidas possuem sprites especificos por item',()=>{
  for(const key of ['carne','vegetais','massa'])assert.equal(actionPose(key),'eat_'+key)
  for(const key of ['agua','suco','leite'])assert.equal(actionPose(key),'drink_'+key)
})
test('900 quadros reais (9 fases, 25 ações, 4 frames) existem e têm PNG válido',()=>{
  const stems=['egg','baby','small','young','rex','bronto','trike','sick','ghost']
  assert.equal(POSES.length,25)
  for(const s of stems) for(const pose of POSES) for(let i=0;i<4;i++){
    const f=path.join(root,'assets/390x450-bip6/anim',s,pose,`frame_${i}.png`)
    assert.equal(existsSync(f),true, f)
    const png=readFileSync(f)
    assert.equal(png.toString('hex',0,8),'89504e470d0a1a0a')
    assert.equal(png.readUInt32BE(16),288)
    assert.equal(png.readUInt32BE(20),164)
  }
})
test('22 arquivos novos de áudio existem e mapeiam ações',()=>{
  const cueNames=['soft_egg','soft_egg_b','soft_hatch','soft_evolve','soft_happy','soft_mischief','soft_giggle','soft_hungry','soft_nibble','soft_drink','soft_bubble','soft_alert','soft_sick','soft_study','soft_play','soft_sleep','soft_wake','soft_win','soft_lose','soft_tie','soft_touch','soft_poop']
  for(const cue of cueNames)assert.equal(existsSync(path.join(root,'assets/390x450-bip6/sfx',cue+'.mp3')),true,cue)
  assert.equal(feedbackForAction('agua'),FX.drink)
  assert.equal(feedbackForAction('dormir'),FX.sleep)
  assert.equal(feedbackForAction('acordar'),FX.wake)
  assert.equal(feedbackForAction('estudar'),FX.study)
  assert.equal(expressiveCue({},FX.win),'soft_win')
})
test('morphs personalizados continuam corretos por fase',()=>{
  assert.equal(characterStem({...born(),stage:1}),'baby')
  assert.equal(characterStem({...born(),stage:4,species:'rex'}),'rex')
  assert.equal(characterStem({...born(),stage:4,species:'bronto'}),'bronto')
  assert.equal(characterStem({...born(),dead:true}),'ghost')
})

test('24h de ticks curtos nao perde progresso nem abandona necessidades',()=>{
  let s=born(),start=t+DAY
  const h0=s.hunger
  for(let minute=1;minute<=24*60;minute++)s=tick(s,start+minute*60000)
  assert.ok(s.hunger<h0-40, 'deve sofrer fome gradual a cada minuto')
  assert.ok(s.poop>0,'coco deve aparecer sem fechar o app')
})
test('limpar coco sem sujeira nao aumenta higiene artificialmente',()=>{
  const s=born(), next=act(s,'limpar_coco',t+DAY)
  assert.equal(next.hygiene,s.hygiene)
})
