import test from 'node:test'
import assert from 'node:assert/strict'
import {
 DEFAULT_SETTINGS, normalizeSettings, updateSettings,
 encodePacket, decodePacket, makeEnvelope, normalizeEnvelope,
 shouldAccept, adjustNaturalEvolution, PET_SAVE_KEY,DEVICE_SETTINGS_KEY
} from '../src/phone_settings.js'
import { newGame, enhance } from '../src/game.js'

test('defaults: classic / random / 5 / enabled',()=>{
 assert.deepEqual(normalizeSettings(),DEFAULT_SETTINGS)
})
test('invalid settings do not overwrite defaults',()=>{
 assert.deepEqual(normalizeSettings('{'),DEFAULT_SETTINGS)
 assert.equal(normalizeSettings({mode:'wrong',species:'bad',sounds:'false'}).sounds,true)
})
test('classic always treats species as random',()=>{
 assert.equal(normalizeSettings({mode:'classic',species:'rex'}).species,'random')
})
test('mode non-classic can choose adult species',()=>{
 const v=updateSettings(DEFAULT_SETTINGS,{mode:'free',species:'bronto'})
 assert.equal(v.species,'bronto');assert.equal(v.mode,'free')
})
test('only five graphic stages in release 1.4',()=>{
 assert.equal(normalizeSettings({stages:100}).stages,5)
})
test('feature toggle values false persist, other types treated as true',()=>{
 const x=normalizeSettings({sounds:false,wrist:false,alerts:false})
 assert.equal(x.sounds,false);assert.equal(x.wrist,false);assert.equal(x.alerts,false)
})
test('wire packet roundtrip',()=>{
 const encoded=encodePacket(makeEnvelope({sounds:false},42))
 assert.deepEqual(normalizeEnvelope(decodePacket(encoded.buffer)),makeEnvelope({sounds:false},42))
})
test('wire packet accepts byte offset and length',()=>{
 const packet=encodePacket({type:'GET_DINO_CONFIG'})
 const expanded=new Uint8Array(packet.length+4);expanded.set(packet,2)
 assert.deepEqual(decodePacket(expanded.subarray(2,2+packet.length)),{type:'GET_DINO_CONFIG'})
})
test('invalid and corrupt packet cannot affect config',()=>{
 assert.equal(decodePacket('oops'),null);assert.equal(normalizeEnvelope({type:'wrong'}),null)
})
test('revision older rejected, same and newer accepted',()=>{
 assert.equal(shouldAccept(17,16),false)
 assert.equal(shouldAccept(17,17),true)
 assert.equal(shouldAccept(17,18),true)
})
test('natural evolution respects classic path',()=>{
 const before={stage:3,species:null,generation:2}
 const after={stage:4,species:'trike',generation:2}
 assert.equal(adjustNaturalEvolution(before,after,DEFAULT_SETTINGS),after)
})
test('free species selection acts only at transition to adulthood',()=>{
 const before={stage:3,generation:1}
 const after={stage:4,generation:1,species:'rex'}
 const cfg={mode:'free',species:'bronto'}
 assert.deepEqual(adjustNaturalEvolution(before,after,cfg),{...after,species:'bronto'})
 assert.equal(adjustNaturalEvolution(after,after,cfg),after)
})
test('free species cannot revive or rewrite dead pet',()=>{
 const before={stage:3};const after={stage:4,dead:true,species:'rex'}
 assert.equal(adjustNaturalEvolution(before,after,{mode:'free',species:'bronto'}),after)
})
test('progress key unchanged from version 1.3',()=>{
 assert.equal(PET_SAVE_KEY,'dinopocket.state.v1')
 assert.notEqual(PET_SAVE_KEY,DEVICE_SETTINGS_KEY)
 const original=newGame(1500000000000)
 assert.equal(enhance(original).schema,1)
})
