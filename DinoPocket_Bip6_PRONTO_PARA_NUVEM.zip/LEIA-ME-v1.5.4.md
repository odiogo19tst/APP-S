# DinoPocket Retro 1.5.4 — MultiBip (beta)

## Alvos previstos

- Amazfit Bip 5: Zepp OS 2.1, 320x380; interface e sprites adaptados. Feedback sonoro substituído por vibração devido à ausência da API `@zos/media` (introduzida no API_LEVEL 3.0).
- Amazfit Bip 5 Unity: Zepp OS 3.0, 320x380; gráficos adaptados, áudio tentado quando suportado pelo hardware.
- Amazfit Bip 6: 390x450; gráficos originais da v1.5.3 e novo cenário discreto de dia/noite.
- Amazfit Bip Max: Zepp OS 5.0, 432x514; gráficos e layout adaptados.

Os `deviceSource` foram extraídos da lista oficial da Zepp. A compatibilidade real ainda depende da compilação pelo Zeus, da instalação e dos testes físicos em cada modelo.

## Compatibilidade e proteção do pet

- `appId` preservado: `29318764`.
- Chave de salvamento preservada: `dinopocket.state.v1`.
- 5 etapas de evolução preservadas: ovo, bebê, filhote, jovem, adulto; espécie adulta conforme alimentação.
- 25 tipos de expressão/ação e 4 quadros por sequência.
- Sem modificação do jogo já enviado à revisão da Zepp. Esta versão é um candidato local para testes.

## GitHub Actions

1. Enviar `DinoPocket_Bip6_PRONTO_PARA_NUVEM.zip` à raiz de `odiogo19tst/APP-S`, substituindo o anterior.
2. Aguardar `.github/workflows/compilar-dinopocket.yml`.
3. Validar o artefato `.zab`.
4. Abrir no Codespaces com `git pull --ff-only`, extrair o ZIP numa pasta nova e executar `zeus preview` selecionando um modelo de cada vez.
5. Não desinstalar a versão antiga ao atualizar o Bip 6: queremos preservar o salvamento. Sempre verificar a idade, a geração e a espécie após a atualização.

## Nota de publicação

Este projeto ainda **não foi compilado pelo Zeus nem validado em Bip 5, Bip 5 Unity ou Bip Max**. O Zepp Developer Console precisa aceitar os dispositivos e uma atualização futura precisa ser revisada para distribuição na loja. Não habilite todos os dispositivos em produção antes dos testes.
